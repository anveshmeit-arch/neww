package com.scb.clm.services.admin.v1.process;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.JobScheduleEntity;
import com.scb.clm.core.controller.BaseController;
import com.scb.clm.core.service.ScheduleServiceAbstract;
import com.scb.clm.core.service.ScheduleServiceInterface;


@Service
@Configurable
public class HouseKeepingProcess extends ScheduleServiceAbstract implements ScheduleServiceInterface
{
    
    @Autowired
    BaseController baseController;


    @Override
    public ResponseEntity<Object> executeService(JobScheduleEntity jobScheduleEntity, Map<String, String> header) 
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "executeService", LogType.APPLICATION.name());
        try
        {
            log.println("HouseKeeping Execution Started - Process ");
            return baseController.processRequest("", header, jobScheduleEntity.getApiVersion(), jobScheduleEntity.getPathIdentifier(),null);
        }
        catch(Exception e)
        {
            return null;
        }        
    }

}
