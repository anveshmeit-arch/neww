package com.scb.clm.services.companysearch.chekk.v1.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.scb.clm.services.companysearch.chekk.v1.model.ChekkRequestsHKEntity;

@Repository
public interface ChekkRequestsHKRepository extends JpaRepository<ChekkRequestsHKEntity, String> { 

    @Override
    public <S extends ChekkRequestsHKEntity> S save(S entity);

    @Override
    public <S extends ChekkRequestsHKEntity> S saveAndFlush(S entity);
    
    @Override
    public ChekkRequestsHKEntity getOne(String arg0);
      
    public List<ChekkRequestsHKEntity> findByRequestId(String requestId);
    
}