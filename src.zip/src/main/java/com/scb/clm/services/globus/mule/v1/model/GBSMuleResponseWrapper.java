package com.scb.clm.services.globus.mule.v1.model;

import java.util.HashSet;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonProperty;
public class GBSMuleResponseWrapper
{
	@JsonProperty("muleFlag")
	private String muleFlag;

	@JsonProperty("errorDetails")
	Set<GBSMuleResponseErrorDetails > gbsMuleResponseErrorDetails = new HashSet<>();

	public String getMuleFlag() {
		return muleFlag;
	}

	public void setMuleFlag(String muleFlag) {
		this.muleFlag = muleFlag;
	}

	public Set<GBSMuleResponseErrorDetails> getGbsMuleResponseErrorDetails() {
		return gbsMuleResponseErrorDetails;
	}

	public void setGbsMuleResponseErrorDetails(Set<GBSMuleResponseErrorDetails> gbsMuleResponseErrorDetails) {
		this.gbsMuleResponseErrorDetails = gbsMuleResponseErrorDetails;
	}

}