package com.scb.clm.services.globus.prospect.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSProspectRequestNationality 
{
    @JsonProperty("nationalityCode")
    public String nationalityCode;

    public GBSProspectRequestNationality() {       
    }
    
    public String getNationalityCode() {
        return nationalityCode;
    }

    public void setNationalityCode(String nationalityCode) {
        this.nationalityCode = nationalityCode;
    }
}

