package com.scb.clm.services.globus.prospect.v1.model;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSProspectRequestApplication {

	@JsonProperty("applicationReferenceNumber")  
	String applicationReferenceNumber;

	@JsonProperty("baseLocation")
	String baseLocation;

	@JsonProperty("countryOfAccountOpening")
	ArrayList<GBSProspectAppCountries> countryOfAccountOpening;


	public String getApplicationReferenceNumber() {
		return applicationReferenceNumber;
	}

	public void setApplicationReferenceNumber(String applicationReferenceNumber) {
		this.applicationReferenceNumber = applicationReferenceNumber;
	}

	public ArrayList<GBSProspectAppCountries> getCountryOfAccountOpening() {
		return countryOfAccountOpening;
	}

	public void setCountryOfAccountOpening(ArrayList<GBSProspectAppCountries> countryOfAccountOpening) {
		this.countryOfAccountOpening = countryOfAccountOpening;
	}

	public String getBaseLocation() {
		return baseLocation;
	}

	public void setBaseLocation(String baseLocation) {
		this.baseLocation = baseLocation;
	}
	
}