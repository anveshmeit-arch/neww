package com.scb.clm.services.globus.icm.v1.model;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ICMCustomerKYCNationality {

	@JsonProperty("nationality-code")
	public String nationalityCode;
	
	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	@JsonProperty("country-id")
	private String companyId;

	public String getNationalityCode() {
		return nationalityCode;
	}

	public void setNationalityCode(String nationalityCode) {
		this.nationalityCode = nationalityCode;
	}
	
	public ICMCustomerKYCNationality(String nationalityCode, String companyId) {
		this.nationalityCode = nationalityCode;
		this.companyId = companyId;
	}
	
	public ICMCustomerKYCNationality() {
		
	}
}
