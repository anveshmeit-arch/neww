package com.scb.clm.services.globus.mule.v1.support;

/*
 * 
 * @author     1378958 
 * @version    1.0
 * @since      
 * @use        Mule Constants  
 */
public class MuleConstants
{
    public static final String ICM_INTERFACE_ID       = "ICM";
    public static final String ICM_DEDUPE_SERVICE_ID  = "SDEDUP"; 

    public static final String MULE_INTERFACE_ID      = "MULE";
    public static final String INERFACE_MULE		  = "MULE";
    public static final String SERVICE_MULE			  = "SMULES";

    /* MULE CONSTATNTS */
    public static final String INVALID_JSON_FORMAT           = "MU000001";  
    public static final String MULE_PROCESSING_ERROR         = "MU000002";  
    public static final String INVALID_MULE_FLAG             = "MU000003";
    public static final String INVALID_RELATIONSHIP_NUMBER   = "MU000004";
    public static final String INVALID_PROFILE_ID            = "MU000005";
    public static final String INVALID_ERROR_DETAILS         = "MU000006";
    public static final String INVALID_ERROR_CODE            = "MU000008";
    public static final String INVALID_ERROR_DESCRIPTION     = "MU000009";
    public static final String MULE_ERROR                    = "MU000010";
    public static final String MULE_ERROR_DESCRIPTION        = "PROCESSING ERROR";


    public static final String CLM_REQUEST_ERROR             = "OB000001";
    public static final String ONBOARD_MULE_SRV              = "FONBRD-NMULES-SMULES";

    public static final String EMAIL_ID_TYPE                 = "OB000001";
    public static final String CONTACT_EMAIL_TYPE            = "E";
    public static final String CONTACT_MOBILE_TYPE           = "M";
	public static final String DOCUMENT_K_TYPE               = "K";
	
	public static final String RECORD_MODE_INSERT            = "I";
    public static final String RECORD_MODE_DELETE            = "D";
	
}