package com.scb.clm.services.companysearch.chekk.v1.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.scb.clm.common.model.transactions.InboundRequestsEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ProcessApiRequestsEntity;

@Repository
public interface ProcessApiRequestsRepository extends JpaRepository<ProcessApiRequestsEntity, String> { 

	 public List<InboundRequestsEntity> findByCountryCodeAndInterfaceIdAndTrackingID(String countryCode, String interfaceId , String trackingID);
	 
	 public ProcessApiRequestsEntity findByRequestId(String requestId);

}
