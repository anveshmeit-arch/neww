package com.scb.clm.services.globus.onboarding.v1.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class GBSOnboardResponseAccountReference {
	
	public GBSOnboardResponseAccountReference() {
		
	}
	
	public GBSOnboardResponseAccountReference(String productReferencekey, String accountKey) {
		this.productReferencekey = productReferencekey;
		this.accountKey = accountKey;
	}

	@JsonProperty("productReferenceKey")
	private String productReferencekey;

	@JsonProperty("accountKey")
	private String accountKey;

	public String getProductReferencekey() {
		return productReferencekey;
	}

	public void setProductReferencekey(String productReferencekey) {
		this.productReferencekey = productReferencekey;
	}

	public String getAccountKey() {
		return accountKey;
	}

	public void setAccountKey(String accountKey) {
		this.accountKey = accountKey;
	}
}
