package com.scb.clm.services.globus.cddinitiate.v1.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)  
public class CDDCreateInitiateAliases 
{

    @JsonProperty("alias-type")
    private String alias_type;

    @JsonProperty("alias-name")
    private String alias_name;

    public String getAlias_type() 
    {
        return alias_type;
    }

    public void setAlias_type(String alias_type) 
    {
        this.alias_type = alias_type;
    }

    public String getAlias_name() 
    {
        return alias_name;
    }

    public void setAlias_name(String alias_name) 
    {
        this.alias_name = alias_name;
    }
}
