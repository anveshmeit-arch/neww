package com.scb.clm.services.globus.prospect.v1.model;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.scb.clm.common.util.WrapperUtility;

public class GBSProspectRequestEmployment 
{

    @JsonProperty("workType")
    private String workType;

    @JsonProperty("professionCode")
    private String professionCode;

    @JsonProperty("employerCode")
    private String employerCode;

    @JsonProperty("employerName")
    private String employerName;

    @JsonProperty("staffCategoryCode")
    private String staffCategoryCode;

    @JsonProperty("bankPricingCategoryCode")
    private String bankPricingCategoryCode;

    @JsonProperty("ownOrganisationName")
    private String ownOrganisationName;

    @JsonProperty("empBankingInd")
    private String empBankingInd;

    @JsonProperty("staffEmpId")
    private String staffEmpId;

    @JsonProperty("salaryMode")
    private String salaryMode;

    @JsonProperty("declaredIncome")
    private BigDecimal declaredIncome;

    @JsonProperty("annualDerivedIncome")
    private BigDecimal annualDerivedIncome;

    @JsonProperty("annualDocumentedIncome")
    private BigDecimal annualDocumentedIncome;

    @JsonProperty("proxyIncome")
    private BigDecimal proxyIncome;

    @JsonProperty("declaredIncomeCurrency")
    private String declaredIncomeCurrency;

    @JsonProperty("derivedIncomeCurrency")
    private String derivedIncomeCurrency;

    @JsonProperty("documentedIncomeCurrency")
    private String documentedIncomeCurrency;

    @JsonProperty("proxyIncomeCurrency")
    private String proxyIncomeCurrency;

    @JsonProperty("isicCode")
    private String isicCode;

    @JsonProperty("assetUnderManagement")
    private BigDecimal assetUnderManagement;

    @JsonProperty("assetUnderManagementCurrency")
    private String assetUnderManagementCurrency;

    @JsonProperty("derivedIncomeLastUpdatedDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date derivedIncomeLastUpdatedDate;

    @JsonProperty("documentedIncomeLastUpdatedDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date documentedIncomeLastUpdatedDate;

    @JsonProperty("customerOccupation")
    private String customerOccupation;

    @JsonProperty("industryCode")
    private String industryCode;

    public GBSProspectRequestEmployment () {       
    }
    
    public String getWorkType() {
        return workType;
    }

    public void setWorkType(String workType) {
        this.workType = workType;
    }

    public String getProfessionCode() {
        return professionCode;
    }

    public void setProfessionCode(String professionCode) {
        this.professionCode = professionCode;
    }

    public String getEmployerCode() {
        return employerCode;
    }

    public void setEmployerCode(String employerCode) {
        this.employerCode = employerCode;
    }

    public String getEmployerName() {
        return employerName;
    }

    public void setEmployerName(String employerName) {
        this.employerName = employerName;
    }

    public String getStaffCategoryCode() {
        return staffCategoryCode;
    }

    public void setStaffCategoryCode(String staffCategoryCode) {
        this.staffCategoryCode = staffCategoryCode;
    }

    public String getBankPricingCategoryCode() {
        return bankPricingCategoryCode;
    }

    public void setBankPricingCategoryCode(String bankPricingCategoryCode) {
        this.bankPricingCategoryCode = bankPricingCategoryCode;
    }

    public String getOwnOrganisationName() {
        return ownOrganisationName;
    }

    public void setOwnOrganisationName(String ownOrganisationName) {
        this.ownOrganisationName = ownOrganisationName;
    }

    public String getEmpBankingInd() {
        return empBankingInd;
    }

    public void setEmpBankingInd(String empBankingInd) {
        this.empBankingInd = empBankingInd;
    }

    public String getStaffEmpId() {
        return staffEmpId;
    }

    public void setStaffEmpId(String staffEmpId) {
        this.staffEmpId = staffEmpId;
    }

    public String getSalaryMode() {
        return salaryMode;
    }

    public void setSalaryMode(String salaryMode) {
        this.salaryMode = salaryMode;
    }

    public BigDecimal getDeclaredIncome() {
        return declaredIncome;
    }

    public void setDeclaredIncome(BigDecimal declaredIncome) {
        this.declaredIncome = declaredIncome;
    }

    public BigDecimal getAnnualDerivedIncome() {
        return annualDerivedIncome;
    }

    public void setAnnualDerivedIncome(BigDecimal annualDerivedIncome) {
        this.annualDerivedIncome = annualDerivedIncome;
    }

    public BigDecimal getAnnualDocumentedIncome() {
        return annualDocumentedIncome;
    }

    public void setAnnualDocumentedIncome(BigDecimal annualDocumentedIncome) {
        this.annualDocumentedIncome = annualDocumentedIncome;
    }

    public BigDecimal getProxyIncome() {
        return proxyIncome;
    }

    public void setProxyIncome(BigDecimal proxyIncome) {
        this.proxyIncome = proxyIncome;
    }

    public String getDeclaredIncomeCurrency() {
        return declaredIncomeCurrency;
    }

    public void setDeclaredIncomeCurrency(String declaredIncomeCurrency) {
        this.declaredIncomeCurrency = declaredIncomeCurrency;
    }

    public String getDerivedIncomeCurrency() {
        return derivedIncomeCurrency;
    }

    public void setDerivedIncomeCurrency(String derivedIncomeCurrency) {
        this.derivedIncomeCurrency = derivedIncomeCurrency;
    }

    public String getDocumentedIncomeCurrency() {
        return documentedIncomeCurrency;
    }

    public void setDocumentedIncomeCurrency(String documentedIncomeCurrency) {
        this.documentedIncomeCurrency = documentedIncomeCurrency;
    }

    public String getProxyIncomeCurrency() {
        return proxyIncomeCurrency;
    }

    public void setProxyIncomeCurrency(String proxyIncomeCurrency) {
        this.proxyIncomeCurrency = proxyIncomeCurrency;
    }

    public String getIsicCode() {
        return isicCode;
    }

    public void setIsicCode(String isicCode) {
        this.isicCode = isicCode;
    }

    public BigDecimal getAssetUnderManagement() {
        return assetUnderManagement;
    }

    public void setAssetUnderManagement(BigDecimal assetUnderManagement) {
        this.assetUnderManagement = assetUnderManagement;
    }

    public String getAssetUnderManagementCurrency() {
        return assetUnderManagementCurrency;
    }

    public void setAssetUnderManagementCurrency(String assetUnderManagementCurrency) {
        this.assetUnderManagementCurrency = assetUnderManagementCurrency;
    }

    public Date getDerivedIncomeLastUpdatedDate() {
        return derivedIncomeLastUpdatedDate;
    }

    public void setDerivedIncomeLastUpdatedDate(Date derivedIncomeLastUpdatedDate) {
        this.derivedIncomeLastUpdatedDate = WrapperUtility.cloneData(derivedIncomeLastUpdatedDate);
    }

    public Date getDocumentedIncomeLastUpdatedDate() {
        return documentedIncomeLastUpdatedDate;
    }

    public void setDocumentedIncomeLastUpdatedDate(Date documentedIncomeLastUpdatedDate) {
        this.documentedIncomeLastUpdatedDate = WrapperUtility.cloneData(documentedIncomeLastUpdatedDate);
    }

    public String getCustomerOccupation() {
        return customerOccupation;
    }

    public void setCustomerOccupation(String customerOccupation) {
        this.customerOccupation = customerOccupation;
    }

    public String getIndustryCode() {
        return industryCode;
    }

    public void setIndustryCode(String industryCode) {
        this.industryCode = industryCode;
    }



}

