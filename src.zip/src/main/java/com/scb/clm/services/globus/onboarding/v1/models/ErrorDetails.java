package com.scb.clm.services.globus.onboarding.v1.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ErrorDetails {

	@JsonProperty("errorCode")
	private String errorCode;
	
	@JsonProperty("errorDescription")
	private String errorDescription;
	
	public ErrorDetails () {	    
	}

	public ErrorDetails(String errorCode,String errorDescription) {
	    this.errorCode           = errorCode;
        this.errorDescription    = errorDescription;
	}
	
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorDescription() {
		return errorDescription;
	}
	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}
}
