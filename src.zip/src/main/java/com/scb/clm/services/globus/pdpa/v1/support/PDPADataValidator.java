package com.scb.clm.services.globus.pdpa.v1.support;

import java.util.List;

import org.springframework.stereotype.Component;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ErrorObject;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.util.StringUtility;
import com.scb.clm.services.globus.cddinitiate.v1.support.CDDConstants;
import com.scb.clm.services.globus.pdpa.v1.model.GBSPDPACustomerWrapper;
import com.scb.clm.services.globus.pdpa.v1.model.GBSPDPAPdpaWrapper;

@Component
public class PDPADataValidator 
{


    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    public void validateRequestMessage(GBSPDPACustomerWrapper pdpaCustomer,List<ErrorObject> errorList)
    {
        try
        {            
            if(pdpaCustomer==null)
                return;

            /* VALIDATE BASE DATA VALIDATIONS */
            validateBaseData(pdpaCustomer,errorList);    
            
            /* VALIDATE AUXILIARY DATA */
            validatePdpaQuestionaire(pdpaCustomer,errorList);

          
            
        }
        catch(Exception e) 
        {
            System.out.println("[ProfileDataValidator] [Validtion Error]");
        }

    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    private void validateBaseData(GBSPDPACustomerWrapper customers,List<ErrorObject> errorList)
    {
        try
        {
            if(!StringUtility.minMaxlength(customers.getCoreBankingReferenceKey(),"0","20")) {
                errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_SALUTATION_CODE,"INVALID CORE BANKING REFERENCE KEY["+customers.getCoreBankingReferenceKey()+"] [ MAX-LENGTH 20 ]"));
            }

            if(!StringUtility.minMaxlength(customers.getCustomerMasterReferenceKey(),"0","20")) {
                errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_FIRST_NAME,"INVALID MASTER REFERENCE KEY ["+customers.getCustomerMasterReferenceKey()+"] [ MAX-LENGTH 20 ]"));
            }

        }
        catch(Exception e) 
        {
            LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateBaseData", LogType.APPLICATION.name());
            log.printErrorMessage(e);
        }

    }

   
    private void validatePdpaQuestionaire(GBSPDPACustomerWrapper customers,List<ErrorObject> errorList)
    {

    	List<GBSPDPAPdpaWrapper> pdpaList = customers.getPdpa();

        try
        {
            if (pdpaList==null || pdpaList.size()==0) {
                return;
            }

            for (GBSPDPAPdpaWrapper dat : pdpaList)
            {
                if(!StringUtility.minMaxlength(dat.getCcqSequence(),"0","4")) {
                    errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, PDPAConstant.INVALID_CUSTOMER_COMMUNICATION_QUESTION,"INVALID CUSTOMER COMMUNICATION QUESTION ["+dat.getCcqSequence()+"] [ MAX-LENGTH 4 ]"));
                }

                if(!StringUtility.minMaxlength(dat.getCustSelection(),"0","1")) {
                    errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, PDPAConstant.INVALID_CUSTOMER_COMMUNICATION_ANSWER,"INVALID CUSTOMER COMMUNICATION ANSWER  ["+dat.getCustSelection()+"] [ MAX-LENGTH 1 ]"));       
                }
            }
        }
        catch(Exception e) 
        {
            LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validatePdpaQuestionaire", LogType.APPLICATION.name());
            log.printErrorMessage(e);
        }

    }

 
}
