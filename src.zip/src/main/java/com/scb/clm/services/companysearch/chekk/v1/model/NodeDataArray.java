package com.scb.clm.services.companysearch.chekk.v1.model;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)

public class NodeDataArray {

	@JsonProperty("id_secondary_ssic_code")
	public String idSecondarySsicCode;
	@JsonProperty("fi_financial_year_end_date_for_submitted_financials")
	public String fiFinancialYearEndDateForSubmittedFinancials;
	@JsonProperty("ubo")
	public String ubo;
	@JsonProperty("fi_company_currency")
	public String fiCompanyCurrency;
	@JsonProperty("fi_company_total_current_assets")
	public String fiCompanyTotalCurrentAssets;
	@JsonProperty("fi_net_cashflow_operating_activities")
	public String fiNetCashflowOperatingActivities;
	@JsonProperty("type")
	public String type;
	@JsonProperty("delegationMain")
	public String delegationMain;
	@JsonProperty("id_address_is_valid")
	public String idAddressIsValid;
	@JsonProperty("fi_profit_loss_after_tax_from_discontinued_operations")
	public String fiProfitLossAfterTaxFromDiscontinuedOperations;
	@JsonProperty("fi_last_ar_date")
	public String fiLastArDate;
	@JsonProperty("fi_company_total_liabilities")
	public String fiCompanyTotalLiabilities;
	@JsonProperty("fi_other_reserves")
	public String fiOtherReserves;
	@JsonProperty("id_name_effective_date")
	public String idNameEffectiveDate;
	@JsonProperty("text")
	public String text;
	@JsonProperty("id")
	public String id;
	@JsonProperty("sh_integrated_percentage_estimation")
	public String shIntegratedPercentageEstimation;
	@JsonProperty("fi_interest_cover_ratio")
	public String fiInterestCoverRatio;
	@JsonProperty("fi_return_on_equity")
	public String fiReturnOnEquity;
	@JsonProperty("id_company_number")
	public String idCompanyNumber;
	@JsonProperty("id_zip")
	public String idZip;
	@JsonProperty("fi_return_on_assets")
	public String fiReturnOnAssets;
	@JsonProperty("entity_id")
	public Integer entityId;
	@JsonProperty("fi_total_liabilities_to_equity")
	public String fiTotalLiabilitiesToEquity;
	@JsonProperty("id_formernames")
	public String idFormernames;
	@JsonProperty("fi_last_agm_date")
	public String fiLastAgmDate;
	@JsonProperty("id_local_company_number")
	public String idLocalCompanyNumber;
	@JsonProperty("idv")
	public String idv;
	@JsonProperty("shared_percent")
	public Integer sharedPercent;
	@JsonProperty("fi_profit_loss_after_tax_from_continuing_operations")
	public String fiProfitLossAfterTaxFromContinuingOperations;
	@JsonProperty("fi_fiscal_year_end_date")
	public String fiFiscalYearEndDate;
	@JsonProperty("fi_current_ratio")
	public String fiCurrentRatio;
	@JsonProperty("fi_company_total_current_liablities")
	public String fiCompanyTotalCurrentLiablities;
	@JsonProperty("fi_total_asset_turnover")
	public String fiTotalAssetTurnover;
	@JsonProperty("loc")
	public String loc;
	@JsonProperty("id_status_effective_date")
	public String idStatusEffectiveDate;	
	@JsonProperty("id_nace_code")
	public String idNaceCode;
	@JsonProperty("id_naics_code")
	public String idNaicsCode;
	@JsonProperty("sh_controlling_shareholder")
	public String shControllingShareholder;
	@JsonProperty("sh_shares_value")
	public String shSharesValue;
	@JsonProperty("isKing")
	public Boolean isKing;
	@JsonProperty("le_registration_date")
	public String leRegistrationDate;
	@JsonProperty("id_valid")
	public String idValid;
	@JsonProperty("id_company_name")
	public String idCompanyName;
	@JsonProperty("id_home_company_name")
	public String idHomeCompanyName;
	@JsonProperty("fi_net_cashflow_investing_activities")
	public String fiNetCashflowInvestingActivities;
	@JsonProperty("delegationDisabled")
	public String delegationDisabled;
	@JsonProperty("geo")
	public String geo;
	@JsonProperty("id_status")
	public String idStatus;
	@JsonProperty("fi_revenue")
	public String fiRevenue;
	@JsonProperty("fi_account_currency")
	public String fiAccountCurrency;
	@JsonProperty("id_nature_of_business")
	public String idNatureOfBusiness;
	@JsonProperty("id_inactive")
	public String idInactive;
	@JsonProperty("fi_company_retained_earnings_accumulated_loss")
	public String fiCompanyRetainedEarningsAccumulatedLoss;
	@JsonProperty("fi_ebit")
	public String fiEbit;
	@JsonProperty("id_company_type_code")
	public String idCompanyTypeCode;
	@JsonProperty("businessregisteredid")
	public String businessregisteredid;
	@JsonProperty("uniqueid")
	public String uniqueid;
	@JsonProperty("fi_net_profit_margin")
	public String fiNetProfitMargin;
	@JsonProperty("idvDisabled")
	public String idvDisabled;
	@JsonProperty("key")
	public Integer key;
	@JsonProperty("fi_net_cashflow_financing_activities")
	public String fiNetCashflowFinancingActivities;
	@JsonProperty("distance_from_root")
	public Integer distanceFromRoot;
	@JsonProperty("fi_company_total_equities")
	public String fiCompanyTotalEquities;
	@JsonProperty("id_is_king")
	public String idIsKing;
	@JsonProperty("completion_percent")
	public Integer completionPercent;
	@JsonProperty("company_number")
	public String companyNumber;
	@JsonProperty("id_country")
	public String idCountry;
	@JsonProperty("id_city")
	public String idCity;
	@JsonProperty("id_state")
	public String idState;
	@JsonProperty("le_national_legal_form")
	public String leNationalLegalForm;
	@JsonProperty("id_full_address")
	public String idFullAddress;
	@JsonProperty("id_full_operating_address")
	public String idFullOperatingAddress;
	@JsonProperty("id_full_operating_address_zip")
	public String idFullOperatingAddressZip;
	@JsonProperty("id_full_operating_address_city")
	public String idFullOperatingAddressCity;
	@JsonProperty("id_full_operating_address_state")
	public String idFullOperatingAddressState;
	@JsonProperty("id_full_operating_address_country")
	public String idFullOperatingAddressCountry;	
	@JsonProperty("delegation")
	public String delegation;
	@JsonProperty("id_primary_ssic_code")
	public String idPrimarySsicCode;
	@JsonProperty("fi_company_total_assets")
	public String fiCompanyTotalAssets;
	@JsonProperty("fi_operating_profit_margin")
	public String fiOperatingProfitMargin;
	@JsonProperty("ind_signatory")
	public String indSignatory;
	@JsonProperty("ind_integrated_percentage_estimation")
	public String indIntegratedPercentageEstimation;
	@JsonProperty("color")
	public String color;
	@JsonProperty("ind_address_effective_date")
	public String indAddressEffectiveDate;
	@JsonProperty("ind_role")
	public String indRole;
	@JsonProperty("personal_zip_code")
	public String personalZipCode;
	@JsonProperty("ind_controlling_shareholder")
	public String indControllingShareholder;
	@JsonProperty("ind_biography")
	public String indBiography;
	@JsonProperty("ind_is_king")
	public String indIsKing;
	@JsonProperty("ind_individual_number")
	public String indIndividualNumber;
	@JsonProperty("ind_is_ubo")
	public String indIsUbo;
	@JsonProperty("personal_sgp_id_type")
	public String personalSgpIdType;
	@JsonProperty("ind_shareholder")
	public String indShareholder;
	@JsonProperty("ind_shares_amount")
	public String indSharesAmount;
	@JsonProperty("ind_shares_currency")
	public String indSharesCurrency;
	@JsonProperty("ind_shares_type")
	public String indSharesType;
	@JsonProperty("ind_attorney_powers")
	public String indAttorneyPowers;
	@JsonProperty("ind_appointed_date")
	public String indAppointedDate;
	@JsonProperty("personal_address_country")
	public String personalAddressCountry;
	@JsonProperty("ind_status")
	public String indStatus;
	@JsonProperty("personal_sgp_id")
	public String personalSgpId;
	@JsonProperty("ind_name")
	public String indName;
	@JsonProperty("ind_is_bo")
	public String indIsBo;
	@JsonProperty("personal_address_city")
	public String personalAddressCity;
	@JsonProperty("ind_adress")
	public String indAdress;
	@JsonProperty("intermediate_id_valid")
	public String intermediateIdValid;
	@JsonProperty("intermediate_sh_controlling_shareholder")
	public String intermediateShControllingShareholder;
	@JsonProperty("sh_total_percentage")
	public String shTotalPercentage;
	@JsonProperty("intermediate_id_full_address")
	public String intermediateIdFullAddress;
	@JsonProperty("sh_direct_percentage")
	public String shDirectPercentage;
	@JsonProperty("intermediate_sh_shares_amount")
	public String intermediateShSharesAmount;
	@JsonProperty("intermediate_id_company_number")
	public String intermediateIdCompanyNumber;
	@JsonProperty("intermediate_id_inactive")
	public String intermediateIdInactive;
	@JsonProperty("intermediate_id_zip")
	public String intermediateIdZip;
	@JsonProperty("intermediate_id_country")
	public String intermediateIdCountry;
	@JsonProperty("intermediate_id_state")
	public String intermediateIdState;
	@JsonProperty("intermediate_id_city")
	public String intermediateIdCity;
	@JsonProperty("intermediate_sh_type")
	public String intermediateShType;
	@JsonProperty("intermediate_id_address_is_valid")
	public String intermediateIdAddressIsValid;
	@JsonProperty("intermediate_sh_integrated_percentage_estimation")
	public String intermediateShIntegratedPercentageEstimation;
	@JsonProperty("intermediate_id_role")
	public String intermediateIdRole;
	@JsonProperty("intermediate_sh_currency")
	public String intermediateShCurrency;
	@JsonProperty("intermediate_id_local_company_number")
	public String intermediateIdLocalCompanyNumber;
	@JsonProperty("intermediate_id_company_name")
	public String intermediateIdCompanyName;
	@JsonProperty("intermediate_id_is_king")
	public String intermediateIdIsKing;
	//NEW FIELDS  - ORSH/OTSH/TRSH/PRSH
	@JsonProperty("orsh_shares_number_other")
	public String orshSharesNumberOther;
	@JsonProperty("orsh_shares_number_sgpd")
	public String orshSharesNumberSgpd;
	@JsonProperty("orsh_shares_number_usad")
	public String orshSharesNumberUsad;
	@JsonProperty("orsh_issued_share_capital_sgpd")
	public String orshIssuedShareCapitalSgpd;
	@JsonProperty("orsh_issued_share_capital_usad")
	public String orshIssuedShareCapitalUsad;
	@JsonProperty("orsh_issued_share_capital_other")
	public String orshIssuedShareCapitalOther;
	@JsonProperty("orsh_paid_up_share_capital_usad")
	public String orshPaidUpShareCapitalUsad;
	@JsonProperty("orsh_paid_up_share_capital_sgpd")
	public String orshPaidUpShareCapitalSgpd;
	@JsonProperty("orsh_paid_up_share_capital_other")
	public String orshPaidUpShareCapitalOther;
	
	@JsonProperty("otsh_issued_share_capital_other")
	public String otshIssuedShareCapitalOther;
	@JsonProperty("otsh_issued_share_capital_sgpd")
	public String otshIssuedShareCapitalSgpd;
	@JsonProperty("otsh_issued_share_capital_usad")
	public String otshIssuedShareCapitalUsad;
	@JsonProperty("otsh_paid_up_share_capital_other")
	public String otshPaidUpShareCapitalOther;
	@JsonProperty("otsh_paid_up_share_capital_sgpd")
	public String otshPaidUpShareCapitalSgpd;
	@JsonProperty("otsh_paid_up_share_capital_usad")
	public String otshPaidUpShareCapitalUsad;
	@JsonProperty("otsh_shares_number_other")
	public String otshSharesNumberOther;
	@JsonProperty("otsh_shares_number_sgdp")
	public String otshSharesNumberSgdp;
	@JsonProperty("otsh_shares_number_usad")
	public String otshSharesNumberUsad;

	@JsonProperty("prsh_issued_share_capital_other")
	public String prshIssuedShareCapitalOther;
	@JsonProperty("prsh_issued_share_capital_sgpd")
	public String prshIssuedShareCapitalSgpd;
	@JsonProperty("prsh_issued_share_capital_usad")
	public String prshIssuedShareCapitalUsad;
	@JsonProperty("prsh_paid_up_share_capital_other")
	public String prshPaidUpShareCapitalOther;
	@JsonProperty("prsh_paid_up_share_capital_sgpd")
	public String prshPaidUpShareCapitalSgpd;
	@JsonProperty("prsh_paid_up_share_capital_usad")
	public String prshPaidUpShareCapitalUsad;
	@JsonProperty("prsh_shares_number_other")
	public String prshSharesNumberOther;
	@JsonProperty("prsh_shares_number_sgdp")
	public String prshSharesNumberSgdp;
	@JsonProperty("prsh_shares_number_usad")
	public String prshSharesNumberUsad;
	
	@JsonProperty("trsh_issued_share_capital_other")
	public String trshIssuedShareCapitalOther;
	@JsonProperty("trsh_issued_share_capital_sgpd")
	public String trshIssuedShareCapitalSgpd;
	@JsonProperty("trsh_issued_share_capital_usad")
	public String trshIssuedShareCapitalUsad;
	@JsonProperty("trsh_paid_up_share_capital_other")
	public String trshPaidUpShareCapitalOther;
	@JsonProperty("trsh_paid_up_share_capital_sgpd")
	public String trshPaidUpShareCapitalSgpd;
	@JsonProperty("trsh_paid_up_share_capital_usad")
	public String trshPaidUpShareCapitalUsad;
	@JsonProperty("trsh_shares_number_other")
	public String trshSharesNumberOther;
	@JsonProperty("trsh_shares_number_sgdp")
	public String trshSharesNumberSgdp;
	@JsonProperty("trsh_shares_number_usad")
	public String trshSharesNumberUsad;
	
	@JsonProperty("id_primary_ssic_label")
	public String idPrimarySsicLabel;
	@JsonProperty("id_secondary_ssic_label")
	public String idSecondarySsicLabel;	
	@JsonProperty("id_primary_ssic_other_description")
	public String idPrimarySsicOtherDescription;
	@JsonProperty("id_secondary_ssic_other_description")
	public String idSecondarySsicOtherDescription;
    @JsonProperty("id_address_effective_date")
	public String idAddressEffectiveDate;
	@JsonProperty("id_commencement_date")
	public String idCommencementDate;
	@JsonProperty("id_renewal_cut_off_date")
	public String idRenewalCutOffDate;
	@JsonProperty("id_expiry_date")
	public String idExpiryDate;

	public Map<String, String> additionalInformation = new HashMap<>();
	@JsonAnyGetter
	public Map<String, String> getAdditionalInformation() {
		return additionalInformation;
	}
	public void setAdditionalInformation(Map<String, String> additionalInformation) {
	   this.additionalInformation = additionalInformation;
   	}
	@JsonAnySetter
	public void setAdditionalProperty(final String name, final String value) {
		this.additionalInformation.put(name, value);
	}
}
