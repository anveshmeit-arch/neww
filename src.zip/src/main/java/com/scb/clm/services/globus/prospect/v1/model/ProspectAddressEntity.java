package com.scb.clm.services.globus.prospect.v1.model;

import java.util.Objects;

import com.scb.clm.common.util.StringUtility;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/*
 * 
 *  @author      1378958
 *  @version     1.0
 *  @since       
 *  @use         
 */
@Entity
@Table(name = "GBS_PROSPECT_ADDRESS")
public class ProspectAddressEntity implements Cloneable
{
    @EmbeddedId
    private ProspectAddressEntityKey id;

    @Column(name="ADDRESS_LINE_1")
    private String addressLine1;

    @Column(name="ADDRESS_LINE_2")
    private String addressLine2;

    @Column(name="ADDRESS_LINE_3")
    private String addressLine3;

    @Column(name="NEAREST_LANDMARK")
    private String nearestLandMark;

    @Column(name="CITY_NAME")
    private String cityName;
    
    @Column(name="POSTAL_CODE")
    private String postalCode;
    
    @Column(name="STATE_CODE")
    private String stateCode;
    
	@Column(name="STATE")
    private String state;

    @Column(name="COUNTRY")
    private String country;
    
    @ManyToOne
    @JoinColumns({
        @JoinColumn(name="COUNTRY_CODE", referencedColumnName="COUNTRY_CODE", insertable= false, updatable= false),
        @JoinColumn(name="PROSPECT_ID", referencedColumnName="PROSPECT_ID",insertable= false, updatable=false)
    })
    private ProspectEntity addressMapper;

    public ProspectAddressEntity() {
    }

    public ProspectAddressEntity(ProspectAddressEntityKey id) {
        this.id = (ProspectAddressEntityKey) id.clone();
    }
    public ProspectAddressEntityKey getId() {
        return (ProspectAddressEntityKey) id.clone();
    }
    public void setId(ProspectAddressEntityKey id) {
        this.id = (ProspectAddressEntityKey) id.clone();
    }

    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = StringUtility.toUpperCase(addressLine1);
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = StringUtility.toUpperCase(addressLine2);
    }

    public String getAddressLine3() {
        return addressLine3;
    }

    public void setAddressLine3(String addressLine3) {
        this.addressLine3 = StringUtility.toUpperCase(addressLine3);
    }

    public String getNearestLandMark() {
        return nearestLandMark;
    }

    public void setNearestLandMark(String nearestLandMark) {
        this.nearestLandMark = StringUtility.toUpperCase(nearestLandMark);
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = StringUtility.toUpperCase(cityName);
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = StringUtility.toUpperCase(postalCode);
    }

    public String getStateCode() {
        return stateCode;
    }

    public void setStateCode(String stateCode) {
        this.stateCode = StringUtility.toUpperCase(stateCode);
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = StringUtility.toUpperCase(country);
    }
    
    public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

    @Override
    public int hashCode() {
        return this.getId().hashCode();
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        ProspectAddressEntity prospectAddressEntity=(ProspectAddressEntity) super.clone();
        prospectAddressEntity.setId((ProspectAddressEntityKey) this.getId().clone());
        return prospectAddressEntity;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof ProspectAddressEntity)) {
            return false;
        }
        return Objects.equals(this.getId(), ((ProspectAddressEntity) obj).getId());
    }

    public void synchronizeThisWith( ProspectAddressEntity argProspectAddressEntity) 
    {
        this.setAddressLine1(argProspectAddressEntity.getAddressLine1());
        this.setAddressLine2(argProspectAddressEntity.getAddressLine2());
        this.setAddressLine3(argProspectAddressEntity.getAddressLine3());

        this.setNearestLandMark(argProspectAddressEntity.getNearestLandMark());
        this.setCityName(argProspectAddressEntity.getCityName());
        this.setPostalCode(argProspectAddressEntity.getPostalCode());
        this.setStateCode(argProspectAddressEntity.getStateCode());
        this.setState(argProspectAddressEntity.getState());
        this.setCountry(argProspectAddressEntity.getCountry());
    }
}
