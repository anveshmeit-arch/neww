package com.scb.clm.services.globus.onboarding.v1.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSOnboardJointApplicantsWrapper {

    @JsonProperty("relatedApplicantReferenceKey")
    private String relatedApplicantReferenceKey;

    @JsonProperty("profileRole")
    private String profileRole;

    public String getRelatedApplicantReferenceKey() {
        return relatedApplicantReferenceKey;
    }

    public void setRelatedApplicantReferenceKey(String relatedApplicantReferenceKey) {
        this.relatedApplicantReferenceKey = relatedApplicantReferenceKey;
    }

    public String getProfileRole() {
        return profileRole;
    }

    public void setProfileRole(String profileRole) {
        this.profileRole = profileRole;
    }


}
