package com.scb.clm.services.companysearch.chekk.v1.support;

import java.util.List;
import java.util.function.Function;

import com.scb.clm.common.framework.logger.LoggerUtil;

public class Retrier<T, R> {

    private static final int DEFAULT_RETRY_COUNT = 4;
    private int retryCount;
    private Function<T, R> retriable;
    private T input;
    private int delayInMilliSeconds;
    private static final int DEFAULT_DELAY_IN_MS = 5000;

    public Retrier(T input, Function<T, R> retriable) {
        this(input, retriable, DEFAULT_RETRY_COUNT, DEFAULT_DELAY_IN_MS);
    }

    public Retrier(T input, Function<T, R> retriable, int retryCount, int delayInMilliSeconds) {
        this.retryCount = retryCount;
        this.retriable = retriable;
        this.input = input;
        this.delayInMilliSeconds = delayInMilliSeconds;
    }

    public R execute(List<Class<? extends Exception>> allowedExceptions) {
        int count = 0;
        while (true) {
            try {
                return retriable.apply(input);
            } catch (Exception e) {
                ++count;
                Log.info("Retrier#execute: Retry count: " + count);
                if (isAllowedException(e, allowedExceptions)) {
                    Log.info("Retrier#execute: Attempt = " + count);
                    if (count >= retryCount) {
                        Log.error("Retrier#execute: Failed after " + retryCount + "attempts");
                        throw new RuntimeException("Failed after " + retryCount + "attempts", e);
                    }
                    try {
                        Thread.sleep(delayInMilliSeconds);
                    } catch (InterruptedException e1) {
                        Log.error("Retrier#execute: Error in retrier: " + e1.getMessage());
                    }
                } else {
                    throw new RuntimeException("Unexpected exception occurred", e);
                }
            }
        }
    }

    private static boolean isAllowedException(Exception e, List<Class<? extends Exception>> allowedExceptions) {
        for (Class<? extends Exception> exClass : allowedExceptions) {
            if (exClass.isInstance(e)) {
                return true;
            }
        }
        return false;
    }
}
