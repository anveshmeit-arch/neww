package com.scb.clm.services.globus.onboarding.v1.models;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.scb.clm.common.util.WrapperUtility;

public class GBSOnboardTarsCondnMandatoryWrapper {

    @JsonProperty("usResident")
    private String usResident;

    @JsonProperty("usCitizen")
    private String usCitizen;

    @JsonProperty("usGreenCardHolder")
    private String usGreenCardHolder;

    @JsonProperty("onBoardWithDis")
    private String onBoardWithDis;

    @JsonProperty("usaIndiciaInd")
    private String usaIndiciaInd;

    @JsonProperty("usaPersonInd")
    private String usaPersonInd;

    @JsonProperty("reportToIrsInd")
    private String reportToIrsInd;

    @JsonProperty("jointAcInd")
    private String jointAcInd;

    @JsonProperty("recalcitrantInd")
    private String recalcitrantInd;

    @JsonProperty("recalcitrantIndAssignDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date recalcitrantIndAssignDate;

    @JsonProperty("recalcitrantIndClearedDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date recalcitrantIndClearedDate;

    @JsonProperty("withholdInd")
    private String withholdInd;

    @JsonProperty("enhancedReviewInd")
    private String enhancedReviewInd;

    @JsonProperty("enhancedReviewStartDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date enhancedReviewStartDate;

    @JsonProperty("enhancedReviewEndDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date enhancedReviewEndDate;

    @JsonProperty("documentSubmittedIndicator")
    private String documentSubmittedIndicator;

    @JsonProperty("documentDueDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date documentDueDate;

    @JsonProperty("gstResidentStatus")
    private String gstResidentStatus;

    @JsonProperty("taxResidentStatus")
    private String taxResidentStatus;

    @JsonProperty("usIndiciaDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date usIndiciaDate;

    @JsonProperty("usPersonFlagChangedDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date usPersonFlagChangedDate;

    public String getUsResident() {
        return usResident;
    }

    public void setUsResident(String usResident) {
        this.usResident = usResident;
    }

    public String getUsCitizen() {
        return usCitizen;
    }

    public void setUsCitizen(String usCitizen) {
        this.usCitizen = usCitizen;
    }

    public String getUsGreenCardHolder() {
        return usGreenCardHolder;
    }

    public void setUsGreenCardHolder(String usGreenCardHolder) {
        this.usGreenCardHolder = usGreenCardHolder;
    }

    public String getOnBoardWithDis() {
        return onBoardWithDis;
    }

    public void setOnBoardWithDis(String onBoardWithDis) {
        this.onBoardWithDis = onBoardWithDis;
    }

    public String getUsaIndiciaInd() {
        return usaIndiciaInd;
    }

    public void setUsaIndiciaInd(String usaIndiciaInd) {
        this.usaIndiciaInd = usaIndiciaInd;
    }

    public String getUsaPersonInd() {
        return usaPersonInd;
    }

    public void setUsaPersonInd(String usaPersonInd) {
        this.usaPersonInd = usaPersonInd;
    }

    public String getReportToIrsInd() {
        return reportToIrsInd;
    }

    public void setReportToIrsInd(String reportToIrsInd) {
        this.reportToIrsInd = reportToIrsInd;
    }

    public String getJointAcInd() {
        return jointAcInd;
    }

    public void setJointAcInd(String jointAcInd) {
        this.jointAcInd = jointAcInd;
    }

    public String getRecalcitrantInd() {
        return recalcitrantInd;
    }

    public void setRecalcitrantInd(String recalcitrantInd) {
        this.recalcitrantInd = recalcitrantInd;
    }

    public Date getRecalcitrantIndAssignDate() {
        return recalcitrantIndAssignDate;
    }

    public void setRecalcitrantIndAssignDate(Date recalcitrantIndAssignDate) {
        this.recalcitrantIndAssignDate = WrapperUtility.cloneData(recalcitrantIndAssignDate);
    }

    public Date getRecalcitrantIndClearedDate() {
        return recalcitrantIndClearedDate;
    }

    public void setRecalcitrantIndClearedDate(Date recalcitrantIndClearedDate) {
        this.recalcitrantIndClearedDate = WrapperUtility.cloneData(recalcitrantIndClearedDate);
    }

    public String getWithholdInd() {
        return withholdInd;
    }

    public void setWithholdInd(String withholdInd) {
        this.withholdInd = withholdInd;
    }

    public String getEnhancedReviewInd() {
        return enhancedReviewInd;
    }

    public void setEnhancedReviewInd(String enhancedReviewInd) {
        this.enhancedReviewInd = enhancedReviewInd;
    }

    public Date getEnhancedReviewStartDate() {
        return enhancedReviewStartDate;
    }

    public void setEnhancedReviewStartDate(Date enhancedReviewStartDate) {
        this.enhancedReviewStartDate = WrapperUtility.cloneData(enhancedReviewStartDate);
    }

    public Date getEnhancedReviewEndDate() {
        return enhancedReviewEndDate;
    }

    public void setEnhancedReviewEndDate(Date enhancedReviewEndDate) {
        this.enhancedReviewEndDate = WrapperUtility.cloneData(enhancedReviewEndDate);
    }

    public String getDocumentSubmittedIndicator() {
        return documentSubmittedIndicator;
    }

    public void setDocumentSubmittedIndicator(String documentSubmittedIndicator) {
        this.documentSubmittedIndicator = documentSubmittedIndicator;
    }

    public Date getDocumentDueDate() {
        return documentDueDate;
    }

    public void setDocumentDueDate(Date documentDueDate) {
        this.documentDueDate = WrapperUtility.cloneData(documentDueDate);
    }

    public String getGstResidentStatus() {
        return gstResidentStatus;
    }

    public void setGstResidentStatus(String gstResidentStatus) {
        this.gstResidentStatus = gstResidentStatus;
    }

    public String getTaxResidentStatus() {
        return taxResidentStatus;
    }

    public void setTaxResidentStatus(String taxResidentStatus) {
        this.taxResidentStatus = taxResidentStatus;
    }

    public Date getUsIndiciaDate() {
        return usIndiciaDate;
    }

    public void setUsIndiciaDate(Date usIndiciaDate) {
        this.usIndiciaDate = WrapperUtility.cloneData(usIndiciaDate);
    }

    public Date getUsPersonFlagChangedDate() {
        return usPersonFlagChangedDate;
    }

    public void setUsPersonFlagChangedDate(Date usPersonFlagChangedDate) {
        this.usPersonFlagChangedDate = WrapperUtility.cloneData(usPersonFlagChangedDate);
    }



}
