package com.scb.clm.services.globus.icm.v1.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ICMCustomerCreateAuxiliary {

    @JsonProperty("reference-id")
    private String profileId;

    @JsonProperty("code")
    private String auxiliaryCode;

    @JsonProperty("value")
    private String auxiliaryValue;

	public String getProfileId() {
		return profileId;
	}

	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}

	public String getAuxiliaryCode() {
		return auxiliaryCode;
	}

	public void setAuxiliaryCode(String auxiliaryCode) {
		this.auxiliaryCode = auxiliaryCode;
	}

	public String getAuxiliaryValue() {
		return auxiliaryValue;
	}

	public void setAuxiliaryValue(String auxiliaryValue) {
		this.auxiliaryValue = auxiliaryValue;
	}

    
}
