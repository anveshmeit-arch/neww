package com.scb.clm.services.globus.common;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.codesetup.NodesEntity;
import com.scb.clm.common.model.transactions.ServiceMetadata;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.util.JSONUtility;
import com.scb.clm.common.util.StringUtility;
import com.scb.clm.core.service.ServiceThreadAdvisorAbstract;
import com.scb.clm.core.service.ServiceThreadAdvisorInterface;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardAppCountries;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardReqWrapper;

@Service
public class OnboardServiceThreadAdvisor extends ServiceThreadAdvisorAbstract implements ServiceThreadAdvisorInterface
{
    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
	@Override
	public ServiceMetadata[] seekAdvice(TravellingObject travelObj,NodesEntity nodesEntity, NodeServicesEntity nodeServicesEntity) throws ProcessException
	{
	    LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "getThreadObjects", LogType.APPLICATION.name());
		ArrayList<ServiceMetadata> metaDataList = new ArrayList<ServiceMetadata>();

		try
		{
			log.println("Control Inside OnboardServiceThreadAdvisor");
			GBSOnboardReqWrapper requestWrapper = (GBSOnboardReqWrapper) JSONUtility.jsonTODomainWrapper(travelObj.getRequestData(),GBSOnboardReqWrapper.class);

			if(requestWrapper == null || requestWrapper.getGbs_Onboard_ApplnWrapper()== null || requestWrapper.getGbs_Onboard_ApplnWrapper().getCountryOfAccountOpening()==null) 
			{
				return null;
			}

			for(GBSOnboardAppCountries appCountries : requestWrapper.getGbs_Onboard_ApplnWrapper().getCountryOfAccountOpening()) 
			{
				log.println(("OnboardServiceThreadAdvisor Adding ServiceMetadata for Country: " + appCountries.getCountryCode()));
				if(StringUtility.isEmpty(appCountries.getCountryCode())) {
					continue;
				}

				ServiceMetadata serviceMetaData = new ServiceMetadata();
				serviceMetaData.setServiceCountryCode(appCountries.getCountryCode());
				metaDataList.add(serviceMetaData);
			}
			log.println("OnboardServiceThreadAdvisor Completed");
		}
		catch(Exception e)
		{
		    log.printErrorMessage(e);
			throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, BaseConstants.INTERNAL_PROCESSING_ERROR,"[OnboardServiceThreadAdvisor] Thread Advisor Error ["+nodeServicesEntity.getThreadAdvisor()+"]"); 
		}
		finally
		{
            //N.A
		}
		log.println("OnboardServiceThreadAdvisor" + " metaDataList size: " + metaDataList.size());
		if(metaDataList == null || metaDataList.size()==0) 
		{
			return null;
		} 
		else
		{
			return metaDataList.toArray(new ServiceMetadata[metaDataList.size()]);
		}
	}
}
