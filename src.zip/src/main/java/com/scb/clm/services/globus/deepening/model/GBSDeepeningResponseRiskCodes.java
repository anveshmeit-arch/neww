package com.scb.clm.services.globus.deepening.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.scb.clm.services.globus.icm.v1.model.ICMCustomerCreateRisksDetails;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class GBSDeepeningResponseRiskCodes {

    @JsonProperty("riskdetails")
    private List<GBSDeepeningResponseRiskDetails> riskDetails = new ArrayList<GBSDeepeningResponseRiskDetails>();

    public GBSDeepeningResponseRiskCodes() {
    }

    public List<GBSDeepeningResponseRiskDetails> getRiskDetails() {
        return riskDetails;
    }

    public void setRiskDetails(List<GBSDeepeningResponseRiskDetails> riskDetails) {
        this.riskDetails = riskDetails;
    }
}
