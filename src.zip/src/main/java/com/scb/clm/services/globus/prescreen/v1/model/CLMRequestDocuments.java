package com.scb.clm.services.globus.prescreen.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CLMRequestDocuments
{
    @JsonProperty("id")
    String id;
    @JsonProperty("reference-id") 
    String referenceid;
    @JsonProperty("document-type") 
    String documenttype;
    @JsonProperty("document-code") 
    String documentcode;
    @JsonProperty("document-number") 
    String documentnumber;
    @JsonProperty("document-receive-dt") 
    String documentreceivedt;
    @JsonProperty("document-signatory-dt") 
    String documentsignatorydt;
    @JsonProperty("document-expiry-dt") 
    String documentexpirydt;
    @JsonProperty("tax-residence-country") 
    String taxresidencecountry;
    @JsonProperty("w8n-support-document-indicator") 
    String w8nsupportdocumentindicator;
    @JsonProperty("country-treaty") 
    String countrytreaty;
    @JsonProperty("document-evidence-link") 
    String documentevidencelink;
    @JsonProperty("doc-remarks") 
    String docremarks;
    @JsonProperty("doc-reason-code") 
    String docreasoncode;
    @JsonProperty("expiry-check-override") 
    String expirycheckoverride;
    @JsonProperty("poi-document") 
    String poidocument;
    @JsonProperty("document-due-date") 
    String documentduedate;
    @JsonProperty("sender-id") 
    String senderid;
    @JsonProperty("sender-branch") 
    String senderbranch;
    @JsonProperty("created-at") 
    String createdat;
    @JsonProperty("updated-at") 
    String updatedat;
    @JsonProperty("status") 
    String status;
    @JsonProperty("status-at") 
    String statusat;
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getReferenceid() {
        return referenceid;
    }
    public void setReferenceid(String referenceid) {
        this.referenceid = referenceid;
    }
    public String getDocumenttype() {
        return documenttype;
    }
    public void setDocumenttype(String documenttype) {
        this.documenttype = documenttype;
    }
    public String getDocumentcode() {
        return documentcode;
    }
    public void setDocumentcode(String documentcode) {
        this.documentcode = documentcode;
    }
    public String getDocumentnumber() {
        return documentnumber;
    }
    public void setDocumentnumber(String documentnumber) {
        this.documentnumber = documentnumber;
    }
    public String getDocumentreceivedt() {
        return documentreceivedt;
    }
    public void setDocumentreceivedt(String documentreceivedt) {
        this.documentreceivedt = documentreceivedt;
    }
    public String getDocumentsignatorydt() {
        return documentsignatorydt;
    }
    public void setDocumentsignatorydt(String documentsignatorydt) {
        this.documentsignatorydt = documentsignatorydt;
    }
    public String getDocumentexpirydt() {
        return documentexpirydt;
    }
    public void setDocumentexpirydt(String documentexpirydt) {
        this.documentexpirydt = documentexpirydt;
    }
    public String getTaxresidencecountry() {
        return taxresidencecountry;
    }
    public void setTaxresidencecountry(String taxresidencecountry) {
        this.taxresidencecountry = taxresidencecountry;
    }
    public String getW8nsupportdocumentindicator() {
        return w8nsupportdocumentindicator;
    }
    public void setW8nsupportdocumentindicator(String w8nsupportdocumentindicator) {
        this.w8nsupportdocumentindicator = w8nsupportdocumentindicator;
    }
    public String getCountrytreaty() {
        return countrytreaty;
    }
    public void setCountrytreaty(String countrytreaty) {
        this.countrytreaty = countrytreaty;
    }
    public String getDocumentevidencelink() {
        return documentevidencelink;
    }
    public void setDocumentevidencelink(String documentevidencelink) {
        this.documentevidencelink = documentevidencelink;
    }
    public String getDocremarks() {
        return docremarks;
    }
    public void setDocremarks(String docremarks) {
        this.docremarks = docremarks;
    }
    public String getDocreasoncode() {
        return docreasoncode;
    }
    public void setDocreasoncode(String docreasoncode) {
        this.docreasoncode = docreasoncode;
    }
    public String getExpirycheckoverride() {
        return expirycheckoverride;
    }
    public void setExpirycheckoverride(String expirycheckoverride) {
        this.expirycheckoverride = expirycheckoverride;
    }
    public String getPoidocument() {
        return poidocument;
    }
    public void setPoidocument(String poidocument) {
        this.poidocument = poidocument;
    }
    public String getDocumentduedate() {
        return documentduedate;
    }
    public void setDocumentduedate(String documentduedate) {
        this.documentduedate = documentduedate;
    }
    public String getSenderid() {
        return senderid;
    }
    public void setSenderid(String senderid) {
        this.senderid = senderid;
    }
    public String getSenderbranch() {
        return senderbranch;
    }
    public void setSenderbranch(String senderbranch) {
        this.senderbranch = senderbranch;
    }
    public String getCreatedat() {
        return createdat;
    }
    public void setCreatedat(String createdat) {
        this.createdat = createdat;
    }
    public String getUpdatedat() {
        return updatedat;
    }
    public void setUpdatedat(String updatedat) {
        this.updatedat = updatedat;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getStatusat() {
        return statusat;
    }
    public void setStatusat(String statusat) {
        this.statusat = statusat;
    }
}