package com.scb.clm.services.companysearch.chekk.v1.service;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.scb.clm.services.companysearch.chekk.v1.exception.ChkTknExpiredException;
import com.scb.clm.services.companysearch.chekk.v1.model.ChkCognitoTokenResponse;
import com.scb.clm.services.companysearch.chekk.v1.model.ChkLoginResponse;
import com.scb.clm.services.companysearch.chekk.v1.support.Log;
import com.scb.clm.services.companysearch.chekk.v1.support.ProcessApiConstants;
import com.scb.clm.services.companysearch.chekk.v1.support.Retrier;

/**
 * @author 1394842
 * 
 */
@Service
public class ChkTokenManager {

	public enum TokenType {
		COGNITO, LOGIN;
	}

	private final ConcurrentHashMap<TokenType, CachedToken> tokenCache = new ConcurrentHashMap<>();

	private ChkAuthApiClient authApiClient;

	@Autowired
	public void setAuthApiClient(ChkAuthApiClient authApiClient) {
		this.authApiClient = authApiClient;
	}

	/**
	 * returns validated cognito and login token in map, otherwise throws exception.
	 * 
	 * @return
	 */
	public Map<String, String> getChkTokenHeaders() {
		Map<String, String> tokenHeaders = new HashMap<>();
		if (tokenCache.isEmpty()) {
			// generate both tokens
			generateCognitoToken();
		}
		tokenHeaders.put(ProcessApiConstants.XAUTHORIZATION,
				ProcessApiConstants.BEARER + ProcessApiConstants.SINGLE_SPACE + getAccessToken(TokenType.COGNITO));
		tokenHeaders.put(ProcessApiConstants.AUTHORIZATION,
				ProcessApiConstants.BEARER + ProcessApiConstants.SINGLE_SPACE + getAccessToken(TokenType.LOGIN));
		return tokenHeaders;
	}

	/**
	 * Checks if cognito token and login token exists in cache and valid. Otherwise
	 * creates/refresh tokens and sets in the cache. Throws error if any exception
	 * in retrieving the tokens from Chekk.
	 */
	private void validateTokens() {
		if (!tokenCache.isEmpty()) {
			String cognitoAccessToken = getAccessToken(TokenType.COGNITO);
			String loginAccessToken = getAccessToken(TokenType.LOGIN);

		} else {
			// generate token and add to cache
			generateCognitoToken();
		}
		/**
		 * if cognitoToken is not null and valid do nothing else refresh cognitoToken
		 * and set to cache refresh loginToken and set to cache stop
		 * 
		 * if loginToken is not null and valid do nothing else refresh loginToken and
		 * set to cache
		 * 
		 */
	}

	private String getAccessToken(TokenType tokenType) {
		String accessToken = "";
		CachedToken cachedTkn = tokenCache.get(tokenType);
		if (cachedTkn != null && cachedTkn.isValid()) {
			accessToken = cachedTkn.accessToken;
		} else {
			accessToken = generateToken(tokenType);
		}
		return accessToken;
	}

	/**
	 * Refresh cached login token whenever cognito token is regenerated
	 * 
	 * @param tokenType
	 * @return
	 */
	private String generateToken(TokenType tokenType) {
		String loginAccessToken = "";
		String cognitoAccessTkn = "";
		if (tokenType == TokenType.COGNITO) {
			CachedToken cognitoCache = generateCognitoToken();
			cognitoAccessTkn = cognitoCache.accessToken;
			addOrUpdateToken(TokenType.COGNITO, cognitoCache);
		}
		loginAccessToken = new Retrier<String, String>("input", input -> {
			String cachedCognitoTkn = getAccessToken(TokenType.COGNITO);
			CachedToken cachedLoginTkn = generateLoginToken(cachedCognitoTkn);
			addOrUpdateToken(TokenType.LOGIN, cachedLoginTkn);
			return cachedLoginTkn.accessToken;
		}).execute(Arrays.asList(ChkTknExpiredException.class));
		return tokenType == TokenType.LOGIN ? loginAccessToken : cognitoAccessTkn;
	}

	/**
	 * <p>
	 * This method must be called only from scheduler to periodically check and
	 * refresh both cognito and login tokens N mts before next expiration.
	 * </p>
	 * 
	 * 
	 */
	public void generateToken(int intervalInMts) {
		Log.info("ChkTokenManager#generateToken: Inside generateToken called from scheduler service");

		CachedToken cachedTkn = tokenCache.get(TokenType.COGNITO);
		if(cachedTkn==null || cachedTkn.checkIfTokenExpiresSoon(intervalInMts) ) {
			generateToken(TokenType.COGNITO);
		}
	}
	
	private void addOrUpdateToken(TokenType tokenType, CachedToken cachedToken) {
		tokenCache.put(tokenType, cachedToken);
	}

	private CachedToken generateCognitoToken() {
		ChkCognitoTokenResponse cognitoTknRes = authApiClient.invokeCognitoApi();
		return new CachedToken(cognitoTknRes.getAccessToken(), cognitoTknRes.getExpiresIn(),
				cognitoTknRes.getTokenType());
	}

	private CachedToken generateLoginToken(String accessToken) {

		ChkLoginResponse loginRes = authApiClient.invokeLoginApi(accessToken);
		return new CachedToken(loginRes.getAccessToken(), loginRes.getExpiresIn(), loginRes.getTokenType());
	}

	private static class CachedToken {
		private final String accessToken;
		private final long expiresIn;
		private final String tokenType;
		private final String refreshToken;

		/*
		 * calculate and store this value
		 */
		private final long expirationTime;

		/**
		 * access_token expires_in token_type error refresh_token scope
		 */
		public CachedToken(String accessToken, long expiresIn, String tokenType) {
			this(accessToken, expiresIn, tokenType, null);
		}

		public CachedToken(String accessToken, long expiresIn, String tokenType, String refreshToken) {
			this.accessToken = accessToken;
			this.expiresIn = expiresIn;
			this.tokenType = tokenType;
			this.refreshToken = refreshToken;
			this.expirationTime = calculateExpirationTime(expiresIn);
		}

		private long calculateExpirationTime(long expiresAt) {
			return System.currentTimeMillis() + (expiresAt * 1000) - 1000;
		}

		public boolean isValid() {
			return System.currentTimeMillis() < expirationTime;
		}
		
		public boolean checkIfTokenExpiresSoon(int nMinutes) {
			long currentTime = System.currentTimeMillis();
			// convert N minutes to milliseconds
			long thresholdTime = currentTime + nMinutes * 60 * 1000;
			return expirationTime <= thresholdTime;
		}
	}

}
