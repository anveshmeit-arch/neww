package com.scb.clm.services.globus.icm.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ICMCustomerCreateResponseWrapper {

    @JsonProperty("data")
    private ICMCustomerCreateResponseData data;

    public ICMCustomerCreateResponseData getData() {
        return data;
    }

    public void setData(ICMCustomerCreateResponseData data) {
        this.data = data;
    }


}
