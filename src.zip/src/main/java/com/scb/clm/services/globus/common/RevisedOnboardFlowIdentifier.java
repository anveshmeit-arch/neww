package com.scb.clm.services.globus.common;

import org.springframework.stereotype.Service;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.util.JSONUtility;
import com.scb.clm.core.service.FlowIdentifierInterface;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardReqWrapper;

@Service
public class RevisedOnboardFlowIdentifier implements FlowIdentifierInterface
{
    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
	@Override	
	public String extractFlowIdentifier(TravellingObject travelObj) throws ProcessException
	{
	    LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "extractFlowIdentifier", LogType.APPLICATION.name());
		try
		{
			GBSOnboardReqWrapper requestWrapper = (GBSOnboardReqWrapper) JSONUtility.jsonTODomainWrapper(travelObj.getRequestData(),GBSOnboardReqWrapper.class);
			if(requestWrapper == null || requestWrapper.getGbs_Onboard_ApplnWrapper() == null)
			{
				log.printError("Request Wrapper or GBS Onboard Application Wrapper is null / Incorrect Request Format");
				throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL, BaseConstants.VALIDATION_ERROR,"[Revised Flow Identifier] Invalid Request Format");
			}
			return requestWrapper.getGbs_Onboard_ApplnWrapper().getFlowIdentifier();
		}
		catch(Exception e)
		{
			log.printErrorMessage(e);
			throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL, BaseConstants.VALIDATION_ERROR,"[Revised Flow Identifier] Invalid Request Format");
		}
	}
}
