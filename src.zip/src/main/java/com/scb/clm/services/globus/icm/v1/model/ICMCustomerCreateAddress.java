package com.scb.clm.services.globus.icm.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ICMCustomerCreateAddress {

    @JsonProperty("address-type")
    private String addressType;

    @JsonProperty("address-line1")
    private String address1;

    @JsonProperty("address-line2")
    private String address2;

    @JsonProperty("address-line3")
    private String address3;

    @JsonProperty("city-name")
    private String cityName;

    @JsonProperty("state")
    private String state;

    @JsonProperty("country-code")
    private String countryCode;

    @JsonProperty("postal-code")
    private String postalCode;

    @JsonProperty("nearest-land-mark")
    private String nearestLandMark;

    @JsonProperty("address-invalid-indicator")
    private String isWAUFlag;

    @JsonProperty("alert-required-for-address-amendment")
    private String addrAmendAlertInd;

    @JsonProperty("alert-suppress-reason-code")
    private String alertSuppressReasonCode;

    @JsonProperty("is-mailing-address")
    private String mailAddrInd;

    @JsonProperty("post-box-no")
    private String postBoxNo;

    @JsonProperty("poa-document")
    private String poaDocument;

    @JsonProperty("consolidate-statement-flag")
    private String consolidateStatementFlag;

    @JsonProperty("return-mail-counter")
    private short returnMailCounter;

    @JsonProperty("reset-return-mail-counter")
    private String resetRMailFlag;

    @JsonProperty("state-code")
    private String stateCode;

    @JsonProperty("lang-id")
    private String langID;

    @JsonProperty("sender-id")
    private String senderId;

    @JsonProperty("sender-branch")
    private String senderBranch;

    @JsonProperty("address-classification-code")
    private String addressClassification;

    @JsonProperty("id")
    private String  guid;

    @JsonProperty("reference-id")
    private String profileId;

    @JsonProperty("local-govt-area")
    private String localGovernmentAreaCode;


    public String getAddressType() {
        return addressType;
    }

    public void setAddressType(String addressType) {
        this.addressType = addressType;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getAddress3() {
        return address3;
    }

    public void setAddress3(String address3) {
        this.address3 = address3;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getNearestLandMark() {
        return nearestLandMark;
    }

    public void setNearestLandMark(String nearestLandMark) {
        this.nearestLandMark = nearestLandMark;
    }

    public String getIsWAUFlag() {
        return isWAUFlag;
    }

    public void setIsWAUFlag(String isWAUFlag) {
        this.isWAUFlag = isWAUFlag;
    }

    public String getAddrAmendAlertInd() {
        return addrAmendAlertInd;
    }

    public void setAddrAmendAlertInd(String addrAmendAlertInd) {
        this.addrAmendAlertInd = addrAmendAlertInd;
    }

    public String getAlertSuppressReasonCode() {
        return alertSuppressReasonCode;
    }

    public void setAlertSuppressReasonCode(String alertSuppressReasonCode) {
        this.alertSuppressReasonCode = alertSuppressReasonCode;
    }

    public String getMailAddrInd() {
        return mailAddrInd;
    }

    public void setMailAddrInd(String mailAddrInd) {
        this.mailAddrInd = mailAddrInd;
    }

    public String getPostBoxNo() {
        return postBoxNo;
    }

    public void setPostBoxNo(String postBoxNo) {
        this.postBoxNo = postBoxNo;
    }

    public String getPoaDocument() {
        return poaDocument;
    }

    public void setPoaDocument(String poaDocument) {
        this.poaDocument = poaDocument;
    }

    public String getConsolidateStatementFlag() {
        return consolidateStatementFlag;
    }

    public void setConsolidateStatementFlag(String consolidateStatementFlag) {
        this.consolidateStatementFlag = consolidateStatementFlag;
    }

    public short getReturnMailCounter() {
        return returnMailCounter;
    }

    public void setReturnMailCounter(short returnMailCounter) {
        this.returnMailCounter = returnMailCounter;
    }

    public String getResetRMailFlag() {
        return resetRMailFlag;
    }

    public void setResetRMailFlag(String resetRMailFlag) {
        this.resetRMailFlag = resetRMailFlag;
    }

    public String getStateCode() {
        return stateCode;
    }

    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    public String getLangID() {
        return langID;
    }

    public void setLangID(String langID) {
        this.langID = langID;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public String getSenderBranch() {
        return senderBranch;
    }

    public void setSenderBranch(String senderBranch) {
        this.senderBranch = senderBranch;
    }

    public String getAddressClassification() {
        return addressClassification;
    }

    public void setAddressClassification(String addressClassification) {
        this.addressClassification = addressClassification;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getLocalGovernmentAreaCode() {
        return localGovernmentAreaCode;
    }

    public void setLocalGovernmentAreaCode(String localGovernmentAreaCode) {
        this.localGovernmentAreaCode = localGovernmentAreaCode;
    }
}
