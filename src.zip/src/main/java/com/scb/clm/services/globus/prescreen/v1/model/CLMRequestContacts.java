package com.scb.clm.services.globus.prescreen.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CLMRequestContacts 
{
    @JsonProperty("id") 
    String id;
    @JsonProperty("reference-id") 
    String referenceid;
    @JsonProperty("contact") 
    String contact;
    @JsonProperty("sequence-number") 
    String sequencenumber;
    @JsonProperty("contact-classification-code") 
    String contactclassificationcode;
    @JsonProperty("contact-type-code") 
    String contacttypecode;
    @JsonProperty("country-code") 
    String countrycode;
    @JsonProperty("area-code") 
    String areacode;
    @JsonProperty("home-office-identifier") 
    String homeofficeidentifier;
    @JsonProperty("extension-det") 
    String extensiondet;
    @JsonProperty("reference") 
    String reference;
    @JsonProperty("preferred-contact") 
    String preferredcontact;
    @JsonProperty("primary-contact") 
    String primarycontact;
    @JsonProperty("contact-invalid-indicator") 
    String contactinvalidindicator;
    @JsonProperty("alert-required-for-contact-amendment") 
    String alertrequiredforcontactamendment;
    @JsonProperty("alert-suppress-reason-code") 
    String alertsuppressreasoncode;
    @JsonProperty("do-not-disturb-registry") 
    String donotdisturbregistry;
    @JsonProperty("do-not-disturb-last-updated-date") 
    String donotdisturblastupdateddate;
    @JsonProperty("do-not-disturb-expiry-date") 
    String donotdisturbexpirydate;
    @JsonProperty("attention-party") 
    String attentionparty;
    @JsonProperty("sender-id") 
    String senderid;
    @JsonProperty("sender-branch") 
    String senderbranch;
    @JsonProperty("created-at") 
    String createdat;
    @JsonProperty("updated-at") 
    String updatedat;
    @JsonProperty("status") 
    String status;
    @JsonProperty("status-at") 
    String statusat;
    @JsonProperty("custom-contact-no") 
    String customcontactno;
    @JsonProperty("isd-contact-country-code") 
    String isdcontactcountrycode;
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getReferenceid() {
        return referenceid;
    }
    public void setReferenceid(String referenceid) {
        this.referenceid = referenceid;
    }
    public String getContact() {
        return contact;
    }
    public void setContact(String contact) {
        this.contact = contact;
    }
    public String getSequencenumber() {
        return sequencenumber;
    }
    public void setSequencenumber(String sequencenumber) {
        this.sequencenumber = sequencenumber;
    }
    public String getContactclassificationcode() {
        return contactclassificationcode;
    }
    public void setContactclassificationcode(String contactclassificationcode) {
        this.contactclassificationcode = contactclassificationcode;
    }
    public String getContacttypecode() {
        return contacttypecode;
    }
    public void setContacttypecode(String contacttypecode) {
        this.contacttypecode = contacttypecode;
    }
    public String getCountrycode() {
        return countrycode;
    }
    public void setCountrycode(String countrycode) {
        this.countrycode = countrycode;
    }
    public String getAreacode() {
        return areacode;
    }
    public void setAreacode(String areacode) {
        this.areacode = areacode;
    }
    public String getHomeofficeidentifier() {
        return homeofficeidentifier;
    }
    public void setHomeofficeidentifier(String homeofficeidentifier) {
        this.homeofficeidentifier = homeofficeidentifier;
    }
    public String getExtensiondet() {
        return extensiondet;
    }
    public void setExtensiondet(String extensiondet) {
        this.extensiondet = extensiondet;
    }
    public String getReference() {
        return reference;
    }
    public void setReference(String reference) {
        this.reference = reference;
    }
    public String getPreferredcontact() {
        return preferredcontact;
    }
    public void setPreferredcontact(String preferredcontact) {
        this.preferredcontact = preferredcontact;
    }
    public String getPrimarycontact() {
        return primarycontact;
    }
    public void setPrimarycontact(String primarycontact) {
        this.primarycontact = primarycontact;
    }
    public String getContactinvalidindicator() {
        return contactinvalidindicator;
    }
    public void setContactinvalidindicator(String contactinvalidindicator) {
        this.contactinvalidindicator = contactinvalidindicator;
    }
    public String getAlertrequiredforcontactamendment() {
        return alertrequiredforcontactamendment;
    }
    public void setAlertrequiredforcontactamendment(String alertrequiredforcontactamendment) {
        this.alertrequiredforcontactamendment = alertrequiredforcontactamendment;
    }
    public String getAlertsuppressreasoncode() {
        return alertsuppressreasoncode;
    }
    public void setAlertsuppressreasoncode(String alertsuppressreasoncode) {
        this.alertsuppressreasoncode = alertsuppressreasoncode;
    }
    public String getDonotdisturbregistry() {
        return donotdisturbregistry;
    }
    public void setDonotdisturbregistry(String donotdisturbregistry) {
        this.donotdisturbregistry = donotdisturbregistry;
    }
    public String getDonotdisturblastupdateddate() {
        return donotdisturblastupdateddate;
    }
    public void setDonotdisturblastupdateddate(String donotdisturblastupdateddate) {
        this.donotdisturblastupdateddate = donotdisturblastupdateddate;
    }
    public String getDonotdisturbexpirydate() {
        return donotdisturbexpirydate;
    }
    public void setDonotdisturbexpirydate(String donotdisturbexpirydate) {
        this.donotdisturbexpirydate = donotdisturbexpirydate;
    }
    public String getAttentionparty() {
        return attentionparty;
    }
    public void setAttentionparty(String attentionparty) {
        this.attentionparty = attentionparty;
    }
    public String getSenderid() {
        return senderid;
    }
    public void setSenderid(String senderid) {
        this.senderid = senderid;
    }
    public String getSenderbranch() {
        return senderbranch;
    }
    public void setSenderbranch(String senderbranch) {
        this.senderbranch = senderbranch;
    }
    public String getCreatedat() {
        return createdat;
    }
    public void setCreatedat(String createdat) {
        this.createdat = createdat;
    }
    public String getUpdatedat() {
        return updatedat;
    }
    public void setUpdatedat(String updatedat) {
        this.updatedat = updatedat;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getStatusat() {
        return statusat;
    }
    public void setStatusat(String statusat) {
        this.statusat = statusat;
    }
    public String getCustomcontactno() {
        return customcontactno;
    }
    public void setCustomcontactno(String customcontactno) {
        this.customcontactno = customcontactno;
    }
    public String getIsdcontactcountrycode() {
        return isdcontactcountrycode;
    }
    public void setIsdcontactcountrycode(String isdcontactcountrycode) {
        this.isdcontactcountrycode = isdcontactcountrycode;
    }
}