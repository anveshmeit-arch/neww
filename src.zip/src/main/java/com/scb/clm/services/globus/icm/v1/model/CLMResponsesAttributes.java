package com.scb.clm.services.globus.icm.v1.model;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CLMResponsesAttributes {

	@JsonProperty("service-indicator-code")
	private String serviceIndicatorCode;

	@JsonProperty("close-reason-code")
	private String closeReasonCode;
	
	
	@JsonProperty("group-id")
	private String groupId;

	@JsonProperty("checker-department-code")
	private String departmentCode;

	@JsonProperty("referred-by-relationship-name")
	private String referredByRelationshipName;

	@JsonProperty("customer-nationality-code")
	private String customerNationalityCode;

	@JsonProperty("closing-id")
	private String closingId;

	@JsonProperty("tracking-id")
	private String trackingId;

	@JsonProperty("last-name-override-flag")
	private String lastNameOverrideFlag;

	@JsonProperty("salutation-code")
	private String salutationCode;

	

	@JsonProperty("middle-name")
	String middlename;

	@JsonProperty("senior-citizen-flag")
	private String seniorCitizenFlag;
    
	
	@JsonProperty("deepening-flag")
	private String deepeningFlag;

	@JsonProperty("aux_CustomerGBAFlag")
	private String auxCustomerGBAFlag;

	@JsonProperty("aux_GBA Southbound")
	private String auxGBASouthbound;

	@JsonProperty("aux_CARM Code")
	private String auxCARMCode;

	@JsonProperty("aux_International Mobile Preference flag")
	private String auxInternationalMobilePreferenceFlag;

	@JsonProperty("first-name")
	private String firstName;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	@JsonProperty("last-status-change-date")
	private Date lastStatusChangeDate;

	@JsonProperty("home-branch")
	private String homeBranch;

	@JsonProperty("group-name")
	private String groupName;

	@JsonProperty("auxmap")
	private List<ICMCustomerCreateAuxiliary> auxiliary;

	@JsonProperty("previous-core-banking-id")
	String previousCoreBankingId;

	@JsonProperty("reopen-counter")
	private short reOpenCounter;

	@JsonProperty("interface-id")
	private String interfaceId;

	@JsonProperty("request-country-code")
	private String countrycode;

	@JsonProperty("status")
	private String status;

	@JsonProperty("arm-code")
	private String armCode;

	@JsonProperty("gender")
	private String gender;

	@JsonProperty("bsbda-flag")
	private String isBSBDACustomer;

	@JsonProperty("referred-by-relationship-no")
	private String referredByRelationshipNo;

	@JsonProperty("aux_GBA Northbound")
	private String auxGBANorthbound;

	@JsonProperty("miscmap")
	private String miscMap;

	@JsonProperty("referral-id")
	private String referralId;

	@JsonProperty("full-name-override-flag")
	private String fullNameOverride;

	@JsonProperty("full-name")
	private String fullName;

	@JsonProperty("segment-code")
	private String segmentCode;

	@JsonProperty("reference-id")
	private String profileId;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	@JsonProperty("date-of-birth")
	private Date dateOfBirth;

	private List<ErrorDetails> errordetails;

	@JsonProperty("resident-country")
	private String residentCountry;

	
	 public String getCddRiskCode() {
		return cddRiskCode;
	}

	public void setCddRiskCode(String cddRiskCode) {
		this.cddRiskCode = cddRiskCode;
	}

	public Date getCddNextReviewDt() {
		return cddNextReviewDt;
	}

	public void setCddNextReviewDt(Date cddNextReviewDt) {
		this.cddNextReviewDt = cddNextReviewDt;
	}

	public String getCddReviewStatus() {
		return cddReviewStatus;
	}

	public void setCddReviewStatus(String cddReviewStatus) {
		this.cddReviewStatus = cddReviewStatus;
	}

	public String getCddReason() {
		return cddReason;
	}

	public void setCddReason(String cddReason) {
		this.cddReason = cddReason;
	}

	public String getSddEligibleStatus() {
		return sddEligibleStatus;
	}

	public void setSddEligibleStatus(String sddEligibleStatus) {
		this.sddEligibleStatus = sddEligibleStatus;
	}

	public Date getSddEligibleDate() {
		return sddEligibleDate;
	}

	public void setSddEligibleDate(Date sddEligibleDate) {
		this.sddEligibleDate = sddEligibleDate;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getIcddReferenceNumber() {
		return icddReferenceNumber;
	}

	public void setIcddReferenceNumber(String icddReferenceNumber) {
		this.icddReferenceNumber = icddReferenceNumber;
	}

	public String getCupidReferenceNumber() {
		return cupidReferenceNumber;
	}

	public void setCupidReferenceNumber(String cupidReferenceNumber) {
		this.cupidReferenceNumber = cupidReferenceNumber;
	}

	public Date getCddRiskRatingDate() {
		return cddRiskRatingDate;
	}

	public void setCddRiskRatingDate(Date cddRiskRatingDate) {
		this.cddRiskRatingDate = cddRiskRatingDate;
	}

	public Date getCountryLRD() {
		return countryLRD;
	}

	public void setCountryLRD(Date countryLRD) {
		this.countryLRD = countryLRD;
	}

	public Date getCountryNRD() {
		return countryNRD;
	}

	public void setCountryNRD(Date countryNRD) {
		this.countryNRD = countryNRD;
	}

	public String getCountryReviewStatus() {
		return countryReviewStatus;
	}

	public void setCountryReviewStatus(String countryReviewStatus) {
		this.countryReviewStatus = countryReviewStatus;
	}

	public String getCddReviewedFlag() {
		return cddReviewedFlag;
	}

	public void setCddReviewedFlag(String cddReviewedFlag) {
		this.cddReviewedFlag = cddReviewedFlag;
	}

	public String getSenderBranch() {
		return senderBranch;
	}

	public void setSenderBranch(String senderBranch) {
		this.senderBranch = senderBranch;
	}

	public Timestamp getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Timestamp createdAt) {
		this.createdAt = createdAt;
	}

	public Timestamp getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Timestamp updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Timestamp getStatusAt() {
		return statusAt;
	}

	public void setStatusAt(Timestamp statusAt) {
		this.statusAt = statusAt;
	}

	public String getGuid() {
		return guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}

	public String getCrsRemarks() {
		return crsRemarks;
	}

	public void setCrsRemarks(String crsRemarks) {
		this.crsRemarks = crsRemarks;
	}

	public String getCrsStatus() {
		return crsStatus;
	}

	public void setCrsStatus(String crsStatus) {
		this.crsStatus = crsStatus;
	}

	public String getCrsCreatedTimeStamp() {
		return crsCreatedTimeStamp;
	}

	public void setCrsCreatedTimeStamp(String crsCreatedTimeStamp) {
		this.crsCreatedTimeStamp = crsCreatedTimeStamp;
	}

	@JsonProperty("cdd-risk-rating")
	    private String cddRiskCode;

	    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	    @JsonProperty("cdd-last-review-date")
	    private Date cddLastReviewDt;

	    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	    @JsonProperty("cdd-next-review-date")
	    private Date cddNextReviewDt;

	    @JsonProperty("cdd-review-status")
	    private String cddReviewStatus;

	    @JsonProperty("cdd-reason")
	    private String cddReason;

	    @JsonProperty("sdd-eligible-status")
	    private String sddEligibleStatus;

	    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	    @JsonProperty("sdd-eligible-date")
	    private Date sddEligibleDate;

	    @JsonProperty("country-id")
	    private String companyId;

	    @JsonProperty("icdd-reference")
	    private String icddReferenceNumber;

	    @JsonProperty("cupid-reference")
	    private String cupidReferenceNumber;

	    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	    @JsonProperty("cdd-risk-rating-date")
	    private Date cddRiskRatingDate;

	    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	    @JsonProperty("country-last-review-date")
	    private Date countryLRD;

	    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	    @JsonProperty("country-next-review-date")
	    private Date countryNRD;

	    @JsonProperty("country-review-status")
	    private String countryReviewStatus;

	    @JsonProperty("cdd-reviewed-flag")
	    private String cddReviewedFlag;

	    @JsonProperty("cdd-last-reviewed-by")
	    private String cddLastReviewedBy;

	    @JsonProperty("sender-id")
	    private String senderId;

	    @JsonProperty("sender-branch")
	    private String senderBranch;

	    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	    @JsonProperty("created-at")
	    private Timestamp createdAt;

	    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	    @JsonProperty("updated-at")
	    private Timestamp updatedAt;



	    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	    @JsonProperty("status-at")
	    private Timestamp statusAt;

	    @JsonProperty("id")
	    private String guid;

	   
	    @JsonProperty("crs-remarks")
	    private String crsRemarks;

	    @JsonProperty("crs-status")
	    private String crsStatus;

	    @JsonProperty("crs-created-time-tamp")
	    private String crsCreatedTimeStamp;

	   

	

	@JsonProperty("crs-updated-time-stamp")
	private String crsUpdatedTimeStamp;

	

	@JsonProperty("crs-reference")
	private String crsReference;
	
	 


	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public Date getLastStatusChangeDate() {
		return lastStatusChangeDate;
	}

	public void setLastStatusChangeDate(Date lastStatusChangeDate) {
		this.lastStatusChangeDate = lastStatusChangeDate;
	}

	public String getHomeBranch() {
		return homeBranch;
	}

	public void setHomeBranch(String homeBranch) {
		this.homeBranch = homeBranch;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public List<ICMCustomerCreateAuxiliary> getAuxiliary() {
		return auxiliary;
	}

	public void setAuxiliary(List<ICMCustomerCreateAuxiliary> auxiliary) {
		this.auxiliary = auxiliary;
	}

	public String getPreviousCoreBankingId() {
		return previousCoreBankingId;
	}

	public void setPreviousCoreBankingId(String previousCoreBankingId) {
		this.previousCoreBankingId = previousCoreBankingId;
	}

	public short getReOpenCounter() {
		return reOpenCounter;
	}

	public void setReOpenCounter(short reOpenCounter) {
		this.reOpenCounter = reOpenCounter;
	}

	public String getInterfaceId() {
		return interfaceId;
	}

	public void setInterfaceId(String interfaceId) {
		this.interfaceId = interfaceId;
	}

	public String getCountrycode() {
		return countrycode;
	}

	public void setCountrycode(String countrycode) {
		this.countrycode = countrycode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getArmCode() {
		return armCode;
	}

	public void setArmCode(String armCode) {
		this.armCode = armCode;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getIsBSBDACustomer() {
		return isBSBDACustomer;
	}

	public void setIsBSBDACustomer(String isBSBDACustomer) {
		this.isBSBDACustomer = isBSBDACustomer;
	}

	public String getReferredByRelationshipNo() {
		return referredByRelationshipNo;
	}

	public void setReferredByRelationshipNo(String referredByRelationshipNo) {
		this.referredByRelationshipNo = referredByRelationshipNo;
	}

	public String getAuxGBANorthbound() {
		return auxGBANorthbound;
	}

	public void setAuxGBANorthbound(String auxGBANorthbound) {
		this.auxGBANorthbound = auxGBANorthbound;
	}

	public String getMiscMap() {
		return miscMap;
	}

	public void setMiscMap(String miscMap) {
		this.miscMap = miscMap;
	}

	public String getReferralId() {
		return referralId;
	}

	public void setReferralId(String referralId) {
		this.referralId = referralId;
	}

	public String getFullNameOverride() {
		return fullNameOverride;
	}

	public void setFullNameOverride(String fullNameOverride) {
		this.fullNameOverride = fullNameOverride;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getSegmentCode() {
		return segmentCode;
	}

	public void setSegmentCode(String segmentCode) {
		this.segmentCode = segmentCode;
	}

	public String getProfileId() {
		return profileId;
	}

	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public List<ErrorDetails> getErrordetails() {
		return errordetails;
	}

	public void setErrordetails(List<ErrorDetails> errordetails) {
		this.errordetails = errordetails;
	}

	public String getResidentCountry() {
		return residentCountry;
	}

	public void setResidentCountry(String residentCountry) {
		this.residentCountry = residentCountry;
	}

	public String getSenderId() {
		return senderId;
	}

	public void setSenderId(String senderId) {
		this.senderId = senderId;
	}

	public Date getCddLastReviewDt() {
		return cddLastReviewDt;
	}

	public void setCddLastReviewDt(Date cddLastReviewDt) {
		this.cddLastReviewDt = cddLastReviewDt;
	}

	public String getCrsUpdatedTimeStamp() {
		return crsUpdatedTimeStamp;
	}

	public void setCrsUpdatedTimeStamp(String crsUpdatedTimeStamp) {
		this.crsUpdatedTimeStamp = crsUpdatedTimeStamp;
	}

	public String getCddLastReviewedBy() {
		return cddLastReviewedBy;
	}

	public void setCddLastReviewedBy(String cddLastReviewedBy) {
		this.cddLastReviewedBy = cddLastReviewedBy;
	}

	public String getCrsReference() {
		return crsReference;
	}

	public void setCrsReference(String crsReference) {
		this.crsReference = crsReference;
	}

	public String getServiceIndicatorCode() {
		return serviceIndicatorCode;
	}

	public void setServiceIndicatorCode(String serviceIndicatorCode) {
		this.serviceIndicatorCode = serviceIndicatorCode;
	}

	public String getCloseReasonCode() {
		return closeReasonCode;
	}

	public void setCloseReasonCode(String closeReasonCode) {
		this.closeReasonCode = closeReasonCode;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getDepartmentCode() {
		return departmentCode;
	}

	public void setDepartmentCode(String departmentCode) {
		this.departmentCode = departmentCode;
	}

	public String getReferredByRelationshipName() {
		return referredByRelationshipName;
	}

	public void setReferredByRelationshipName(String referredByRelationshipName) {
		this.referredByRelationshipName = referredByRelationshipName;
	}

	public String getCustomerNationalityCode() {
		return customerNationalityCode;
	}

	public void setCustomerNationalityCode(String customerNationalityCode) {
		this.customerNationalityCode = customerNationalityCode;
	}

	public String getClosingId() {
		return closingId;
	}

	public void setClosingId(String closingId) {
		this.closingId = closingId;
	}

	public String getTrackingId() {
		return trackingId;
	}

	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}

	public String getLastNameOverrideFlag() {
		return lastNameOverrideFlag;
	}

	public void setLastNameOverrideFlag(String lastNameOverrideFlag) {
		this.lastNameOverrideFlag = lastNameOverrideFlag;
	}

	public String getSalutationCode() {
		return salutationCode;
	}

	public void setSalutationCode(String salutationCode) {
		this.salutationCode = salutationCode;
	}

	
	public String getMiddlename() {
		return middlename;
	}

	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}

	public String getSeniorCitizenFlag() {
		return seniorCitizenFlag;
	}

	public void setSeniorCitizenFlag(String seniorCitizenFlag) {
		this.seniorCitizenFlag = seniorCitizenFlag;
	}

	public String getDeepeningFlag() {
		return deepeningFlag;
	}

	public void setDeepeningFlag(String deepeningFlag) {
		this.deepeningFlag = deepeningFlag;
	}

	public String getAuxCustomerGBAFlag() {
		return auxCustomerGBAFlag;
	}

	public void setAuxCustomerGBAFlag(String auxCustomerGBAFlag) {
		this.auxCustomerGBAFlag = auxCustomerGBAFlag;
	}

	public String getAuxGBASouthbound() {
		return auxGBASouthbound;
	}

	public void setAuxGBASouthbound(String auxGBASouthbound) {
		this.auxGBASouthbound = auxGBASouthbound;
	}

	public String getAuxCARMCode() {
		return auxCARMCode;
	}

	public void setAuxCARMCode(String auxCARMCode) {
		this.auxCARMCode = auxCARMCode;
	}

	public String getAuxInternationalMobilePreferenceFlag() {
		return auxInternationalMobilePreferenceFlag;
	}

	public void setAuxInternationalMobilePreferenceFlag(String auxInternationalMobilePreferenceFlag) {
		this.auxInternationalMobilePreferenceFlag = auxInternationalMobilePreferenceFlag;
	}
	
	

}
