package com.scb.clm.services.companysearch.chekk.v1.model.process;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.scb.clm.services.companysearch.chekk.v1.model.Regulators;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class EntityData {

	@JsonProperty("ENID")
	public String enid;
	@JsonProperty("applicationRefNumber")
	public String applicationRefNumber;
	@JsonProperty("entityTypeCode")
	public String entityTypeCode;
	@JsonProperty("entitySubTypeCode")
	public String entitySubTypeCode;
	@JsonProperty("registrationDate")
	public String registrationDate;
	@JsonProperty("countryOfAccountOpening")
	public String countryOfAccountOpening;
	@JsonProperty("countryOfEstablishment")
	public String countryOfEstablishment;
	@JsonProperty("primaryCountryofOperation")
	public String primaryCountryofOperation;
	@JsonProperty("isUnwrappingCompleted")
	public Boolean isUnwrappingCompleted;
	@JsonProperty("reasonForUnwrappingIncomplete")
	public String[] reasonForUnwrappingIncomplete;
	@JsonProperty("totalUnwrappingPercentage")
	public String totalUnwrappingPercentage;
	@JsonProperty("idCommencementDate")
	public String idCommencementDate;
	@JsonProperty("idRenewalDate")
	public String idRenewalCutOffDate;
	@JsonProperty("idExpiryDate")
	public String idExpiryDate;
	@JsonProperty("issuedShares")
	public List<IssuedShares> issuedShares;
	@JsonProperty("validationStatus")
	public List<ValidationStatus> validationStatus;
	@JsonProperty("names")
	public Names names;
	@JsonProperty("external")
	public External external;
	@JsonProperty("industryClassifications")
	public IndustryClassifications industryClassifications;
	@JsonProperty("group")
	public Group group;
	@JsonProperty("product")
	public Product product;
	@JsonProperty("legalFormation")
	public LegalFormation legalFormation;
	@JsonProperty("addresses")
	public List<Address> addresses;
	@JsonProperty("associations")
	public List<Association> associations;
	@JsonProperty("documents")
	public List<Document> documents;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	@JsonProperty("regulators")
	private Regulators regulators;

}