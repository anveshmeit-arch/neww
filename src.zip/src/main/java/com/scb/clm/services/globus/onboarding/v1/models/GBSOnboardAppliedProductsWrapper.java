package com.scb.clm.services.globus.onboarding.v1.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSOnboardAppliedProductsWrapper {

	
	
	@JsonProperty("productReferenceKey")
	private String productReferenceKey;
	
	@JsonProperty("applicantRole")
	private String applicantRole;
	
	@JsonProperty("accountCurrency")
	private String accountCurrency;
	
	@JsonProperty("productCode")
	private String productCode;
	
	@JsonProperty("subProductCode")
	private String subProductCode;
	
	@JsonProperty("purposeOfAccountOpening")
	private String purposeOfAccountOpening;

    @JsonProperty("purposeOfAccountOpeningOthers")
    private String purposeOfAccountOpeningOthers;
	
	@JsonProperty("amountInitialDeposit")
	private String amountInitialDeposit;
	
	@JsonProperty("currencyInitialDeposit")
	private String currencyInitialDeposit;
	
	@JsonProperty("channelReferenceKey")
	private String channelReferenceKey;

    public String getProductReferenceKey() {
        return productReferenceKey;
    }

    public void setProductReferenceKey(String productReferenceKey) {
        this.productReferenceKey = productReferenceKey;
    }

    public String getApplicantRole() {
        return applicantRole;
    }

    public void setApplicantRole(String applicantRole) {
        this.applicantRole = applicantRole;
    }

    public String getAccountCurrency() {
        return accountCurrency;
    }

    public void setAccountCurrency(String accountCurrency) {
        this.accountCurrency = accountCurrency;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getSubProductCode() {
        return subProductCode;
    }

    public void setSubProductCode(String subProductCode) {
        this.subProductCode = subProductCode;
    }

    public String getPurposeOfAccountOpening() {
        return purposeOfAccountOpening;
    }

    public void setPurposeOfAccountOpening(String purposeOfAccountOpening) {
        this.purposeOfAccountOpening = purposeOfAccountOpening;
    }

    public String getAmountInitialDeposit() {
        return amountInitialDeposit;
    }

    public void setAmountInitialDeposit(String amountInitialDeposit) {
        this.amountInitialDeposit = amountInitialDeposit;
    }

    public String getCurrencyInitialDeposit() {
        return currencyInitialDeposit;
    }

    public void setCurrencyInitialDeposit(String currencyInitialDeposit) {
        this.currencyInitialDeposit = currencyInitialDeposit;
    }

    public String getChannelReferenceKey() {
        return channelReferenceKey;
    }

    public void setChannelReferenceKey(String channelReferenceKey) {
        this.channelReferenceKey = channelReferenceKey;
    }

    public String getPurposeOfAccountOpeningOthers() {
        return purposeOfAccountOpeningOthers;
    }

    public void setPurposeOfAccountOpeningOthers(String purposeOfAccountOpeningOthers) {
        this.purposeOfAccountOpeningOthers = purposeOfAccountOpeningOthers;
    }
}
