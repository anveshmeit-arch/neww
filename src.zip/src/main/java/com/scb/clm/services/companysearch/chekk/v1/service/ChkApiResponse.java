package com.scb.clm.services.companysearch.chekk.v1.service;

import com.scb.clm.common.exception.ErrorObject;
import com.scb.clm.services.companysearch.chekk.v1.service.ChkResponseValidator;
import com.scb.clm.services.companysearch.chekk.v1.support.ChkApiType;
import com.scb.clm.services.companysearch.chekk.v1.support.JsonParserUtil;
import com.scb.clm.services.companysearch.chekk.v1.support.ProcessApiConstants;

public class ChkApiResponse {

	private ChkApiType apiType;
	private String responseData;
	private int statusCode;
	private ErrorObject errObj;

	public ChkApiResponse(ChkApiType apiType, int statusCode, String responseData) {
		this.apiType = apiType;
		this.statusCode = statusCode;
		this.responseData = responseData;
		validateResponse();
	}

	public ChkApiType getApiType() {
		return apiType;
	}

	public void setApiType(ChkApiType apiType) {
		this.apiType = apiType;
	}

	public String getResponseData() {
		return responseData;
	}

	public void setResponseData(String responseData) {
		this.responseData = responseData;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public ErrorObject getErrObj() {
		return errObj;
	}

	public void setErrObj(ErrorObject errObj) {
		this.errObj = errObj;
	}

	private void validateResponse() {
		ChkResponseValidator responseValidator = new ChkResponseValidator();
		errObj = responseValidator.validateResponseCode(statusCode, responseData);
	}

	/**
	 * Returns true if status code is 200 and no error message exists in Chekk
	 * response, otherwise false
	 * 
	 * @return
	 */
	public boolean isSuccess() {
		boolean retValue = false;
		boolean errorExists = (errObj != null && !isNullOrEmpty(errObj.getDescription()));
		if (statusCode == 200 && !errorExists) {
			retValue = true;
		}
		return retValue;
	}

	public <T> T getResponse(Class<T> tClass) {
		return JsonParserUtil.toObject(responseData, tClass);
	}

	private boolean isNullOrEmpty(Object value) {
		boolean retValue = true;
		if (value != null) {
			String text = value.toString();
			retValue = text.isEmpty() ? true : false;
		}
		return retValue;
	}

	public String getSearchEntQUpdateStatus(boolean isMultiLevel) {
		String nextUpdateStatus = null;
		if (getApiType() == ChkApiType.SEARCH) {
			nextUpdateStatus = isSuccess() ? ProcessApiConstants.STATUS_CREATE_PENDING : "SF";
		} else if (getApiType() == ChkApiType.CREATE) {
			nextUpdateStatus = isSuccess() ? ProcessApiConstants.STATUS_GET_PENDING : "CF";
		} else if (getApiType() == ChkApiType.GET && isMultiLevel) {
			nextUpdateStatus = isSuccess() ? ProcessApiConstants.STATUS_UNWRAP_PENDING : "GF";
		}else if(getApiType() == ChkApiType.GET ) {
			nextUpdateStatus = isSuccess() ? ProcessApiConstants.STATUS_COMPLETED : "GF";
		}
		return nextUpdateStatus;
	}
	
}
