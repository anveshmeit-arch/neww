package com.scb.clm.services.globus.prescreen.v1.support;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/*
 * 
 * @author     1378958 
 * @version    1.0
 * @since      
 * @use        PreScreen Constants  
 */
public class PrescreenConstants
{
    public static final String ICM_INTERFACE_ID       = "ICM";
    public static final String ICM_DEDUPE_SERVICE_ID  = "SDEDUP"; 

    
    public static final String MANDATORY_PARAMETER_GROUP   = "MANDATORY";
    public static final String MANDATORY_FIRST_NAME        = "MANDATORY_FIRST_NAME";
    public static final String MANDATORY_FULL_NAME         = "MANDATORY_FULL_NAME";
    public static final String MANDATORY_DATE_OF_BIRTH     = "MANDATORY_DATE_OF_BIRTH";
    public static final String MANDATORY_DOCUMENT          = "MANDATORY_DOCUMENT";

    public static final String DEDUPE_INTERFACE_ID         = "ICM";

    public static final String EXACT_MATCH                 = "EXACTMATCH";
    public static final String LIKELY_MATCH                = "LIKELYMATCH";
    public static final String REJECT                      = "REJECT";
    public static final String NOMATCH                     = "NOMATCH";

    public static final String ERROR_CODE_NO_MATCH_FOUND   = "CP043109";

    public static final String INVALID_JSON_FORMAT                    = "DD000001";  
    public static final String INVALID_APPLICATION_REFERENCE_NUMBER   = "DD000002";  
    public static final String INVALID_FIRST_NAME                     = "DD000003";  
    public static final String INVALID_MIDDLE_NAME                    = "DD000004";  
    public static final String INVALID_LAST_NAME                      = "DD000005";  
    public static final String INVALID_FULL_NAME                      = "DD000006";  
    public static final String INVALID_DATE_OF_BIRTH                  = "DD000007";  
    public static final String FIRST_NAME_MANDATORY                   = "DD000009";
    public static final String FULL_NAME_MANDATORY                    = "DD000010";
    public static final String DATE_OF_BIRTH_MANDATORY                = "DD000011";
    public static final String DOCUMENT_DATA_MANDATORY                = "DD000012";
    public static final String DEDUPE_INTERNAL_ERROR                  = "DD000013";   

    public static final String INVALID_CONTACT_TYPE                   = "DD000014";   
    public static final String INVALID_CONTACT                        = "DD000015";   
    public static final String INVALID_DOCUMENT_TYPE                  = "DD000016";   
    public static final String INVALID_DOCUMENT_NUMBER                = "DD000017";       

    public static final String VALIDATION_ERROR                       = "GB000002";   
    public static final String CLM_REQUEST_ERROR                      = "OB000001";
    
 public static final Map<String, String> ONBOARDING_STATUS_COMBO;
    
    static {
    	Map<String, String> statusMap = new HashMap<>();
    	statusMap.put("YCO", "Y");
		statusMap.put("YCN", "Y");
		statusMap.put("YRO", "Y");
		statusMap.put("YRN", "Y");
		statusMap.put("YRA", "Y");
		statusMap.put("YNO", "Y");
		statusMap.put("YNN", "Y");
		statusMap.put("YNA", "Y");
    	// Make the map unmodifiable
    	ONBOARDING_STATUS_COMBO = Collections.unmodifiableMap(statusMap);
    }

}