package com.scb.clm.services.globus.deepening.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.scb.clm.services.globus.prospect.v1.model.GBSProspectRequestCustomers;
import com.scb.clm.services.globus.prospect.v1.model.GBSProspectResponseErrorDetails;

import java.util.ArrayList;

public class GBSDeepeningResponseWrapper {
    @JsonProperty("customers")
    private GBSDeepeningResponseCustomers customers;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty("errorDetails")
    private ArrayList<GBSDeepeningResponseErrorDetails> errorDetails;

    public ArrayList<GBSDeepeningResponseErrorDetails> getErrorDetails() {
        return errorDetails;
    }

    public void setErrorDetails(ArrayList<GBSDeepeningResponseErrorDetails> errorDetails) {
        this.errorDetails = errorDetails;
    }

    public GBSDeepeningResponseCustomers getCustomers() {
        return customers;
    }

    public void setCustomers(GBSDeepeningResponseCustomers customers) {
        this.customers = customers;
    }

    public void addErrors(GBSDeepeningResponseErrorDetails argErrors) {
        if(this.errorDetails == null) {
            this.errorDetails= new ArrayList<GBSDeepeningResponseErrorDetails>();
        }
        this.errorDetails.add(argErrors);
    }
}
