package com.scb.clm.services.globus.onboarding.v1.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class GBSOnboardResponseOnboardingStatusReason {
	
	public GBSOnboardResponseOnboardingStatusReason() {
		
	}
	
	public GBSOnboardResponseOnboardingStatusReason(String reasonCode, String reasonDescription) {
		this.reasonCode = reasonCode;
		this.reasonDescription = reasonDescription;
	}

	@JsonProperty("reasonCode")
    private String reasonCode;

    @JsonProperty("reasonDescription")
    private String reasonDescription;

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getReasonDescription() {
		return reasonDescription;
	}

	public void setReasonDescription(String reasonDescription) {
		this.reasonDescription = reasonDescription;
	}
}
