package com.scb.clm.services.globus.onboarding.v1.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSOnboardDigitalIdentityWrapper {

    @JsonProperty("deviceType")
    private String deviceType;

    @JsonProperty("deviceValue")
    private String deviceValue;

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String device_type) {
        this.deviceType = device_type;
    }

    public String getDeviceValue() {
        return deviceValue;
    }

    public void setDeviceValue(String device_value) {
        this.deviceValue = device_value;
    }

}
