package com.scb.clm.services.globus.cleanup.v1.support;

/*
 * 
 * @author      
 * @version    1.0
 * @since      
 * @use        Admin Constants  
 */
public class CleanupConstants
{

    /* ADMIN CONSTATNTS */
    public static final String CLEANUP_GROUP_ID           = "CLEANUP";
    public static final String PROSPECT_CLEANUP_DAYS          = "PROSPECT_CLEANUP_DAYS";
    public static final String PROSPECT_CLEANUP_BATCH_SIZE    = "PROSPECT_CLEANUP_BATCH_SIZE";
    public static final String INVALID_CONFIGURATION            = "CP000001";

    public static final String CLEANUP_ROLL_BACK    = "CP000002";



}