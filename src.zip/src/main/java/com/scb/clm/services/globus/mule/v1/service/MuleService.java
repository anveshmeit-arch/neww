package com.scb.clm.services.globus.mule.v1.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import com.scb.clm.common.config.ApplicationConfiguration;
import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.config.StartUpConfigurations;
import com.scb.clm.common.exception.ErrorObject;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.repository.InterfaceRequestTypeRepository;
import com.scb.clm.common.util.JSONUtility;
import com.scb.clm.common.util.ServiceParameterUtility;
import com.scb.clm.common.util.StringUtility;
import com.scb.clm.core.service.ServiceAbstract;
import com.scb.clm.core.service.ServiceInterface;
import com.scb.clm.services.globus.mule.v1.model.GBSMuleResponseErrorDetails;
import com.scb.clm.services.globus.mule.v1.model.GBSMuleResponseWrapper;
import com.scb.clm.services.globus.mule.v1.support.MuleConstants;
import com.scb.clm.services.globus.onboarding.v1.models.ErrorDetails;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardContactsWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardCustomerWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardDigitalIdentityWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardDocumentsWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardReqWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardResponseOnboardingStatusReason;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardResponseWrapper;

@Service
public class MuleService extends ServiceAbstract implements ServiceInterface
{

    @Autowired
    InterfaceRequestTypeRepository interfaceRequestTypeRepository;
	
	@Autowired
    ApplicationConfiguration applicationConfiguration;

    @Autowired
    RestTemplate restTemplate;
    
    public static final String MUL_REASON     = "MUL";

    @Override
    public Object readRequestObject(TravellingObject travellingObject, NodeServicesEntity srvEntity) throws ProcessException 
    {
        try
        {
            return JSONUtility.jsonTODomainWrapper(travellingObject.getRequestData(),GBSOnboardReqWrapper.class);
        }
        catch(Exception e) 
        {
            ProcessException gbxEx = new ProcessException();
            gbxEx.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, BaseConstants.VALIDATION_ERROR,"INVALID REQUEST MESSAGE FORMAT FOR PROSPECT SERVICE"));
            throw gbxEx;
        }
        finally
        {
            // N.A
        }
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public void validateData(TravellingObject travellingObject,NodeServicesEntity srvEntity,Object requestPayload) throws ProcessException 
    {
        LoggerUtil log                    = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateData", LogType.APPLICATION.name());
        List<ErrorObject> errorObjectList = new ArrayList<ErrorObject>();
        try
        {
            GBSOnboardReqWrapper requestWrapper = (GBSOnboardReqWrapper) requestPayload;
            if(requestWrapper == null)
            {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_TECHNICAL, MuleConstants.INVALID_JSON_FORMAT,"INVALID REQUEST"));
            }
        }
        catch (Exception e)
        {
            log.printErrorMessage(e);
            errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, BaseConstants.VALIDATION_ERROR,"INTERNAL ERROR"));
            ProcessException gbxEx = new ProcessException();
            gbxEx.addAll(errorObjectList);
            throw gbxEx; 
        }
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */

    @Override
    public Object constructOutboundObject(TravellingObject travellingObject,NodeServicesEntity srvEntity,Object requestPayload) throws ProcessException
    {
        try
        {
            return requestPayload;
        }
        catch (Exception e)
        {
            LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "constructOutboundObject", LogType.APPLICATION.name());
            log.printErrorMessage(e);

            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, BaseConstants.VALIDATION_ERROR," INTERNAL ERROR WHILE PAYLOAD CONSTRUCTION ");
        }
        finally
        {
            //N.A
        }
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */

    @Override
    public Object process(TravellingObject travellingObject,NodeServicesEntity srvEntity,ServiceStatus serviceStatus,Object processPayload) throws ProcessException
    {
        GBSMuleResponseWrapper muleResponseData 		=	null;
        GBSOnboardResponseWrapper resOnboardObj 		=	new GBSOnboardResponseWrapper();
        List<ErrorObject> errorObjectList 				=	new ArrayList<ErrorObject>();
        Set<GBSMuleResponseErrorDetails> errorDetails	=   null;
        LoggerUtil log                                  =   LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "process", LogType.APPLICATION.name());

        try
        {
            serviceStatus.setInterfaceId(MuleConstants.MULE_INTERFACE_ID);
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("countryCode", travellingObject.getCountryCode());
            headers.set("interfaceId", travellingObject.getInterfaceId());
			//headers.set("interfaceId", "EOPS");
            headers.set("transactionId", travellingObject.getTransactionID());
            String token = applicationConfiguration.getAccessToken(travellingObject, BaseConstants.MULE_SCOPE);
            headers.add("Authorization", "Bearer "+ token);


            GBSOnboardReqWrapper requestWrapper = (GBSOnboardReqWrapper) processPayload;

            String hostServiceURL = interfaceRequestTypeRepository.getInterfaceURL(travellingObject.getCountryCode(),MuleConstants.INERFACE_MULE,MuleConstants.SERVICE_MULE,"OB", BaseConstants.CODE_SETUP_ACTIVE);
            log.println("Mule URL # "+ hostServiceURL);
            String parameter = constructFilters(requestWrapper,srvEntity);
            String data = hostServiceURL+((parameter==null||parameter.trim().length()==0)?"":parameter);
            log.println("Mule Complete URL # "+ data);
            
            HttpEntity<String> entity = new HttpEntity<>(headers);
            ResponseEntity<String> response= restTemplate.exchange(data,HttpMethod.GET,entity,String.class);
            String muleResponse = response.getBody();
            log.println(muleResponse);
            serviceStatus.setResponsePayload(muleResponse);

            log.println("[Mule Raw Response] \n "+muleResponse); 

            muleResponseData = (GBSMuleResponseWrapper) JSONUtility.jsonTODomainWrapper(muleResponse, GBSMuleResponseWrapper.class);
            log.println("[Mule Response Data] \n - "+JSONUtility.domainWrapperToJSON(muleResponseData));

            if(muleResponseData == null)
            {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_TECHNICAL, MuleConstants.INVALID_JSON_FORMAT,"INVALID RESPONSE"));
            }
            if(muleResponseData !=null &&(muleResponseData.getMuleFlag() == null || !StringUtility.containsData(muleResponseData.getMuleFlag()))) {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, MuleConstants.INVALID_MULE_FLAG,"INVALID MULE FLAG"));
            }
            if (muleResponseData !=null && muleResponseData.getGbsMuleResponseErrorDetails()!=null) {
                errorDetails = muleResponseData.getGbsMuleResponseErrorDetails();
            }

            if(muleResponseData!=null && muleResponseData.getMuleFlag()!=null) {
                serviceStatus.addServiceParams("MULE_INDICATOR", muleResponseData.getMuleFlag());
            }

            if(errorDetails!=null) {     
                for(GBSMuleResponseErrorDetails errorDetail: errorDetails) {
                    if(!StringUtility.containsData(errorDetail.getErrorcode())) {
                        errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, MuleConstants.INVALID_ERROR_CODE, "INVALID RESPONSE"));
                    }
                    if(!StringUtility.containsData(errorDetail.getErrordescription())) {
                        errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, MuleConstants.INVALID_ERROR_DESCRIPTION, "INVALID RESPONSE"));
                    }
                }
            }

            if(errorObjectList!=null && errorObjectList.size()> 0) {
                ProcessException gbxEx = new ProcessException();
                gbxEx.addAll(errorObjectList);
                throw gbxEx;
            }

            for(ErrorObject errorObject : errorObjectList)
            {
                resOnboardObj.addErrors(new ErrorDetails((String)errorObject.getCode(),(String)errorObject.getDescription()));
            }
            serviceStatus.setResponsePayload(resOnboardObj);
            serviceStatus.setHttpStatus(String.valueOf(response.getStatusCodeValue()));

        }
        catch (ResourceAccessException eX) 
        {
            log.printErrorMessage(eX);
            serviceStatus.setHttpStatus(""+BaseConstants.HTTP_500);
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, MuleConstants.CLM_REQUEST_ERROR," INTERNAL ERROR WHILE SERVICE PROCESSING WITH MULE [HTTP-ERROR]");            
        }
        catch (HttpStatusCodeException ex) 
        {
        	ex.printStackTrace();
            log.printErrorMessage(ex);
            log.println("Raw Code ["+ex.getRawStatusCode()+"] Status Code ["+ex.getStatusCode().toString()+"]");
            serviceStatus.setHttpStatus(""+ex.getRawStatusCode());
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, MuleConstants.CLM_REQUEST_ERROR," INTERNAL ERROR WHILE SERVICE PROCESSING WITH MULE [HTTP ERROR]");
        }
        catch(Exception e)
        {
            log.printErrorMessage(e);
            serviceStatus.setHttpStatus(String.valueOf(BaseConstants.HTTP_500));
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, MuleConstants.CLM_REQUEST_ERROR," INTERNAL ERROR WHILE SERVICE PROCESSING MULE ");
        }

        return muleResponseData;
    }


    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */

    @Override
    public Object constructServiceResponse(TravellingObject travellingObject,NodeServicesEntity srvEntity, Object muleResponseData,ServiceStatus serviceStatus) throws ProcessException
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "constructServiceResponse", LogType.APPLICATION.name());

        GBSMuleResponseWrapper requestWrapper		=	(GBSMuleResponseWrapper) muleResponseData;
        GBSOnboardResponseWrapper resOnboardObj		=	new GBSOnboardResponseWrapper();
        List<GBSOnboardResponseOnboardingStatusReason> cddStatusReasonlist = new ArrayList<GBSOnboardResponseOnboardingStatusReason>();

        try 
        {
            if(requestWrapper == null)
            {
                resOnboardObj.addErrors(new ErrorDetails(BaseConstants.ERROR_TYPE_TECHNICAL, MuleConstants.INVALID_JSON_FORMAT));
            }
            else if(requestWrapper.getMuleFlag()!=null && requestWrapper.getMuleFlag().equals("Y"))
            {
            	resOnboardObj.setOnboardingStatus("Rejected");
            	serviceStatus.setStatus(BaseConstants.SERVICE_FAILURE);
            	cddStatusReasonlist.add(new GBSOnboardResponseOnboardingStatusReason(MUL_REASON, ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),MUL_REASON,MUL_REASON)));
            	 if(cddStatusReasonlist.size() > 0) {
                     resOnboardObj.setOnboardingStatusReason(cddStatusReasonlist);
                     ArrayList<ErrorObject> errorObjectList = new ArrayList<ErrorObject>();
                     errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_PROCESSING, BaseConstants.VALIDATION_ERROR,ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),MUL_REASON,MUL_REASON)));
                     serviceStatus.setErrorObject(errorObjectList);
                 }

                log.println("\n "+JSONUtility.domainWrapperToJSON(resOnboardObj));
            }
        }
        catch (Exception e)
        {
            log.printErrorMessage(e);
        }
        return resOnboardObj;
    }


    private String constructFilters(GBSOnboardReqWrapper requestObject,NodeServicesEntity srvEntity)
    {
        LoggerUtil log                =  LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "constructFilters", LogType.APPLICATION.name());
        StringBuffer filterConditions =  new StringBuffer();

        GBSOnboardCustomerWrapper customerWrapper = requestObject.getGbs_Onboard_CustomerWrapper();

        try 
        {
            if(customerWrapper == null)
            {
                return filterConditions.toString();
            }

            if(customerWrapper.getObjOnboard_DigitalIdentityWrapper()!=null) 
            { 
                String filterAllowed = ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),"ENQ_FILTER","DEVICE");
                if(filterAllowed!=null && filterAllowed.equals("Y")) 
                {
                    for(GBSOnboardDigitalIdentityWrapper devices :customerWrapper.getObjOnboard_DigitalIdentityWrapper()) 
                    {
                        filterConditions.append(appendData(filterConditions.toString(),"deviceID",devices.getDeviceValue()));
                    }
                }
            }

            if(customerWrapper.getObjOnboard_DocumentsWrapper()!=null)
            {
                String filterAllowed = ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),"ENQ_FILTER","DOCUMENT");
                if(filterAllowed!=null && filterAllowed.equals("Y")) 
                {	
                	String docNumbers="";
                    for(GBSOnboardDocumentsWrapper documents :customerWrapper.getObjOnboard_DocumentsWrapper()) 
                    {
                    	if(documents.getDocumentType() != null && documents.getDocumentCode().equalsIgnoreCase(MuleConstants.DOCUMENT_K_TYPE)){
                    		if(docNumbers!=null && docNumbers.trim().length()>0) {
		                		docNumbers=docNumbers+","+documents.getDocumentNumber().toUpperCase();
		                	}
		                	else {
		                		docNumbers=documents.getDocumentNumber().toUpperCase();
		                	}
                    	}
                    }
                    
                    if (docNumbers!=null && docNumbers.trim().length()>0){
   	            	 filterConditions.append(appendData(filterConditions.toString(),"documentNumber",docNumbers));
   	             	}
                }
            }

            if(customerWrapper.getObjOnboard_ContactsWrapper()!=null) 
            {
                String mobFilterAllowed = ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),"ENQ_FILTER","MOBILE");
                String emlFilterAllowed = ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),"ENQ_FILTER","EMAIL");
                for(GBSOnboardContactsWrapper contact :customerWrapper.getObjOnboard_ContactsWrapper()) 
                {
                    if(emlFilterAllowed!=null && emlFilterAllowed.equals("Y") && MuleConstants.CONTACT_EMAIL_TYPE.equals(contact.getContactClassificationCode())) 
                    {
                        filterConditions.append(appendData(filterConditions.toString(),"emailId",contact.getContact()));
                    }
                    if(mobFilterAllowed!=null && mobFilterAllowed.equals("Y") && MuleConstants.CONTACT_MOBILE_TYPE.equals(contact.getContactClassificationCode())) 
                    {
                        filterConditions.append(appendData(filterConditions.toString(),"contact",contact.getCountryCode()+""+contact.getContact()));
                    }
                }
            }

            return filterConditions.toString();
        }
        catch (Exception e) 
        {
            log.printErrorMessage(e);
        }
        return filterConditions.toString();
    }

    private String appendData(String filter,String type,String value)
    {
        if(filter!=null && filter.trim().length()>0) 
        {
            return "&filter["+type+"]="+value+"";        
        } 
        else 
        {
            return "?filter["+type+"]="+value+"";
        }
    }
}
