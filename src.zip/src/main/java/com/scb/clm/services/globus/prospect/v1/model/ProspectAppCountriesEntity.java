package com.scb.clm.services.globus.prospect.v1.model;

import java.util.Objects;



import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "GBS_PROSPECT_APP_COUNTRIES")
public class ProspectAppCountriesEntity implements Cloneable {

	@EmbeddedId
	private ProspectAppCountriesEntityKey id;

	@Column(name="base_location")
	private String baseLocation;

	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="COUNTRY_CODE", referencedColumnName="COUNTRY_CODE", insertable= false, updatable= false),
		@JoinColumn(name="PROSPECT_ID", referencedColumnName="PROSPECT_ID",insertable= false, updatable=false)

	})
	private ProspectEntity prospectAppCountriesMapper;

	public ProspectAppCountriesEntity()
	{

	}


	public ProspectAppCountriesEntity(ProspectAppCountriesEntityKey id)
	{
		this.id= (ProspectAppCountriesEntityKey) id.clone();
	}


	public ProspectAppCountriesEntityKey getId() {
		return (ProspectAppCountriesEntityKey) id.clone();
	}


	public void setId(ProspectAppCountriesEntityKey id) {
		this.id = (ProspectAppCountriesEntityKey) id.clone();
	}

	public String getBaseLocation() {
		return baseLocation;
	}


	public void setBaseLocation(String baseLocation) {
		this.baseLocation = baseLocation;
	}

	@Override
	public int hashCode() {
		return this.getId().hashCode();
	}
	@Override
	public Object clone() throws CloneNotSupportedException {
		ProspectAppCountriesEntity prospectAppCountriesEntity=(ProspectAppCountriesEntity) super.clone();
		prospectAppCountriesEntity.setId((ProspectAppCountriesEntityKey) this.getId().clone());
		return prospectAppCountriesEntity;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null || !(obj instanceof ProspectAppCountriesEntity)) {
			return false;
		}
		return Objects.equals(this.getId(), ((ProspectAppCountriesEntity) obj).getId());
	}

	public void synchronizeThisWith(ProspectAppCountriesEntity argProspectContactEntity) 
	{       
		this.setBaseLocation(argProspectContactEntity.getBaseLocation());
	}

}

