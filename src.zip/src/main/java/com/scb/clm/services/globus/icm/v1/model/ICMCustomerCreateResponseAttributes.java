package com.scb.clm.services.globus.icm.v1.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ICMCustomerCreateResponseAttributes extends RequestHeaderInformation{

    @JsonProperty("customers") 
    private ICMCustomerCreateCustomer customers;

    @JsonProperty("errordetails")
    private List<ErrorDetails> errordetails;

    public ICMCustomerCreateCustomer getCustomers() {
        return customers;
    }

    public void setCustomers(ICMCustomerCreateCustomer customers) {
        this.customers = customers;
    }

    public List<ErrorDetails> getErrordetails() {
        return errordetails;
    }
    public void setErrordetails(List<ErrorDetails> errordetails) {
        this.errordetails = errordetails;
    }


}
