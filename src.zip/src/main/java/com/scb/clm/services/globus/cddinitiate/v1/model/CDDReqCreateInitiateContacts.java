package com.scb.clm.services.globus.cddinitiate.v1.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
@JsonInclude(JsonInclude.Include.NON_NULL)  
public class CDDReqCreateInitiateContacts {

    @JsonProperty("contact-type")
    private String contact_type;

    @JsonProperty("contact")
    private String contact;

    @JsonProperty("contact-type-code")
    private String contact_type_code;

    @JsonProperty("country-code")
    private String country_code;

    @JsonProperty("area-code")
    private String area_code;

    @JsonProperty("country-isd-code")
    private String country_isd_code;


    public String getContact_type() {
        return contact_type;
    }

    public void setContact_type(String contact_type) {
        this.contact_type = contact_type;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getContact_type_code() {
        return contact_type_code;
    }

    public void setContact_type_code(String contact_type_code) {
        this.contact_type_code = contact_type_code;
    }

    @Override
    public String toString() {
        return "CDDReq_Create_Iniate_Contacts [contact_type=" + contact_type + ", contact=" + contact
                + ", contact_type_code=" + contact_type_code + "]";
    }

    public String getCountry_code() {
        return country_code;
    }

    public void setCountry_code(String country_code) {
        this.country_code = country_code;
    }

    public String getArea_code() {
        return area_code;
    }

    public void setArea_code(String area_code) {
        this.area_code = area_code;
    }

    public String getCountry_isd_code() {
        return country_isd_code;
    }

    public void setCountry_isd_code(String country_isd_code) {
        this.country_isd_code = country_isd_code;
    }
}
