package com.scb.clm.services.globus.prospect.v1.model;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSProspectRequestCustomers 
{

    @JsonProperty("firstName")
    private String firstName;

    @JsonProperty("middleName")
    private String middleName;
   
    @JsonProperty("lastName")
    private String lastName;

    @JsonProperty("fullName")
    private String fullName;

    @JsonProperty("dateOfBirth")
    private String dateOfBirth;
    
    @JsonProperty("clientType")
    private String clientType;

    @JsonProperty("contacts")
    ArrayList<GBSProspectRequestContacts> contacts;

    @JsonProperty("digitalIdentity")
    ArrayList<GBSProspectRequestIdentity> digitalIdentity;

    @JsonProperty("addresses")
    ArrayList<GBSProspectRequestAddress> address;
    
    @JsonProperty("documents")
    ArrayList<GBSProspectRequestDocuments> documents;
    
    @JsonProperty("kyc")
    GBSProspectRequestKyc kyc;

    @JsonProperty("aliases")
    ArrayList<GBSProspectRequestAlias> alias;
    
    @JsonProperty("customerMultilingual")
    GBSProspectRequestProfileMultilingual multilingual;
    
    @JsonProperty("employments")
    GBSProspectRequestEmployment employment;
    
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getClientType() {
        return clientType;
    }

    public void setClientType(String clientType) {
        this.clientType = clientType;
    }

    public ArrayList<GBSProspectRequestContacts> getContacts() {
        return contacts;
    }

    public void setContacts(ArrayList<GBSProspectRequestContacts> contacts) {
        this.contacts = contacts;
    }

    public ArrayList<GBSProspectRequestIdentity> getDigitalIdentity() {
        return digitalIdentity;
    }

    public void setDigitalIdentity(ArrayList<GBSProspectRequestIdentity> digitalIdentity) {
        this.digitalIdentity = digitalIdentity;
    }
    
    public ArrayList<GBSProspectRequestAddress> getAddress() {
        return address;
    }

    public void setAddress(ArrayList<GBSProspectRequestAddress> address) {
        this.address = address;
    }

    public ArrayList<GBSProspectRequestDocuments> getDocuments() {
        return documents;
    }

    public void setDocuments(ArrayList<GBSProspectRequestDocuments> documents) {
        this.documents = documents;
    }

    public GBSProspectRequestKyc getKyc() {
        return kyc;
    }

    public void setKyc(GBSProspectRequestKyc kyc) {
        this.kyc = kyc;
    }

    public ArrayList<GBSProspectRequestAlias> getAlias() {
        return alias;
    }

    public void setAlias(ArrayList<GBSProspectRequestAlias> alias) {
        this.alias = alias;
    }

    public GBSProspectRequestProfileMultilingual getMultilingual() {
        return multilingual;
    }

    public void setMultilingual(GBSProspectRequestProfileMultilingual multilingual) {
        this.multilingual = multilingual;
    }

    public GBSProspectRequestEmployment getEmployment() {
        return employment;
    }

    public void setEmployment(GBSProspectRequestEmployment employment) {
        this.employment = employment;
    }

    public void addContacts(GBSProspectRequestContacts contactEntity) {
        if(this.contacts == null) {
            this.contacts = new ArrayList<GBSProspectRequestContacts>();     
        }
        this.contacts.add(contactEntity);
    }
    public void addDigital(GBSProspectRequestIdentity digitalDetail) {
        if(this.digitalIdentity == null) {
            this.digitalIdentity = new ArrayList<GBSProspectRequestIdentity>();     
        }
        this.digitalIdentity.add(digitalDetail);
    }
    public void addAddress(GBSProspectRequestAddress addressDetail) {
        if(this.address == null) {
            this.address = new ArrayList<GBSProspectRequestAddress>();     
        }
        this.address.add(addressDetail);
    }
    public void addDocuments(GBSProspectRequestDocuments documentsDetail) {
        if(this.documents == null) {
            this.documents = new ArrayList<GBSProspectRequestDocuments>();
        }
        this.documents.add(documentsDetail);
    }

}