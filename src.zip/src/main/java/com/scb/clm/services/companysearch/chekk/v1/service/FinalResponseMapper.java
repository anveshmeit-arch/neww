package com.scb.clm.services.companysearch.chekk.v1.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.scb.clm.services.companysearch.chekk.v1.model.ChekkPartyEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.Regulators;
import com.scb.clm.services.companysearch.chekk.v1.model.process.Address;
import com.scb.clm.services.companysearch.chekk.v1.model.process.Association;
import com.scb.clm.services.companysearch.chekk.v1.model.process.Document;
import com.scb.clm.services.companysearch.chekk.v1.model.process.EntityData;
import com.scb.clm.services.companysearch.chekk.v1.model.process.FinalResponse;
import com.scb.clm.services.companysearch.chekk.v1.model.process.Group;
import com.scb.clm.services.companysearch.chekk.v1.model.process.Headers;
import com.scb.clm.services.companysearch.chekk.v1.model.process.Individual;
import com.scb.clm.services.companysearch.chekk.v1.model.process.IssuedShares;
import com.scb.clm.services.companysearch.chekk.v1.model.process.LegalFormation;
import com.scb.clm.services.companysearch.chekk.v1.model.process.Organisation;
import com.scb.clm.services.companysearch.chekk.v1.model.process.Product;
import com.scb.clm.services.companysearch.chekk.v1.support.ChkPartyType;
import com.scb.clm.services.companysearch.chekk.v1.support.MainEntityFieldNames;
import com.scb.clm.services.companysearch.chekk.v1.support.ProcessApiConstants;

/**
 * 
 */
public class FinalResponseMapper {

	// Passed from calling method
	private List<ChekkPartyEntity> partyList;
	private Map<String, String> requestHeaders;
	private Map<String, String> requestBody;
	
	private ChkTableReferences refData;
	private String[] unwrappingIncompleteReasons;
	private String thresholdPercentage;

	// Internal member variables
	private EntityData entityData;
	private Map<String, String> uniqueIndMap;
	private Map<String, String> uniqueEntMap;

	private FinalResponseMapper(FinalResponseMapBuilder builder) {
		this.partyList = builder.partyList;
		this.requestHeaders = builder.requestHeaders;
		this.requestBody = builder.requestBody;
		this.refData = builder.refData;
		this.unwrappingIncompleteReasons = builder.unwrappingIncompleteReasons;
		this.thresholdPercentage = builder.thresholdPercentage;

		uniqueIndMap = new HashMap<>();
		uniqueEntMap = new HashMap<>();
		
		init();
	}


	/**
	 * Initializes all list objects under EntityData, if <code>partyList</code> is
	 * not empty
	 */
	private void init() {
		if (partyList != null && !partyList.isEmpty()) {
			entityData = new EntityData();
			entityData.setAddresses(new ArrayList<>());
			LegalFormation legalFormation = new LegalFormation();
			legalFormation.setOrganisation(new ArrayList<>());
			legalFormation.setIndividual(new ArrayList<>());
			entityData.setLegalFormation(legalFormation);
			entityData.setAssociations(new ArrayList<>());
			entityData.setDocuments(new ArrayList<>());
			entityData.setIssuedShares(new ArrayList<>());
		}

	}

	/**
	 * 
	 * @return
	 */
	public FinalResponse generate() {
		for (ChekkPartyEntity aParty : partyList) {
			addParty(aParty);
		}
		FinalResponse finalResponse = new FinalResponse();
		finalResponse.setHeaders(getHeaders());

		if (partyList != null && !partyList.isEmpty()) {
			finalResponse.setEntityData(entityData);
		} else {
			/**
			 *  TODO add error object , if no parties present for final response
			 */
		}
		return finalResponse;
	}

	/**
	 * 
	 * @return
	 */
	private Headers getHeaders() {
		Headers headers = new Headers();
		headers.setCountryCode(requestHeaders.get(ProcessApiConstants.PROCESS_API_HEADER_COUNTRY_CODE));
		headers.setInterfaceId(requestHeaders.get(ProcessApiConstants.PROCESS_API_HEADER_INTERFACE_ID));
		headers.setTransactionID(requestHeaders.get(ProcessApiConstants.PROCESS_API_HEADER_TRANSACTION_ID));
		return headers;
	}

	/**
	 * 
	 * @param theParty
	 */
	private void addParty(ChekkPartyEntity theParty) {
		ChkPartyType partyType = getPartyType(theParty);
		if (partyType == ChkPartyType.MAIN_ENTITY) {
			addMainEntity(theParty);
		} else if (partyType == ChkPartyType.COMPANY) {
			addIntermediateEntity(theParty);
		} else if (partyType == ChkPartyType.INDIVIDUAL) {
			addIntermediateIndividual(theParty);
		} else {
			// Add warning message : party type is null or Invalid party type.
		}
	}

	/**
	 * 
	 * @param indParty
	 */
	private void addIntermediateIndividual(ChekkPartyEntity indParty) {
		IndividualPartyMapper individualPartyMapper = new IndividualPartyMapper(indParty, refData);
		String duplicateKeyId = individualPartyMapper.getDuplicateKeyId();
		if (isDuplicate(uniqueIndMap, duplicateKeyId, indParty.getUniqueId())) {
			String existingUniqueId = uniqueIndMap.get(duplicateKeyId);
			indParty.setUniqueId(existingUniqueId);
			individualPartyMapper = new IndividualPartyMapper(indParty, refData);
		} else {
			// if not null add object otherwise ignore it
			Individual individual = individualPartyMapper.createIndividual();
			if (individual != null) {
				entityData.getLegalFormation().getIndividual().add(individual);
			}
			Address address = individualPartyMapper.createAddress();
			if (address != null) {
				entityData.getAddresses().add(address);
			}
			Document document = individualPartyMapper.createDocument();

			if (document != null) {
				entityData.getDocuments().add(document);
			}
		}
		Association association = individualPartyMapper.createAssociation();
		if (association != null)
			entityData.getAssociations().add(association);
	}

	/**
	 * 
	 * @param uniqueParyMap
	 * @param duplicateKeyId
	 * @param uniqueId
	 * @return
	 */
	private boolean isDuplicate(Map<String, String> uniqueParyMap, String duplicateKeyId, String uniqueId) {
		if (uniqueParyMap == null) {
			uniqueParyMap = new HashMap<>();
		}
		if (uniqueParyMap.containsKey(duplicateKeyId)) {
			return true;
		}
		uniqueParyMap.put(duplicateKeyId, uniqueId);
		return false;
	}

	private void addIntermediateEntity(ChekkPartyEntity entParty) {
		EntityPartyMapper entityPartyMapper = new EntityPartyMapper(entParty, refData);

		String duplicateKeyId = entityPartyMapper.getDuplicateKeyId();
		if (isDuplicate(uniqueEntMap, duplicateKeyId, entParty.getUniqueId())) {
			String existingUniqueId = uniqueEntMap.get(duplicateKeyId);
			entParty.setUniqueId(existingUniqueId);
			entityPartyMapper = new EntityPartyMapper(entParty, refData);
		} else {
			// if not null add object otherwise ignore it
			Organisation organisation = entityPartyMapper.createOrganization();
			if (organisation != null) {
				entityData.getLegalFormation().getOrganisation().add(organisation);
			}
			Address address = entityPartyMapper.createAddress();
			if (address != null)
				entityData.getAddresses().add(address);
		}
		Association association = entityPartyMapper.createAssociation();
		if (association != null)
			entityData.getAssociations().add(association);
		// Add association - add this part even if the party is duplicate
	}

	private void addMainEntity(ChekkPartyEntity mainEntParty) {
		MainEntityPartyMapper mainEntityPartyMapper = new MainEntityPartyMapper(mainEntParty, refData);
		addMainEntityFieldNames(mainEntityPartyMapper);
		List<IssuedShares> issuedShares = mainEntityPartyMapper.createIssuedShares();
		if (issuedShares != null && !issuedShares.isEmpty()) {
			entityData.setIssuedShares(issuedShares);
		}
		entityData.setValidationStatus(Arrays.asList(mainEntityPartyMapper.createValidationStatus()));
		entityData.setNames(mainEntityPartyMapper.createNames());
		entityData.setExternal(mainEntityPartyMapper.createExternal());
		entityData.setIndustryClassifications(mainEntityPartyMapper.createIndustryClassification());
		Group group = mainEntityPartyMapper.createGroup();
		if (group != null) {
			entityData.setGroup(group);
		}

		Product product = mainEntityPartyMapper.createProduct();
		if (product != null) {
			entityData.setProduct(product);
		}

		Address address1 = mainEntityPartyMapper.createAddress();
		Address address2Ra = mainEntityPartyMapper.createAddressRa();
		if (address1 != null) {
			entityData.getAddresses().add(address1);
		}
		if (address2Ra != null) {
			entityData.getAddresses().add(address2Ra);

		}
		
		Regulators regulators = mainEntityPartyMapper.createRegulator();
		if(regulators!=null) {
			entityData.setRegulators(regulators);
		}
	}

	private void addMainEntityFieldNames(final MainEntityPartyMapper mainEntityPartyMapper) {
		entityData.setEnid(mainEntityPartyMapper.getValue(MainEntityFieldNames.ENID));
		entityData.setApplicationRefNumber(requestBody.get(ProcessApiConstants.REQ_BODY_APPL_REF_NO));
		entityData.setCountryOfAccountOpening(requestBody.get(ProcessApiConstants.REQ_BODY_CNTRY_ACCTOPEN));
		entityData.setCountryOfEstablishment(requestBody.get(ProcessApiConstants.REQ_BODY_CNTRY_EST));

		entityData.setIdCommencementDate(mainEntityPartyMapper.getValue(MainEntityFieldNames.ID_COMMENCEMENT_DATE));
		entityData.setIdExpiryDate(mainEntityPartyMapper.getValue(MainEntityFieldNames.ID_EXPIRY_DATE));
		entityData.setIdRenewalCutOffDate(mainEntityPartyMapper.getValue(MainEntityFieldNames.ID_RENEWAL_CUTOFF_DATE));
		entityData.setRegistrationDate(mainEntityPartyMapper.getValue(MainEntityFieldNames.REGISTRATION_DATE));
	
		entityData.setEntityTypeCode(mainEntityPartyMapper.getValue(MainEntityFieldNames.ENTITY_TYPE_CODE));
		entityData.setEntitySubTypeCode(mainEntityPartyMapper.getValue(MainEntityFieldNames.ENTITY_SUBTYPE_CODE));

		BigDecimal totalUnwrappingPercentage = calculateOverallPercentage();
		entityData.setTotalUnwrappingPercentage(totalUnwrappingPercentage + "");
		entityData.setIsUnwrappingCompleted(unwrappingCompletedStatus(totalUnwrappingPercentage));
		if (unwrappingIncompleteReasons != null && unwrappingIncompleteReasons.length > 0) {
			entityData.setReasonForUnwrappingIncomplete(unwrappingIncompleteReasons);
		}
	}

	/**
	 * <ul>
	 * MainEntity - indicates the company for which Company Search API request is
	 * received from source application.
	 * </ul>
	 * <ul>
	 * Individual - all intermediate individual parties that were received as part
	 * of MainEntity (level 0) or other entity (>=1 level) search results.</ul
	 * <ul>
	 * Company - all intermediate Entity parties received as part of main entity
	 * (level 0) search results or intermediate entity (>=1 level) search results
	 * </ul>
	 * 
	 * @param theParty
	 * @return
	 */
	public ChkPartyType getPartyType(ChekkPartyEntity theParty) {
		String type = theParty.getPartyType();
		String isMainEntity = theParty.getIsMainEntity();

		ChkPartyType partyType = null;

		if ("Yes".equalsIgnoreCase(isMainEntity)) {
			partyType = ChkPartyType.MAIN_ENTITY;
		} else if (type.equalsIgnoreCase(ChkPartyType.INDIVIDUAL.name())) {
			partyType = ChkPartyType.INDIVIDUAL;
		} else if (type.equalsIgnoreCase(ChkPartyType.COMPANY.name())) {
			partyType = ChkPartyType.COMPANY;
		}

		return partyType;
	}

	/**
	 * All individual parties, including duplicate party's share holding percentage
	 * calculated against MainEntity {@link ChkPartyType} are considered for
	 * calculation.
	 * 
	 * @return Sum of all individual parties share holding percentage value <code>
	 *         ChekkPartyEntity.getShTotalPercentage() <code>
	 */
	private BigDecimal calculateOverallPercentage() {
		List<ChekkPartyEntity> individualParties = partyList.stream()
				.filter(p -> getPartyType(p) == ChkPartyType.INDIVIDUAL).toList();
		BigDecimal totalPercentage;
		if (individualParties != null) {
			totalPercentage = individualParties.stream().map(FinalResponseMapper::getPercentageInBigDecimal)
					.reduce(BigDecimal.ZERO, BigDecimal::add);
		} else {
			totalPercentage = new BigDecimal("0.00");
		}
		return totalPercentage;
	}

	private static BigDecimal getPercentageInBigDecimal(final ChekkPartyEntity party) {
		BigDecimal retValue;
		try {
			String parentPercentage = party.getParentPercentage() == null ? "0.00" : party.getParentPercentage();
			retValue = new BigDecimal(parentPercentage);
		} catch (NumberFormatException nfe) {
			retValue = new BigDecimal("0");
		}
		return retValue;
	}

	/**
	 * Returns true if <code>totalPercentage</code> >= <code>threshold</code>
	 * otherwise false
	 * 
	 * @param totalPercentage
	 * @return
	 */
	private boolean unwrappingCompletedStatus(BigDecimal totalPercentage) {
		BigDecimal threshold = new BigDecimal(thresholdPercentage);
		boolean status = false;
		if (totalPercentage.compareTo(threshold) > 0) {
			status = true;
		}
		return status;
	}

	public static class FinalResponseMapBuilder {
		private final List<ChekkPartyEntity> partyList;
		private final Map<String, String> requestHeaders;
		private Map<String, String> requestBody;

		private String[] unwrappingIncompleteReasons;
		private String thresholdPercentage;

		private ChkTableReferences refData;

		public FinalResponseMapBuilder(List<ChekkPartyEntity> partyList, Map<String, String> requestHeaders) {
			this.partyList = partyList;
			this.requestHeaders = requestHeaders;
		}

		public FinalResponseMapBuilder refData(ChkTableReferences refData) {
			this.refData = refData;
			return this;
		}

		public FinalResponseMapBuilder unwrappingIncompleteReasons(String[] unwrappingIncompleteReasons) {
			this.unwrappingIncompleteReasons = unwrappingIncompleteReasons;
			return this;
		}

		public FinalResponseMapBuilder thresholdPercentage(String thresholdPercentage) {
			this.thresholdPercentage = thresholdPercentage;
			return this;
		}

		public FinalResponseMapBuilder requestBody(Map<String, String> requestBody) {
			this.requestBody = requestBody;
			return this;
		}

		public FinalResponseMapper build() {
			return new FinalResponseMapper(this);
		}
	}
}
