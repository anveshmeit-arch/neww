package com.scb.clm.services.globus.prescreen.v1.model;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CLMResponseAttributes
{
    @JsonProperty("id") 
    String id;
    @JsonProperty("type") 
    String type;
    @JsonProperty("customers") 
    ArrayList<CLMResponseCustomers> customers;

    @JsonProperty("errordetails") 
    ArrayList<CLMResponseErrorDetails> errordetails;

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public ArrayList<CLMResponseCustomers> getCustomers() {
        return customers;
    }
    public void setCustomers(ArrayList<CLMResponseCustomers> customers) {
        this.customers = customers;
    } 

    public ArrayList<CLMResponseErrorDetails> getErrordetails() {
        return errordetails;
    }
    public void setErrordetails(ArrayList<CLMResponseErrorDetails> errordetails) {
        this.errordetails = errordetails;
    }
    public void addCustomers(CLMResponseCustomers argCustomers) {
        if(this.customers == null) {
            this.customers= new ArrayList<CLMResponseCustomers>();     
        }
        this.customers.add(argCustomers);
    }
}