package com.scb.clm.services.companysearch.chekk.v1.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "CHK_SSIC_SCB_ISIC_REF")
@Getter
@Setter
public class ChekkSSICCodeMappingEntity {

	@Id
	@Column(name="ssic")
	private String ssic;

	@Column(name="scb_enhanced_isic")
	private String scbEnhancedIsic;
}
