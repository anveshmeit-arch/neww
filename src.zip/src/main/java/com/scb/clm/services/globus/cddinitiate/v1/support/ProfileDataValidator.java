package com.scb.clm.services.globus.cddinitiate.v1.support;

import java.util.List;

import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardPdpaWrapper;
import com.scb.clm.services.globus.pdpa.v1.support.PDPAConstant;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ErrorObject;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.util.StringUtility;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardAddressesWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardAliasesWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardAppliedProductsWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardAuxiliaryWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardBankInternalInfoWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardCDDComplianceWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardCDDWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardContactsWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardCustomerLinkWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardCustomerMultiLingualWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardCustomerNationaliltyWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardCustomerWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardDigitalIdentityWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardDocumentsWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardEmploymentsMandatoryWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardJointApplicantsWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardKYCWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardMiscWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardPreferencesWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardSourceOfWealthWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardSuspiciousFlagsWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardTarsCondnMandatoryWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardVerificationStatusWrapper;

@Component
public class ProfileDataValidator
{
	/**
	 * <Description>
	 * <p> 
	 * <p> 
	 *
	 * @param
	 * @return
	 * @exception
	 * @see
	 * @since
	 */
	public void validateRequestMessage(GBSOnboardCustomerWrapper customers,List<ErrorObject> errorList)
	{
		try
		{
			if(customers==null)
				return;

			/* VALIDATE BASE DATA VALIDATIONS */
			validateBaseData(customers,errorList);

			/* VALIDATE PDPA DATA */
			validatePdpa(customers,errorList);

			/* VALIDATE BANK INTERNAL BLOCK */
			validateBankInternalInfo(customers,errorList);

			/* VALIDATE SUSPICIOUS BLOCK */
			validateSuspiciousFlags(customers,errorList);

			/* VALIDATE CDD BLOCK */
			validateCddCompliance(customers,errorList);

			/* VALIDATE MULTILINGUAL BLOCK */
			validateCustomerMultilingual(customers,errorList);

			/* VALIDATE DIGITAL ENTITY */
			validateDigitalIdentity(customers,errorList);

			/* VALIDATE MISC DATA */
			validateMisc(customers,errorList);

			/* VALIDATE AUXILIARY DATA */
			validateAuxiliary(customers,errorList);

			/* VALIDATE ADDRESS */
			validateAddress(customers,errorList);

			/* VALIDATE CONTACTS */
			validateContacts(customers,errorList);

			/* VALIDATE ALIAS */
			validateAlias(customers,errorList);

			/* VALIDATE CDD */
			validateCdd(customers,errorList);

			/* VALIDATE KYC */
			validateKyc(customers,errorList);

			/* VALIDATE EMPLOYMENTS */
			validateEmployments(customers,errorList);

			/* VALIDATE SOURCE OF WEALTH */
			validateSourceOfWealth(customers,errorList);

			/* VALIDATE DOCUMENTS */
			validateDocuments(customers,errorList);

			/* VALIDATE TARS */
			validateTars(customers,errorList);

			/* VALIDATE PREFERENCES */
			validatePreferences(customers,errorList);

			/* VALIDATE APPLIED PRODUCTS */
			validateAppliedProducts(customers,errorList);

			/* VALIDATE JOINT APPLICANTS */
			validateJointApplicants(customers,errorList);

			/* VALIDATE VERIFICATION STATUS */
			validateVerificationStatus(customers,errorList);
		}
		catch(Exception e)
		{
			System.out.println("[ProfileDataValidator] [Validation Error]");
		}
	}

	/**
	 * <Description>
	 * <p> 
	 * <p> 
	 *
	 * @param
	 * @return
	 * @exception
	 * @see
	 * @since
	 */
	private void validateBaseData(GBSOnboardCustomerWrapper customers,List<ErrorObject> errorList)
	{
		try
		{
			if(!StringUtility.minMaxlength(customers.getSalutationCode(),"0","3")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_SALUTATION_CODE,"INVALID SALUTATION CODE ["+customers.getSalutationCode()+"] [ MAX-LENGTH 3 ]"));
			}

			if(!StringUtility.minMaxlength(customers.getFirstName(),"0","35")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_FIRST_NAME,"INVALID FIRST NAME ["+customers.getFirstName()+"] [ MAX-LENGTH 35 ]"));
			}

			if(!StringUtility.minMaxlength(customers.getMiddleName(),"0","35")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_MIDDLE_NAME,"INVALID MIDDLE NAME ["+customers.getMiddleName()+"] [ MAX-LENGTH 35 ]"));
			}

			if(!StringUtility.minMaxlength(customers.getLastName(),"0","35")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_LAST_NAME,"INVALID LAST NAME ["+customers.getLastName()+"] [ MAX-LENGTH 35 ]"));
			}

			if(!StringUtility.minMaxlength(customers.getFullName(),"0","110"))
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_FULL_NAME,"INVALID FULL NAME ["+customers.getFullName()+"] [ MAX-LENGTH 110 ]"));


			if(!StringUtility.minMaxlength(customers.getGender(),"0","1")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_GENDER,"INVALID GENDER ["+customers.getGender()+"] [ MAX-LENGTH 1 ]"));
			}

			if(customers.getDateOfBirth()==null) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_DATE_OF_BIRTH,"DATE OF BIRTH IS MANDATORY"));
			}

			if(!StringUtility.minMaxlength(customers.getResidentCountry(),"0","2")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_RESIDENT_COUNTRY,"INVALID RESIDENT COUNTRY CODE ["+customers.getResidentCountry()+"] [ MAX-LENGTH 2 ]"));
			}

			if(!StringUtility.minMaxlength(customers.getBirthCountry(),"0","2")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_BIRTH_COUNTRY,"INVALID BIRTH COUNTRY CODE ["+customers.getBirthCountry()+"] [ MAX-LENGTH 2 ]"));
			}

			if(!StringUtility.minMaxlength(customers.getAccountOpeningCountry(),"0","2")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_ACCOUNT_OPENING_COUNTRY,"INVALID ACCOUNT OPENING COUNTRY ["+customers.getAccountOpeningCountry()+"] [ MAX-LENGTH 2 ]"));
			}
		}
		catch(Exception e)
		{
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateBaseData", LogType.APPLICATION.name());
			log.printErrorMessage(e);
		}

	}
	
	private void validateBankInternalInfoExtended(GBSOnboardCustomerWrapper customers,List<ErrorObject> errorList)
	{
		GBSOnboardBankInternalInfoWrapper bank = customers.getObjBankInternalInfo();
		try
		{
			if(bank == null  ) {
				return;
			}

			if(!StringUtility.minMaxlength(bank.getCoreBankingReferenceKey(),"0","20")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_RELATIONSHIP_NUMBER,"INVALID RELATIONSHIP NUMBER ["+bank.getCoreBankingReferenceKey()+"] [ MAX-LENGTH 20 ]"));
			}

			if(!StringUtility.minMaxlength(bank.getAcquisitionChannel(),"0","4")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_ACQUISITION_CHANNEL,"INVALID ACQUISITION CHANNEL ["+bank.getAcquisitionChannel()+"] [ MAX-LENGTH 4 ]"));
			}

			if(!StringUtility.minMaxlength(bank.getCheckerDepartmentCode(),"0","3")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_CHECKER_DEPARTMENT_CODE,"INVALID CHECKER DEPARTMENT CODE ["+bank.getCheckerDepartmentCode()+"] [ MAX-LENGTH 3 ]"));
			}
			if(!StringUtility.minMaxlength(bank.getCaseOwnerPsid(),"0","7")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_CASE_OWNER_PSID,"INVALID CASE OWNER PSID ["+bank.getCaseOwnerPsid()+"] [ MAX-LENGTH 7 ]"));
			}
		}
		catch(Exception e)
		{
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateBankInternalInfoExtended", LogType.APPLICATION.name());
			log.printErrorMessage(e);
		}



	}

	/**
	 * <Description>
	 * <p>
	 * <p>
	 *
	 * @param
	 * @return
	 * @exception
	 * @see
	 * @since
	 */
	private void validatePdpa(GBSOnboardCustomerWrapper customers,List<ErrorObject> errorList) {

		List<GBSOnboardPdpaWrapper> pdpaList = customers.getObjOnboard_PdpaWrapper();

		if (pdpaList == null) {
			return;
		}

		try {
			for (GBSOnboardPdpaWrapper dat : pdpaList) {
				if (dat != null) {
					if (!StringUtility.minMaxlength(dat.getCcqSequence(), "0", "4")) {
						errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, PDPAConstant.INVALID_CUSTOMER_COMMUNICATION_QUESTION, "INVALID CUSTOMER COMMUNICATION QUESTION [" + dat.getCcqSequence() + "] [ MAX-LENGTH 4 ]"));
					}

					if (!StringUtility.minMaxlength(dat.getCustSelection(), "0", "1")) {
						errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, PDPAConstant.INVALID_CUSTOMER_COMMUNICATION_ANSWER, "INVALID CUSTOMER COMMUNICATION ANSWER  [" + dat.getCustSelection() + "] [ MAX-LENGTH 1 ]"));
					}
				}
			}
		} catch (Exception e) {
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validatePdpaQuestionaire", LogType.APPLICATION.name());
			log.printErrorMessage(e);
		}
	}

	/**
	 * <Description>
	 * <p> 
	 * <p> 
	 *
	 * @param
	 * @return
	 * @exception
	 * @see
	 * @since
	 */
	private void validateBankInternalInfo(GBSOnboardCustomerWrapper customers,List<ErrorObject> errorList)
	{
		GBSOnboardBankInternalInfoWrapper bank = customers.getObjBankInternalInfo();
		try
		{
			if(bank == null  ) {
				return;
			}

			if(!StringUtility.minMaxlength(bank.getHomeBranch(),"1","5")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_HOME_BRANCH,"INVALID HOME BRANCH ["+bank.getHomeBranch()+"] [  MIN-LENGTH 1 / MAX-LENGTH 5 ]"));
			}

			if(!StringUtility.minMaxlength(bank.getProfileType(),"0","1")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_PROFILE_TYPE,"INVALID PROFILE TYPE ["+bank.getProfileType()+"] [ MAX-LENGTH 1 ]"));
			}

			if(!StringUtility.minMaxlength(bank.getClientType(),"0","1")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_CLIENT_TYPE,"INVALID CLIENT TYPE ["+bank.getClientType()+"] [ MAX-LENGTH 1 ]"));
			}

			if(!StringUtility.minMaxlength(bank.getBsbdaFlag(),"0","1")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_BSBDA_FLAG,"INVALID BSBDA FLAG ["+bank.getBsbdaFlag()+"] [ MAX-LENGTH 1 ]"));
			}

			if(!StringUtility.minMaxlength(bank.getArmCode(),"0","3")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_ARM_CODE,"INVALID ARM CODE ["+bank.getArmCode()+"] [ MAX-LENGTH 3 ]"));
			}

			if(!StringUtility.minMaxlength(bank.getSegmentCode(),"0","2")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_SEGMENT_CODE,"INVALID SEGMENT CODE ["+bank.getSegmentCode()+"] [ MAX-LENGTH 2 ]"));
			}

			if(!StringUtility.minMaxlength(bank.getSubSegmentCode(),"0","3")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_SUB_SEGMENT_CODE,"INVALID SUB SEGMENT CODE ["+bank.getSubSegmentCode()+"] [ MAX-LENGTH 3 ]"));
			}

			if(!StringUtility.minMaxlength(bank.getServiceIndicatorCode(),"0","2")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_SERVICE_INDICATOR,"INVALID SERVICE INDICATOR ["+bank.getServiceIndicatorCode()+"] [ MAX-LENGTH 2 ]"));
			}

			validateBankInternalInfoExtended(customers, errorList);

		}
		catch(Exception e)
		{
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateBankInternalInfo", LogType.APPLICATION.name());
			log.printErrorMessage(e);
		}
	}

	/**
	 * <Description>
	 * <p> 
	 * <p> 
	 *
	 * @param
	 * @return
	 * @exception
	 * @see
	 * @since
	 */
	private void validateSuspiciousFlags(GBSOnboardCustomerWrapper customers,List<ErrorObject> errorList)
	{

		GBSOnboardSuspiciousFlagsWrapper suspicious = customers.getObjSuspiciousFlags();

		try
		{
			if(suspicious == null) {
				return;
			}

			if(!StringUtility.minMaxlength(suspicious.getAdverseFlag(),"0","2")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_ADVERSE_FLAG,"INVALID ADVERSE FLAG ["+customers.getAccountOpeningCountry()+"] [ MAX-LENGTH 2 ]"));
			}

			if(!StringUtility.minMaxlength(suspicious.getPepFlag(),"0","2")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_PEP_FLAG,"INVALID PEP FLAG ["+customers.getAccountOpeningCountry()+"] [ MAX-LENGTH 2 ]"));
			}

			if(!StringUtility.minMaxlength(suspicious.getPepDetails(),"0","500")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_PEP_DETAILS,"INVALID PEP DETAILS ["+customers.getAccountOpeningCountry()+"] [ MAX-LENGTH 500 ]"));
			}

			if(!StringUtility.minMaxlength(suspicious.getSanctionFlag(),"0","2")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_SANCTION_FLAG,"INVALID SANCTION FLAG ["+customers.getAccountOpeningCountry()+"] [ MAX-LENGTH 2 ]"));
			}
		}
		catch(Exception e)
		{
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateSuspiciousFlags", LogType.APPLICATION.name());
			log.printErrorMessage(e);
		}

	}

	/**
	 * <Description>
	 * <p> 
	 * <p> 
	 *
	 * @param
	 * @return
	 * @exception
	 * @see
	 * @since
	 */
	private void validateCddCompliance(GBSOnboardCustomerWrapper customers,List<ErrorObject> errorList)
	{

		GBSOnboardCDDComplianceWrapper cdd = customers.getObjCddCompliance();

		try
		{
			if(cdd == null) {
				return;
			}

			if(!StringUtility.minMaxlength(cdd.getNumberOfDeposits(),"0","5")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_NUMBER_OF_DEPOSITS,"INVALID NUMBER OF DEPOSITS ["+cdd.getNumberOfDeposits()+"] [ MAX-LENGTH 5 ]"));
			}


			if(!StringUtility.minMaxlength(cdd.getValueOfDeposits(),"0","20"))
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_VALUE_OF_DEPOSITS,"INVALID VALUE OF DEPOSITS ["+cdd.getValueOfDeposits()+"] [ MAX-LENGTH 20 ]"));


			if(!StringUtility.minMaxlength(cdd.getNumberOfWithdrawals(),"0","5")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_NUMBER_OF_WITHDRAWALS,"INVALID NUMBER OF WITHDRAWALS ["+cdd.getNumberOfWithdrawals()+"] [ MAX-LENGTH 5 ]"));
			}


			if(!StringUtility.minMaxlength(cdd.getValueOfWithdrawals(),"0","20"))
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_VALUE_OF_WITHDRAWALS,"INVALID VALUE OF WITHDRAWALS ["+cdd.getValueOfWithdrawals()+"] [ MAX-LENGTH 20 ]"));


			if(!StringUtility.minMaxlength(cdd.getClientSourceOfFund(),"0","3")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_SOURCE_OF_FUND,"INVALID SOURCE OF FUND ["+cdd.getClientSourceOfFund()+"] [ MAX-LENGTH 3 ]"));
			}

			if(!StringUtility.minMaxlength(cdd.getClientSourceOfFundOth(),"0","50")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_SOURCE_OF_FUNDS_OTHERS,"INVALID SOURCE OF FUNDS OTHERS ["+cdd.getClientSourceOfFundOth()+"] [ MAX-LENGTH 50 ]"));
			}

			if(!StringUtility.minMaxlength(cdd.getPurposeOfAccountOpeningOffshore(),"0","3")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_PURPOSE_OF_ACCOUNT_OPENING_OFFSHORE,"INVALID PURPOSE OF ACCOUNT OPENING OFFSHORE ["+cdd.getPurposeOfAccountOpeningOffshore()+"] [ MAX-LENGTH 3 ]"));
			}

			if(!StringUtility.minMaxlength(cdd.getPurposeOfAccountOpeningOffshoreOthers(),"0","50")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_PURPOSE_OF_ACCOUNT_OPENING_OFFSHORE_OTHERS,"INVALID PURPOSE OF ACCOUNT OPENING OFFSHORE -OTHERS- ["+cdd.getPurposeOfAccountOpeningOffshoreOthers()+"] [ MAX-LENGTH 50 ]"));
			}
		}
		catch(Exception e)
		{
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateCddCompliance", LogType.APPLICATION.name());
			log.printErrorMessage(e);
		}

	}

	/**
	 * <Description>
	 * <p>
	 * <p>
	 *
	 * @param
	 * @return
	 * @exception
	 * @see
	 * @since
	 */
	private void validateCustomerMultilingual(GBSOnboardCustomerWrapper customers,List<ErrorObject> errorList)
	{

		GBSOnboardCustomerMultiLingualWrapper multiLingual = customers.getObjOnboard_CustomerMultiLingualWrapper();

		try
		{
			if(multiLingual == null) {
				return;
			}

			//N.A
		}
		catch(Exception e)
		{
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateCustomerMultilingual", LogType.APPLICATION.name());
			log.printErrorMessage(e);
		}

	}

	/**
	 * <Description>
	 * <p>
	 * <p>
	 *
	 * @param
	 * @return
	 * @exception
	 * @see
	 * @since
	 */
	private void validateDigitalIdentity(GBSOnboardCustomerWrapper customers,List<ErrorObject> errorList)
	{

		List<GBSOnboardDigitalIdentityWrapper> digitalList = customers.getObjOnboard_DigitalIdentityWrapper();

		try
		{
			if (digitalList==null || digitalList.size()==0) {
				return;
			}

			for ( GBSOnboardDigitalIdentityWrapper dat : digitalList)
			{
				if(!StringUtility.minMaxlength(dat.getDeviceType(),"0","3")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_DEVICE_TYPE,"INVALID DEVICE TYPE ["+dat.getDeviceType()+"] [ MAX-LENGTH 3 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getDeviceValue(),"0","50")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_DEVICE_TYPE_VALUE,"INVALID DEVICE TYPE VALUE ["+dat.getDeviceValue()+"] [ MAX-LENGTH 50 ]"));
				}
			}
		}
		catch(Exception e)
		{
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateDigitalIdentity", LogType.APPLICATION.name());
			log.printErrorMessage(e);
		}

	}

	/**
	 * <Description>
	 * <p>
	 * <p>
	 *
	 * @param
	 * @return
	 * @exception
	 * @see
	 * @since
	 */
	private void validateMisc(GBSOnboardCustomerWrapper customers,List<ErrorObject> errorList)
	{

		List<GBSOnboardMiscWrapper> miscList = customers.getObjOnboard_MiscWrapper();

		try
		{
			if (miscList==null || miscList.size()==0) {
				return;
			}

			for (GBSOnboardMiscWrapper dat : miscList)
			{
				if(!StringUtility.minMaxlength(dat.getMisc_code(),"0","3")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_MISC_CODE,"INVALID MISC CODE ["+dat.getMisc_code()+"] [ MAX-LENGTH 3 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getMisc_value(),"0","99")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_MISC_VALUE,"INVALID MISC VALUE ["+dat.getMisc_value()+"] [ MAX-LENGTH 99 ]"));
				}

			}
		}
		catch(Exception e)
		{
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateMisc", LogType.APPLICATION.name());
			log.printErrorMessage(e);
		}

	}

	/**
	 * <Description>
	 * <p>
	 * <p>
	 *
	 * @param
	 * @return
	 * @exception
	 * @see
	 * @since
	 */
	private void validateAuxiliary(GBSOnboardCustomerWrapper customers,List<ErrorObject> errorList)
	{

		List<GBSOnboardAuxiliaryWrapper> auxList = customers.getObjOnboard_AuxiliaryWrapper();

		try
		{
			if (auxList==null || auxList.size()==0) {
				return;
			}

			for (GBSOnboardAuxiliaryWrapper dat : auxList)
			{
				if(!StringUtility.minMaxlength(dat.getAuxiliary_code(),"0","3")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_AUXILIARY_CODE,"INVALID AUXILIARY CODE ["+dat.getAuxiliary_code()+"] [ MAX-LENGTH 3 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getAuxiliary_value(),"0","99")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_AUXILIARY_VALUE,"INVALID AUXILIARY VALUE ["+dat.getAuxiliary_value()+"] [ MAX-LENGTH 99 ]"));
				}
			}
		}
		catch(Exception e)
		{
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateAuxiliary", LogType.APPLICATION.name());
			log.printErrorMessage(e);
		}

	}

	/**
	 * <Description>
	 * <p>
	 * <p>
	 *
	 * @param
	 * @return
	 * @exception
	 * @see
	 * @since
	 */
	private void validateAddress(GBSOnboardCustomerWrapper customers,List<ErrorObject> errorList)
	{

		List<GBSOnboardAddressesWrapper> addressList = customers.getObjOnboard_AddressesWrapper();

		try
		{
			if (addressList == null || addressList.size()==0) {
				return;
			}

			for (GBSOnboardAddressesWrapper dat : addressList)
			{
				if(!StringUtility.minMaxlength(dat.getAddressType(),"0","3")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_ADDRESS_TYPE,"INVALID ADDRESS TYPE ["+dat.getAddressType()+"] [ MAX-LENGTH 3 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getAddressLine1(),"0","30")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_ADDRESS_LINE_1,"INVALID ADDRESS LINE 1 ["+dat.getAddressLine1()+"] [ MAX-LENGTH 30 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getAddressLine2(),"0","30")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_ADDRESS_LINE_2,"INVALID ADDRESS LINE 2 ["+dat.getAddressLine2()+"] [ MAX-LENGTH 30 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getAddressLine3(),"0","30")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_ADDRESS_LINE_3,"INVALID ADDRESS LINE 3 ["+dat.getAddressLine3()+"] [ MAX-LENGTH 30 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getCityName(),"0","25")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_CITY_NAME,"INVALID CITY NAME ["+dat.getCityName()+"] [ MAX-LENGTH 25 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getState(),"0","15")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_STATE,"INVALID STATE ["+dat.getState()+"] [ MAX-LENGTH 15 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getCountryCode(),"0","2")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_COUNTRY_CODE,"INVALID COUNTRY CODE ["+dat.getCountryCode()+"] [ MAX-LENGTH 2 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getPostalCode(),"0","10")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_POSTAL_CODE,"INVALID POSTAL CODE ["+dat.getPostalCode()+"] [ MAX-LENGTH 10 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getNearestLandMark(),"0","30")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_NEAREST_LANDMARK,"INVALID NEAREST LANDMARK ["+dat.getNearestLandMark()+"] [ MAX-LENGTH 30 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getIsMailingAddress(),"0","1")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_MAILING_ADDRESS,"INVALID MAILING ADDRESS ["+dat.getIsMailingAddress()+"] [ MAX-LENGTH 1 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getPostBoxNo(),"0","10")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_POST_BOX_NUMBER,"INVALID POST BOX NUMBER ["+dat.getPostBoxNo()+"] [ MAX-LENGTH 10 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getPoaDocument(),"0","3")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_POA_DOCUMENT,"INVALID POA DOCUMENT ["+dat.getPoaDocument()+"] [ MAX-LENGTH 3 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getStateCode(),"0","2")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_STATE_CODE,"INVALID STATE CODE ["+dat.getStateCode()+"] [ MAX-LENGTH 2 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getLangId(),"0","1")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_LANGUAGE_ID,"INVALID LANGUAGE ID ["+dat.getLangId()+"] [ MAX-LENGTH 1 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getAddressClassificationCode(),"0","1")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_ADDRESS_CLASSIFICATION_CODE,"INVALID ADDRESS CLASSIFICATION CODE ["+dat.getAddressClassificationCode()+"] [ MAX-LENGTH 1 ]"));
				}

				//LENGTH DEFAULTED
				if(!StringUtility.minMaxlength(dat.getLocalGovernmentAreaCode(),"0","999")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_LOCAL_GOVERNMENT_AREA_CODE,"INVALID LOCAL GOVERNMENT AREA CODE ["+dat.getLocalGovernmentAreaCode()+"] [ MAX-LENGTH 999 ]"));
				}

				validateCombinedCityAndState(dat,errorList);
			}
		}
		catch(Exception e)
		{
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateAddress", LogType.APPLICATION.name());
			log.printErrorMessage(e);
		}

	}

	private void validateCombinedCityAndState(GBSOnboardAddressesWrapper dat, List<ErrorObject> errorList) {
		try {
			if(((dat.getCityName()==null?0:dat.getCityName().length()) + (dat.getState()==null?0:dat.getState().length())) >29 ){
				String err ="" + (((dat.getCityName() == null || (dat.getCityName().trim().length() == 0)) ? "" : dat.getCityName() + ",")
						+ ((dat.getState() == null || dat.getState().trim().length() == 0) ? "" : dat.getState())).replaceAll(",$", "");
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_CITY_NAME_AND_STATE,"INVALID LENGTH FOR CITY NAME AND STATE (COMBINED) ["+err+"] [ MAX-LENGTH 29 ]"));
			}
		}
		catch(Exception e) {
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateCombinedCityAndState", LogType.APPLICATION.name());
			log.printErrorMessage(e);
		}
	}

	/**
	 * <Description>
	 * <p>
	 * <p>
	 *
	 * @param
	 * @return
	 * @exception
	 * @see
	 * @since
	 */
	private void validateContacts(GBSOnboardCustomerWrapper customers,List<ErrorObject> errorList)
	{
		List<GBSOnboardContactsWrapper> contList = customers.getObjOnboard_ContactsWrapper();

		try
		{
			if (contList==null || contList.size()==0) {
				return;
			}

			for (GBSOnboardContactsWrapper dat : contList)
			{
				if(StringUtility.containsData(dat.getContactClassificationCode()) &&
						(
								dat.getContactClassificationCode().equalsIgnoreCase("M") ||
								dat.getContactClassificationCode().equalsIgnoreCase("O") ||
								dat.getContactClassificationCode().equalsIgnoreCase("T")
								)
						)
				{
					if(!StringUtility.minMaxlength(dat.getContact(),"0","17")) {
						errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_CONTACT,"INVALID CONTACT ["+dat.getContact()+"] [ MAX-LENGTH 17 ]"));
					}

				} else {

					if(!StringUtility.minMaxlength(dat.getContact(),"0","70"))
						errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_CONTACT,"INVALID CONTACT ["+dat.getContact()+"] [ MAX-LENGTH 70 ]"));

				}

				if(!StringUtility.minMaxlength(dat.getContactClassificationCode(),"1","1")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_CONTACT_CLASSIFICATION_CODE,"INVALID CONTACT CLASSIFICATION CODE ["+dat.getContactClassificationCode()+"]"));
				}

				if(!StringUtility.minMaxlength(dat.getContactTypeCode(),"0","3")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_CONTACT_TYPE_CODE,"INVALID CONTACT TYPE CODE ["+dat.getContactTypeCode()+"] [ MAX-LENGTH 3 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getCountryCode(),"0","10")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_CONTACT_COUNTRY_CODE,"INVALID CONTACT COUNTRY CODE ["+dat.getCountryCode()+"] [ MAX-LENGTH 10 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getAreaCode(),"0","5")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_AREA_CODE,"INVALID AREA CODE ["+dat.getAreaCode()+"] [ MAX-LENGTH 5 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getExtensionDetail(),"0","7")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_EXTENSION_DETAIL,"INVALID EXTENSION DETAIL ["+dat.getExtensionDetail()+"] [ MAX-LENGTH 7 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getPreferredContact(),"0","1")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_PREFERRED_CONTACT,"INVALID PREFERRED CONTACT ["+dat.getPreferredContact()+"] [ MAX-LENGTH 1 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getPrimaryContact(),"0","1")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_PRIMARY_CONTACT,"INVALID PRIMARY CONTACT ["+dat.getPrimaryContact()+"] [ MAX-LENGTH 1 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getDoNotDisturbRegistry(),"0","1")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_DND_REGISTRY,"INVALID DND REGISTRY ["+dat.getDoNotDisturbRegistry()+"] [ MAX-LENGTH 1 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getAttentionParty(),"0","100")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_ATTENTION_PARTY,"INVALID ATTENTION PARTY ["+dat.getAttentionParty()+"] [ MAX-LENGTH 100 ]"));
				}

				//DEFAULTED

				if(!StringUtility.minMaxlength(dat.getIsdContactCountryCode(),"0","2"))
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_ISD_COUNTRY_CODE,"INVALID ISD COUNTRY CODE ["+dat.getIsdContactCountryCode()+"] [ MAX-LENGTH 2 ]"));

			}
		}
		catch(Exception e)
		{
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateContacts", LogType.APPLICATION.name());
			log.printErrorMessage(e);
		}

	}

	/**
	 * <Description>
	 * <p>
	 * <p>
	 *
	 * @param
	 * @return
	 * @exception
	 * @see
	 * @since
	 */
	private void validateAlias(GBSOnboardCustomerWrapper customers,List<ErrorObject> errorList)
	{
		List<GBSOnboardAliasesWrapper> aliasList = customers.getObjOnboard_AliasesWrapper();

		try
		{
			if (aliasList  == null || aliasList.size()==0) {
				return;
			}

			for (GBSOnboardAliasesWrapper dat : aliasList)
			{
				if(!StringUtility.minMaxlength(dat.getAliasType(),"0","3")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_ALIAS_TYPE,"INVALID ALIAS TYPE ["+dat.getAliasType()+"] [ MAX-LENGTH 3 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getAliasName(),"0","40")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_ALIAS_NAME,"INVALID ALIAS NAME ["+dat.getAliasName()+"] [ MAX-LENGTH 110 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getLangId(),"0","1")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_LANGUAGE_ID_ALIAS,"INVALID LANGUAGE ID - ALIAS ["+dat.getLangId()+"] [ MAX-LENGTH 1 ]"));
				}
			}
		}
		catch(Exception e)
		{
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateAlias", LogType.APPLICATION.name());
			log.printErrorMessage(e);
		}

	}

	/**
	 * <Description>
	 * <p>
	 * <p>
	 *
	 * @param
	 * @return
	 * @exception
	 * @see
	 * @since
	 */
	private void validateCdd(GBSOnboardCustomerWrapper customers,List<ErrorObject> errorList)
	{
		List<GBSOnboardCDDWrapper> cddList = customers.getObjOnboard_CDDWrapper();
		try
		{
			if (ObjectUtils.isEmpty(cddList)) {
				return;
			}

			for (GBSOnboardCDDWrapper dat : cddList)
			{
				if(!StringUtility.minMaxlength(dat.getCddRiskRating(),"0","3")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_CDD_RATING,"INVALID CDD RATING ["+dat.getCddRiskRating()+"] [ MAX-LENGTH 3 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getCddReviewStatus(),"0","1")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_CDD_REVIEW_STATUS,"INVALID CDD REVIEW STATUS ["+dat.getCddReviewStatus()+"] [ MAX-LENGTH 1 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getCddReason(),"0","250")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_CDD_REASON,"INVALID CDD REASON ["+dat.getCddReason()+"] [ MAX-LENGTH 250 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getSddEligibleStatus(),"0","1")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_SDD_ELIGIBLE_STATUS,"INVALID SDD ELIGIBLE STATUS ["+dat.getSddEligibleStatus()+"] [ MAX-LENGTH 1 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getCountryReviewStatus(),"0","1")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_COUNTRY_REVIEW_STATUS,"INVALID COUNTRY REVIEW STATUS ["+dat.getCountryReviewStatus()+"] [ MAX-LENGTH 1 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getCddReviewedFlag(),"0","1")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_CDD_REVIEW_FLAG,"INVALID CDD REVIEW FLAG ["+dat.getCddReviewedFlag()+"] [ MAX-LENGTH 1 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getCddLastReviewedBy(),"0","10")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_CDD_LAST_REVIEWED_BY,"INVALID CDD LAST REVIEWED BY ["+dat.getCddLastReviewedBy()+"] [ MAX-LENGTH 10 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getSenderId(),"0","15")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_SENDER_ID,"INVALID SENDER ID ["+dat.getSenderId()+"] [ MAX-LENGTH 15 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getSenderBranch(),"0","5")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_SENDER_BRANCH,"INVALID SENDER BRANCH ["+dat.getSenderBranch()+"] [ MAX-LENGTH 5 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getIcddReference(),"0","30")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_ICDD_REFERENCE,"INVALID ICDD REFERENCE ["+dat.getIcddReference()+"] [ MAX-LENGTH 30 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getCupidReference(),"0","30")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_CUPID_REFERENCE,"INVALID CUPID REFERENCE ["+dat.getCupidReference()+"] [ MAX-LENGTH 30 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getCrsStatus(),"0","20")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_CRS_STATUS,"INVALID CRS STATUS ["+dat.getCrsStatus()+"] [ MAX-LENGTH 20 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getCrsRemarks(),"0","30")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_CRD_REMARKS,"INVALID CRD REMARKS ["+dat.getCrsRemarks()+"] [ MAX-LENGTH 30 ]"));
				}
			}
		}
		catch(Exception e)
		{
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateCdd", LogType.APPLICATION.name());
			log.printErrorMessage(e);
		}

	}

	/** 
	 * <Description>
	 * <p>
	 * <p>
	 *
	 * @param
	 * @return
	 * @exception
	 * @see
	 * @since
	 */
	private void validateKyc(GBSOnboardCustomerWrapper customers,List<ErrorObject> errorList)
	{

		GBSOnboardKYCWrapper kyc = customers.getObjOnboard_KYCWrapper();

		try
		{
			if(kyc == null) {
				return;
			}

			if(!StringUtility.minMaxlength(kyc.getQualificationCode(),"0","3")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_QUALIFICATION_CODE,"INVALID QUALIFICATION CODE ["+kyc.getQualificationCode()+"] [ MAX-LENGTH 3 ]"));
			}

			if(!StringUtility.minMaxlength(kyc.getMaritalStatus(),"0","1")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_MARITAL_STATUS,"INVALID MARITAL STATUS ["+kyc.getMaritalStatus()+"] [ MAX-LENGTH 1 ]"));
			}

			if(!StringUtility.minMaxlength(kyc.getPlaceOfBirth(),"0","25")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_PLACE_OF_BIRTH,"INVALID PLACE OF BIRTH ["+kyc.getPlaceOfBirth()+"] [ MAX-LENGTH 25 ]"));
			}

			//DEFAULT
			if(!StringUtility.minMaxlength(kyc.getAiStatus(),"0","999")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_AI_STATUS,"INVALID AI STATUS ["+kyc.getAiStatus()+"] [ MAX-LENGTH 999 ]"));
			}

			//DEFAULT
			if(!StringUtility.minMaxlength(kyc.getAiOptIn(),"0","999")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_AI_OPT_IN,"INVALID AI OPT IN ["+kyc.getAiOptIn()+"] [ MAX-LENGTH 999 ]"));
			}

			if(!StringUtility.minMaxlength(kyc.getMotherMaidenName(),"0","35")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_MOTHER_MAIDEN_NAME,"INVALID MOTHER MAIDEN NAME ["+kyc.getMotherMaidenName()+"] [ MAX-LENGTH 35 ]"));
			}

			List<GBSOnboardCustomerNationaliltyWrapper> nationList = kyc.getNationality();
			if(nationList!=null && nationList.size()>0)
			{
				for( GBSOnboardCustomerNationaliltyWrapper dat : nationList)
				{
					if(!StringUtility.minMaxlength(dat.getNationalityCode(),"0","3")) {
						errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_NATIONALITY_CODE ,"INVALID NATIONALITY CODE ["+dat.getNationalityCode()+"] [ MAX-LENGTH 3 ]"));
					}
				}
			}

			List<GBSOnboardCustomerLinkWrapper> linksList = kyc.getObjOnboard_Customer_LinkWrapper();
			if(linksList!=null && linksList.size()>0)
			{
				for( GBSOnboardCustomerLinkWrapper dat : linksList)
				{
					//DEFAULTED
					if(!StringUtility.minMaxlength(dat.getRelationshipTypeCode(),"0","999")) {
						errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_RELATIONSHIP_TYPE_CODE,"INVALID RELATIONSHIP TYPE CODE ["+dat.getRelationshipTypeCode()+"] [ MAX-LENGTH 999 ]"));
					}

					//DEFAULTED
					if(!StringUtility.minMaxlength(dat.getLinkedRelationshipNumber(),"0","999")) {
						errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_LINKED_RELATIONSHIP_NUMBER,"INVALID LINKED RELATIONSHIP NUMBER ["+dat.getLinkedRelationshipNumber()+"] [ MAX-LENGTH 999 ]"));
					}

					//DEFAULTED
					if(!StringUtility.minMaxlength(dat.getLinkedRelationshipName(),"0","999")) {
						errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_LINKED_RELATIONSHIP_NAME,"INVALID LINKED RELATIONSHIP NAME ["+dat.getLinkedRelationshipName()+"] [ MAX-LENGTH 999 ]"));
					}

					//DEFAULTED
					if(!StringUtility.minMaxlength(dat.getEntityReferenceNumber(),"0","999")) {
						errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_ENTITY_RELATIONSHIP_NUMBER,"INVALID ENTITY RELATIONSHIP NUMBER ["+dat.getEntityReferenceNumber()+"] [ MAX-LENGTH 999 ]"));
					}

					//DEFAULTED
					if(!StringUtility.minMaxlength(dat.getSenderId(),"0","999")) {
						errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_LINK_SENDER_ID,"INVALID LINK SENDER ID ["+dat.getSenderId()+"] [ MAX-LENGTH 999 ]"));
					}

					//DEFAULTED
					if(!StringUtility.minMaxlength(dat.getSenderBranch(),"0","999")) {
						errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_LINK_SENDER_BRANCH,"INVALID SENDER BRANCH ["+dat.getSenderBranch()+"] [ MAX-LENGTH 999 ]"));
					}

				}
			}
		}
		catch(Exception e)
		{
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateKyc", LogType.APPLICATION.name());
			log.printErrorMessage(e);
		}

	}

	/**
	 * <Description>
	 * <p>
	 * <p>
	 *
	 * @param
	 * @return
	 * @exception
	 * @see
	 * @since
	 */
	private void validateEmployments(GBSOnboardCustomerWrapper customers,List<ErrorObject> errorList)
	{
		GBSOnboardEmploymentsMandatoryWrapper dat = customers.getObjOnboard_EmploymentsMandatoryWrapper();

		try
		{
			if(dat == null) {
				return;
			}

			if(!StringUtility.minMaxlength(dat.getWorkType(),"0","1")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_WORK_TYPE,"INVALID WORK TYPE ["+dat.getWorkType()+"] [ MAX-LENGTH 1 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getProfessionCode(),"0","3")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_PROFESSION_CODE,"INVALID PROFESSION CODE ["+dat.getProfessionCode()+"] [ MAX-LENGTH 3 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getEmployerCode(),"0","5")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_EMPLOYER_CODE,"INVALID EMPLOYER CODE ["+dat.getEmployerCode()+"] [ MAX-LENGTH 5 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getEmployerName(),"0","110")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_EMPLOYER_NAME,"INVALID EMPLOYER NAME ["+dat.getEmployerName()+"] [ MAX-LENGTH 110 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getStaffCategoryCode(),"0","3")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_STAFF_CATEGORY_CODE,"INVALID STAFF CATEGORY CODE ["+dat.getStaffCategoryCode()+"] [ MAX-LENGTH 3 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getBankPricingCategoryCode(),"0","1")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_BANK_PRICING_CATEGORY_CODE,"INVALID BANK PRICING CATEGORY CODE ["+dat.getBankPricingCategoryCode()+"] [ MAX-LENGTH 1 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getOwnOrganisationName(),"0","35")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_OWN_ORGANIZATION_NAME,"INVALID OWN ORGANIZATION NAME ["+dat.getOwnOrganisationName()+"] [ MAX-LENGTH 35 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getEmpBankingInd(),"0","1")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_EMPLOYER_BANKING_ID,"INVALID EMPLOYER BANKING ID ["+dat.getEmpBankingInd()+"] [ MAX-LENGTH 1 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getStaffEmpId(),"0","10")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_STAFF_ID ,"INVALID STAFF ID ["+dat.getStaffEmpId()+"] [ MAX-LENGTH 10 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getSalaryMode(),"0","3")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_SALARY_MODE,"INVALID SALARY MODE ["+dat.getSalaryMode()+"] [ MAX-LENGTH 3 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getDeclaredIncomeCurrency(),"0","3")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_DECLARED_INCOME_CURRENCY,"INVALID DECLARED INCOME CURRENCY ["+dat.getDeclaredIncomeCurrency()+"] [ MAX-LENGTH 3 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getDerivedIncomeCurrency(),"0","3")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_DERIVED_INCOME_CURRENCY,"INVALID DERIVED INCOME CURRENCY ["+dat.getDerivedIncomeCurrency()+"] [ MAX-LENGTH 3 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getDocumentedIncomeCurrency(),"0","3")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_DOCUMENTED_INCOME_CURRENCY ,"INVALID DOCUMENTED INCOME CURRENCY ["+dat.getDocumentedIncomeCurrency()+"] [ MAX-LENGTH 3 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getProxyIncomeCurrency(),"0","3")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_PROXY_INCOME_CURRENCY,"INVALID PROXY INCOME CURRENCY ["+dat.getProxyIncomeCurrency()+"] [ MAX-LENGTH 3 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getIsicCode(),"0","6")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_ISIC_CODE,"INVALID ISIC CODE ["+dat.getIsicCode()+"] [ MAX-LENGTH 6 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getAssetUnderManagementCurrency(),"0","3")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_ASSET_MANAGEMENT_CURRENCY,"INVALID ASSET MANAGEMENT CURRENCY ["+dat.getAssetUnderManagementCurrency()+"] [ MAX-LENGTH 3 ]"));
			}

			//DEFAULTED
			if(!StringUtility.minMaxlength(dat.getCustomerOccupation(),"0","999")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_CUSTOMER_OCCUPATION,"INVALID CUSTOMER OCCUPATION ["+dat.getCustomerOccupation()+"] [ MAX-LENGTH 999 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getIndustryCode(),"0","4")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_INDUSTRY_CODE,"INVALID INDUSTRY CODE ["+dat.getIndustryCode()+"] [ MAX-LENGTH 4 ]"));
			}
			if(!StringUtility.minMaxlength(dat.getPositionTitle(),"0","3")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_POSITION_TITLE,"INVALID POSITION TITLE ["+dat.getPositionTitle()+"] [ MAX-LENGTH 3 ]"));
			}

		}
		catch(Exception e)
		{
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateEmployments", LogType.APPLICATION.name());
			log.printErrorMessage(e);
		}

	}

	/**
	 * <Description>
	 * <p>
	 * <p>
	 *
	 * @param
	 * @return
	 * @exception
	 * @see
	 * @since
	 */
	private void validateSourceOfWealth(GBSOnboardCustomerWrapper customers,List<ErrorObject> errorList)
	{

		GBSOnboardSourceOfWealthWrapper dat = customers.getObjOnboard_SourceOfWealthWrapper();

		try
		{

			if(dat == null) {
				return;
			}

			if(!StringUtility.minMaxlength(dat.getPrimarySource(),"0","15")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_PRIMARY_SOURCE_SOURCE_OF_WEALTH,"INVALID PRIMARY SOURCE [SOURCE OF WEALTH] ["+dat.getPrimarySource()+"] [ MAX-LENGTH 15 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getOccupationCode(),"0","3")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_OCCUPATION_CODE_SOURCE_OF_WEALTH,"INVALID OCCUPATION CODE [SOURCE OF WEALTH] ["+dat.getOccupationCode()+"] [ MAX-LENGTH 3 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getEmployerName(),"0","110")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_EMPLOYER_NAME_SOURCE_OF_WEALTH,"INVALID EMPLOYER NAME [SOURCE OF WEALTH] ["+dat.getEmployerName()+"] [ MAX-LENGTH 110 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getEmployerAddress(),"0","200")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_EMPLOYER_ADDRESS_SOURCE_OF_WEALTH,"INVALID EMPLOYER ADDRESS [SOURCE OF WEALTH] ["+dat.getEmployerAddress()+"] [ MAX-LENGTH 200 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getEmploymentIncome(),"0","20")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_EMPLOYER_INCOME_SOURCE_OF_WEALTH,"INVALID EMPLOYER INCOME [SOURCE OF WEALTH] ["+dat.getEmploymentIncome()+"] [ MAX-LENGTH 20 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getEmploymentIncomeCurrency(),"0","3")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_EMPLOYER_INCOME_CURRENCY_SOURCE_OF_WEALTH,"INVALID EMPLOYER INCOME CURRENCY [SOURCE OF WEALTH] ["+dat.getEmploymentIncomeCurrency()+"] [ MAX-LENGTH 3 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getBusinessType(),"0","110")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_BUSINESS_TYPE_SOURCE_OF_WEALTH,"INVALID BUSINESS TYPE [SOURCE OF WEALTH] ["+dat.getBusinessType()+"] [ MAX-LENGTH 110 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getBusinessName(),"0","110")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_BUSINESS_NAME_SOURCE_OF_WEALTH,"INVALID BUSINESS NAME [SOURCE OF WEALTH] ["+dat.getBusinessName()+"] [ MAX-LENGTH 110 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getBusinessAddress(),"0","200")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_BUSINESS_ADDRESS_SOURCE_OF_WEALTH,"INVALID BUSINESS ADDRESS [SOURCE OF WEALTH] ["+dat.getBusinessAddress()+"] [ MAX-LENGTH 200 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getBusinessIncome(),"0","20")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_BUSINESS_INCOME_SOURCE_OF_WEALTH,"INVALID BUSINESS INCOME [SOURCE OF WEALTH] ["+dat.getBusinessIncome()+"] [ MAX-LENGTH 20 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getBusinessIncomeCurrency(),"0","3")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_BUSINESS_CURRENCY_SOURCE_OF_WEALTH,"INVALID BUSINESS CURRENCY [SOURCE OF WEALTH] ["+dat.getBusinessIncomeCurrency()+"] [ MAX-LENGTH 3 ]"));
			}


			if(!StringUtility.minMaxlength(dat.getPreviousCompanyName(),"0","110")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_PREVIOUS_COMPANY_NAME,"INVALID PREVIOUS COMPANY NAME ["+dat.getPreviousCompanyName()+"] [ MAX-LENGTH 110 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getRelationshipWithFundingMember(),"0","5")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_DATA_FOR_RELATIONSHIP_WITH_FUNDING_MEMBER,"INVALID DATA FOR RELATIONSHIP WITH FUNDING MEMBER ["+dat.getRelationshipWithFundingMember()+"] [ MAX-LENGTH 5 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getFundingMemberEmployeeName(),"0","110")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_FUNDING_EMPLOYEE_NAME,"INVALID FUNDING EMPLOYEE NAME ["+dat.getFundingMemberEmployeeName()+"] [ MAX-LENGTH 110 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getRelationshipWithBenefactor(),"0","5")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_RELATIONSHIP_WITH_BENEFACTOR ,"INVALID RELATIONSHIP WITH BENEFACTOR ["+dat.getRelationshipWithBenefactor()+"] [ MAX-LENGTH 5 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getBenefactorEmployeeName(),"0","110")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_EMPLOYEE_NAME,"INVALID EMPLOYEE NAME ["+dat.getBenefactorEmployeeName()+"] [ MAX-LENGTH 110 ]"));
			}
			if(!StringUtility.minMaxlength(dat.getSowArticulation(),"0","4000")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_SOW_ARTICULATION  ,"INVALID SOW ARTICULATION   ["+dat.getSowArticulation()+"] [ MAX-LENGTH 4000 ]"));
			}
		}
		catch(Exception e)
		{
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateSourceOfWealth", LogType.APPLICATION.name());
			log.printErrorMessage(e);
		}

	}

	/**
	 * <Description>
	 * <p>
	 * <p>
	 *
	 * @param
	 * @return
	 * @exception
	 * @see
	 * @since
	 */
	private void validateDocuments(GBSOnboardCustomerWrapper customers,List<ErrorObject> errorList)
	{

		List<GBSOnboardDocumentsWrapper> docList = customers.getObjOnboard_DocumentsWrapper();

		try
		{
			if (docList==null || docList.size()==0) {
				return;
			}

			for (GBSOnboardDocumentsWrapper dat : docList)
			{
				if(!StringUtility.minMaxlength(dat.getDocumentType(),"0","3")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_DOCUMENT_TYPE,"INVALID DOCUMENT TYPE ["+dat.getDocumentType()+"] [ MAX-LENGTH 3 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getDocumentCode(),"0","1")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_DOCUMENT_CODE,"INVALID DOCUMENT CODE ["+dat.getDocumentCode()+"] [ MAX-LENGTH 1 ]"));
				}


				if(!StringUtility.minMaxlength(dat.getDocumentNumber(),"0","30"))
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_DOCUMENT_NUMBER,"INVALID DOCUMENT NUMBER ["+dat.getDocumentNumber()+"] [ MAX-LENGTH 30 ]"));

				if(!StringUtility.minMaxlength(dat.getTaxResidenceCountry(),"0","2")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_TAX_RESIDENCY_COUNTRY,"INVALID TAX RESIDENCY COUNTRY ["+dat.getTaxResidenceCountry()+"] [ MAX-LENGTH 2 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getW8nSupportDocumentIndicator(),"0","1")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_W8N_SUPPORT_INDICATOR,"INVALID W8N SUPPORT INDICATOR ["+dat.getW8nSupportDocumentIndicator()+"] [ MAX-LENGTH 1 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getCountryTreaty(),"0","2")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_COUNTRY_OF_TREATY,"INVALID COUNTRY OF TREATY ["+dat.getCountryTreaty()+"] [ MAX-LENGTH 2 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getDocumentEvidenceLink(),"0","200")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_DOCUMENT_EVIDENCE_LINK,"INVALID DOCUMENT EVIDENCE LINK ["+dat.getDocumentEvidenceLink()+"] [ MAX-LENGTH 200 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getDocRemarks(),"0","250")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_DOCUMENT_REMARKS,"INVALID DOCUMENT REMARKS ["+dat.getDocRemarks()+"] [ MAX-LENGTH 250 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getDocReasonCode(),"0","5")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_DOCUMENT_REASON_CODE,"INVALID DOCUMENT REASON CODE ["+dat.getDocReasonCode()+"] [ MAX-LENGTH 5 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getExpiryCheckOverride(),"0","1")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_EXPIRY_CHECK_OVERRIDE,"INVALID EXPIRY CHECK OVERRIDE ["+dat.getExpiryCheckOverride()+"] [ MAX-LENGTH 1 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getPoiDocument(),"0","1")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_POI_DOCUMENT,"INVALID POI DOCUMENT ["+dat.getPoiDocument()+"] [ MAX-LENGTH 1 ]"));
				}

			}
		}
		catch(Exception e)
		{
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateDocuments", LogType.APPLICATION.name());
			log.printErrorMessage(e);
		}

	}

	/**
	 * <Description>
	 * <p>
	 * <p>
	 *
	 * @param
	 * @return
	 * @exception
	 * @see
	 * @since
	 */
	private void validateTars(GBSOnboardCustomerWrapper customers,List<ErrorObject> errorList)
	{

		GBSOnboardTarsCondnMandatoryWrapper dat = customers.getObjOnboard_TarsCondnMandatoryWrapper();

		try
		{
			if(dat == null) {
				return;
			}

			if(!StringUtility.minMaxlength(dat.getUsResident(),"0","1")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_US_RESIDENT_FLAG ,"INVALID US RESIDENT FLAG ["+dat.getUsResident()+"] [ MAX-LENGTH 1]"));
			}

			if(!StringUtility.minMaxlength(dat.getUsCitizen(),"0","1")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_US_CITIZEN_FLAG,"INVALID US CITIZEN FLAG ["+dat.getUsCitizen()+"] [ MAX-LENGTH 1 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getUsGreenCardHolder(),"0","1")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_GREEN_CARD_HOLDER_FLAG,"INVALID GREEN CARD HOLDER FLAG ["+dat.getUsGreenCardHolder()+"] [ MAX-LENGTH 1 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getOnBoardWithDis(),"0","1")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_ONBOARD_WITH_DISPENSATION_FLAG,"INVALID ONBOARD WITH DISPENSATION FLAG ["+dat.getOnBoardWithDis()+"] [ MAX-LENGTH 1 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getUsaIndiciaInd(),"0","1")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_US_INDICIA_INDICATOR_FLAG,"INVALID US INDICIA INDICATOR FLAG ["+dat.getUsaIndiciaInd()+"] [ MAX-LENGTH 1 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getUsaPersonInd(),"0","1")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_US_PERSON_INDICATOR_FLAG ,"INVALID US PERSON INDICATOR FLAG ["+dat.getUsaPersonInd()+"] [ MAX-LENGTH 1 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getReportToIrsInd(),"0","1")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_REPORT_TO_IRS_INDICATOR_FLAG,"INVALID REPORT TO IRS INDICATOR FLAG ["+dat.getReportToIrsInd()+"] [ MAX-LENGTH 1 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getJointAcInd(),"0","1")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_JOINT_ACCOUNT_INDICATOR_FLAG,"INVALID JOINT ACCOUNT INDICATOR FLAG ["+dat.getJointAcInd()+"] [ MAX-LENGTH 1 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getRecalcitrantInd(),"0","1")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_RECAL_INDICATOR_FLAG,"INVALID RECAL INDICATOR FLAG ["+dat.getRecalcitrantInd()+"] [ MAX-LENGTH 1 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getWithholdInd(),"0","1")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_WITHHOLD_INDICATOR,"INVALID WITHHOLD INDICATOR ["+dat.getWithholdInd()+"] [ MAX-LENGTH 1 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getEnhancedReviewInd(),"0","1")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_ENHANCED_REVIEW_INDICATOR,"INVALID ENHANCED REVIEW INDICATOR ["+dat.getEnhancedReviewInd()+"] [ MAX-LENGTH 1 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getDocumentSubmittedIndicator(),"0","1")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_DOCUMENT_SUBMITTED_INDICATOR,"INVALID DOCUMENT SUBMITTED INDICATOR ["+dat.getDocumentSubmittedIndicator()+"] [ MAX-LENGTH 1 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getGstResidentStatus(),"0","1")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_GST_RESIDENT_STATUS,"INVALID GST RESIDENT STATUS ["+dat.getGstResidentStatus()+"] [ MAX-LENGTH 1 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getTaxResidentStatus(),"0","1")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_TAX_RESIDENT_STATUS,"INVALID TAX RESIDENT STATUS ["+dat.getTaxResidentStatus()+"] [ MAX-LENGTH 1 ]"));
			}

		}
		catch(Exception e)
		{
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateTars", LogType.APPLICATION.name());
			log.printErrorMessage(e);
		}

	}

	/**
	 * <Description>
	 * <p>
	 * <p>
	 *
	 * @param
	 * @return
	 * @exception
	 * @see
	 * @since
	 */
	private void validatePreferences(GBSOnboardCustomerWrapper customers,List<ErrorObject> errorList)
	{

		GBSOnboardPreferencesWrapper dat = customers.getObjOnboard_PreferencesWrapper();

		try
		{

			if(dat == null) {
				return;
			}

			if(!StringUtility.minMaxlength(dat.getPrefLangForComm(),"0","3")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_PREFERRED_LANGUAGE,"INVALID PREFERRED LANGUAGE ["+dat.getPrefLangForComm()+"] [ MAX-LENGTH 3 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getPreferredStatementLanguage(),"0","3")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_PREFERRED_STATEMENT_LANGUAGE ,"INVALID PREFERRED STATEMENT LANGUAGE ["+dat.getPreferredStatementLanguage()+"] [ MAX-LENGTH 3 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getPreferredAtmLanguage(),"0","999")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_PREFERRED_ATM_LANGUAGE,"INVALID PREFERRED ATM LANGUAGE ["+dat.getPreferredAtmLanguage()+"] [ MAX-LENGTH 999 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getPreferredPhoneLanguage(),"0","999")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_PREFERRED_PHONE_LANGUAGE,"INVALID PREFERRED PHONE LANGUAGE ["+dat.getPreferredPhoneLanguage()+"] [ MAX-LENGTH 999 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getIbankingRegistered(),"0","1")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_IBANKING_REGISTERED_FLAG,"INVALID IBANKING REGISTERED FLAG ["+dat.getIbankingRegistered()+"] [ MAX-LENGTH 1 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getPhoneBankingRegistered(),"0","1")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_PHONE_BANKING_REGISTERED_FLAG,"INVALID PHONE BANKING REGISTERED FLAG  ["+dat.getPhoneBankingRegistered()+"] [ MAX-LENGTH 1 ]"));
			}

			if(!StringUtility.minMaxlength(dat.getSmsBankingRegistered(),"0","1")) {
				errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_SMS_BANKING_REGISTERED_FLAG ,"INVALID SMS BANKING REGISTERED FLAG  ["+dat.getSmsBankingRegistered()+"] [ MAX-LENGTH 1 ]"));
			}

		}
		catch(Exception e)
		{
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validatePreferences", LogType.APPLICATION.name());
			log.printErrorMessage(e);
		}

	}

	/**
	 * <Description>
	 * <p>
	 * <p>
	 *
	 * @param
	 * @return
	 * @exception
	 * @see
	 * @since
	 */
	private void validateAppliedProducts(GBSOnboardCustomerWrapper customers,List<ErrorObject> errorList)
	{

		List<GBSOnboardAppliedProductsWrapper> applProdList = customers.getObjOnboard_AppliedProductsWrapper();

		try
		{
			if (applProdList==null || applProdList.size()==0) {
				return;
			}

			for (GBSOnboardAppliedProductsWrapper dat : applProdList)
			{
				if(!StringUtility.minMaxlength(dat.getProductReferenceKey(),"0","30")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_PRODUCT_NUMBER,"INVALID PRODUCT NUMBER ["+dat.getProductReferenceKey()+"] [ MAX-LENGTH 30 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getApplicantRole(),"0","4")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_APPLICANT_ROLE,"INVALID APPLICANT ROLE ["+dat.getApplicantRole()+"] [ MAX-LENGTH 4 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getAccountCurrency(),"0","3")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_ACCOUNT_CURRRENCY,"INVALID ACCOUNT CURRRENCY ["+dat.getAccountCurrency()+"] [ MAX-LENGTH 3 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getProductCode(),"0","4")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_PRODUCT_CODE,"INVALID PRODUCT CODE ["+dat.getProductCode()+"] [ MAX-LENGTH 4 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getSubProductCode(),"0","4")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_SUB_PRODUCT_CODE,"INVALID SUB PRODUCT CODE ["+dat.getSubProductCode()+"] [ MAX-LENGTH 4 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getPurposeOfAccountOpening(),"0","30")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_PURPOSE_OF_ACCOUNT_OPENING,"INVALID PURPOSE OF ACCOUNT OPENING ["+dat.getPurposeOfAccountOpening()+"] [ MAX-LENGTH 30 ]"));
				}
				if(!StringUtility.minMaxlength(dat.getPurposeOfAccountOpeningOthers(),"0","50")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_PURPOSE_OF_ACCOUNT_OPENING_OTHERS,"INVALID PURPOSE OF ACCOUNT OPENING -OTHERS- ["+dat.getPurposeOfAccountOpeningOthers()+"] [ MAX-LENGTH 50 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getAmountInitialDeposit(),"0","20")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_INITIAL_AMOUNT,"INVALID INITIAL AMOUNT ["+dat.getAmountInitialDeposit()+"] [ MAX-LENGTH 20 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getCurrencyInitialDeposit(),"0","3")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_CURRENCY_INITIAL_DEPOSIT ,"INVALID CURRENCY INITIAL DEPOSIT ["+dat.getCurrencyInitialDeposit()+"] [ MAX-LENGTH 3 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getChannelReferenceKey(),"0","20")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_CHANNEL_REFERENCE_KEY,"INVALID CHANNEL REFERENCE KEY ["+dat.getChannelReferenceKey()+"] [ MAX-LENGTH 20 ]"));
				}
			}
		}
		catch(Exception e)
		{
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateAppliedProducts", LogType.APPLICATION.name());
			log.printErrorMessage(e);
		}

	}

	/**
	 * <Description>
	 * <p> 
	 * <p> 
	 *
	 * @param
	 * @return
	 * @exception
	 * @see
	 * @since
	 */
	private void validateJointApplicants(GBSOnboardCustomerWrapper customers,List<ErrorObject> errorList)
	{
		List<GBSOnboardJointApplicantsWrapper> jointList = customers.getObjOnboard_JointApplicantsWrapper();

		try
		{
			if (jointList == null || jointList.size()==0) {
				return;
			}

			for (GBSOnboardJointApplicantsWrapper dat : jointList)
			{
				if(!StringUtility.minMaxlength(dat.getRelatedApplicantReferenceKey(),"0","50")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_JOINT_APPLICANT_REFERENCE_KEY,"INVALID JOINT APPLICANT REFERENCE KEY ["+dat.getRelatedApplicantReferenceKey()+"] [ MAX-LENGTH 50 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getProfileRole(),"0","3")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_JOINT_APPLICANT_REFERENCE_ROLE ,"INVALID JOINT APPLICANT REFERENCE ROLE ["+dat.getProfileRole()+"] [ MAX-LENGTH 3 ]"));
				}
			}
		}
		catch(Exception e)
		{
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateJointApplicants", LogType.APPLICATION.name());
			log.printErrorMessage(e);
		}

	}

	/**
	 * <Description>
	 * <p> 
	 * <p> 
	 *
	 * @param
	 * @return
	 * @exception
	 * @see
	 * @since
	 */
	private void validateVerificationStatus(GBSOnboardCustomerWrapper customers,List<ErrorObject> errorList)
	{
		List<GBSOnboardVerificationStatusWrapper> verificationStatus = customers.getObjOnboard_VerificationStatusWrapper();
		try
		{
			if (verificationStatus == null || verificationStatus.size()==0) {
				return;
			}

			for (GBSOnboardVerificationStatusWrapper dat : verificationStatus)
			{

				if(!StringUtility.minMaxlength(dat.getApplicantDetailsVerified(),"0","2"))
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_APPLICANT_DETAILS_VERIFIED,"INVALID APPLICANT DETAILS VERIFIED ["+dat.getApplicantDetailsVerified()+"] [ MAX-LENGTH 2 ]"));

				if(!StringUtility.minMaxlength(dat.getModeOfVerification(),"0","2")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_MODE_OF_VERIFICATION ,"INVALID MODE OF VERIFICATION ["+dat.getModeOfVerification()+"] [ MAX-LENGTH 2 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getVerifiedBy(),"0","7")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_VERIFIED_BY,"INVALID VERIFIED BY ["+dat.getVerifiedBy()+"] [ MAX-LENGTH 7 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getNameOfVerification(),"0","1")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_NAME_OF_VERIFICATION_FLAG,"INVALID NAME OF VERIFICATION FLAG ["+dat.getNameOfVerification()+"] [ MAX-LENGTH 1 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getDateOfBirthVerification(),"0","1")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_DATE_OF_BIRTH_FLAG,"INVALID DATE OF BIRTH FLAG ["+dat.getDateOfBirthVerification()+"] [ MAX-LENGTH 1 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getResidenceAddressVerification(),"0","1")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_ADDRESS_VERIFICATION_FLAG,"INVALID ADDRESS VERIFICATION FLAG ["+dat.getResidenceAddressVerification()+"] [ MAX-LENGTH 1 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getIdNumberVerification(),"0","1")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_NUMBER_VERIFICATION_FLAG,"INVALID NUMBER VERIFICATION FLAG ["+dat.getIdNumberVerification()+"] [ MAX-LENGTH 1 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getNationalityVerification(),"0","1")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_NATIONALITY_VERIFICATION_FLAG,"INVALID NATIONALITY VERIFICATION FLAG ["+dat.getNationalityVerification()+"] [ MAX-LENGTH 1 ]"));
				}

				if(!StringUtility.minMaxlength(dat.getCountrySpecificTwoVerification(),"0","1")) {
					errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_COUNTRY_SPECIFIC_VERIFICATION,"INVALID COUNTRY SPECIFIC VERIFICATION ["+dat.getCountrySpecificTwoVerification()+"] [ MAX-LENGTH 1 ]"));
				}

			}
		}
		catch(Exception e)
		{
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateVerificationStatus", LogType.APPLICATION.name());
			log.printErrorMessage(e);
		}

	}
}
