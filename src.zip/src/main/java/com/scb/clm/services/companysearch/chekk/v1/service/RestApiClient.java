package com.scb.clm.services.companysearch.chekk.v1.service;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ProxySelector;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublisher;
import java.net.http.HttpResponse;
import java.util.Arrays;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.clm.services.companysearch.chekk.v1.exception.RetryException;
import com.scb.clm.services.companysearch.chekk.v1.support.ChkConfigProperties;
import com.scb.clm.services.companysearch.chekk.v1.support.Retrier;

@Service
public class RestApiClient {

    @Autowired
    private ChkConfigProperties configProperties;

    public HttpResponse<String> callApi(String url, Map<String, String> reqHeader) {
        return callApi(url, reqHeader, null);
    }

    public HttpResponse<String> callApi(String url, Map<String, String> reqHeader, String reqData) {
        HttpResponse<String> response = null;
        HttpRequest request = getHttpRequest(url, reqHeader, reqData);
        HttpClient client = getHttpClientBuilder().build();
        response = new Retrier<String, HttpResponse<String>>("input", input -> {
            try {
                return client.send(request, HttpResponse.BodyHandlers.ofString());
            } catch (IOException e) {
                e.printStackTrace();
                throw new RetryException(e.getMessage());
            } catch (InterruptedException e) {
                e.printStackTrace();
                throw new RetryException(e.getMessage());
            }
        }).execute(Arrays.asList(IOException.class, InterruptedException.class, RetryException.class));
        return response;
    }

    private HttpRequest getHttpRequest(String url, Map<String, String> reqHeader, String reqData) {
        HttpRequest.Builder requestBuilder = HttpRequest.newBuilder().uri(URI.create(url));
        if (reqHeader != null && !reqHeader.isEmpty()) {
            for (Map.Entry<String, String> entry : reqHeader.entrySet()) {
                requestBuilder.header(entry.getKey(), entry.getValue());
            }
        }
        requestBuilder.POST(getPostBody(reqData));
        return requestBuilder.build();
    }

    private BodyPublisher getPostBody(String reqData) {
        return (reqData == null) ? HttpRequest.BodyPublishers.noBody() : HttpRequest.BodyPublishers.ofString(reqData);
    }

    public String getResponseBody(HttpResponse<String> response) {
        return (response != null ? response.body() : null);
    }

    private HttpClient.Builder getHttpClientBuilder() {
        HttpClient.Builder builder = HttpClient.newBuilder();

        if ("Y".equalsIgnoreCase(configProperties.getEnableProxy())) {
            builder.proxy(ProxySelector.of(InetSocketAddress.createUnresolved(configProperties.getProxyHost(),
                    configProperties.getProxyPort())));
        }

        return builder;
    }
}
