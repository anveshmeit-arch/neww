package com.scb.clm.services.globus.cddinitiate.v1.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)  
public class CDDRespAccountReferencesInitiateJson {

    @JsonProperty("product-reference-key")
    private String product_reference_key;

    @JsonProperty("account-key")
    private String account_key;

    public String getProduct_reference_key() {
        return product_reference_key;
    }

    public void setProduct_reference_key(String product_reference_key) {
        this.product_reference_key = product_reference_key;
    }

    public String getAccount_key() {
        return account_key;
    }

    public void setAccount_key(String account_key) {
        this.account_key = account_key;
    }

}
