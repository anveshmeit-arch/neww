package com.scb.clm.services.companysearch.chekk.v1.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.scb.clm.services.companysearch.chekk.v1.model.ChekkRequestsEntity;

import jakarta.transaction.Transactional;

@Repository
public interface ChekkRequestsRepository extends JpaRepository<ChekkRequestsEntity, String> { 

    @Override
    public <S extends ChekkRequestsEntity> S save(S entity);

    @Override
    public <S extends ChekkRequestsEntity> S saveAndFlush(S entity);
    
    @Override
    public ChekkRequestsEntity getOne(String arg0);
    
    public List<ChekkRequestsEntity> findByStatusAndInstanceName(String status, String instanceName);

    public List<ChekkRequestsEntity> findByRequestId(String requestId);
    @Transactional
    @Modifying
    @Query(value = "update CHK_REQUESTS set status = :status, updated_on =now() where request_id = :requestId",nativeQuery = true )
    public int updateStatusByIds(@Param("status") String status,@Param("requestId") String requestId);
}