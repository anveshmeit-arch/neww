package com.scb.clm.services.companysearch.chekk.v1.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Service;

import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.util.SystemUtility;
import com.scb.clm.services.companysearch.chekk.v1.exception.ApplicationException;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkPartyEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkRequestsEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkResponseDataEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkSearchEntityQEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ProcessApiRequestsEntity;
import com.scb.clm.services.companysearch.chekk.v1.support.ChkApiType;
import com.scb.clm.services.companysearch.chekk.v1.support.ChkConfigProperties;
import com.scb.clm.services.companysearch.chekk.v1.support.DBUtility;
import com.scb.clm.services.companysearch.chekk.v1.support.Log;
import com.scb.clm.services.companysearch.chekk.v1.support.ProcessApiConstants;

import jakarta.annotation.PostConstruct;

@Service
public class ChkSchedulerService {

	@Autowired
	private TaskScheduler taskScheduler;

	@Autowired
	private ChkConfigProperties configProperties;
	@Autowired
	private ChkApiClient apiClient;
	@Autowired
	private DBUtility dbUtility;

	@Autowired
	private ChkSchedulerDao scheudlerDao;

	@Autowired
	private ChkTableReferences refData;

	@Autowired
	private ChkApiProcessor apiProcessor;

	@Autowired
	private EntitySearchUnwrapper unwrapper;

	@Autowired
	private ResponseToEntityConverter resToEntConverter;

	private final String instanceName;


	public ChkSchedulerService() {
		instanceName = SystemUtility.getInstanceName();
	}

	@PostConstruct
	public void schduleJobs() {
		Log.info("Initializing chekk scheduler services at... "+instanceName);
		String serviceName = SystemUtility.getServiceName();
		if(ProcessApiConstants.CHEKK_SERVICE_NAME.equalsIgnoreCase(serviceName)) {
		    Runnable task1 = this::processScheduler1Job;
		    Runnable task2 = this::processScheduler2Job;
		    Runnable task3 = this::processScheduler3Job;
		    taskScheduler.schedule(task1, new CronTrigger(configProperties.getScheduler1CronExpression()));
		    taskScheduler.schedule(task2, new CronTrigger(configProperties.getScheduler2CronExpression()));
		    taskScheduler.schedule(task3, new CronTrigger(configProperties.getScheduler3CronExpression()));
		    Log.info("Chekk scheduler services started surcessfully.");
		}else {
		    Log.info("Chekk scheduler services not started for this service "+serviceName);
		}
	}

	public void processScheduler1Job() {
		Log.debug("Starting Scheduler1 Job to perform Search and Create API calls for multi level processing.");
		processPendingSearchCreateEntityQ();
		Log.debug("processPendingSearchCreateEntityQ completed and starting processUnwrapPendingRequests");
		processUnwrapPendingRequests();
		Log.debug("processUnwrapPendingRequests completed");

	}

	public void processScheduler2Job() {
		processPendingGetEntityQ();
	}

	public void processScheduler3Job() {
		processFinalResponse();
	}

	/**
	 * Read all records pending for Search and Create Chekk API calls and process
	 * it. On successful completion updates the status to SearchEntityQ and
	 * ResponseData tables.
	 */
	public void processPendingSearchCreateEntityQ() {
		List<ChekkSearchEntityQEntity> chkSrchEntityList = scheudlerDao.readPendingSearchCreateRequests(instanceName);
		boolean isErrorOccurred = false;
		String previousApiResponseJson = null;
		Map<String, Object> apiResponseMap = null;
		ChkApiType apiTypeToCall = null;
		for (ChekkSearchEntityQEntity chkSrchEntity : chkSrchEntityList) {
			try {
				isErrorOccurred = false;
				if (ProcessApiConstants.STATUS_SEARCH_PENDING.equalsIgnoreCase(chkSrchEntity.getStatus())) {
					apiTypeToCall = ChkApiType.SEARCH;
				} else if (ProcessApiConstants.STATUS_CREATE_PENDING.equalsIgnoreCase(chkSrchEntity.getStatus())) {
					apiTypeToCall = ChkApiType.CREATE;
					previousApiResponseJson = readSearchApiResponse(chkSrchEntity);
				} else {
					// TODO throw exception, mostly which will not occur
				}
				apiResponseMap = apiProcessor.processApi(chkSrchEntity, apiTypeToCall, previousApiResponseJson, true);
			} catch (ApplicationException e) {
				isErrorOccurred = true;
				// TODO set error code here and store it in db for problem analysis
			} catch (Exception e) {
				isErrorOccurred = true;
				// TODO add runtime error code and store it in db for problem analsyis
			} finally {

			}
		}
	}

	public void processPendingGetEntityQ() {
		// Read the records from CHK_SEARCH_ENTITY_QUEUE table having status - "GP".
		boolean isErrorOccurred = false;
		List<ChekkSearchEntityQEntity> chkSearchEntityQList = scheudlerDao.readPendingGetRequests(instanceName);
		String previousApiResponseJson = null;
		Map<String, Object> apiResponseMap = null;

		for (ChekkSearchEntityQEntity srchEntity : chkSearchEntityQList) {

			try {
				isErrorOccurred = false;
				previousApiResponseJson = readCreateResponse(srchEntity);
				apiResponseMap = apiProcessor.processApi(srchEntity, ChkApiType.GET, previousApiResponseJson, true);
			} catch (ApplicationException e) {
				isErrorOccurred = true;
				// TODO set error code here and store it in db for problem analysis
			} catch (Exception e) {
				isErrorOccurred = true;
				// TODO add runtime error code and store it in db for problem analsyis
			}
		}
	}

	private String readSearchApiResponse(ChekkSearchEntityQEntity chkSearchEntity) {
		ChekkResponseDataEntity chkRespData = scheudlerDao.getSearchApiResponse(chkSearchEntity.getRequestId(),
				chkSearchEntity.getSearchEntityId());
		String responseJson = null;
		if (chkRespData != null && !chkRespData.getResData().isEmpty()) {
			responseJson = chkRespData.getResData();
		} else {
			// throw runtime exception and update status as failure
		}
		return responseJson;
	}

	private String readCreateApiResponse(ChekkSearchEntityQEntity chkSearchEntity) {
		ChekkResponseDataEntity chkRespData = scheudlerDao.getGetApiResponse(chkSearchEntity.getRequestId(),
				chkSearchEntity.getSearchEntityId());
		String responseJson = null;

		if (chkRespData != null && !chkRespData.getResData().isEmpty()) {
			responseJson = chkRespData.getResData();
		} else {
			// throw runtime exception and update status as failure
		}
		return responseJson;
	}

	private String readCreateResponse(ChekkSearchEntityQEntity chkSearchEntity) {
		ChekkResponseDataEntity chkRespData = scheudlerDao.getGetApiResponse(chkSearchEntity.getRequestId(),
				chkSearchEntity.getSearchEntityId());
		String responseJson = null;

		if (chkRespData != null && !chkRespData.getResData().isEmpty()) {
			responseJson = chkRespData.getResData();
		} else {
			// throw runtime exception and update status as failure
		}
		return responseJson;
	}

	private void processFinalResponse() {
		List<ChekkRequestsEntity> chekkRequestsEntityLst = scheudlerDao.readUCRequests(instanceName);
		String finalResponseJson = null;
		for (ChekkRequestsEntity chekkRequestentity : chekkRequestsEntityLst) {
			try {
				ProcessApiRequestsEntity processApiRequestsEntity = scheudlerDao
						.getRequestHeaders(chekkRequestentity.getRequestId());
				List<ChekkPartyEntity> chekkPartyEntityLst = scheudlerDao
						.getAllParties(chekkRequestentity.getRequestId());

				if (chekkPartyEntityLst != null && !chekkPartyEntityLst.isEmpty()) {
					finalResponseJson = apiProcessor.generateFinalResponse(
							resToEntConverter.populateRequestHeader(processApiRequestsEntity), chekkRequestentity,
							chekkPartyEntityLst);
					boolean msgSendStatus = apiProcessor.sendMessageToSolaceTopic(chekkRequestentity.getRequestId(),
							finalResponseJson, chekkRequestentity.getCountryCode(),
							processApiRequestsEntity.getInterfaceId());

				} else {
					// TODO construct FinalResponse with Error Object and write it to solace topic.
				}

			} catch (ApplicationException ae) {

			} catch (Exception e) {

			}
		}
	}

	private void processUnwrapPendingRequests() {
		List<ChekkSearchEntityQEntity> chkSearchEntityQList = scheudlerDao.readUnwrapPendingRequests(instanceName);
		unwrapper.unwrapSearchEntityQ(chkSearchEntityQList);
	}

	/**
	 * Pending Items % calculation requirs correction with precise decimal values -
	 * done scheduler 3 to construct and send fina response - 70% completed
	 * Exception handling for PendingGetAPI calls
	 * 
	 * DecisionMaking
	 */

}
