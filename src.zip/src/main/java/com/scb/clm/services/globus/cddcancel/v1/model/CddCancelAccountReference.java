package com.scb.clm.services.globus.cddcancel.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CddCancelAccountReference {

    @JsonProperty("account-key")
    private String accountKey;

    @JsonProperty("account-number")
    private String accountNumber;

    public String getAccountKey() {
        return accountKey;
    }

    public void setAccountKey(String accountKey) {
        this.accountKey = accountKey;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

}
