package com.scb.clm.services.companysearch.chekk.v1.model;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "CHK_PARTY")
@Getter
@Setter
public class ChekkPartyEntity {	
	
	@Id
	@Column(name="party_id")
	private String partyId;

	@Column(name="associated_to_id")
	private String associatedToId;

	@Column(name="commencement_date")
	private String commencementDate;

	@Column(name="distance_from_root")
	private String distanceFromRoot;

	@Column(name="fi_account_currency")
	private String fiAccountCurrency;

	@Column(name="fi_company_currency")
	private String fiCompanyCurrency;

	@Column(name="fi_revenue")
	private String fiRevenue;

	@Column(name="id_address_effective_date")
	private String idAddressEffectiveDate;

	@Column(name="id_address_is_valid")
	private String idAddressIsValid;

	@Column(name="id_city")
	private String idCity;

	@Column(name="id_cmp_reg_exp_date")
	private String idCmpRegExpDate;

	@Column(name="id_commencement_date")
	private String idCommencementDate;

	@Column(name="id_company_name")
	private String idCompanyName;

	@Column(name="id_company_number")
	private String idCompanyNumber;

	@Column(name="id_countries_of_operation")
	private String idCountriesOfOperation;

	@Column(name="id_country")
	private String idCountry;

	@Column(name="id_expiry_date")
	private String idExpiryDate;

	@Column(name="id_formernames")
	private String idFormernames;

	@Column(name="id_full_address")
	private String idFullAddress;

	@Column(name="id_full_operating_address")
	private String idFullOperatingAddress;

	@Column(name="id_full_operating_address_city")
	private String idFullOperatingAddressCity;

	@Column(name="id_full_operating_address_country")
	private String idFullOperatingAddressCountry;

	@Column(name="id_full_operating_address_state")
	private String idFullOperatingAddressState;

	@Column(name="id_full_operating_address_zip")
	private String idFullOperatingAddressZip;

	@Column(name="id_home_company_name")
	private String idHomeCompanyName;

	@Column(name="id_nace_code")
	private String idNaceCode;

	@Column(name="id_naics_code")
	private String idNaicsCode;

	@Column(name="id_name_effective_date")
	private String idNameEffectiveDate;

	@Column(name="id_nature_of_business")
	private String idNatureOfBusiness;

	@Column(name="id_primary_ssic_label")
	private String idPrimarySsicLabel;

	@Column(name="id_primary_ssic_code")
	private String idPrimarySsicCode;

	@Column(name="id_primary_ssic_other_description")
	private String idPrimarySsicOtherDescription;

	@Column(name="id_renewal_cut_off_date")
	private String idRenewalCutOffDate;

	@Column(name="id_secondary_ssic_label")
	private String idSecondarySsicLabel;

	@Column(name="id_secondary_ssic_code")
	private String idSecondarySsicCode;

	@Column(name="id_secondary_ssic_other_description")
	private String idSecondarySsicOtherDescription;

	@Column(name="id_state")
	private String idState;

	@Column(name="id_status")
	private String idStatus;

	@Column(name="id_status_effective_date")
	private String idStatusEffectiveDate;

	@Column(name="id_zip")
	private String idZip;

	@Column(name="ind_adress")
	private String indAdress;

	@Column(name="ind_attorney_powers")
	private String indAttorneyPowers;

	@Column(name="ind_biography")
	private String indBiography;

	@Column(name="ind_controlling_shareholder")
	private String indControllingShareholder;

	@Column(name="ind_individual_number")
	private String indIndividualNumber;

	@Column(name="ind_is_king")
	private String indIsking;

	@Column(name="ind_is_ubo")
	private String indIsUbo;

	@Column(name="ind_name")
	private String indName;

	@Column(name="ind_role")
	private String indRole;

	@Column(name="ind_shares_amount")
	private String indSharesAmount;

	@Column(name="ind_shares_currency")
	private String indSharesCurrency;

	@Column(name="ind_shares_type")
	private String indSharesType;

	@Column(name="ind_signatory")
	private String indSignatory;

	@Column(name="ind_status")
	private String indStatus;

	@Column(name="individual_percentage")
	private BigDecimal individualPercentage;

	@Column(name="intermediate_id_city")
	private String intermediateIdCity;

	@Column(name="intermediate_id_company_name")
	private String intermediateIdCompanyName;

	@Column(name="intermediate_id_company_number")
	private String intermediateIdCompanyNumber;

	@Column(name="intermediate_id_country")
	private String intermediateIdCountry;

	@Column(name="intermediate_id_full_address")
	private String intermediateIdFullAddress;

	@Column(name="intermediate_id_inactive")
	private String intermediateIdInactive;

	@Column(name="intermediate_id_role")
	private String intermediateIdRole;

	@Column(name="intermediate_id_state")
	private String intermediateIdState;

	@Column(name="intermediate_id_zip")
	private String intermediateIdZip;

	@Column(name="intermediate_sh_currency")
	private String intermediateShCurrency;

	@Column(name="intermediate_sh_shares_amount")
	private String intermediateShSharesAmount;

	@Column(name="intermediate_sh_type")
	private String intermediateShType;

	@Column(name="is_main_entity")
	private String isMainEntity;

	private String key;

	private String landmark;

	@Column(name="le_national_legal_form")
	private String leNationalLegalForm;

	@Column(name="le_registration_date")
	private String leRegistrationDate;

	@Column(name="orsh_shares_number_other")
	private String orshSharesNumberOther;

	@Column(name="orsh_shares_number_sgdp")
	private String orshSharesNumberSgdp;

	@Column(name="orsh_shares_number_usad")
	private String orshSharesNumberUsad;

	@Column(name = "orsh_issued_share_capital_sgpd")
	public String orshIssuedShareCapitalSgpd;
	
	@Column(name = "orsh_issued_share_capital_other")
	public String orshIssuedShareCapitalOther;
	
	@Column(name = "orsh_issued_share_capital_usad")
	public String orshIssuedShareCapitalUsad;

	@Column(name = "orsh_paid_up_share_capital_usad")
	public String orshPaidUpShareCapitalUsad;
	
	@Column(name = "orsh_paid_up_share_capital_sgpd")
	public String orshPaidUpShareCapitalSgpd;
	
	@Column(name = "orsh_paid_up_share_capital_other")
	public String orshPaidUpShareCapitalOther;
	
	@Column(name="otsh_issued_share_capital_other")
	private String otshIssuedShareCapitalOther;

	@Column(name="otsh_issued_share_capital_sgpd")
	private String otshIssuedShareCapitalSgpd;

	@Column(name="otsh_issued_share_capital_usad")
	private String otshIssuedShareCapitalUsad;

	@Column(name="otsh_paid_up_share_capital_other")
	private String otshPaidUpShareCapitalOther;

	@Column(name="otsh_paid_up_share_capital_sgpd")
	private String otshPaidUpShareCapitalSgpd;

	@Column(name="otsh_paid_up_share_capital_usad")
	private String otshPaidUpShareCapitalUsad;

	@Column(name="otsh_shares_number_other")
	private String otshSharesNumberOther;

	@Column(name="otsh_shares_number_sgdp")
	private String otshSharesNumberSgdp;

	@Column(name="otsh_shares_number_usad")
	private String otshSharesNumberUsad;

	@Column(name="parent_percentage")
	private String parentPercentage;

	@Column(name="party_type")
	private String partyType;

	@Column(name="personal_address_city")
	private String personalAddressCity;

	@Column(name="personal_address_country")
	private String personalAddressCountry;

	@Column(name="personal_sgp_id")
	private String personalSgpId;

	@Column(name="personal_sgp_id_type")
	private String personalSgpIdType;

	@Column(name="personal_zip_code")
	private String personalZipCode;

	@Column(name="prsh_issued_share_capital_other")
	private String prshIssuedShareCapitalOther;

	@Column(name="prsh_issued_share_capital_sgpd")
	private String prshIssuedShareCapitalSgpd;

	@Column(name="prsh_issued_share_capital_usad")
	private String prshIssuedShareCapitalUsad;

	@Column(name="prsh_paid_up_share_capital_other")
	private String prshPaidUpShareCapitalOther;

	@Column(name="prsh_paid_up_share_capital_sgpd")
	private String prshPaidUpShareCapitalSgpd;

	@Column(name="prsh_paid_up_share_capital_usad")
	private String prshPaidUpShareCapitalUsad;

	@Column(name="prsh_shares_number_other")
	private String prshSharesNumberOther;

	@Column(name="prsh_shares_number_sgdp")
	private String prshSharesNumberSgdp;

	@Column(name="prsh_shares_number_usad")
	private String prshSharesNumberUsad;

	@Column(name="request_id")
	private String requestId;

	@Column(name="search_entity_id")
	private String searchEntityId;

	@Column(name="sh_total_percentage")
	private String shTotalPercentage;

	@Column(name="trsh_issued_share_capital_other")
	private String trshIssuedShareCapitalOther;

	@Column(name="trsh_issued_share_capital_sgpd")
	private String trshIssuedShareCapitalSgpd;

	@Column(name="trsh_issued_share_capital_usad")
	private String trshIssuedShareCapitalUsad;

	@Column(name="trsh_paid_up_share_capital_other")
	private String trshPaidUpShareCapitalOther;

	@Column(name="trsh_paid_up_share_capital_sgpd")
	private String trshPaidUpShareCapitalSgpd;

	@Column(name="trsh_paid_up_share_capital_usad")
	private String trshPaidUpShareCapitalUsad;

	@Column(name="trsh_shares_number_other")
	private String trshSharesNumberOther;

	@Column(name="trsh_shares_number_sgdp")
	private String trshSharesNumberSgdp;

	@Column(name="trsh_shares_number_usad")
	private String trshSharesNumberUsad;

	@Column(name="unique_id")
	private String uniqueId;

	@Column(name="creation_date")
	public String creationDate;
}