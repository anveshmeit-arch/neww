package com.scb.clm.services.globus.pdpa.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;


public class GBSPDPARequestWrapper {

	@JsonProperty("application")
    private GBSPDPAApplnWrapper gbsPDPAApplnWrapper;

    @JsonProperty("customers")
    private GBSPDPACustomerWrapper gbsPDPACustomerWrapper;

	public GBSPDPAApplnWrapper getGbsPDPAApplnWrapper() {
		return gbsPDPAApplnWrapper;
	}

	public void setGbsPDPAApplnWrapper(GBSPDPAApplnWrapper gbsPDPAApplnWrapper) {
		this.gbsPDPAApplnWrapper = gbsPDPAApplnWrapper;
	}

	public GBSPDPACustomerWrapper getGbsPDPACustomerWrapper() {
		return gbsPDPACustomerWrapper;
	}

	public void setGbsPDPACustomerWrapper(GBSPDPACustomerWrapper gbsPDPACustomerWrapper) {
		this.gbsPDPACustomerWrapper = gbsPDPACustomerWrapper;
	}
}
