package com.scb.clm.services.globus.icm.v1.model;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ICMCustomerCreateCustomer {

	@JsonProperty("addresses")
	private List<ICMCustomerCreateAddress> addresses; 

	@JsonProperty("contacts")
	private List<ICMCustomerCreateContacts> contacts;

	@JsonProperty("kyc")
	private ICMCustomerCreateKYC kyc;

	@JsonProperty("cdd")
	private ICMCustomerCreateCDD cdd;

	@JsonProperty("tars")
	private ICMCustomerCreateTAR tars;

	@JsonProperty("employments")
	private ICMCustomerCreateEmployments employments;

	@JsonProperty("pdpa")
	private List<ICMCustomerCreatePDPA> pdpa;

	@JsonProperty("documents")
	private List<ICMCustomerCreateDocuments> documents;

	@JsonProperty("aliases")
	private List<ICMCustomerCreateAlias> aliases;

	@JsonProperty("auxmap")
	private List<ICMCustomerCreateAuxiliary> auxiliary;

	@JsonProperty("risks")
	private ICMCustomerCreateRisks risks;    

	@JsonProperty("preferences")
	private ICMCustomerCreatePreference preferences;

	@JsonProperty("id") 
	private String  guid;

	@JsonProperty("reference-id")
	private String  profileId;

	@JsonProperty("previous-core-banking-id")
	private String relationshipNo;

	@JsonProperty("revision-number")
	private int revisionNumber;

	@JsonProperty("salutation-code")
	private String salutationCode;

	@JsonProperty("first-name")
	private String firstName;

	@JsonProperty("middle-name")
	private String middleName;

	@JsonProperty("last-name")
	private String lastName;

	@JsonProperty("full-name")
	private String fullName;

	@JsonProperty("gender")
	private String gender;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	@JsonProperty("date-of-birth")
	private Date dateOfBirth;

	@JsonProperty("resident-country")
	private String residentCountry;

	@JsonProperty("resident-status")
	private String residentStatus;

	@JsonProperty("profile-type")
	private String profileType;

	@JsonProperty("dedup-reference-number")
	private String dedupReferenceNumber;

	@JsonProperty("dedup-reason-code")
	private String DedupReasonCode;

	@JsonProperty("full-name-override-flag")
	private String fullNameOverride;

	@JsonProperty("last-name-override-flag")
	private String lastnameOverride;

	@JsonProperty("customer-nationality-code")
	private String customerNationalityCode;

	@JsonProperty("bsbda-flag")
	private String isBSBDACustomer;

	@JsonProperty("senior-citizen-flag")
	private String seniorCitizenFlag;

	@JsonProperty("group-id")
	private String groupId;

	@JsonProperty("group-name")
	private String groupName;

	@JsonProperty("sender-id")
	private String senderId;

	@JsonProperty("sender-branch")
	private String senderBranch;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	@JsonProperty("created-at")
	private Timestamp createdAt;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	@JsonProperty("updated-at")
	private Timestamp updatedAt;

	@JsonProperty("status")
	private String status;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	@JsonProperty("status-at")
	private Timestamp statusAt;

	@JsonProperty("arm-code")
	private String armCode;

	@JsonProperty("relationship-status")
	private String relationshipStatus;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	@JsonProperty("last-status-change-date")
	private Date lastStatusChangeDate;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	@JsonProperty("profile-activation-date")
	private Date profileActivationDate;

	@JsonProperty("reopen-indicator")
	private String reOpenedInd;

	@JsonProperty("reopen-counter")
	private short reOpenCounter;

	@JsonProperty("close-reason-code")
	private String closeReasonCode;

	@JsonProperty("segment-code")
	private String segmentCode;

	@JsonProperty("sub-segment-code")
	private String subSegmentCode;

	@JsonProperty("service-indicator-code")
	private String serviceIndicatorCode;

	@JsonProperty("referral-id")
	private String referralId;

	@JsonProperty("sourcing-id")
	private String sourcingId;

	@JsonProperty("closing-id")
	private String closingId;

	@JsonProperty("acquisition-channel")
	private String acquisitionChannel;

	@JsonProperty("home-branch")
	private String homeBranch;

	@JsonProperty("referred-by-relationship-no")
	private String referredByRelationshipNo;

	@JsonProperty("referred-by-relationship-name")
	private String referredByRelationshipName;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	@JsonProperty("demised-date")
	private Date demisedDate;

	@JsonProperty("country-id")
	private String companyId;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	@JsonProperty("profile-purging-date")
	private Date purgingDate;

	@JsonProperty("checker-department-code")
	private String departmentCode;


	public List<ICMCustomerCreateAddress> getAddresses() {
		return addresses;
	}

	public void setAddresses(List<ICMCustomerCreateAddress> addresses) {
		this.addresses = addresses;
	}

	public List<ICMCustomerCreateContacts> getContacts() {
		return contacts;
	}

	public void setContacts(List<ICMCustomerCreateContacts> contacts) {
		this.contacts = contacts;
	}

	public ICMCustomerCreateKYC getKyc() {
		return kyc;
	}

	public void setKyc(ICMCustomerCreateKYC kyc) {
		this.kyc = kyc;
	}

	public ICMCustomerCreateCDD getCdd() {
		return cdd;
	}

	public void setCdd(ICMCustomerCreateCDD cdd) {
		this.cdd = cdd;
	}

	public ICMCustomerCreateTAR getTars() {
		return tars;
	}

	public void setTars(ICMCustomerCreateTAR tars) {
		this.tars = tars;
	}

	public ICMCustomerCreateEmployments getEmployments() {
		return employments;
	}

	public void setEmployments(ICMCustomerCreateEmployments employments) {
		this.employments = employments;
	}

	public List<ICMCustomerCreatePDPA> getPdpa() {
		return pdpa;
	}

	public void setPdpa(List<ICMCustomerCreatePDPA> pdpa) {
		this.pdpa = pdpa;
	}

	public List<ICMCustomerCreateDocuments> getDocuments() {
		return documents;
	}

	public void setDocuments(List<ICMCustomerCreateDocuments> documents) {
		this.documents = documents;
	}

	public List<ICMCustomerCreateAlias> getAliases() {
		return aliases;
	}

	public void setAliases(List<ICMCustomerCreateAlias> aliases) {
		this.aliases = aliases;
	}

	public List<ICMCustomerCreateAuxiliary> getAuxiliary() {
		return auxiliary;
	}

	public void setAuxiliary(List<ICMCustomerCreateAuxiliary> auxiliary) {
		this.auxiliary = auxiliary;
	}

	public ICMCustomerCreateRisks getRisks() {
		return risks;
	}

	public void setRisks(ICMCustomerCreateRisks risks) {
		this.risks = risks;
	}

	public ICMCustomerCreatePreference getPreferences() {
		return preferences;
	}

	public void setPreferences(ICMCustomerCreatePreference preferences) {
		this.preferences = preferences;
	}

	public String getGuid() {
		return guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}

	public String getProfileId() {
		return profileId;
	}

	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}

	public String getRelationshipNo() {
		return relationshipNo;
	}

	public void setRelationshipNo(String relationshipNo) {
		this.relationshipNo = relationshipNo;
	}

	public int getRevisionNumber() {
		return revisionNumber;
	}

	public void setRevisionNumber(int revisionNumber) {
		this.revisionNumber = revisionNumber;
	}

	public String getSalutationCode() {
		return salutationCode;
	}

	public void setSalutationCode(String salutationCode) {
		this.salutationCode = salutationCode;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getResidentCountry() {
		return residentCountry;
	}

	public void setResidentCountry(String residentCountry) {
		this.residentCountry = residentCountry;
	}

	public String getResidentStatus() {
		return residentStatus;
	}

	public void setResidentStatus(String residentStatus) {
		this.residentStatus = residentStatus;
	}

	public String getProfileType() {
		return profileType;
	}

	public void setProfileType(String profileType) {
		this.profileType = profileType;
	}

	public String getDedupReferenceNumber() {
		return dedupReferenceNumber;
	}

	public void setDedupReferenceNumber(String dedupReferenceNumber) {
		this.dedupReferenceNumber = dedupReferenceNumber;
	}

	public String getDedupReasonCode() {
		return DedupReasonCode;
	}

	public void setDedupReasonCode(String dedupReasonCode) {
		DedupReasonCode = dedupReasonCode;
	}

	public String getFullNameOverride() {
		return fullNameOverride;
	}

	public void setFullNameOverride(String fullNameOverride) {
		this.fullNameOverride = fullNameOverride;
	}

	public String getLastnameOverride() {
		return lastnameOverride;
	}

	public void setLastnameOverride(String lastnameOverride) {
		this.lastnameOverride = lastnameOverride;
	}

	public String getCustomerNationalityCode() {
		return customerNationalityCode;
	}

	public void setCustomerNationalityCode(String customerNationalityCode) {
		this.customerNationalityCode = customerNationalityCode;
	}

	public String getIsBSBDACustomer() {
		return isBSBDACustomer;
	}

	public void setIsBSBDACustomer(String isBSBDACustomer) {
		this.isBSBDACustomer = isBSBDACustomer;
	}

	public String getSeniorCitizenFlag() {
		return seniorCitizenFlag;
	}

	public void setSeniorCitizenFlag(String seniorCitizenFlag) {
		this.seniorCitizenFlag = seniorCitizenFlag;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getSenderId() {
		return senderId;
	}

	public void setSenderId(String senderId) {
		this.senderId = senderId;
	}

	public String getSenderBranch() {
		return senderBranch;
	}

	public void setSenderBranch(String senderBranch) {
		this.senderBranch = senderBranch;
	}

	public Timestamp getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Timestamp createdAt) {
		this.createdAt = createdAt;
	}

	public Timestamp getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Timestamp updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getStatusAt() {
		return statusAt;
	}

	public void setStatusAt(Timestamp statusAt) {
		this.statusAt = statusAt;
	}

	public String getArmCode() {
		return armCode;
	}

	public void setArmCode(String armCode) {
		this.armCode = armCode;
	}

	public String getRelationshipStatus() {
		return relationshipStatus;
	}

	public void setRelationshipStatus(String relationshipStatus) {
		this.relationshipStatus = relationshipStatus;
	}

	public Date getLastStatusChangeDate() {
		return lastStatusChangeDate;
	}

	public void setLastStatusChangeDate(Date lastStatusChangeDate) {
		this.lastStatusChangeDate = lastStatusChangeDate;
	}

	public Date getProfileActivationDate() {
		return profileActivationDate;
	}

	public void setProfileActivationDate(Date profileActivationDate) {
		this.profileActivationDate = profileActivationDate;
	}

	public String getReOpenedInd() {
		return reOpenedInd;
	}

	public void setReOpenedInd(String reOpenedInd) {
		this.reOpenedInd = reOpenedInd;
	}

	public short getReOpenCounter() {
		return reOpenCounter;
	}

	public void setReOpenCounter(short reOpenCounter) {
		this.reOpenCounter = reOpenCounter;
	}

	public String getCloseReasonCode() {
		return closeReasonCode;
	}

	public void setCloseReasonCode(String closeReasonCode) {
		this.closeReasonCode = closeReasonCode;
	}

	public String getSegmentCode() {
		return segmentCode;
	}

	public void setSegmentCode(String segmentCode) {
		this.segmentCode = segmentCode;
	}

	public String getSubSegmentCode() {
		return subSegmentCode;
	}

	public void setSubSegmentCode(String subSegmentCode) {
		this.subSegmentCode = subSegmentCode;
	}

	public String getServiceIndicatorCode() {
		return serviceIndicatorCode;
	}

	public void setServiceIndicatorCode(String serviceIndicatorCode) {
		this.serviceIndicatorCode = serviceIndicatorCode;
	}

	public String getReferralId() {
		return referralId;
	}

	public void setReferralId(String referralId) {
		this.referralId = referralId;
	}

	public String getSourcingId() {
		return sourcingId;
	}

	public void setSourcingId(String sourcingId) {
		this.sourcingId = sourcingId;
	}

	public String getClosingId() {
		return closingId;
	}

	public void setClosingId(String closingId) {
		this.closingId = closingId;
	}

	public String getAcquisitionChannel() {
		return acquisitionChannel;
	}

	public void setAcquisitionChannel(String acquisitionChannel) {
		this.acquisitionChannel = acquisitionChannel;
	}

	public String getHomeBranch() {
		return homeBranch;
	}

	public void setHomeBranch(String homeBranch) {
		this.homeBranch = homeBranch;
	}

	public String getReferredByRelationshipNo() {
		return referredByRelationshipNo;
	}

	public void setReferredByRelationshipNo(String referredByRelationshipNo) {
		this.referredByRelationshipNo = referredByRelationshipNo;
	}

	public String getReferredByRelationshipName() {
		return referredByRelationshipName;
	}

	public void setReferredByRelationshipName(String referredByRelationshipName) {
		this.referredByRelationshipName = referredByRelationshipName;
	}

	public Date getDemisedDate() {
		return demisedDate;
	}

	public void setDemisedDate(Date demisedDate) {
		this.demisedDate = demisedDate;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public Date getPurgingDate() {
		return purgingDate;
	}

	public void setPurgingDate(Date purgingDate) {
		this.purgingDate = purgingDate;
	}

	public String getDepartmentCode() {
		return departmentCode;
	}

	public void setDepartmentCode(String departmentCode) {
		this.departmentCode = departmentCode;
	}


	public void addAuxiliary(ICMCustomerCreateAuxiliary auxiliary)
	{
		if(auxiliary == null) {
			return;
		}
		if(this.auxiliary==null || this.auxiliary.size()==0) {
			this.auxiliary = new ArrayList<ICMCustomerCreateAuxiliary>();
		}
		this.auxiliary.add(auxiliary);   	
	}
}
