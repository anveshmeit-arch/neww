package com.scb.clm.services.globus.icm.v1.model;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ICMCustomerCreateTAR {

    @JsonProperty("us-resident")
    private String usResident;

    @JsonProperty("us-citizen")
    private String usCitizen;

    @JsonProperty("us-green-card-holder")
    private String usGreenCardHolder;

    @JsonProperty("on-board-with-dis")
    private String onBoardWithDis;

    @JsonProperty("usa-indicia-ind")
    private String usaIndiciaInd;

    @JsonProperty("usa-person-ind")
    private String usaPersonInd;

    @JsonProperty("report-to-irs-ind")
    private String reportToIRSInd;

    @JsonProperty("joint-ac-ind")
    private String jointAcInd;

    @JsonProperty("recalcitrant-ind")
    private String recalcitrantInd;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @JsonProperty("recalcitrant-ind-assign-dt")
    private Date recalcitrantIndAssignDt;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @JsonProperty("recalcitrant-ind-cleared-dt")
    private Date recalcitrantIndClearedDt;

    @JsonProperty("withhold-ind")
    private String withholdInd;

    @JsonProperty("enhanced-review-ind")
    private String enhancedReviewInd;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @JsonProperty("enhanced-review-start-dt")
    private Date enhancedReviewStartDt;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @JsonProperty("enhanced-review-end-dt")
    private Date enhancedReviewEndDt;

    @JsonProperty("document-submitted-indicator")
    private String documentSubmittedIndicator;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @JsonProperty("document-due-dt")
    private Date documentDueDt;

    @JsonProperty("gst-resident-status")
    private String gstResidentStatus;

    @JsonProperty("tax-resident-status")
    private String taxResidentStatus;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @JsonProperty("us-indicia-date")
    private Date lastChangeDateForUSIndicia;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @JsonProperty("us-person-flag-changed-date")
    private Date lastChangeDateForUSPerson;

    @JsonProperty("sender-id")
    private String senderId;

    @JsonProperty("sender-branch")
    private String senderBranch;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    @JsonProperty("created-at")
    private Timestamp createdAt;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    @JsonProperty("updated-at")
    private Timestamp updatedAt;

    @JsonProperty("status")
    private String status;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    @JsonProperty("status-at")
    private Timestamp statusAt;

    @JsonIgnore
    private short recordStatus;

    @JsonProperty("country-id")
    private String companyId;

    @JsonProperty("id")
    private String guid;

    @JsonProperty("reference-id")
    private String profileId;

    private List<ErrorDetails> errordetails;

    public String getUsResident() {
        return usResident;
    }

    public void setUsResident(String usResident) {
        this.usResident = usResident;
    }

    public String getUsCitizen() {
        return usCitizen;
    }

    public void setUsCitizen(String usCitizen) {
        this.usCitizen = usCitizen;
    }

    public String getUsGreenCardHolder() {
        return usGreenCardHolder;
    }

    public void setUsGreenCardHolder(String usGreenCardHolder) {
        this.usGreenCardHolder = usGreenCardHolder;
    }

    public String getOnBoardWithDis() {
        return onBoardWithDis;
    }

    public void setOnBoardWithDis(String onBoardWithDis) {
        this.onBoardWithDis = onBoardWithDis;
    }

    public String getUsaIndiciaInd() {
        return usaIndiciaInd;
    }

    public void setUsaIndiciaInd(String usaIndiciaInd) {
        this.usaIndiciaInd = usaIndiciaInd;
    }

    public String getUsaPersonInd() {
        return usaPersonInd;
    }

    public void setUsaPersonInd(String usaPersonInd) {
        this.usaPersonInd = usaPersonInd;
    }

    public String getReportToIRSInd() {
        return reportToIRSInd;
    }

    public void setReportToIRSInd(String reportToIRSInd) {
        this.reportToIRSInd = reportToIRSInd;
    }

    public String getJointAcInd() {
        return jointAcInd;
    }

    public void setJointAcInd(String jointAcInd) {
        this.jointAcInd = jointAcInd;
    }

    public String getRecalcitrantInd() {
        return recalcitrantInd;
    }

    public void setRecalcitrantInd(String recalcitrantInd) {
        this.recalcitrantInd = recalcitrantInd;
    }

    public Date getRecalcitrantIndAssignDt() {
        return recalcitrantIndAssignDt;
    }

    public void setRecalcitrantIndAssignDt(Date recalcitrantIndAssignDt) {
        this.recalcitrantIndAssignDt = recalcitrantIndAssignDt;
    }

    public Date getRecalcitrantIndClearedDt() {
        return recalcitrantIndClearedDt;
    }

    public void setRecalcitrantIndClearedDt(Date recalcitrantIndClearedDt) {
        this.recalcitrantIndClearedDt = recalcitrantIndClearedDt;
    }

    public String getWithholdInd() {
        return withholdInd;
    }

    public void setWithholdInd(String withholdInd) {
        this.withholdInd = withholdInd;
    }

    public String getEnhancedReviewInd() {
        return enhancedReviewInd;
    }

    public void setEnhancedReviewInd(String enhancedReviewInd) {
        this.enhancedReviewInd = enhancedReviewInd;
    }

    public Date getEnhancedReviewStartDt() {
        return enhancedReviewStartDt;
    }

    public void setEnhancedReviewStartDt(Date enhancedReviewStartDt) {
        this.enhancedReviewStartDt = enhancedReviewStartDt;
    }

    public Date getEnhancedReviewEndDt() {
        return enhancedReviewEndDt;
    }

    public void setEnhancedReviewEndDt(Date enhancedReviewEndDt) {
        this.enhancedReviewEndDt = enhancedReviewEndDt;
    }

    public String getDocumentSubmittedIndicator() {
        return documentSubmittedIndicator;
    }

    public void setDocumentSubmittedIndicator(String documentSubmittedIndicator) {
        this.documentSubmittedIndicator = documentSubmittedIndicator;
    }

    public Date getDocumentDueDt() {
        return documentDueDt;
    }

    public void setDocumentDueDt(Date documentDueDt) {
        this.documentDueDt = documentDueDt;
    }

    public String getGstResidentStatus() {
        return gstResidentStatus;
    }

    public void setGstResidentStatus(String gstResidentStatus) {
        this.gstResidentStatus = gstResidentStatus;
    }

    public String getTaxResidentStatus() {
        return taxResidentStatus;
    }

    public void setTaxResidentStatus(String taxResidentStatus) {
        this.taxResidentStatus = taxResidentStatus;
    }

    public Date getLastChangeDateForUSIndicia() {
        return lastChangeDateForUSIndicia;
    }

    public void setLastChangeDateForUSIndicia(Date lastChangeDateForUSIndicia) {
        this.lastChangeDateForUSIndicia = lastChangeDateForUSIndicia;
    }

    public Date getLastChangeDateForUSPerson() {
        return lastChangeDateForUSPerson;
    }

    public void setLastChangeDateForUSPerson(Date lastChangeDateForUSPerson) {
        this.lastChangeDateForUSPerson = lastChangeDateForUSPerson;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public String getSenderBranch() {
        return senderBranch;
    }

    public void setSenderBranch(String senderBranch) {
        this.senderBranch = senderBranch;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getStatusAt() {
        return statusAt;
    }

    public void setStatusAt(Timestamp statusAt) {
        this.statusAt = statusAt;
    }

    public short getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(short recordStatus) {
        this.recordStatus = recordStatus;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public List<ErrorDetails> getErrordetails() {
        return errordetails;
    }

    public void setErrordetails(List<ErrorDetails> errordetails) {
        this.errordetails = errordetails;
    }
}
