package com.scb.clm.services.globus.onboarding.v1.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSOnboardCustomerLinkWrapper {
	
	@JsonProperty("relationshipTypeCode")
	private String relationshipTypeCode;
	
	@JsonProperty("linkedRelationshipNumber")
	private String linkedRelationshipNumber;
	
	@JsonProperty("linkedRelationshipName")
	private String linkedRelationshipName;
	
	@JsonProperty("entityReferenceNumber")
	private String entityReferenceNumber;
	
	@JsonProperty("senderId")
	private String senderId;
	
	@JsonProperty("senderBranch")
	private String senderBranch;

	public String getRelationshipTypeCode() {
		return relationshipTypeCode;
	}

	public void setRelationshipTypeCode(String relationship_type_code) {
		this.relationshipTypeCode = relationship_type_code;
	}

	public String getLinkedRelationshipNumber() {
		return linkedRelationshipNumber;
	}

	public void setLinkedRelationshipNumber(String linked_relationship_number) {
		this.linkedRelationshipNumber = linked_relationship_number;
	}

	public String getLinkedRelationshipName() {
		return linkedRelationshipName;
	}

	public void setLinkedRelationshipName(String linked_relationship_name) {
		this.linkedRelationshipName = linked_relationship_name;
	}

	public String getEntityReferenceNumber() {
		return entityReferenceNumber;
	}

	public void setEntityReferenceNumber(String entity_reference_number) {
		this.entityReferenceNumber = entity_reference_number;
	}

	public String getSenderId() {
		return senderId;
	}

	public void setSenderId(String sender_id) {
		this.senderId = sender_id;
	}

	public String getSenderBranch() {
		return senderBranch;
	}

	public void setSenderBranch(String sender_branch) {
		this.senderBranch = sender_branch;
	}	

}
