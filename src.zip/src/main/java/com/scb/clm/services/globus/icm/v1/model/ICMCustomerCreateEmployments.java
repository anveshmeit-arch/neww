package com.scb.clm.services.globus.icm.v1.model;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ICMCustomerCreateEmployments {

	@JsonProperty("id")
	private String guid;
	
	@JsonProperty("reference-id")
	private String profileId;
	
	@JsonProperty("work-type")
	private String workType;
	
	@JsonProperty("profession-code")
	private String professionCode;
	
	@JsonProperty("employer-code")
	private String employerCode;
	
	@JsonProperty("employer-name")
	private String employerName;
	
	@JsonProperty("staff-category-code")
	private String staffCategoryCode;
	
	@JsonProperty("bank-pricing-category-code")
	private String bankPricingCategoryCode;
	
	@JsonProperty("own-organisation-name")
	private String ownOrganisationName;
	
	@JsonProperty("emp-banking-ind")
	private String empBankingInd;
	
	@JsonProperty("staff-empId")
	private String staffEmpId;
	
	@JsonProperty("salary-mode")
	private String salaryMode;
	
	@JsonProperty("declared-income")
	private BigDecimal declaredIncome;
	
	@JsonProperty("annual-derived-income")
	private BigDecimal unSecuredIncome;
	
	@JsonProperty("annual-documented-income")
	private BigDecimal documentedIncome;
	
	@JsonProperty("proxy-income")
	private BigDecimal proxyIncome;
	
	@JsonProperty("declared-income-currency")
	private String declaredIncomeCurr;
	
	@JsonProperty("derived-income-currency")
	private String unSecuredIncomeCurr;
	
	@JsonProperty("documented-income-currency")
	private String documentedIncomeCurrency;
	
	@JsonProperty("proxy-income-currency")
	private String proxyIncomeCurr;
	
	@JsonProperty("isic-code")
	private String isicCode;
	
	@JsonProperty("asset-under-management")
	private BigDecimal assetUnderManagement;
	
	@JsonProperty("asset-under-management-currency")
	private String assetUnderManagementCurrency;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	@JsonProperty("derived-income-last-updated-date")
	private Date unSecuredIncomeLastUpdatedDate;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	@JsonProperty("documented-income-last-updated-date")
	private Date documentedIncomeLastUpdatedDate;
	
	@JsonProperty("sender-id")
	private String senderId;
	
	@JsonProperty("sender-branch")
	private String senderBranch;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	@JsonProperty("created-at")
	private Timestamp createdAt;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	@JsonProperty("updated-at")
	private Timestamp updatedAt;
	
	@JsonProperty("status")
	private String status;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	@JsonProperty("status-at")
	private Timestamp statusAt;
	
	
	@JsonProperty("country-id")
	private String companyId;
	
	@JsonProperty("customer-occupation")
	private String occupationCode;
	
	private List<ErrorDetails> errordetails;

	public String getGuid() {
		return guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}

	public String getProfileId() {
		return profileId;
	}

	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}

	public String getWorkType() {
		return workType;
	}

	public void setWorkType(String workType) {
		this.workType = workType;
	}

	public String getProfessionCode() {
		return professionCode;
	}

	public void setProfessionCode(String professionCode) {
		this.professionCode = professionCode;
	}

	public String getEmployerCode() {
		return employerCode;
	}

	public void setEmployerCode(String employerCode) {
		this.employerCode = employerCode;
	}

	public String getEmployerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public String getStaffCategoryCode() {
		return staffCategoryCode;
	}

	public void setStaffCategoryCode(String staffCategoryCode) {
		this.staffCategoryCode = staffCategoryCode;
	}

	public String getBankPricingCategoryCode() {
		return bankPricingCategoryCode;
	}

	public void setBankPricingCategoryCode(String bankPricingCategoryCode) {
		this.bankPricingCategoryCode = bankPricingCategoryCode;
	}

	public String getOwnOrganisationName() {
		return ownOrganisationName;
	}

	public void setOwnOrganisationName(String ownOrganisationName) {
		this.ownOrganisationName = ownOrganisationName;
	}

	public String getEmpBankingInd() {
		return empBankingInd;
	}

	public void setEmpBankingInd(String empBankingInd) {
		this.empBankingInd = empBankingInd;
	}

	public String getStaffEmpId() {
		return staffEmpId;
	}

	public void setStaffEmpId(String staffEmpId) {
		this.staffEmpId = staffEmpId;
	}

	public String getSalaryMode() {
		return salaryMode;
	}

	public void setSalaryMode(String salaryMode) {
		this.salaryMode = salaryMode;
	}

	public BigDecimal getDeclaredIncome() {
		return declaredIncome;
	}

	public void setDeclaredIncome(BigDecimal declaredIncome) {
		this.declaredIncome = declaredIncome;
	}

	public BigDecimal getUnSecuredIncome() {
		return unSecuredIncome;
	}

	public void setUnSecuredIncome(BigDecimal unSecuredIncome) {
		this.unSecuredIncome = unSecuredIncome;
	}

	public BigDecimal getDocumentedIncome() {
		return documentedIncome;
	}

	public void setDocumentedIncome(BigDecimal documentedIncome) {
		this.documentedIncome = documentedIncome;
	}

	public BigDecimal getProxyIncome() {
		return proxyIncome;
	}

	public void setProxyIncome(BigDecimal proxyIncome) {
		this.proxyIncome = proxyIncome;
	}

	public String getDeclaredIncomeCurr() {
		return declaredIncomeCurr;
	}

	public void setDeclaredIncomeCurr(String declaredIncomeCurr) {
		this.declaredIncomeCurr = declaredIncomeCurr;
	}

	public String getUnSecuredIncomeCurr() {
		return unSecuredIncomeCurr;
	}

	public void setUnSecuredIncomeCurr(String unSecuredIncomeCurr) {
		this.unSecuredIncomeCurr = unSecuredIncomeCurr;
	}

	public String getDocumentedIncomeCurrency() {
		return documentedIncomeCurrency;
	}

	public void setDocumentedIncomeCurrency(String documentedIncomeCurrency) {
		this.documentedIncomeCurrency = documentedIncomeCurrency;
	}

	public String getProxyIncomeCurr() {
		return proxyIncomeCurr;
	}

	public void setProxyIncomeCurr(String proxyIncomeCurr) {
		this.proxyIncomeCurr = proxyIncomeCurr;
	}

	public String getIsicCode() {
		return isicCode;
	}

	public void setIsicCode(String isicCode) {
		this.isicCode = isicCode;
	}

	public BigDecimal getAssetUnderManagement() {
		return assetUnderManagement;
	}

	public void setAssetUnderManagement(BigDecimal assetUnderManagement) {
		this.assetUnderManagement = assetUnderManagement;
	}

	public String getAssetUnderManagementCurrency() {
		return assetUnderManagementCurrency;
	}

	public void setAssetUnderManagementCurrency(String assetUnderManagementCurrency) {
		this.assetUnderManagementCurrency = assetUnderManagementCurrency;
	}

	public Date getUnSecuredIncomeLastUpdatedDate() {
		return unSecuredIncomeLastUpdatedDate;
	}

	public void setUnSecuredIncomeLastUpdatedDate(Date unSecuredIncomeLastUpdatedDate) {
		this.unSecuredIncomeLastUpdatedDate = unSecuredIncomeLastUpdatedDate;
	}

	public Date getDocumentedIncomeLastUpdatedDate() {
		return documentedIncomeLastUpdatedDate;
	}

	public void setDocumentedIncomeLastUpdatedDate(Date documentedIncomeLastUpdatedDate) {
		this.documentedIncomeLastUpdatedDate = documentedIncomeLastUpdatedDate;
	}

	public String getSenderId() {
		return senderId;
	}

	public void setSenderId(String senderId) {
		this.senderId = senderId;
	}

	public String getSenderBranch() {
		return senderBranch;
	}

	public void setSenderBranch(String senderBranch) {
		this.senderBranch = senderBranch;
	}

	public Timestamp getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Timestamp createdAt) {
		this.createdAt = createdAt;
	}

	public Timestamp getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Timestamp updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getStatusAt() {
		return statusAt;
	}

	public void setStatusAt(Timestamp statusAt) {
		this.statusAt = statusAt;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getOccupationCode() {
		return occupationCode;
	}

	public void setOccupationCode(String occupationCode) {
		this.occupationCode = occupationCode;
	}

	public List<ErrorDetails> getErrordetails() {
		return errordetails;
	}

	public void setErrordetails(List<ErrorDetails> errordetails) {
		this.errordetails = errordetails;
	}
}
