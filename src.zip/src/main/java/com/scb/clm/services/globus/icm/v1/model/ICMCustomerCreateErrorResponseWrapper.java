package com.scb.clm.services.globus.icm.v1.model;


import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ICMCustomerCreateErrorResponseWrapper {
	
	 @JsonProperty("errors")
	 private List<Error> errors;

	public List<Error> getErrors() {
		return errors;
	}

	public void setErrors(List<Error> errors) {
		this.errors = errors;
	}


}
