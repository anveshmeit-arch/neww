package com.scb.clm.services.companysearch.chekk.v1.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.scb.clm.services.companysearch.chekk.v1.model.ChekkSearchEntityQEntity;

@Repository
public interface ChekkSearchEntityQueueRepository extends JpaRepository<ChekkSearchEntityQEntity, String> {

	@Override
	public <S extends ChekkSearchEntityQEntity> S save(S entity);

	@Override
	public <S extends ChekkSearchEntityQEntity> S saveAndFlush(S entity);

	List<ChekkSearchEntityQEntity> findByStatusIn(List<String> statusList);

    @Query(value = "select Q.request_id,Q.party_id,Q.search_entity_id,Q.level,Q.entity_name,Q.registration_id,Q.country_of_registration,Q.status,Q.error_code,Q.created_on,Q.updated_on from CHK_SEARCH_ENTITY_QUEUE Q join CHK_REQUESTS REQ on Q.request_id=REQ.request_id WHERE REQ.instance_name= :instanceName AND Q.status in ('CP','SP') AND REQ.search_depth>1 order by status",nativeQuery = true)
    public List<ChekkSearchEntityQEntity> getPendingGetCreateRequests(@Param("instanceName")String instanceName);

	
	//TODO update query extract(EPOCH from (NOW() - updated_on )) 
    @Query(value = "select Q.request_id,Q.party_id,Q.search_entity_id,Q.level,Q.entity_name,Q.registration_id,Q.country_of_registration,Q.status,Q.error_code,Q.created_on,Q.updated_on from CHK_SEARCH_ENTITY_QUEUE Q join CHK_REQUESTS REQ on Q.request_id=REQ.request_id WHERE REQ.instance_name= :instanceName AND Q.status = :status AND REQ.search_depth>1 order by level",nativeQuery = true)
    public List<ChekkSearchEntityQEntity> getSearchEntityQueue(@Param("instanceName")String instanceName,@Param("status")String status);
    
    @Transactional
    @Modifying
    @Query(value = "update CHK_SEARCH_ENTITY_QUEUE set status = :status,  updated_on =now() where search_entity_id = :searchEntityId and request_id = :requestId",nativeQuery = true )
    public int updateStatusByIds(@Param("status") String status,@Param("searchEntityId") String searchEntityId,@Param("requestId") String requestId);

    List<ChekkSearchEntityQEntity> findByRequestIdAndStatus(String requestId,String status);
    
    List<ChekkSearchEntityQEntity> findByRequestIdAndStatusIn(String requestId,List<String> statusList);

    
    @Query(value = "select Q.request_id,Q.party_id,Q.search_entity_id,Q.LEVEL,Q.entity_name,Q.registration_id,\r\n"
    		+ "Q.country_of_registration,Q.status,Q.error_code,Q.created_on,Q.updated_on\r\n"
    		+ "from chk_search_entity_queue Q join ( select Q1.request_id,MAX(Q1.level) max_level\r\n"
    		+ "from CHK_SEARCH_ENTITY_QUEUE Q1\r\n"
    		+ "join CHK_REQUESTS REQ on Q1.request_id=REQ.request_id\r\n"
    		+ "where  REQ.instance_name= :instanceName  and REQ.status=:status AND REQ.search_depth>1 \r\n"
    		+ "GROUP BY Q1.request_id) A \r\n"
    		+ "on Q.request_id=A.request_id and Q.level=A.max_level \r\n"
    		+ "order by level desc",nativeQuery = true)
    public List<ChekkSearchEntityQEntity> getSearchEntityQueueDetails(@Param("instanceName")String instanceName,@Param("status")String status);
}
