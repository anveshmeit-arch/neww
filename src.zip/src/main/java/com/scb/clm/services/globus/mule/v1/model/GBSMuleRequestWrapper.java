package com.scb.clm.services.globus.mule.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSMuleRequestWrapper
{
    
    @JsonProperty("application")
    private GBSMuleRequestApplication application;

    public GBSMuleRequestApplication getApplication() {
        return application;
    }

    public void setApplication(GBSMuleRequestApplication application) {
        this.application = application;
    }
}