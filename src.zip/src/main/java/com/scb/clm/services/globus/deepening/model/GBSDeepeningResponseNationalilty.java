package com.scb.clm.services.globus.deepening.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSDeepeningResponseNationalilty {
    @JsonProperty("nationalityCode")
    public String nationalityCode;

    public GBSDeepeningResponseNationalilty() {
    }

    public String getNationalityCode() {
        return nationalityCode;
    }

    public void setNationalityCode(String nationalityCode) {
        this.nationalityCode = nationalityCode;
    }
}
