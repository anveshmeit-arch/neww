package com.scb.clm.services.companysearch.chekk.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class ErrorDetails {

	@JsonProperty("errorCode")
	private String errorCode;
	
	@JsonProperty("errorDescription")
	private String errorDescription;
	
}
