package com.scb.clm.services.companysearch.chekk.v1.service;

import java.util.Map;

import com.scb.clm.common.util.DateTimeUtility;
import com.scb.clm.common.util.SystemUtility;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkRequestsEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkResponseDataEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.SearchRequest;
import com.scb.clm.services.companysearch.chekk.v1.support.ChkApiType;
import com.scb.clm.services.companysearch.chekk.v1.support.ProcessApiConstants;

public class ChkResponse2EntityConveter {

	
	public ChekkRequestsEntity constructChekkRequestEnity(String requestId, Map<String, String> headers,
			SearchRequest searchReq, boolean isSuccess) {
		String status = isSuccess ? ProcessApiConstants.STATUS_UNWRAP_PENDING : ProcessApiConstants.STATUS_PUBLISH_FAILED;
		ChekkRequestsEntity chekkRequestsEntity = new ChekkRequestsEntity();
		chekkRequestsEntity.setCountryCode(headers.get(ProcessApiConstants.REQ_HDR_COUNTRY_CODE)); 
		chekkRequestsEntity.setRequestId(requestId);
		chekkRequestsEntity.setInstanceName(SystemUtility.getInstanceName());
		chekkRequestsEntity.setApplicationReference(searchReq.getApplicationReferenceNumber());
		chekkRequestsEntity.setEntityName(searchReq.getEntityName());
		chekkRequestsEntity.setRegistrationId(searchReq.getRegistrationID());
		chekkRequestsEntity.setClientEntityType(searchReq.getClientEntityType());
		chekkRequestsEntity.setSearchDepth(Integer.valueOf(searchReq.getSearchDepth())); //TODO handle exception properly
		chekkRequestsEntity.setCountryAccountOpen(searchReq.getCountryOfAccountOpening());
		chekkRequestsEntity.setCountryOfRegistration(searchReq.getCountryOfRegistration());
		chekkRequestsEntity.setCreatedOn(DateTimeUtility.getCurrentTime());
		chekkRequestsEntity.setUpdatedOn(DateTimeUtility.getCurrentTime());
		chekkRequestsEntity.setStatus(status);
		return chekkRequestsEntity;
	}
	
	private ChekkResponseDataEntity constructChekkResponseEnity(String id,String requestId, String searchId,
			ChkApiResponse apiResponse) {
		String status = apiResponse.isSuccess() ? "S" : "F";

		ChekkResponseDataEntity chekkResponseDataEntity = new ChekkResponseDataEntity();
		chekkResponseDataEntity.setId(id);
		chekkResponseDataEntity.setSearchEntityId(searchId);
		chekkResponseDataEntity.setCreatedOn(DateTimeUtility.getCurrentTime());
		chekkResponseDataEntity.setRequestId(requestId);
		chekkResponseDataEntity.setResType("S");
		chekkResponseDataEntity.setStatus(status);
		chekkResponseDataEntity.setResData(apiResponse.getResponseData());
		return chekkResponseDataEntity;
	}

}
