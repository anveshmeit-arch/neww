package com.scb.clm.services.globus.icm.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RequestHeaderInformation {

    @JsonProperty("tracking-id")
    private String  trackingId;	

    @JsonProperty("interface-id")
    private String  interfaceId;

    @JsonProperty("request-country-code")
    private String  countrycode;

    public String getTrackingId() {
        return trackingId;
    }

    public void setTrackingId(String trackingId) {
        this.trackingId = trackingId;
    }

    public String getInterfaceId() {
        return interfaceId;
    }

    public void setInterfaceId(String interfaceId) {
        this.interfaceId = interfaceId;
    }

    public String getCountrycode() {
        return countrycode;
    }

    public void setCountrycode(String countrycode) {
        this.countrycode = countrycode;
    }


}
