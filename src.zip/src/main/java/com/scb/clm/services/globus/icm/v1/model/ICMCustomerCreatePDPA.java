package com.scb.clm.services.globus.icm.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ICMCustomerCreatePDPA {
    @JsonProperty("ccq-sequence")
    private String ccqSequence;

    @JsonProperty("cust-selection")
    private String custSelection;

    public String getCcqSequence() {
        return ccqSequence;
    }

    public void setCcqSequence(String ccqSequence) {
        this.ccqSequence = ccqSequence;
    }

    public String getCustSelection() {
        return custSelection;
    }

    public void setCustSelection(String custSelection) {
        this.custSelection = custSelection;
    }

}
