package com.scb.clm.services.globus.icm.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ICMResponsesData {

	@JsonProperty("id")
	String id;

	@JsonProperty("type")
	String type;

	@JsonProperty("attributes")
	CLMResponsesAttributes attributes;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public CLMResponsesAttributes getAttributes() {
		return attributes;
	}

	public void setAttributes(CLMResponsesAttributes attributes) {
		this.attributes = attributes;
	}

	public ICMResponsesData(String id, String type, CLMResponsesAttributes attributes) {
		super();
		this.id = id;
		this.type = type;
		this.attributes = attributes;
	}

	public ICMResponsesData() {
		super();
	}

}
