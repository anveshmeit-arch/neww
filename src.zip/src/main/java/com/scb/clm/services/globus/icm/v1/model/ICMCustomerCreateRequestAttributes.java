package com.scb.clm.services.globus.icm.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ICMCustomerCreateRequestAttributes {

    @JsonProperty("customers") 
    private ICMCustomerCreateCustomer customers;

    public ICMCustomerCreateCustomer getCustomers() {
        return customers;
    }

    public void setCustomers(ICMCustomerCreateCustomer customers) {
        this.customers = customers;
    }

}
