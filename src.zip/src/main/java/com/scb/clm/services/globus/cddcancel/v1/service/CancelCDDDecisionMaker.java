package com.scb.clm.services.globus.cddcancel.v1.service;

import java.util.List;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.codesetup.NodeServicesEntityKey;
import com.scb.clm.common.model.codesetup.NodesEntity;
import com.scb.clm.common.model.transactions.NodeStatus;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.util.JSONUtility;
import com.scb.clm.core.service.DecisionMakerInterface;

public class CancelCDDDecisionMaker implements DecisionMakerInterface
{

	@Override
	public void isGoodToProceed(TravellingObject travelObj,NodesEntity nodesEntity,List<NodeServicesEntity> service,NodeStatus nodeStatus)
	{
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "method_name", LogType.APPLICATION.name());
		try
		{
			for(NodeServicesEntity services :  service) 
			{
				ServiceStatus stat = travelObj.getServiceStatus(services.getId());
				if(!stat.getStatus().equals(BaseConstants.SERVICE_SUCCESS)) 
				{
				    log.println("CDD Decision Maker Service Failed For "+stat.printKey());
					nodeStatus.setProcessToNextNode(false);
				}
			}
			log.println("Cancel CDD Decision Maker - Service Success Status ["+((nodeStatus.isProcessToNextNode())?"Success":"Failure")+"]");
		}
		catch(Exception e)
		{
		    log.printErrorMessage(e);
		}
		finally
		{

		}
	}

	@Override
	public void buildResponse(TravellingObject travelObj,NodesEntity nodesEntity,List<NodeServicesEntity> service,boolean isSuccess)
	{
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "buildResponse", LogType.APPLICATION.name());
		try
		{
			ServiceStatus serviceStatus = travelObj.getServiceStatus().get(BaseConstants.ONBOARD_CREATEICM_SRV);
			log.println("Building Response Data Cancel cdd ["+isSuccess+"]");
			if(isSuccess) 
			{
				travelObj.setResponseData(serviceStatus.getResponsePayload());
			} 
			else 
			{
				travelObj.setResponseData(serviceStatus.getResponsePayload());
			}
		}
		catch(Exception e)
		{
			log.printErrorMessage(e);
		}
		finally
		{

		}
	}

	private Object buildSuccessResponse(TravellingObject travelObj,NodesEntity nodesEntity,List<NodeServicesEntity> service)
	{
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "buildSuccessResponse", LogType.APPLICATION.name());
		try
		{
			log.println("Success - "+JSONUtility.domainWrapperToJSON(travelObj));
			return (travelObj.getServiceStatus(new NodeServicesEntityKey(
					service.get(0).getId().getCountryCode(), 
					service.get(0).getId().getFlowIdentifier(), 
					service.get(0).getId().getNodeIdentifier(), 
					service.get(0).getId().getServiceIdentifier()))).getResponsePayload();
		}
		catch(Exception e)
		{
			log.printErrorMessage(e);
		}
		finally
		{
		    //N.A
		}
		return null;
	}

	private Object buildFailureResponse(TravellingObject travelObj,NodesEntity nodesEntity,List<NodeServicesEntity> service)
	{
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "buildFailureResponse", LogType.APPLICATION.name());
		try
		{
		    log.println("CDD Fail -"+JSONUtility.domainWrapperToJSON(travelObj));
			return (travelObj.getServiceStatus(new NodeServicesEntityKey(
					service.get(0).getId().getCountryCode(), 
					service.get(0).getId().getFlowIdentifier(), 
					service.get(0).getId().getNodeIdentifier(), 
					service.get(0).getId().getServiceIdentifier()))).getResponsePayload();
		}
		catch(Exception e)
		{
			log.printErrorMessage(e);
		}
		finally
		{
		    //N.A
		}
		return null;
	}
}
