package com.scb.clm.services.globus.onboarding.v1.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSOnboardAddressesWrapper {
	
	@JsonProperty("addressType")
	private String addressType;
	
	@JsonProperty("addressLine1")
	private String addressLine1;
	
	@JsonProperty("addressLine2")
	private String addressLine2;
	
	@JsonProperty("addressLine3")
	private String addressLine3;
	
	@JsonProperty("cityName")
	private String cityName;
	
	@JsonProperty("state")
	private String state;
	
	@JsonProperty("countryCode")
	private String countryCode;
	
	@JsonProperty("postalCode")
	private String postalCode;
	
	@JsonProperty("nearestLandMark")
	private String nearestLandMark;
	
	@JsonProperty("isMailingAddress")
	private String isMailingAddress;
	
	@JsonProperty("postBoxNo")
	private String postBoxNo;
	
	@JsonProperty("poaDocument")
	private String poaDocument;
	
	@JsonProperty("stateCode")
	private String stateCode;
	
	@JsonProperty("langId")
	private String langId;

	@JsonProperty("addressClassificationCode")
	private String addressClassificationCode;
	
	@JsonProperty("localGovernmentAreaCode")
	private String localGovernmentAreaCode;

    public String getAddressType() {
        return addressType;
    }

    public void setAddressType(String addressType) {
        this.addressType = addressType;
    }

    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getAddressLine3() {
        return addressLine3;
    }

    public void setAddressLine3(String addressLine3) {
        this.addressLine3 = addressLine3;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getNearestLandMark() {
        return nearestLandMark;
    }

    public void setNearestLandMark(String nearestLandMark) {
        this.nearestLandMark = nearestLandMark;
    }

    public String getIsMailingAddress() {
        return isMailingAddress;
    }

    public void setIsMailingAddress(String isMailingAddress) {
        this.isMailingAddress = isMailingAddress;
    }

    public String getPostBoxNo() {
        return postBoxNo;
    }

    public void setPostBoxNo(String postBoxNo) {
        this.postBoxNo = postBoxNo;
    }

    public String getPoaDocument() {
        return poaDocument;
    }

    public void setPoaDocument(String poaDocument) {
        this.poaDocument = poaDocument;
    }

    public String getStateCode() {
        return stateCode;
    }

    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    public String getLangId() {
        return langId;
    }

    public void setLangId(String langId) {
        this.langId = langId;
    }

    public String getAddressClassificationCode() {
        return addressClassificationCode;
    }

    public void setAddressClassificationCode(String addressClassificationCode) {
        this.addressClassificationCode = addressClassificationCode;
    }

    public String getLocalGovernmentAreaCode() {
        return localGovernmentAreaCode;
    }

    public void setLocalGovernmentAreaCode(String localGovernmentAreaCode) {
        this.localGovernmentAreaCode = localGovernmentAreaCode;
    }


}
