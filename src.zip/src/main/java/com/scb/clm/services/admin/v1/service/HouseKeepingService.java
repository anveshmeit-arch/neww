package com.scb.clm.services.admin.v1.service;

import java.sql.Date;
import java.time.Duration;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.transactions.InboundRequestsEntity;
import com.scb.clm.common.model.transactions.JobStatusEntity;
import com.scb.clm.common.model.transactions.OutboundRequestsEntity;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.repository.InboundRequestsRepository;
import com.scb.clm.common.repository.JobStatusRepository;
import com.scb.clm.common.repository.OutboundRequestsRepository;
import com.scb.clm.common.util.ServiceParameterUtility;
import com.scb.clm.core.service.ServiceAbstract;
import com.scb.clm.core.service.ServiceInterface;
import com.scb.clm.services.admin.v1.support.AdminConstants;
import com.scb.clm.services.admin.v1.support.AdminUtility;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

@Service
@Configurable
public class HouseKeepingService extends ServiceAbstract implements ServiceInterface
{
    @Autowired 
    private EntityManager em;

    @Autowired
    InboundRequestsRepository inboundRequestsRepository;

    @Autowired
    OutboundRequestsRepository outboundRequestsRepository;

    @Autowired
    JobStatusRepository jobStatusRepository;

    @Override
    public Object readRequestObject(TravellingObject travellingObject, NodeServicesEntity srvEntity) throws ProcessException 
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "readRequestObject", LogType.APPLICATION.name());
        log.println("Read Request House Keeping ");
        return null;
    }

    @Override
    public void validateData(TravellingObject travellingObject, NodeServicesEntity srvEntity, Object requestPayload) throws ProcessException 
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateData", LogType.APPLICATION.name());
        log.println("Validate House Keeping ");
    }

    @Override
    public Object constructOutboundObject(TravellingObject travellingObject, NodeServicesEntity srvEntity,Object requestPayload) throws ProcessException 
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "constructOutboundObject", LogType.APPLICATION.name());
        log.println("Outbound House Keeping ");
        return null;
    }

    @Override
    public Object process(TravellingObject travellingObject, NodeServicesEntity srvEntity, ServiceStatus serviceStatus,Object obj) throws ProcessException 
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "process", LogType.APPLICATION.name());
        log.println("Process House Keeping ");

        try 
        {
            houseKeepInBoundData(travellingObject, srvEntity, serviceStatus, obj);
            houseKeepOutBoundData(travellingObject, srvEntity, serviceStatus, obj);
            houseKeepJobStatusData(travellingObject, srvEntity, serviceStatus, obj);
        } 
        catch (Exception e) 
        {
            log.printErrorMessage(e);

        }
        return null;
    }

    @Override
    public Object constructServiceResponse(TravellingObject travellingObject, NodeServicesEntity srvEntity, Object obj,ServiceStatus serviceStatus) throws ProcessException 
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "constructServiceResponse", LogType.APPLICATION.name());
        log.println("Inbound House Keeping ");
        return null;
    }

    @Transactional
    private void houseKeepInBoundData(TravellingObject travellingObject, NodeServicesEntity srvEntity, ServiceStatus serviceStatus,Object obj)
    {
        LoggerUtil log   = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "houseKeepInBoundData", LogType.APPLICATION.name());
        String purgeDays = "999";
        String batchSize = "0";
        try 
        {
            purgeDays = ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),AdminConstants.HOUSE_KEEPING_GROUP_ID,AdminConstants.INBOUND_HOUSE_KEEP_DAYS);
            batchSize = ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),AdminConstants.HOUSE_KEEPING_GROUP_ID,AdminConstants.INBOUND_HOUSE_KEEP_BATCH_SIZE);

            if (AdminUtility.isValidDay(purgeDays) && AdminUtility.isValidBatchSize(batchSize))
            {
                log.println("Deleting InBound Data - Days less than "+purgeDays+" days / Batch Size ["+batchSize+"]");

                while(true)
                {
                    TypedQuery<InboundRequestsEntity> query = em.createQuery("SELECT i FROM InboundRequestsEntity i WHERE  i.requestDate < :thresholdDate ",InboundRequestsEntity.class);
                    query.setParameter("thresholdDate", getThresholdDays(purgeDays));
                    query.setMaxResults(Integer.parseInt(batchSize));
    
                    List<InboundRequestsEntity> inBoundEntityList = query.getResultList();
                    log.println("Deleting InBound Data - Size : "+(inBoundEntityList==null?0:inBoundEntityList.size()));
                    try
                    {
                        for(InboundRequestsEntity inBoundEntity : inBoundEntityList)
                        {
                            inboundRequestsRepository.deleteById(inBoundEntity.getId());
                        }
                    }
                    catch(Exception e) {
                        log.println("[FATAL] House Keeping Rolled Back for GBS_INBOUND_REQUESTS");
                    }
                    finally {
    
                    }
                    log.println("Deleting InBound Data Completed");
                    
                    if(inBoundEntityList==null || inBoundEntityList.size()==0) 
                    {
                        System.out.println("Breaking Inbound Loop");
                        log.println("Breaking Inbound Loop");
                        break;
                    }
                }  
                    
            } 
            else 
            {
                throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,AdminConstants.INVALID_CONFIGURATION,"INVALID DAYS / BATCH SIZE CONFIGURED FOR INBOUND HOUSE KEEPING DAYS");
            }
        } 
        catch (Exception e) 
        {
            log.printErrorMessage(e);

        }
    }



    @Transactional
    private void houseKeepOutBoundData(TravellingObject travellingObject, NodeServicesEntity srvEntity, ServiceStatus serviceStatus,Object obj)
    {
        String purgeDays = "999";
        String batchSize = "0";
        LoggerUtil log   = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "houseKeepOutBoundData", LogType.APPLICATION.name());

        try 
        {
            purgeDays = ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),AdminConstants.HOUSE_KEEPING_GROUP_ID,AdminConstants.OUTBOUND_HOUSE_KEEP_DAYS);
            batchSize = ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),AdminConstants.HOUSE_KEEPING_GROUP_ID,AdminConstants.OUTBOUND_HOUSE_KEEP_BATCH_SIZE);

            if (AdminUtility.isValidDay(purgeDays) && AdminUtility.isValidBatchSize(batchSize))
            {
                log.println("Deleting OutBound Data - Days less than "+purgeDays+" days / Batch Size ["+batchSize+"]");

                while(true)
                {
                    TypedQuery<OutboundRequestsEntity> query = em.createQuery("SELECT o FROM OutboundRequestsEntity o WHERE  o.requestDate < :thresholdDate ",OutboundRequestsEntity.class);
                    query.setParameter("thresholdDate", getThresholdDays(purgeDays));
                    query.setMaxResults(Integer.parseInt(batchSize));
    
                    List<OutboundRequestsEntity> outBoundEntityList = query.getResultList();
                    log.println("Deleting OutBound Data - Size : "+(outBoundEntityList==null?0:outBoundEntityList.size()));
                    try
                    {
                        for(OutboundRequestsEntity outBoundEntity : outBoundEntityList)
                        {
                            outboundRequestsRepository.deleteById(outBoundEntity.getId());
                        }
                    }
                    catch(Exception e)
                    {
                        log.println("[FATAL] House Keeping Rolled Back for GBS_OUTBOUND_REQUESTS");
                    }
                    finally {
    
                    }
                    log.println("Deleting InBound Data Completed");
                    
                    if(outBoundEntityList==null || outBoundEntityList.size()==0) 
                    {
                        System.out.println("Breaking Outbound Loop");
                        log.println("Breaking Outbound Loop");
                        break;
                    }
                }
            } 
            else 
            {
                throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,AdminConstants.INVALID_CONFIGURATION,"INVALID DAYS / BATCH SIZE CONFIGURED FOR INBOUND HOUSE KEEPING DAYS");
            }
        } 
        catch (Exception e) 
        {
            log.printErrorMessage(e);
        }

    }

    @Transactional
    private void houseKeepJobStatusData(TravellingObject travellingObject, NodeServicesEntity srvEntity, ServiceStatus serviceStatus,Object obj)
    {
        String purgeDays = "999";
        String batchSize = "0";

        LoggerUtil log   = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "houseKeepJobStatusData", LogType.APPLICATION.name());

        try 
        {
            purgeDays = ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),AdminConstants.HOUSE_KEEPING_GROUP_ID,AdminConstants.JOB_STATUS_HOUSE_KEEP_DAYS);
            batchSize = ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),AdminConstants.HOUSE_KEEPING_GROUP_ID,AdminConstants.JOB_STATUS_HOUSE_KEEP_BATCH_SIZE);

            if (AdminUtility.isValidDay(purgeDays) && AdminUtility.isValidBatchSize(batchSize))
            {
                log.println("Deleting Job Status Data - Days less than ["+purgeDays+"] days / Batch Size ["+batchSize+"]");

                while(true)
                {
                   
                    TypedQuery<JobStatusEntity> query = em.createQuery("SELECT i FROM JobStatusEntity i WHERE i.processDate < :thresholdDate ",JobStatusEntity.class);
                    query.setParameter("thresholdDate", Date.valueOf(getThresholdDays(purgeDays)));
                    query.setMaxResults(Integer.parseInt(batchSize));
    
                    List<JobStatusEntity> jobStatusEntityList = query.getResultList();
                    log.println("Deleting Job Status Data - Size : "+(jobStatusEntityList==null?0:jobStatusEntityList.size()));
                    try
                    {
                        for(JobStatusEntity jobStatusEntity : jobStatusEntityList)
                        {
                            jobStatusRepository.deleteById(jobStatusEntity.getId());
                        }
                    }
                    catch(Exception e) 
                    {
                        log.println("[FATAL] House Keeping Rolled Back for GBS_JOB_STATUS");
                    }
                    finally 
                    {
    
                    }
                    log.println("Deleting Job Status Data Completed");

                    if(jobStatusEntityList==null || jobStatusEntityList.size()==0) 
                    {
                        System.out.println("Breaking JobStatusEntity");
                        log.println("Breaking JobStatusEntity");
                        break;
                    }
                    
                }
            } 
            else 
            {
                throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,AdminConstants.INVALID_CONFIGURATION,"INVALID DAYS / BATCH SIZE CONFIGURED FOR JOB STATUS HOUSE KEEPING DAYS");
            }
        } 
        catch (Exception e) 
        {
            log.printErrorMessage(e);
        }

    }
    
    public LocalDate getThresholdDays(String purgeDays) {
        Duration duration = Duration.ofDays(Integer.valueOf(purgeDays));
        LocalDate currentDate = LocalDate.now();
        return currentDate.minusDays(duration.toDays());
    }
}
