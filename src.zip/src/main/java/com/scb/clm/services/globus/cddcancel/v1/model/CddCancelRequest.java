package com.scb.clm.services.globus.cddcancel.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CddCancelRequest {

    @JsonProperty("type")
    public String type="applicant-external-references";

    @JsonProperty("id")
    public String id;

    @JsonProperty("attributes") 
    private CddCancelRequestAttributes attributes;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public CddCancelRequestAttributes getAttributes() {
        return attributes;
    }

    public void setAttributes(CddCancelRequestAttributes attributes) {
        this.attributes = attributes;
    }

}
