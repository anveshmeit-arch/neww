package com.scb.clm.services.globus.icm.v1.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.HashMap;
import java.util.Optional;

import com.scb.clm.services.globus.icm.v1.model.*;
import com.scb.clm.services.globus.onboarding.v1.models.*;
import com.scb.clm.services.globus.onboarding.v1.models.ErrorDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.clm.common.config.ApplicationConfiguration;
import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.config.ContactServerInfo;
import com.scb.clm.common.exception.ErrorObject;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.repository.CountryCodeRepository;
import com.scb.clm.common.repository.InterfaceRequestTypeRepository;
import com.scb.clm.common.util.DateTimeUtility;
import com.scb.clm.common.util.JSONUtility;
import com.scb.clm.common.util.ServiceParameterUtility;
import com.scb.clm.common.util.StringUtility;
import com.scb.clm.core.service.ServiceAbstract;
import com.scb.clm.core.service.ServiceInterface;
import com.scb.clm.services.globus.cddinitiate.v1.model.CDDRespAccountReferencesInitiateJson;
import com.scb.clm.services.globus.cddinitiate.v1.model.CDDRespCreateInitiateJson;
import com.scb.clm.services.globus.icm.v1.model.ICMCustomerCreateAddress;
import com.scb.clm.services.globus.icm.v1.model.ICMCustomerCreateAlias;
import com.scb.clm.services.globus.icm.v1.model.ICMCustomerCreateAuxiliary;
import com.scb.clm.services.globus.icm.v1.model.ICMCustomerCreateCDD;
import com.scb.clm.services.globus.icm.v1.model.ICMCustomerCreateContacts;
import com.scb.clm.services.globus.icm.v1.model.ICMCustomerCreateCustomer;
import com.scb.clm.services.globus.icm.v1.model.ICMCustomerCreateDocuments;
import com.scb.clm.services.globus.icm.v1.model.ICMCustomerCreateEmployments;
import com.scb.clm.services.globus.icm.v1.model.ICMCustomerCreateErrorResponseWrapper;
import com.scb.clm.services.globus.icm.v1.model.ICMCustomerCreateKYC;
import com.scb.clm.services.globus.icm.v1.model.ICMCustomerCreatePreference;
import com.scb.clm.services.globus.icm.v1.model.ICMCustomerCreateRequestAttributes;
import com.scb.clm.services.globus.icm.v1.model.ICMCustomerCreateRequestData;
import com.scb.clm.services.globus.icm.v1.model.ICMCustomerCreateRequestWrapper;
import com.scb.clm.services.globus.icm.v1.model.ICMCustomerCreateResponseWrapper;
import com.scb.clm.services.globus.icm.v1.model.ICMCustomerCreateRisks;
import com.scb.clm.services.globus.icm.v1.model.ICMCustomerCreateRisksDetails;
import com.scb.clm.services.globus.icm.v1.model.ICMCustomerCreateTAR;
import com.scb.clm.services.globus.icm.v1.model.ICMCustomerKYCNationality;
import com.scb.clm.services.globus.icm.v1.support.ICMConstants;
import com.scb.clm.services.globus.onboarding.v1.models.ErrorDetails;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardAddressesWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardAliasesWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardCDDWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardContactsWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardCustomerNationaliltyWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardCustomerWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardDocumentsWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardEmploymentsMandatoryWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardKYCWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardPreferencesWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardReqWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardResponseAccountReference;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardResponseCDDRiskDetails;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardResponseNameScreeningResults;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardResponseOnboardingStatusReason;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardResponseWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardTarsCondnMandatoryWrapper;

@Service
public class ICMCreateService extends ServiceAbstract implements ServiceInterface
{

    @Autowired
    InterfaceRequestTypeRepository interfaceRequestTypeRepository;

    @Autowired
    ApplicationConfiguration applicationConfiguration;

    @Autowired
    CountryCodeRepository countryCodeRepository;
    
    @Autowired
    RestTemplate restTemplate;

    private static final String ICM_CREATE_INTERFACE_ID         = "ICM";
    private static final String ICM_CREATE_SERVICE_ID           = "SCRICM";
    private static final String ICM_UPDATE_SERVICE_ID           = "SCRICMUPDATE";
    private static final String CDD_REASON_PRO                  = "PRO";
    private static final String CDD_REASON_NSP                  = "NSP";
    private static final String CDD_REASON_HRC                  = "HRC";
    private static final String CDD_REASON_NSH                  = "NSH";

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object readRequestObject(TravellingObject travellingObject, NodeServicesEntity srvEntity) throws ProcessException 
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "readRequestObject", LogType.APPLICATION.name());

        List<ErrorObject> errorObjectList = new ArrayList<ErrorObject>();
        try
        {
            return JSONUtility.jsonTODomainWrapper(travellingObject.getRequestData(),GBSOnboardReqWrapper.class);
        }
        catch(Exception e)
        {
            log.printErrorMessage(e);
            errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_TECHNICAL, BaseConstants.VALIDATION_ERROR,"Invalid Request Format for Prospect Service"));
            ProcessException gbxEx = new ProcessException();
            gbxEx.addAll(errorObjectList);
            throw gbxEx;
        }
        finally
        {
            // N.A
        }
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public void validateData(TravellingObject travellingObject,NodeServicesEntity srvEntity,Object requestPayload) throws ProcessException 
    {
        List<ErrorObject> errorObjectList = new ArrayList<ErrorObject>();
        LoggerUtil log                    = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateData", LogType.APPLICATION.name());

        try 
        {
            log.println("Request Payload \n "+requestPayload);
            GBSOnboardReqWrapper requestWrapper = (GBSOnboardReqWrapper) requestPayload;
            ObjectMapper mapper = new ObjectMapper();

            log.println("Response Payload \n "+mapper.writeValueAsString(requestWrapper));

            if(requestWrapper == null)
            {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_TECHNICAL, ICMConstants.INVALID_JSON_FORMAT,"INVALID REQUEST"));
            } else if( (requestWrapper.getGbs_Onboard_ApplnWrapper() == null || !StringUtility.containsData(requestWrapper.getGbs_Onboard_ApplnWrapper().getApplicationReferenceNumber()))) {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, ICMConstants.INVALID_APPLICATION_REFERENCE_NUMBER,"INVALID APPLICATION REFERENCE NUMBER"));
            } else {
                travellingObject.setApplicationReferenceNumber(requestWrapper.getGbs_Onboard_ApplnWrapper().getApplicationReferenceNumber());
            }

            if(requestWrapper != null && requestWrapper.getGbs_Onboard_ApplnWrapper() == null) {

                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, ICMConstants.INVALID_JSON_FORMAT,"BASIC INFORMATION ('application') TAG IS NULL"));
            }
            if(requestWrapper != null && requestWrapper.getGbs_Onboard_CustomerWrapper() == null) {

                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, ICMConstants.INVALID_JSON_FORMAT,"BASIC INFORMATION ('customers') TAG IS NULL"));
            }



            if(errorObjectList.size()> 0) {
                ProcessException gbxEx = new ProcessException();
                gbxEx.addAll(errorObjectList);
                throw gbxEx;
            }
        } 
        catch (ProcessException e)
        {
            log.println(" Error ["+e.getAllErrors()+"]");
            throw e;
        }
        catch (Exception e)
        {
            log.printErrorMessage(e);
            errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, BaseConstants.VALIDATION_ERROR,"INTERNAL ERROR"));
            ProcessException gbxEx = new ProcessException();
            gbxEx.addAll(errorObjectList);
            throw gbxEx; 
        }
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    public void setDocumentsList(List<GBSOnboardDocumentsWrapper> listDocumentsWrapper,ICMCustomerCreateCustomer obCustomer, String profileId) 
    {
        List<ICMCustomerCreateDocuments> documentsList = new ArrayList<ICMCustomerCreateDocuments>();
        for (GBSOnboardDocumentsWrapper objForDoc : listDocumentsWrapper) 
        {
            ICMCustomerCreateDocuments document = new ICMCustomerCreateDocuments();
            document.setDocumentType(getRequestPayloadData(objForDoc.getDocumentType()));
            document.setDocumentCode(getRequestPayloadData(objForDoc.getDocumentCode()));
            if(getRequestPayloadData(profileId) == null) {
                document.setDocumentNumber(getRequestPayloadData(objForDoc.getDocumentNumber()));
            }
            document.setSeqNo(objForDoc.getSequenceNumber());
            document.setDocumentReceiveDt(getRequestPayloadDate(objForDoc.getDocumentReceiveDate()));
            document.setDocumentSignatoryDt(getRequestPayloadDate(objForDoc.getDocumentSignatoryDate()));
            document.setDocumentExpDt(getRequestPayloadDate(objForDoc.getDocumentExpiryDate()));
            document.setTaxResidenceCountry(getRequestPayloadData(objForDoc.getTaxResidenceCountry()));
            document.setW8nSupportDocumentIndicator(getRequestPayloadData(objForDoc.getW8nSupportDocumentIndicator()));
            document.setCountryTreaty(getRequestPayloadData(objForDoc.getCountryTreaty()));
            document.setDocumentEvidenceLink(getRequestPayloadData(objForDoc.getDocumentEvidenceLink()));
            document.setDocRemarks(getRequestPayloadData(objForDoc.getDocRemarks()));
            document.setDocReasonCode(getRequestPayloadData(objForDoc.getDocReasonCode()));	
            document.setExpiryCheckOverride(getRequestPayloadData(objForDoc.getExpiryCheckOverride()));
            document.setPoiDocument(getRequestPayloadData(objForDoc.getPoiDocument()));
            document.setDocumentDueDt(null);
            document.setCompanyId(null);
            document.setCreatedAt(null);
            document.setGuid(null);
            document.setProfileId(getRequestPayloadData(profileId));
            document.setSenderBranch(null);
            document.setSenderId(null);
            document.setStatus(null);
            document.setStatusAt(null);
            document.setUpdatedAt(null);

            documentsList.add(document);
        }
        if(documentsList != null && documentsList.size() >0) {
            obCustomer.setDocuments(documentsList);
        }
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    public void setEmployment(GBSOnboardEmploymentsMandatoryWrapper objEmploymentOnboard,ICMCustomerCreateCustomer obCustomer, String profileId, NodeServicesEntity srvEntity)
    {
        ICMCustomerCreateEmployments employment = new ICMCustomerCreateEmployments();
        employment.setWorkType(getRequestPayloadData(objEmploymentOnboard.getWorkType()));
        employment.setProfessionCode(getRequestPayloadData(objEmploymentOnboard.getProfessionCode()));
        employment.setEmployerCode(getRequestPayloadData(objEmploymentOnboard.getEmployerCode()));
        employment.setEmployerName(getRequestPayloadData(objEmploymentOnboard.getEmployerName()));
        employment.setStaffCategoryCode(getRequestPayloadData(objEmploymentOnboard.getStaffCategoryCode()));
        employment.setBankPricingCategoryCode(getRequestPayloadData(objEmploymentOnboard.getBankPricingCategoryCode()));
        employment.setOwnOrganisationName(getRequestPayloadData(objEmploymentOnboard.getOwnOrganisationName()));
        employment.setEmpBankingInd(getRequestPayloadData(objEmploymentOnboard.getEmpBankingInd()));
        employment.setStaffEmpId(getRequestPayloadData(objEmploymentOnboard.getStaffEmpId()));
        employment.setSalaryMode(getRequestPayloadData(objEmploymentOnboard.getSalaryMode()));
        employment.setDeclaredIncome(objEmploymentOnboard.getDeclaredIncome());
        employment.setUnSecuredIncome(objEmploymentOnboard.getAnnualDerivedIncome());
        employment.setDocumentedIncome((objEmploymentOnboard.getAnnualDocumentedIncome()));
        employment.setProxyIncome((objEmploymentOnboard.getProxyIncome()));
        employment.setDeclaredIncomeCurr(getRequestPayloadData(objEmploymentOnboard.getDeclaredIncomeCurrency()));
        employment.setUnSecuredIncomeCurr(getRequestPayloadData(objEmploymentOnboard.getDerivedIncomeCurrency()));
        employment.setDocumentedIncomeCurrency(getRequestPayloadData(objEmploymentOnboard.getDocumentedIncomeCurrency()));
        employment.setProxyIncomeCurr(getRequestPayloadData(objEmploymentOnboard.getProxyIncomeCurrency()));
        employment.setIsicCode(getRequestPayloadData(objEmploymentOnboard.getIsicCode()));
        employment.setAssetUnderManagement((objEmploymentOnboard.getAssetUnderManagement()));
        employment.setAssetUnderManagementCurrency(getRequestPayloadData(objEmploymentOnboard.getAssetUnderManagementCurrency()));
        employment.setUnSecuredIncomeLastUpdatedDate(getRequestPayloadDate(objEmploymentOnboard.getDerivedIncomeLastUpdatedDate()));
        employment.setDocumentedIncomeLastUpdatedDate(getRequestPayloadDate(objEmploymentOnboard.getDocumentedIncomeLastUpdatedDate()));
		employment.setOccupationCode(getRequestPayloadData(objEmploymentOnboard.getCustomerOccupation()));
		 if(getRequestPayloadData(objEmploymentOnboard.getWorkType()) != null) {
	        	if(getRequestPayloadData(objEmploymentOnboard.getCustomerOccupation()) == null) {
	        	String occupationCode = ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),"OCCUPATION",objEmploymentOnboard.getWorkType());
	        	employment.setOccupationCode(occupationCode);
	        	}        	
	        }
			
        employment.setSenderId(null);
        employment.setSenderBranch(null);
        employment.setCreatedAt(null);
        employment.setErrordetails(null);
        employment.setGuid(null);
        employment.setProfileId(getRequestPayloadData(profileId));
        employment.setStatus(null);
        employment.setStatusAt(null);
        employment.setUpdatedAt(null);
        obCustomer.setEmployments(employment);

    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    public void setAliases(GBSOnboardCustomerWrapper custWraper,ICMCustomerCreateCustomer obCustomer,NodeServicesEntity srvEntity, String profileId) 
    {
        boolean hasDefaultAliasType = false;
        List<GBSOnboardAliasesWrapper> listAliases = custWraper.getObjOnboard_AliasesWrapper();
        List<ICMCustomerCreateAlias> aliasesList = new ArrayList<ICMCustomerCreateAlias>();
        String aliasType = ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),"DEFAULTS","ALIAS_TYPE");


        if(listAliases!= null) {
            for (GBSOnboardAliasesWrapper objForAliases : listAliases) 
            {	        	
                if(getRequestPayloadData(objForAliases.getAliasType()) != null || getRequestPayloadData(objForAliases.getAliasName()) != null) 
                {
                    if(getRequestPayloadData(objForAliases.getAliasType())==aliasType) {
                        hasDefaultAliasType = true;
                    }
                    ICMCustomerCreateAlias aliases = new ICMCustomerCreateAlias();
                    aliases.setAliasType(getRequestPayloadData(objForAliases.getAliasType()));
                    aliases.setAliasName(getRequestPayloadData(objForAliases.getAliasName()));
                    aliases.setSeqNo(objForAliases.getSequenceNumber());
                    aliases.setProfileId(getRequestPayloadData(profileId));
                    aliasesList.add(aliases);

                }

            }

        }

        if(!hasDefaultAliasType && StringUtility.containsData(aliasType)) 
        {

            ICMCustomerCreateAlias aliases = new ICMCustomerCreateAlias();
            aliases.setAliasType(aliasType);
            aliases.setAliasName(custWraper.getFullName());
            aliases.setProfileId(getRequestPayloadData(profileId));
            aliases.setSeqNo((short)1);
            aliasesList.add(aliases);
        }


        if(aliasesList != null && aliasesList.size() >0) {
            obCustomer.setAliases(aliasesList);
        }

    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    private void setPreferences(GBSOnboardPreferencesWrapper objOnboard_PreferencesWrapper,ICMCustomerCreateCustomer obCustomer, String profileId) 
    {		
        ICMCustomerCreatePreference preferences = new ICMCustomerCreatePreference();
        preferences.setProfileId(getRequestPayloadData(profileId));
        preferences.setPrefLangForComm(getRequestPayloadData(objOnboard_PreferencesWrapper.getPrefLangForComm()));
        preferences.setPrefStmtLang(getRequestPayloadData(objOnboard_PreferencesWrapper.getPreferredStatementLanguage()));
        preferences.setPreferredATMLanguage(getRequestPayloadData(objOnboard_PreferencesWrapper.getPreferredAtmLanguage()));
        preferences.setPreferredPhoneLanguage(getRequestPayloadData(objOnboard_PreferencesWrapper.getPreferredPhoneLanguage()));
        preferences.setIbankingRegistered(getRequestPayloadData(objOnboard_PreferencesWrapper.getIbankingRegistered()));
        preferences.setPhoneBankingRegistered(getRequestPayloadData(objOnboard_PreferencesWrapper.getPhoneBankingRegistered()));
        preferences.setSmsBankingRegistered(getRequestPayloadData(objOnboard_PreferencesWrapper.getSmsBankingRegistered()));
        obCustomer.setPreferences(preferences);
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    private void setContacts(List<GBSOnboardContactsWrapper> listContacts,ICMCustomerCreateCustomer obCustomer, String profileId) 
    {
        List<ICMCustomerCreateContacts> contactList = new ArrayList<ICMCustomerCreateContacts>();
        short seqNo = 1;
        for (GBSOnboardContactsWrapper objForContacts : listContacts) 
        {
            ICMCustomerCreateContacts contact = new ICMCustomerCreateContacts();
            if(getRequestPayloadData(profileId) == null) {
                if(getRequestPayloadData(objForContacts.getContactClassificationCode()) != null && objForContacts.getContactClassificationCode().equalsIgnoreCase("E")) {
                    contact.setReference(getRequestPayloadData(objForContacts.getContact()));	 
                }else if(getRequestPayloadData(objForContacts.getContactClassificationCode()) != null) {
                    contact.setContact(getRequestPayloadData(objForContacts.getContact()));
                }
            }

            contact.setProfileId(getRequestPayloadData(profileId));
            contact.setSeqNo((short) seqNo);
            contact.setContactClassificationCode(getRequestPayloadData(objForContacts.getContactClassificationCode()));
            contact.setContactTypeCode(getRequestPayloadData(objForContacts.getContactTypeCode()));
            contact.setCountryCode(getRequestPayloadData(objForContacts.getCountryCode()));
            contact.setAreaCode(getRequestPayloadData(objForContacts.getAreaCode()));
            contact.setExtensionDet(getRequestPayloadData(objForContacts.getExtensionDetail()));
            contact.setPreferredContact(getRequestPayloadData(objForContacts.getPreferredContact()));
            contact.setPrimaryContact(getRequestPayloadData(objForContacts.getPrimaryContact()));
            contact.setDndRegistry(getRequestPayloadData(objForContacts.getDoNotDisturbRegistry()));
            contact.setDndExpiryDt(getRequestPayloadDate(objForContacts.getDoNotDisturbExpiryDate()));
            contact.setAttentionParty(getRequestPayloadData(objForContacts.getAttentionParty()));
            contact.setIsdCountryCode(getRequestPayloadData(objForContacts.getIsdContactCountryCode()));
            contactList.add(contact);
            seqNo++;
        }
        if(contactList != null && contactList.size() >0) {
            obCustomer.setContacts(contactList);
        }

    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    private void setKYC(GBSOnboardKYCWrapper objOnboard_KYCWrapper, ICMCustomerCreateCustomer obCustomer, GBSOnboardCustomerWrapper obj_Onboard_CustomerWrapper, NodeServicesEntity srvEntity, String profileId, TravellingObject travellingObject) 
    {
        ICMCustomerCreateKYC obKYC = new ICMCustomerCreateKYC();
        obKYC.setBirthCountry(getRequestPayloadData(obj_Onboard_CustomerWrapper.getBirthCountry()));
        obKYC.setQualificationCode(getRequestPayloadData(objOnboard_KYCWrapper.getQualificationCode()));
        obKYC.setProfileId(getRequestPayloadData(profileId));
        if(!StringUtility.containsData(obKYC.getQualificationCode())) {
            obKYC.setQualificationCode(ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),"DEFAULTS","QUALIFICATION_CODE"));          

        }
        obKYC.setMaritalStatus((getRequestPayloadData(objOnboard_KYCWrapper.getMaritalStatus()) == null ? "" : objOnboard_KYCWrapper.getMaritalStatus()));
        obKYC.setNoOfDependent(objOnboard_KYCWrapper.getNoOfDependent());
        obKYC.setPlaceOfBirth(getRequestPayloadData(objOnboard_KYCWrapper.getPlaceOfBirth()));
        obKYC.setAiStatus(getRequestPayloadData(objOnboard_KYCWrapper.getAiStatus()));
        obKYC.setAiExpiryDate(getRequestPayloadDate(objOnboard_KYCWrapper.getAiExpiryDate()));
        obKYC.setAiOptIn(getRequestPayloadData(objOnboard_KYCWrapper.getAiOptIn()));
        obKYC.setMotherMaidenName(getRequestPayloadData(objOnboard_KYCWrapper.getMotherMaidenName()));
        
        if(objOnboard_KYCWrapper.getNationality() != null) {
        	List<ICMCustomerKYCNationality> listNationality = new ArrayList<ICMCustomerKYCNationality>();
        	int rowCount = 0;
        	for(GBSOnboardCustomerNationaliltyWrapper nationality : objOnboard_KYCWrapper.getNationality()) {
        		if(rowCount == 0) {
        			obCustomer.setCustomerNationalityCode(getRequestPayloadData(getNationalty(obj_Onboard_CustomerWrapper)));
        		}else {
        		if(nationality.getNationalityCode() != null && !nationality.getNationalityCode().trim().equalsIgnoreCase("")) {
        			if(nationality.getNationalityCode().trim().length() == 2) {
        				
        				listNationality.add(new ICMCustomerKYCNationality(countryCodeRepository.getNationality(nationality.getNationalityCode()), travellingObject.getCountryCode()));
        			}else {
        				listNationality.add(new ICMCustomerKYCNationality(nationality.getNationalityCode(), travellingObject.getCountryCode()));
        			}
        		}
        	}
        		rowCount++;
        	}
        	

        	if(listNationality.size()>0) {
        		obKYC.setNationality(listNationality);
        	}
        }
        
        obCustomer.setKyc(obKYC);
        
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    private void setCDD(List<GBSOnboardCDDWrapper> listcdd, ICMCustomerCreateCustomer obCustomer, TravellingObject travellingObject, String profileId) 
    {
        CDDRespCreateInitiateJson obCDDRes = null;
        obCDDRes = getCDDResponse(travellingObject);
        ICMCustomerCreateCDD obCDD = new ICMCustomerCreateCDD();
        for (GBSOnboardCDDWrapper objOnboard_CDDWrapper : listcdd) 
        {
            obCDD.setCddLastReviewDt(getRequestPayloadDate(objOnboard_CDDWrapper.getCddLastReviewDate()));
            obCDD.setCddNextReviewDt(getRequestPayloadDate(objOnboard_CDDWrapper.getCddNextReviewDate()));
            obCDD.setCddReviewStatus(getRequestPayloadData(objOnboard_CDDWrapper.getCddReviewStatus()));
            obCDD.setCddReason(getRequestPayloadData(objOnboard_CDDWrapper.getCddReason()));
            obCDD.setSddEligibleStatus(getRequestPayloadData(objOnboard_CDDWrapper.getSddEligibleStatus()));
            obCDD.setSddEligibleDate(getRequestPayloadDate(objOnboard_CDDWrapper.getSddEligibleDate()));
            obCDD.setCompanyId(null);

            if(obCDDRes != null && obCDDRes.getApplicant_reference_key() != null) 
            {
                obCDD.setIcddReferenceNumber(getRequestPayloadData(obCDDRes.getApplicant_reference_key()));
            }

            if(obCDDRes != null && obCDDRes.getRisk_rating() != null) 
            {
                obCDD.setCddRiskCode(getRequestPayloadData(obCDDRes.getRisk_rating()));
            }

            obCDD.setCupidReferenceNumber(null);
            obCDD.setCddRiskRatingDate(null);
            obCDD.setCountryLRD(getRequestPayloadDate(objOnboard_CDDWrapper.getCountryLastReviewDate()));
            obCDD.setCountryNRD(null);
            obCDD.setCountryReviewStatus(getRequestPayloadData(objOnboard_CDDWrapper.getCountryReviewStatus()));
            obCDD.setCddReviewedFlag(null);
            obCDD.setCddLastReviewedBy(null);
            obCDD.setSenderId(travellingObject.getInterfaceId());
            obCDD.setSenderBranch(null);
            obCDD.setCreatedAt(null);
            obCDD.setErrordetails(null);
            obCDD.setGuid(null);
            obCDD.setProfileId(getRequestPayloadData(profileId));
            obCDD.setStatus(null);
            obCDD.setStatusAt(null);
            obCDD.setUpdatedAt(null);
            obCustomer.setCdd(obCDD);
        }
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    private void setTar(GBSOnboardTarsCondnMandatoryWrapper objOnboard_Tars,ICMCustomerCreateCustomer obCustomer, String profileId) 
    {		 
        ICMCustomerCreateTAR objTars = new ICMCustomerCreateTAR();
        objTars.setUsResident(getRequestPayloadData(objOnboard_Tars.getUsResident()));
        objTars.setUsCitizen(getRequestPayloadData(objOnboard_Tars.getUsCitizen()));
        objTars.setUsGreenCardHolder(getRequestPayloadData(objOnboard_Tars.getUsGreenCardHolder()));
        objTars.setOnBoardWithDis(getRequestPayloadData(objOnboard_Tars.getOnBoardWithDis()));
        objTars.setUsaIndiciaInd(getRequestPayloadData(objOnboard_Tars.getUsaIndiciaInd()));
        objTars.setUsaPersonInd(getRequestPayloadData(objOnboard_Tars.getUsaPersonInd()));
        objTars.setReportToIRSInd(getRequestPayloadData(objOnboard_Tars.getReportToIrsInd()));
        objTars.setJointAcInd(getRequestPayloadData(objOnboard_Tars.getJointAcInd()));
        objTars.setRecalcitrantInd(getRequestPayloadData(objOnboard_Tars.getRecalcitrantInd()));
        objTars.setRecalcitrantIndAssignDt(getRequestPayloadDate(objOnboard_Tars.getRecalcitrantIndAssignDate()));
        objTars.setRecalcitrantIndClearedDt(getRequestPayloadDate(objOnboard_Tars.getRecalcitrantIndAssignDate()));
        objTars.setWithholdInd(getRequestPayloadData(objOnboard_Tars.getWithholdInd()));
        objTars.setEnhancedReviewInd(getRequestPayloadData(objOnboard_Tars.getEnhancedReviewInd()));
        objTars.setEnhancedReviewStartDt(getRequestPayloadDate(objOnboard_Tars.getEnhancedReviewStartDate()));
        objTars.setEnhancedReviewEndDt(getRequestPayloadDate(objOnboard_Tars.getEnhancedReviewEndDate()));
        objTars.setDocumentSubmittedIndicator(getRequestPayloadData(objOnboard_Tars.getDocumentSubmittedIndicator()));
        objTars.setDocumentDueDt(getRequestPayloadDate(objOnboard_Tars.getDocumentDueDate()));
        objTars.setGstResidentStatus(getRequestPayloadData(objOnboard_Tars.getGstResidentStatus()));
        objTars.setTaxResidentStatus(getRequestPayloadData(objOnboard_Tars.getTaxResidentStatus()));
        objTars.setLastChangeDateForUSIndicia(getRequestPayloadDate(objOnboard_Tars.getUsIndiciaDate()));
        objTars.setLastChangeDateForUSPerson(getRequestPayloadDate(objOnboard_Tars.getUsPersonFlagChangedDate()));
        objTars.setSenderId(null);
        objTars.setSenderBranch(null);
        objTars.setCreatedAt(null);
        objTars.setErrordetails(null);
        objTars.setGuid(null);
        objTars.setProfileId(getRequestPayloadData(profileId));
        objTars.setStatus(null);
        objTars.setStatusAt(null);
        objTars.setUpdatedAt(null);
        obCustomer.setTars(objTars);
    }	 

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    private void setAddresses(List<GBSOnboardAddressesWrapper> listAddress,ICMCustomerCreateCustomer obCustomer, String profileId,  NodeServicesEntity srvEntity) 
    {
        String csaAddressType = ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),"CSA","CSA_ADDRESS_TYPE");
        boolean csaAddressTypeAlreadyExist = false;
        if(csaAddressType != null && csaAddressType.equalsIgnoreCase("Y")) {
            for (GBSOnboardAddressesWrapper objAddress : listAddress) 
            {
                if(getRequestPayloadData(objAddress.getAddressType()) != null && getRequestPayloadData(objAddress.getAddressType()).equalsIgnoreCase("CSA")){

                    csaAddressTypeAlreadyExist = true;
                }
            }
        }

        List<ICMCustomerCreateAddress> listAddresses = new ArrayList<ICMCustomerCreateAddress>();
        for (GBSOnboardAddressesWrapper objAddress : listAddress) 
        {
            if(csaAddressType != null && csaAddressType.equalsIgnoreCase("Y")) {

                if(!csaAddressTypeAlreadyExist) {
                    if(objAddress.getIsMailingAddress() != null && objAddress.getIsMailingAddress().equalsIgnoreCase("Y")) {
                        addAddress(objAddress, listAddresses, true, null, profileId);
                        addAddress(objAddress, listAddresses, false, "N", profileId);
                    }else {
                        addAddress(objAddress, listAddresses, false, null, profileId);
                    }

                }else {
                    addAddress(objAddress, listAddresses, false, null, profileId);
                }

            }else {
                addAddress(objAddress, listAddresses, false, null, profileId);
            }


        }
        if(listAddresses != null && listAddresses.size() >0) {
            obCustomer.setAddresses(listAddresses);
        }

    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    private void addAddress(GBSOnboardAddressesWrapper objAddress, List<ICMCustomerCreateAddress> listAddresses, boolean isCSAType, String isMailingAddress, String profileId) {

        ICMCustomerCreateAddress address = new ICMCustomerCreateAddress();
        if(!isCSAType) {
            address.setAddressType(getRequestPayloadData(objAddress.getAddressType()));
        }else {
            address.setAddressType("CSA");
            address.setMailAddrInd("Y");
        }
        address.setProfileId(getRequestPayloadData(profileId));
        address.setAddress1(getRequestPayloadData(objAddress.getAddressLine1()));
        address.setAddress2(getRequestPayloadData(objAddress.getAddressLine2()));
        address.setAddress3(getRequestPayloadData(objAddress.getAddressLine3()));
        address.setCityName(getRequestPayloadData(objAddress.getCityName()));
        address.setState(getRequestPayloadData(objAddress.getState()));
        address.setCountryCode(getRequestPayloadData(objAddress.getCountryCode()));
        address.setPostalCode(getRequestPayloadData(objAddress.getPostalCode()));
        address.setNearestLandMark(getRequestPayloadData(objAddress.getNearestLandMark()));
        address.setIsWAUFlag(null);
        address.setAddrAmendAlertInd(null);
        address.setAlertSuppressReasonCode(null);
        if(null !=isMailingAddress) {
            address.setMailAddrInd(isMailingAddress);
        }else {
            address.setMailAddrInd(getRequestPayloadData(objAddress.getIsMailingAddress()));
        }
        address.setPostBoxNo(getRequestPayloadData(objAddress.getPostBoxNo()));
        address.setPoaDocument(getRequestPayloadData(objAddress.getPoaDocument()));
        address.setConsolidateStatementFlag(null);
        address.setReturnMailCounter((short)0);
        address.setResetRMailFlag(null);
        address.setStateCode(getRequestPayloadData(objAddress.getStateCode()));
        address.setLangID(getRequestPayloadData(objAddress.getLangId()));
        address.setSenderBranch(null);
        address.setSenderId(null);
        address.setAddressClassification(getRequestPayloadData(objAddress.getAddressClassificationCode()));
        listAddresses.add(address);
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    private String getNationalty(GBSOnboardCustomerWrapper requestCustomer)
    {			
        if(requestCustomer != null && requestCustomer.getObjOnboard_KYCWrapper() != null && requestCustomer.getObjOnboard_KYCWrapper().getNationality() != null) 
        {
            if(
                    requestCustomer.getObjOnboard_KYCWrapper().getNationality().get(0) !=null 
                    && requestCustomer.getObjOnboard_KYCWrapper().getNationality().get(0).getNationalityCode()!=null
            )
            {
                if(requestCustomer.getObjOnboard_KYCWrapper().getNationality().get(0).getNationalityCode().length()==2) 
                {
                    return countryCodeRepository.getNationality(requestCustomer.getObjOnboard_KYCWrapper().getNationality().get(0).getNationalityCode());
                } 
                else 
                {
                    return requestCustomer.getObjOnboard_KYCWrapper().getNationality().get(0).getNationalityCode();
                }
            }
        }
        return null;
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    private void setCustomers(GBSOnboardCustomerWrapper requestCustomer, ICMCustomerCreateCustomer obCustomer, String application_reference_number, String countryCode, String profileId) 
    {
        obCustomer.setRevisionNumber(0);
        obCustomer.setSalutationCode(getRequestPayloadData(requestCustomer.getSalutationCode()));
        if(getRequestPayloadData(profileId) == null) {
            if(getRequestPayloadData(obCustomer.getCompanyId()) != null && getRequestPayloadData(obCustomer.getCompanyId()).equalsIgnoreCase("HK")) 
            {
                obCustomer.setFirstName(getRequestPayloadData(requestCustomer.getFirstName()));
                obCustomer.setMiddleName(getRequestPayloadData(requestCustomer.getMiddleName()));
                obCustomer.setLastName(getRequestPayloadData(requestCustomer.getLastName()));
            }        
            obCustomer.setFullName(getRequestPayloadData(requestCustomer.getFullName()));
            obCustomer.setDateOfBirth(getRequestPayloadDate(requestCustomer.getDateOfBirth()));
        }

        obCustomer.setGender(getRequestPayloadData(requestCustomer.getGender()));
        obCustomer.setResidentCountry(getRequestPayloadData(requestCustomer.getResidentCountry()));
        obCustomer.setResidentStatus(getRequestPayloadData(requestCustomer.getSalutationCode()));

        obCustomer.setDedupReferenceNumber(null);
        obCustomer.setDedupReasonCode(null);
        obCustomer.setFullNameOverride(null);
        obCustomer.setLastnameOverride(null);

//        obCustomer.setCustomerNationalityCode(getRequestPayloadData(getNationalty(requestCustomer)));
        if(requestCustomer.getObjBankInternalInfo() != null) {
            obCustomer.setIsBSBDACustomer(getRequestPayloadData(requestCustomer.getObjBankInternalInfo().getBsbdaFlag()));
            obCustomer.setArmCode(getRequestPayloadData(requestCustomer.getObjBankInternalInfo().getArmCode()));
            obCustomer.setSegmentCode(getRequestPayloadData(requestCustomer.getObjBankInternalInfo().getSegmentCode()));
            obCustomer.setSubSegmentCode(getRequestPayloadData(requestCustomer.getObjBankInternalInfo().getSubSegmentCode()));
            obCustomer.setServiceIndicatorCode(getRequestPayloadData(requestCustomer.getObjBankInternalInfo().getServiceIndicatorCode()));
            obCustomer.setAcquisitionChannel(getRequestPayloadData(requestCustomer.getObjBankInternalInfo().getAcquisitionChannel()));
            obCustomer.setProfileType(ICMConstants.PROFILE_CLIENT);
            obCustomer.setHomeBranch(getRequestPayloadData(requestCustomer.getObjBankInternalInfo().getHomeBranch()));
			
            obCustomer.setReferralId(getRequestPayloadData(requestCustomer.getObjBankInternalInfo().getReferralId()) == null ? getRequestPayloadData(requestCustomer.getObjBankInternalInfo().getCaseOwnerPsid()) : getRequestPayloadData(requestCustomer.getObjBankInternalInfo().getReferralId()));
            obCustomer.setSourcingId(getRequestPayloadData(requestCustomer.getObjBankInternalInfo().getSourcingId()) == null ? getRequestPayloadData(requestCustomer.getObjBankInternalInfo().getCaseOwnerPsid()) : getRequestPayloadData(requestCustomer.getObjBankInternalInfo().getSourcingId()));
            obCustomer.setClosingId(getRequestPayloadData(requestCustomer.getObjBankInternalInfo().getClosingId()) == null ? getRequestPayloadData(requestCustomer.getObjBankInternalInfo().getCaseOwnerPsid()) : getRequestPayloadData(requestCustomer.getObjBankInternalInfo().getClosingId()));
        }else {
        	obCustomer.setReferralId(getRequestPayloadData(application_reference_number));
            obCustomer.setSourcingId(getRequestPayloadData(application_reference_number));
            obCustomer.setClosingId(getRequestPayloadData(application_reference_number));
        }

        obCustomer.setSeniorCitizenFlag(null);
        obCustomer.setGroupId(null);
        obCustomer.setGroupName(null);
        obCustomer.setSenderId(null);
        obCustomer.setSenderBranch(null);
        obCustomer.setCreatedAt(null);
        obCustomer.setUpdatedAt(null);
        obCustomer.setStatus(null);
        obCustomer.setStatusAt(null);

        obCustomer.setRelationshipStatus("O");
        obCustomer.setLastStatusChangeDate(null);
        obCustomer.setProfileActivationDate(null);
        obCustomer.setReOpenedInd(null);
        obCustomer.setReOpenCounter((short)0);
        obCustomer.setCloseReasonCode(null);

        

        //obCustomer.setHomeBranch(null);
        obCustomer.setCompanyId(getRequestPayloadData(countryCode));
        obCustomer.setDedupReasonCode(null);
        obCustomer.setDemisedDate(null);
        obCustomer.setGuid(null);
        obCustomer.setRelationshipNo(null);
        obCustomer.setProfileId(null);
        obCustomer.setReferredByRelationshipName(null);
        obCustomer.setReferredByRelationshipNo(null);
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    private CDDRespCreateInitiateJson getCDDResponse(TravellingObject travellingObject) 
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "getCDDResponse", LogType.APPLICATION.name());

        if(travellingObject != null && travellingObject.getServiceStatus() != null) 
        {
            ServiceStatus serviceStatus = travellingObject.getServiceStatus().get(BaseConstants.ONBOARD_CREATECDD_SRV);
            if(serviceStatus != null) 
            {
                CDDRespCreateInitiateJson obCDDRes = (CDDRespCreateInitiateJson) serviceStatus.getResponsePayload();
                if(obCDDRes != null) 
                {
                    log.println("goodToProceedICM =====> "+obCDDRes.getStp_flag());
                    return obCDDRes;
                }
            }
        }
        return null;
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object constructOutboundObject(TravellingObject travellingObject,NodeServicesEntity srvEntity,Object requestPayload) throws ProcessException
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "constructOutboundObject", LogType.APPLICATION.name());

        try
        {
            log.println("[ICMCreateService] [constructOutboundObject] "+requestPayload);

            if(travellingObject.getServiceProcessParameter(BaseConstants.ONBOARD_CREATECDD_SRV, "STP_FLAG").equals("Y"))
            {            	
                GBSOnboardReqWrapper requestWrapper 	=	(GBSOnboardReqWrapper) requestPayload; 
                ICMCustomerCreateCustomer obCustomer 	=	new ICMCustomerCreateCustomer();
                String relNumber 						= 	null;
                String profileId						=	null;

                if(requestWrapper == null ) {
                    throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, ICMConstants.INVALID_REQUEST," INVALID REQUEST PAYLOAD "); 
                }

                GBSOnboardCustomerWrapper customerWrapper = requestWrapper.getGbs_Onboard_CustomerWrapper();

                if(customerWrapper == null ) {
                    throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, ICMConstants.INVALID_REQUEST," INVALID REQUEST PAYLOAD - CUSTOMER DATA MISSING"); 
                }


                if(requestWrapper != null && customerWrapper != null) {
                    if(customerWrapper.getObjBankInternalInfo() != null && customerWrapper.getObjBankInternalInfo().getCoreBankingReferenceKey() != null) {
                        relNumber = getRequestPayloadData(customerWrapper.getObjBankInternalInfo().getCoreBankingReferenceKey());
                    }

                    if(customerWrapper.getObjBankInternalInfo() != null && customerWrapper.getObjBankInternalInfo().getCustomerMasterReferenceKey() != null) {
                        profileId = getRequestPayloadData(customerWrapper.getObjBankInternalInfo().getCustomerMasterReferenceKey());
                    }
                }

                if(customerWrapper.getObjOnboard_AddressesWrapper() != null) {
                    setAddresses(customerWrapper.getObjOnboard_AddressesWrapper(), obCustomer, profileId, srvEntity);
                }

                if(customerWrapper.getObjOnboard_ContactsWrapper() != null) {
                    setContacts(customerWrapper.getObjOnboard_ContactsWrapper(), obCustomer, profileId);
                }

                if(customerWrapper != null && customerWrapper.getObjOnboard_KYCWrapper() != null) {
                    setKYC(customerWrapper.getObjOnboard_KYCWrapper(), obCustomer, customerWrapper,srvEntity, profileId, travellingObject);
                }

                if(customerWrapper.getObjOnboard_CDDWrapper() != null) {
                    setCDD(customerWrapper.getObjOnboard_CDDWrapper(), obCustomer, travellingObject, profileId);
                }

                if(customerWrapper.getObjOnboard_TarsCondnMandatoryWrapper() != null) {
                    setTar(customerWrapper.getObjOnboard_TarsCondnMandatoryWrapper(), obCustomer, profileId);
                }

                if(customerWrapper.getObjOnboard_EmploymentsMandatoryWrapper() != null) {
                    setEmployment(customerWrapper.getObjOnboard_EmploymentsMandatoryWrapper(), obCustomer, profileId, srvEntity); 
                }

                if(customerWrapper.getObjOnboard_DocumentsWrapper() != null && customerWrapper.getObjOnboard_DocumentsWrapper().size() >0) {
                    setDocumentsList(customerWrapper.getObjOnboard_DocumentsWrapper(), obCustomer, profileId);
                }

                if(customerWrapper.getObjOnboard_AliasesWrapper() != null) {
                    setAliases(customerWrapper, obCustomer,srvEntity, profileId); 
                }

                if(customerWrapper.getObjOnboard_PreferencesWrapper() != null) {
                    setPreferences(customerWrapper.getObjOnboard_PreferencesWrapper(), obCustomer, profileId); 
                }

                setPdpa(customerWrapper.getObjOnboard_PdpaWrapper(),obCustomer,srvEntity);

                setCustomers(customerWrapper, obCustomer, 
                        requestWrapper.getGbs_Onboard_ApplnWrapper().getApplicationReferenceNumber(), travellingObject.getCountryCode(), profileId);

                obCustomer.setProfileId(getRequestPayloadData(profileId));
                obCustomer.setRelationshipNo(getRequestPayloadData(relNumber));

                setRisks(customerWrapper, obCustomer,srvEntity, profileId,travellingObject); 
                setAuxiliary(requestWrapper, obCustomer,srvEntity, profileId,travellingObject);  

                ICMCustomerCreateRequestAttributes obAttribute = new ICMCustomerCreateRequestAttributes();
                obAttribute.setCustomers(obCustomer);

                ICMCustomerCreateRequestData obCreate = new ICMCustomerCreateRequestData();
                if(getRequestPayloadData(profileId) != null) {
                    obCreate.setType("update-profile");

                }else {
                    obCreate.setType("customercreate");
                }
                obCreate.setAttributes(obAttribute);

                ICMCustomerCreateRequestWrapper obReq = new ICMCustomerCreateRequestWrapper();
                obReq.setData(obCreate);

                return obReq;
            }
            else 
            {
                return null;
            }
        }
        catch (Exception e)
        {
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, BaseConstants.VALIDATION_ERROR," INTERNAL ERROR WHILE PAYLOAD CONSTRUCTION ");
        }
        finally
        {
            //N.A
        }
    }


    /**
     * Method Defined is to Attach Default Risks During Profile Creation. 
     * Initial Release ADO-4715706
     *  
     *  
     * @param  
     * @return
     * @throws ProcessException 
     * @exception
     * @see
     * @since
     */
    private void setRisks(GBSOnboardCustomerWrapper requestWrapper, ICMCustomerCreateCustomer icmWrapper,NodeServicesEntity srvEntity, String profileId,TravellingObject trObj) throws ProcessException
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "setRisks", LogType.APPLICATION.name());

        try
        {
            String defaultAcqChannel = ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),"RISK"+trObj.getRegion(),"RISK_ACQUIISITION_CHANNEL_ID");
            String riskForAcqChannel = ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),"RISK"+trObj.getRegion(),"RISK_CODE_FOR_ACQUIISITION_CHANNEL");

            if(requestWrapper.getObjBankInternalInfo()!=null && 
                    StringUtility.containsData(requestWrapper.getObjBankInternalInfo().getAcquisitionChannel()) && 
                    StringUtility.containsData(defaultAcqChannel) &&
                    requestWrapper.getObjBankInternalInfo().getAcquisitionChannel().equalsIgnoreCase(defaultAcqChannel) &&
                    StringUtility.containsData(riskForAcqChannel)
                    )
            {
                ICMCustomerCreateRisksDetails riskDetailObj = new ICMCustomerCreateRisksDetails();
                riskDetailObj.setRiskCode(riskForAcqChannel);
                riskDetailObj.setProfileId(getRequestPayloadData(profileId));
                riskDetailObj.setRiskStartDate(
                        DateTimeUtility.formatDateToString(
                                DateTimeUtility.getDateByCountryCode(srvEntity.getId().getCountryCode()),"yyyy-MM-dd")
                        );

                ICMCustomerCreateRisks riskObj = new ICMCustomerCreateRisks();
                riskObj.addRisks(riskDetailObj);
                icmWrapper.setRisks(riskObj);
            }
        }
        catch(Exception e)
        {
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, ICMConstants.ICM_REQUEST_RISK_CONSTRUCTION_ERROR," PAYLOAD ERROR [RISK]");
        }
    }

    /**
     * Method Defined is to Attach Default Auxiliary During Profile Creation. 
     * Initial Release ADO-4715706
     * 
     *  
     * @param  
     * @return
     * @throws ProcessException 
     * @exception
     * @see
     * @since
     */
    private void setAuxiliary(GBSOnboardReqWrapper requestWrapper, ICMCustomerCreateCustomer icmWrapper,NodeServicesEntity srvEntity, String profileId,TravellingObject trObj) throws ProcessException
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "setAuxiliary", LogType.APPLICATION.name());

        try
        {


            String defaultAcqChannel = ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),"AUXILIARY"+trObj.getRegion(),"RISK_ACQUIISITION_CHANNEL_ID");
            String auxCodeForAcqChannel = ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),"AUXILIARY"+trObj.getRegion(),"AUXILIARY_CODE_FOR_ACQUIISITION_CHANNEL");
            String auxValueForAcqChannel = ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),"AUXILIARY"+trObj.getRegion(),"AUXILIARY_VALUE_FOR_ACQUIISITION_CHANNEL");

            if(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjBankInternalInfo()!=null && 
                    StringUtility.containsData(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjBankInternalInfo().getAcquisitionChannel()) && 
                    StringUtility.containsData(defaultAcqChannel) &&
                    requestWrapper.getGbs_Onboard_CustomerWrapper().getObjBankInternalInfo().getAcquisitionChannel().equalsIgnoreCase(defaultAcqChannel) &&
                    StringUtility.containsData(auxCodeForAcqChannel)
                    )
            {
                ICMCustomerCreateAuxiliary auxDetailObj = new ICMCustomerCreateAuxiliary();
                auxDetailObj.setAuxiliaryCode(auxCodeForAcqChannel);
                auxDetailObj.setAuxiliaryValue(auxValueForAcqChannel);
                auxDetailObj.setProfileId(getRequestPayloadData(profileId));
                icmWrapper.addAuxiliary(auxDetailObj);
            }

            // ADDING APPLICATION REFERENCE NUMBER TO AUXILIARY DATA
            String auxCodeForApplicationReference = ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),"AUXILIARY"+trObj.getRegion(),"AUXILIARY_CODE_FOR_APPLICATION_REF_NUMBER");
            if(StringUtility.containsData(auxCodeForApplicationReference))
            {
                ICMCustomerCreateAuxiliary auxDetailObj = new ICMCustomerCreateAuxiliary();
                auxDetailObj.setAuxiliaryCode(auxCodeForApplicationReference);
                auxDetailObj.setAuxiliaryValue(requestWrapper.getGbs_Onboard_ApplnWrapper().getApplicationReferenceNumber());
                auxDetailObj.setProfileId(getRequestPayloadData(profileId));
                icmWrapper.addAuxiliary(auxDetailObj);
            }
        }
        catch(Exception e)
        {
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, ICMConstants.ICM_REQUEST_AUXILIARY_CONSTRUCTION_ERROR," PAYLOAD ERROR [AUX]");
        }
    }    

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    private Date getRequestPayloadDate(Date reqPayloadDate) 
    {	
        if(reqPayloadDate != null) {
            return reqPayloadDate;
        }
        return null;
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    private String getRequestPayloadData(String reqPayloadData) 
    {
        if(reqPayloadData != null && !reqPayloadData.trim().equalsIgnoreCase("")) {
            return reqPayloadData;
        }
        return null;
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object process(TravellingObject travellingObject,NodeServicesEntity srvEntity,ServiceStatus serviceStatus,Object outBoundRequestObject) throws ProcessException
    {
        ICMCustomerCreateResponseWrapper resObj = null;
        GBSOnboardResponseWrapper resOnboard = null;
        ObjectMapper mapper = null;
        ContactServerInfo contactServerInfo = null;
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "process", LogType.APPLICATION.name());


        try
        {
            if(travellingObject.getServiceProcessParameter(BaseConstants.ONBOARD_CREATECDD_SRV, "STP_FLAG") != null &&
                    travellingObject.getServiceProcessParameter(BaseConstants.ONBOARD_CREATECDD_SRV, "STP_FLAG").equals("Y")){

                serviceStatus.setInterfaceId("ICM");
                ICMCustomerCreateRequestWrapper outBoundData = (ICMCustomerCreateRequestWrapper) outBoundRequestObject;         
                log.println("Out Bound Data -- : "+ outBoundData);
                String jsonString = (String)JSONUtility.domainWrapperToJSON(outBoundData, ICMCustomerCreateRequestWrapper.class);
                log.println("Request Orchrestrated from Globus to ICM : "+ jsonString);
                
                log.println("Create URL Construction For Country Code -"+travellingObject.getCountryCode()+"/ Interface ID -"+ICM_CREATE_INTERFACE_ID+"/ Service ID -"+ICM_CREATE_SERVICE_ID+" / OB / ");

                String hostServiceURL =null;

                if(getRequestPayloadData(outBoundData.getData().getAttributes().getCustomers().getProfileId()) != null) {
                    hostServiceURL = interfaceRequestTypeRepository.getInterfaceURL(travellingObject.getServiceContext().getCountryCodeWithRegion(),ICM_CREATE_INTERFACE_ID,ICM_UPDATE_SERVICE_ID,"OB", BaseConstants.CODE_SETUP_ACTIVE);
                }else {
                    hostServiceURL = interfaceRequestTypeRepository.getInterfaceURL(travellingObject.getServiceContext().getCountryCodeWithRegion(),ICM_CREATE_INTERFACE_ID,ICM_CREATE_SERVICE_ID,"OB", BaseConstants.CODE_SETUP_ACTIVE);
                }

                
                log.println("Sending Request to ICM ["+hostServiceURL+"] / Region ["+travellingObject.getServiceContext().getRequestHeaderValue(BaseConstants.REQUEST_REGION)+"]");

                String scope = BaseConstants.ICM_SCOPE;
                String protocolMethod = BaseConstants.POST_PROTOCOL;

                contactServerInfo = new ContactServerInfo(travellingObject.getCountryCode(),hostServiceURL, scope, travellingObject.getTransactionID(), travellingObject.getInterfaceId(), jsonString, protocolMethod, srvEntity);

                contactServerInfo = applicationConfiguration.contactServer(contactServerInfo,travellingObject);

                try 
                {
                    resObj = (ICMCustomerCreateResponseWrapper) JSONUtility.jsonTODomainWrapper(contactServerInfo.getResponseMessage(), ICMCustomerCreateResponseWrapper.class);
                }
                catch (Exception e) 
                {
                    log.printErrorMessage(e);
                }

                if(resObj != null) {
                    resOnboard = new GBSOnboardResponseWrapper();

                    setResponseValues(resObj, resOnboard, serviceStatus, travellingObject, contactServerInfo.getResponseMessage(), srvEntity);

                } else {
                    System.out.println("Response Data is "+resObj);
                }
            }
            else 
            {
                if(travellingObject != null && travellingObject.getServiceStatus() != null && travellingObject.getServiceStatus().get(BaseConstants.ONBOARD_CREATECDD_SRV) != null 
                        && travellingObject.getServiceStatus().get(BaseConstants.ONBOARD_CREATECDD_SRV).getResponsePayload() != null) {
                    return travellingObject.getServiceStatus().get(BaseConstants.ONBOARD_CREATECDD_SRV).getResponsePayload();
                }

                log.println("Since stp-flag is N in CDD, we can not proceed to ICM Create");
            }

            if(contactServerInfo!=null) 
            {
                serviceStatus.setHttpStatus(contactServerInfo.getHttpResponseCode());
            }
            
            if(contactServerInfo!=null && contactServerInfo.getHttpResponseCode()!=null && contactServerInfo.getHttpResponseCode().charAt(0)!='2') 
            {
                if(contactServerInfo.getHttpResponseCode().charAt(0) == BaseConstants.HTTP_4XX_SERIES) 
                {
                    throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,ICMConstants.CLM_REQUEST_ERROR,"CLM RETURNED TECHNICAL ERROR");
                }
                else if(contactServerInfo.getHttpResponseCode().charAt(0) == BaseConstants.HTTP_5XX_SERIES)
                {
                    throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,ICMConstants.CLM_REQUEST_ERROR,"CLM CONNECTIVITY ERROR - RETRY");
                }
                else
                {
                    throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,ICMConstants.CLM_REQUEST_ERROR,"CLM CONNECTIVITY ERROR");
                }
            } 
            else {
                //N.A
            }
        }
        catch (HttpStatusCodeException ex) 
        { 
            log.println("Raw Code ["+ex.getRawStatusCode()+"] Status Code ["+ex.getStatusCode().toString()+"]");
            serviceStatus.setHttpStatus(ex.getRawStatusCode()+"");
            log.println(ex.getResponseBodyAsString());

            try
            {
                mapper = new ObjectMapper();
                mapper.setSerializationInclusion(Include.NON_NULL);
                log.println(ex.getResponseHeaders()+"\n ex.getResponseBodyAsString() =========> "+ex.getResponseBodyAsString());
                resObj = mapper.readValue(ex.getResponseBodyAsString(), ICMCustomerCreateResponseWrapper.class);
                if(resObj != null) {
                    resOnboard = new GBSOnboardResponseWrapper();
                    setResponseValues(resObj, resOnboard, serviceStatus, travellingObject, null, srvEntity);
                }
                travellingObject.setResponseData(resObj);
            } 
            catch (Exception e) 
            {
                log.printErrorMessage(e);
            }  

        }
        catch(ProcessException e)
        {
            throw e;
        }
        catch(Exception e)
        {
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, ICMConstants.ICM_REQUEST_ERROR,"ICM - PROCESSING ERROR");
        }

        return resOnboard;
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    private void addCDDReasonCodes(CDDRespCreateInitiateJson resCDDObj, List<GBSOnboardResponseOnboardingStatusReason> cddStatusReasonlist, NodeServicesEntity srvEntity) 
    {
        if(resCDDObj.getRisk_rating() != null) 
        {
            if(resCDDObj.getRisk_rating().equalsIgnoreCase("P")) 
            {
                cddStatusReasonlist.add(new GBSOnboardResponseOnboardingStatusReason(CDD_REASON_PRO, ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),"CDD",CDD_REASON_PRO)));
            }
            if(resCDDObj.getStp_flag() != null && resCDDObj.getStp_flag().equalsIgnoreCase("N")) 
            {
                if(resCDDObj.getRisk_rating().equalsIgnoreCase("A") || resCDDObj.getRisk_rating().equalsIgnoreCase("B")) 
                {
                    cddStatusReasonlist.add(new GBSOnboardResponseOnboardingStatusReason(CDD_REASON_NSP, ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),"CDD",CDD_REASON_NSP)));
                }
            }

            if(resCDDObj.getRisk_rating().equalsIgnoreCase("C") || resCDDObj.getRisk_rating().equalsIgnoreCase("D") || 
                    resCDDObj.getRisk_rating().equalsIgnoreCase("E") || resCDDObj.getRisk_rating().equalsIgnoreCase("P")) 
            {
                cddStatusReasonlist.add(new GBSOnboardResponseOnboardingStatusReason(CDD_REASON_HRC, ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),"CDD",CDD_REASON_HRC)));
            }
        }

        if(resCDDObj.getName_screening_hit() != null && resCDDObj.getName_screening_hit().trim().equalsIgnoreCase("Y")) {
            cddStatusReasonlist.add(new GBSOnboardResponseOnboardingStatusReason(CDD_REASON_NSH, ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),"CDD",CDD_REASON_NSH)));
        }
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    private void doUpdateRelidProfileid(TravellingObject travellingObject, GBSOnboardResponseWrapper resOnboardObj) {    	

        if(travellingObject != null) 
        {    		
            JSONUtility.jsonTODomainWrapper(travellingObject.getRequestData(),GBSOnboardReqWrapper.class);

            GBSOnboardReqWrapper requestWrapper = (GBSOnboardReqWrapper) JSONUtility.jsonTODomainWrapper(travellingObject.getRequestData(),GBSOnboardReqWrapper.class);   

            if(requestWrapper != null && requestWrapper.getGbs_Onboard_CustomerWrapper() != null) 
            {
                if(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjBankInternalInfo() != null && requestWrapper.getGbs_Onboard_CustomerWrapper().getObjBankInternalInfo().getCoreBankingReferenceKey() != null) 
                {
                    resOnboardObj.setCoreBankingReferenceKey(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjBankInternalInfo().getCoreBankingReferenceKey());
                }

                if(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjBankInternalInfo() != null && requestWrapper.getGbs_Onboard_CustomerWrapper().getObjBankInternalInfo().getCustomerMasterReferenceKey() != null) 
                {
                    resOnboardObj.setCustomerMasterReferenceKey(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjBankInternalInfo().getCustomerMasterReferenceKey());
                }
            }

        }
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    private void setResponseValues(ICMCustomerCreateResponseWrapper resICMObj, GBSOnboardResponseWrapper resOnboardObj, ServiceStatus serviceStatus, TravellingObject travellingObject, String icmCustomerCreateResponse, NodeServicesEntity srvEntity) 
    {
        ServiceStatus serviceStatusCDD = travellingObject.getServiceStatus().get(BaseConstants.ONBOARD_CREATECDD_SRV);

        if(serviceStatusCDD != null && serviceStatusCDD.getResponsePayload() != null) 
        {
            CDDRespCreateInitiateJson cddResponse = (CDDRespCreateInitiateJson) serviceStatusCDD.getResponsePayload();
            if(cddResponse != null) 
            {
                List<GBSOnboardResponseOnboardingStatusReason> cddStatusReasonlist = new ArrayList<GBSOnboardResponseOnboardingStatusReason>();
                resOnboardObj.setCddReferenceKey(cddResponse.getApplicant_reference_key());

                if(cddResponse.getName_screening_hit() != null && !cddResponse.getName_screening_hit().trim().equalsIgnoreCase("")) {
                    resOnboardObj.setNameScreeningResults(new GBSOnboardResponseNameScreeningResults(cddResponse.getName_screening_hit(), cddResponse.getName_screening_alert_id()));
                }

                if(cddResponse.getRisk_rating() != null) {
                    resOnboardObj.setCddRiskDetails(new GBSOnboardResponseCDDRiskDetails(cddResponse.getRisk_rating(), cddResponse.getCdd_status()));

                }

                if(cddResponse.getAccount_references() != null && cddResponse.getAccount_references().size() > 0) {
                    List<GBSOnboardResponseAccountReference> accountReferences = new ArrayList<GBSOnboardResponseAccountReference>();
                    for(CDDRespAccountReferencesInitiateJson reference : cddResponse.getAccount_references()) {
                        accountReferences.add(new GBSOnboardResponseAccountReference(reference.getProduct_reference_key(), reference.getAccount_key()));
                    }
                    if(accountReferences.size() > 0) {
                        resOnboardObj.setAccountReferences(accountReferences);
                    }
                }

                addCDDReasonCodes(cddResponse, cddStatusReasonlist, srvEntity);

                if(cddStatusReasonlist.size() > 0) {
                    resOnboardObj.setOnboardingStatusReason(cddStatusReasonlist);
                }

            }
        }

        doUpdateRelidProfileid(travellingObject, resOnboardObj);
        ArrayList<ErrorObject> errorObjectList = new ArrayList<ErrorObject>();
        if(resICMObj.getData() != null && resICMObj.getData().getAttributes() != null && resICMObj.getData().getAttributes().getErrordetails() != null
                && resICMObj.getData().getAttributes().getErrordetails().size()>0) 
        {

            List<com.scb.clm.services.globus.onboarding.v1.models.ErrorDetails> errorList = new ArrayList<com.scb.clm.services.globus.onboarding.v1.models.ErrorDetails>();
            
            for (com.scb.clm.services.globus.icm.v1.model.ErrorDetails objForErrors: resICMObj.getData().getAttributes().getErrordetails()) 
            {
                com.scb.clm.services.globus.onboarding.v1.models.ErrorDetails objErr = new com.scb.clm.services.globus.onboarding.v1.models.ErrorDetails();
                objErr.setErrorCode(getRequestPayloadData(objForErrors.getErrorCode()));
                objErr.setErrorDescription(getRequestPayloadData(objForErrors.getErrorDescription()));
                errorList.add(objErr);
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, objErr.getErrorCode(),objErr.getErrorDescription()));
                
            }

            if(errorList != null && errorList.size() > 0) {
                resOnboardObj.setErrordetails(errorList);
                resOnboardObj.setOnboardingStatus("Rejected");
                if(errorObjectList.size() > 0) {
                serviceStatus.setErrorObject(errorObjectList);
                }
                serviceStatus.setStatus("S");
                serviceStatus.setResponsePayload(resOnboardObj);
            }
        }
        else if(resICMObj.getData() != null && resICMObj.getData().getAttributes() != null) 
        {	
            resOnboardObj.setCoreBankingReferenceKey(resICMObj.getData().getAttributes().getCustomers().getRelationshipNo());
            resOnboardObj.setCustomerMasterReferenceKey(resICMObj.getData().getAttributes().getCustomers().getProfileId());
            resOnboardObj.setOnboardingStatus("Completed");
            serviceStatus.addServiceParams("ONBOARDINGSTATUS", "COMPLETED");
            serviceStatus.setStatus("S");
            serviceStatus.setResponsePayload(resOnboardObj);
        }else {

            ICMCustomerCreateErrorResponseWrapper obErrResp = null;
            obErrResp = (ICMCustomerCreateErrorResponseWrapper) JSONUtility.jsonTODomainWrapper(icmCustomerCreateResponse, ICMCustomerCreateErrorResponseWrapper.class);

            if(obErrResp != null) {
                List<com.scb.clm.services.globus.onboarding.v1.models.ErrorDetails> errorList = new ArrayList<com.scb.clm.services.globus.onboarding.v1.models.ErrorDetails>();

                if(obErrResp!=null)
                {
                for (com.scb.clm.services.globus.icm.v1.model.Error objForErrors: obErrResp.getErrors()) 
                {
                    com.scb.clm.services.globus.onboarding.v1.models.ErrorDetails objErr = new com.scb.clm.services.globus.onboarding.v1.models.ErrorDetails();
                    objErr.setErrorCode(getRequestPayloadData(objForErrors.getTitle()));
                    objErr.setErrorDescription(getRequestPayloadData(objForErrors.getDetail()+" from ICM"));
                    errorList.add(objErr);
                    errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, objErr.getErrorCode(),objErr.getErrorDescription()));
                }
                }

                if(errorList != null && errorList.size() > 0) {
                    resOnboardObj.setErrordetails(errorList);
                    serviceStatus.setResponsePayload(resOnboardObj);
                    serviceStatus.setErrorObject(errorObjectList);

                }
            }
        }
    }


    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param   
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object constructServiceResponse(TravellingObject travellingObject,NodeServicesEntity srvEntity, Object clmResponseData,ServiceStatus serviceStatus) throws ProcessException
    {  
        serviceStatus.setInterfaceId("ICM");
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "constructServiceResponse", LogType.APPLICATION.name());
        GBSOnboardResponseWrapper responseWrarp = (GBSOnboardResponseWrapper)clmResponseData;
        if(responseWrarp==null) {
            responseWrarp = new GBSOnboardResponseWrapper();
            if(serviceStatus!=null && serviceStatus.getErrorObject()!=null && serviceStatus.getErrorObject().size() >0)
            { 
                for(ErrorObject errorObject : serviceStatus.getErrorObject())
                {
                    responseWrarp.addErrors(new ErrorDetails((String)errorObject.getCode(),(String)errorObject.getDescription()));
                }                
            }
        }

        serviceStatus.setResponsePayload(responseWrarp);
        
        
        log.println("Create ICM Service Status "+JSONUtility.domainWrapperToJSON(serviceStatus));
        return (GBSOnboardResponseWrapper) responseWrarp;

    }

    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    private void setPdpa(List<GBSOnboardPdpaWrapper> listPdpa, ICMCustomerCreateCustomer obCustomer, NodeServicesEntity srvEntity) {
        List<ICMCustomerCreatePDPA> pdpaList = new ArrayList<>();
        HashMap<String, String> customerChoice = ServiceParameterUtility.getParameterList(srvEntity.getNodeServicesMapper(), "CUSTOMER_CHOICE");

        if (listPdpa == null || listPdpa.isEmpty()) {
            customerChoice.forEach((key, value) -> pdpaList.add(createPdpa(key, value)));
        } else {
            listPdpa.forEach(obj -> pdpaList.add(createPdpa(getRequestPayloadData(obj.getCcqSequence()),
                    Optional.ofNullable(obj.getCustSelection()).orElse("N"))));
        }

        customerChoice.forEach((key, value) -> {
            if (pdpaList.stream().noneMatch(pdpa -> pdpa.getCcqSequence().equals(key))) {
                pdpaList.add(createPdpa(key, value));
            }
        });

        obCustomer.setPdpa(pdpaList);
    }

    private ICMCustomerCreatePDPA createPdpa(String ccqSequence, String custSelection) {
        ICMCustomerCreatePDPA obPdpa = new ICMCustomerCreatePDPA();
        obPdpa.setCcqSequence(ccqSequence);
        obPdpa.setCustSelection(custSelection);
        return obPdpa;
    }
}

