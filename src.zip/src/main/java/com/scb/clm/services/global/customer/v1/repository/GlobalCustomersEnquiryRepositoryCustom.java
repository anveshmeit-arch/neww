package com.scb.clm.services.global.customer.v1.repository;

import java.util.List;
import com.scb.clm.services.global.customer.v1.model.GlobalCustomersEntity;
 
public interface GlobalCustomersEnquiryRepositoryCustom 
{
    List<GlobalCustomersEntity> findByFilters(List<String> applicationRefList,List<String> globalIDRefList,List<String> relationshipRefList,List<String> profileIDRefList,String countryCode,int offset,int limit);
}