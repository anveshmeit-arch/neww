package com.scb.clm.services.companysearch.chekk.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class HKRequestData {

    @JsonProperty("fromDate")
	private String fromDate;
    
    @JsonProperty("purgeDays")
	private Integer purgeDays;

}
