package com.scb.clm.services.companysearch.chekk.v1.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.scb.clm.services.companysearch.chekk.v1.model.ChekkPartyEntity;

@Repository
public interface ChekkPartyRepository extends JpaRepository<ChekkPartyEntity, String> { 

    @Override
    public <S extends ChekkPartyEntity> S save(S entity);
    
    public List<ChekkPartyEntity> findByRequestId(String requestId);
    
    public ChekkPartyEntity findByPartyId(String partyId);
    public List<ChekkPartyEntity> findBySearchEntityIdAndRequestIdAndPartyType(String searchEntityId,String requestId,String partyType);

    @Transactional
    @Modifying
    @Query(value = "update CHK_PARTY set id_status = :status where search_entity_id = :searchEntityId and request_id = :requestId",nativeQuery = true )
    public int updateStatusByIds(@Param("status") String status,@Param("searchEntityId") String searchEntityId,@Param("requestId") String requestId);
    
    @Query(value = "select SUM(CAST(coalesce(parent_percentage,'0') AS FLOAT)) from chk_party where request_id = :requestId and party_type = :entityType and parent_percentage is not null",nativeQuery = true )
    public Float caliculateSumOfIndPercentage(@Param("requestId") String requestId,@Param("entityType") String entityType);
}