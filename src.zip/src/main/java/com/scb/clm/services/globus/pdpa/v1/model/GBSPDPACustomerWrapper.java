package com.scb.clm.services.globus.pdpa.v1.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;


public class GBSPDPACustomerWrapper {

	@JsonProperty("coreBankingReferenceKey")
	private String coreBankingReferenceKey;
	
	@JsonProperty("customerMasterReferenceKey")
	private String customerMasterReferenceKey;
	
	@JsonProperty("pdpa")
    private List<GBSPDPAPdpaWrapper> pdpa; 
	


	public String getCoreBankingReferenceKey() {
		return coreBankingReferenceKey;
	}

	public void setCoreBankingReferenceKey(String coreBankingReferenceKey) {
		this.coreBankingReferenceKey = coreBankingReferenceKey;
	}

	public String getCustomerMasterReferenceKey() {
		return customerMasterReferenceKey;
	}

	public void setCustomerMasterReferenceKey(String customerMasterReferenceKey) {
		this.customerMasterReferenceKey = customerMasterReferenceKey;
	}

	public List<GBSPDPAPdpaWrapper> getPdpa() {
		return pdpa;
	}

	public void setPdpa(List<GBSPDPAPdpaWrapper> pdpa) {
		this.pdpa = pdpa;
	}



	

    
}
