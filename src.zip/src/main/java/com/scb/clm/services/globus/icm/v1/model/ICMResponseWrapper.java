package com.scb.clm.services.globus.icm.v1.model;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ICMResponseWrapper  {
	
	@JsonProperty("data")
	private List<ICMResponsesData> data;
	
	@JsonProperty("included")
	private List<ICMResponsesData> included;

	public List<ICMResponsesData> getIncluded() {
		return included;
	}

	public void setIncluded(List<ICMResponsesData> included) {
		this.included = included;
	}

	public List<ICMResponsesData> getData() {
		return data;
	}
    
	public void setData(List<ICMResponsesData> data) {
		this.data = data;
	}
}
