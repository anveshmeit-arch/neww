package com.scb.clm.services.globus.deepening.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.scb.clm.services.globus.onboarding.v1.models.*;
import com.scb.clm.services.globus.prospect.v1.model.GBSProspectRequestDocuments;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class GBSDeepeningResponseCustomers {
    @JsonProperty("firstName")
    private String firstName;

    @JsonProperty("middleName")
    private String middleName;

    @JsonProperty("lastName")
    private String lastName;

    @JsonProperty("fullName")
    private String fullName;

    @JsonProperty("isDeepeningAllowed")
    private String isDeepeningAllowed;

    @JsonProperty("profileType")
    private String profileType;

    @JsonProperty("profileStatus")
    private String profileStatus;

    @JsonProperty("gender")
    private String gender;

    @JsonProperty("residentCountry")
    private String residentCountry;

    @JsonProperty("dateOfBirth")
    private Date dateOfBirth;

    @JsonProperty("customerNationalityCode")
    private String customerNationalityCode;

    @JsonProperty("bankInternalInfo")
    private GBSDeepeningResponseBankInternalInfo bankInternalInfo;

    @JsonProperty("documents")
    List<GBSDeepeningResponseDocuments> documents;

    @JsonProperty("cdd")
    private GBSDeepeningResponseCDD deepeningResponseCDD;

    @JsonProperty("contacts")
    private List<GBSDeepeningResponseContacts> deepeningResponseContacts;

    @JsonProperty("addresses")
    private List<GBSDeepeningResponseAddresses> deepeningResponseAddresses;

    @JsonProperty("tars")
    private GBSDeepeningResponseTars deepeningResponseTars;

    @JsonProperty("kyc")
    private GBSDeepeningResponseKYC deepeningResponseKYC;

    @JsonProperty("risks")
    private GBSDeepeningResponseRiskCodes deepeningResponseRiskCodes;

    public GBSDeepeningResponseCustomers() {
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getIsDeepeningAllowed() {
        return isDeepeningAllowed;
    }

    public void setIsDeepeningAllowed(String isDeepeningAllowed) {
        this.isDeepeningAllowed = isDeepeningAllowed;
    }

    public String getProfileType() {
        return profileType;
    }

    public void setProfileType(String profileType) {
        this.profileType = profileType;
    }

    public String getProfileStatus() {
        return profileStatus;
    }

    public void setProfileStatus(String profileStatus) {
        this.profileStatus = profileStatus;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getResidentCountry() {
        return residentCountry;
    }

    public void setResidentCountry(String residentCountry) {
        this.residentCountry = residentCountry;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public GBSDeepeningResponseBankInternalInfo getBankInternalInfo() {
        return bankInternalInfo;
    }

    public void setBankInternalInfo(GBSDeepeningResponseBankInternalInfo bankInternalInfo) {
        this.bankInternalInfo = bankInternalInfo;
    }

    public List<GBSDeepeningResponseDocuments> getDocuments() {
        return documents;
    }

    public void setDocuments(List<GBSDeepeningResponseDocuments> documents) {
        this.documents = documents;
    }

    public GBSDeepeningResponseCDD getDeepeningResponseCDD() {
        return deepeningResponseCDD;
    }

    public void setDeepeningResponseCDD(GBSDeepeningResponseCDD deepeningResponseCDD) {
        this.deepeningResponseCDD = deepeningResponseCDD;
    }

    public List<GBSDeepeningResponseContacts> getDeepeningResponseContacts() {
        return deepeningResponseContacts;
    }

    public void setDeepeningResponseContacts(List<GBSDeepeningResponseContacts> deepeningResponseContacts) {
        this.deepeningResponseContacts = deepeningResponseContacts;
    }

    public List<GBSDeepeningResponseAddresses> getDeepeningResponseAddresses() {
        return deepeningResponseAddresses;
    }

    public void setDeepeningResponseAddresses(List<GBSDeepeningResponseAddresses> deepeningResponseAddresses) {
        this.deepeningResponseAddresses = deepeningResponseAddresses;
    }

    public GBSDeepeningResponseTars getDeepeningResponseTars() {
        return deepeningResponseTars;
    }

    public void setDeepeningResponseTars(GBSDeepeningResponseTars deepeningResponseTars) {
        this.deepeningResponseTars = deepeningResponseTars;
    }
    public String getCustomerNationalityCode() {
        return customerNationalityCode;
    }

    public void setCustomerNationalityCode(String customerNationalityCode) {
        this.customerNationalityCode = customerNationalityCode;
    }

    public GBSDeepeningResponseKYC getDeepeningResponseKYC() {
        return deepeningResponseKYC;
    }

    public void setDeepeningResponseKYC(GBSDeepeningResponseKYC deepeningResponseKYC) {
        this.deepeningResponseKYC = deepeningResponseKYC;
    }

    public GBSDeepeningResponseRiskCodes getDeepeningResponseRiskCodes() {
        return deepeningResponseRiskCodes;
    }

    public void setDeepeningResponseRiskCodes(GBSDeepeningResponseRiskCodes deepeningResponseRiskCodes) {
        this.deepeningResponseRiskCodes = deepeningResponseRiskCodes;
    }
}
