package com.scb.clm.services.globus.prospect.v1.model;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
public class ProspectAppCountriesEntityKey implements Serializable,Cloneable{

	@Column(name = "COUNTRY_CODE", nullable = false ,insertable=false, updatable=false)
	private String countryCode;

	@Column(name = "PROSPECT_ID", nullable = false ,insertable=false, updatable=false)
	private String prospectID;

	@Column(name = "ONBOARD_COUNTRY_CODE", nullable = false ,insertable=false, updatable=false)
	private String onboardCountryCode;

	public String getOnboardCountryCode() {
		return onboardCountryCode;
	}

	public void setOnboardCountryCode(String onboardCountryCode) {
		this.onboardCountryCode = onboardCountryCode;
	}

	public ProspectAppCountriesEntityKey()
	{

	}

	public ProspectAppCountriesEntityKey (String countryCode,String prospectID,String onboardCountryCode) {
		this.countryCode    = countryCode;
		this.prospectID     = prospectID;
		this.onboardCountryCode  = onboardCountryCode;

	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getProspectID() {
		return prospectID;
	}

	public void setProspectID(String prospectID) {
		this.prospectID = prospectID;
	}
	@Override
	public int hashCode() {
		StringBuilder finalHashCode = new StringBuilder();
		if (this.countryCode != null && this.prospectID != null && this.onboardCountryCode != null) 
		{
			finalHashCode.append(countryCode);
			finalHashCode.append(prospectID);
			finalHashCode.append(onboardCountryCode);

		}
		return finalHashCode.toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
		{
			return true;
		}
		if ((obj == null) || (obj.getClass() != this.getClass())) 
		{
			return false;
		}
		ProspectAppCountriesEntityKey other = (ProspectAppCountriesEntityKey) obj;
		return   Objects.equals(this.countryCode, other.countryCode) 
				&& Objects.equals(this.prospectID, other.prospectID)
				&& Objects.equals(this.onboardCountryCode, other.onboardCountryCode)
				;
	}

	@Override
	public Object clone() {
		try {
			return (ProspectAppCountriesEntityKey) super.clone();
		} catch (CloneNotSupportedException e) {
			return new ProspectAppCountriesEntityKey(this.getCountryCode(),this.getProspectID(),this.getOnboardCountryCode());
		}
	}    

}
