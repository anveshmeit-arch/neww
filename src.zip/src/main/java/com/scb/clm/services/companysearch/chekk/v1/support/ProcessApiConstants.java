package com.scb.clm.services.companysearch.chekk.v1.support;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProcessApiConstants {

	//DUPLICATE REQUEST
	public static final String DUPLICATE_REQUEST = "Ck006";
	public static final String DUPLICATE_REQUEST_FOUND = "Duplicate request found";
	
	//HEADER DETAILS
	public static final String CONTENT_TYPE = "Content-Type";
	public static final String AUTHORIZATION = "Authorization";
	public static final String XAUTHORIZATION = "X-Authorization";
	public static final String APPLICATION_JSON ="application/json";
	public static final String APPLICATION_FORM_URLENCODED ="application/x-www-form-urlencoded";
	public static final String BEARER = "Bearer";
	public static final String SINGLE_SPACE=" ";
	public static final String REQ_HDR_COUNTRY_CODE="countrycode";

	
	public static final int  MILLISECONDS=1000;

	//SERVER ERRORS
	public static final String ERRCODE_UNAUTHORIZED_TOKENEXPIRED = "Ck007";
	public static final String ERRCODE_INVALID_PATH = "Ck008";
	public static final String ERRCODE_INTERNAL_ERROR = "Ck009";
	public static final String CONNECTION_FAILURE = "Connectivity Issue";
	public static final String ERRCODE_INVALID_DATA = "Ck010";
	public static final String ERRCODE_INVALID_CLIENT = "Ck011";
	
	public static final String APPLICATION_REFERENCEID = "application-reference-id";
	
	//CHEKK ERROR MESSAGES
	public static final String TOKEN_EXPIRTY_MSG = "The incoming token has expired";
	
	public static final String STATUS_UNWRAP_PENDING= "UP";
	public static final String STATUS_CREATE_PENDING= "CP";
	public static final String STATUS_GET_PENDING = "GP";
	public static final String STATUS_GET_FAILED = "GF";
	public static final String STATUS_CREATE_FAILED = "CF";
	public static final String STATUS_SEARCH_FAILED = "SF";
	public static final String STATUS_UNWRAP_FAILED = "UF";

	public static final String STATUS_UNWRAPPING_COMPLETED = "UC";
	public static final String STATUS_PUBLISH_COMPLETED = "XC";
	public static final String STATUS_COMPLETED = "XC";

	public static final String STATUS_MSG_SEND_FAILED= "PF";
	
	public static final String STATUS_PUBLISH_FAILED = "XF";
	public static final String STATUS_SEARCH_PENDING = "SP";
	public static final String TARGET_DT_FORMAT = "yyyy-MM-dd";

	//ADDRESS SPLIT CONSTANTS
    public static final String COMMA_SEPARATOR = ",";
    public static final String EMPTY_STRING = "";
    public static final String BLANK_SPACE = " ";
    public static final String NEWLINE = "\n";
    public static final String SPACE_SEPARATOR = " ";
    public static final String SPLIT_REGEXP1 = "\\s+";
    public static final String SPLIT_REGEXP2 = "\\r?\\n";
    public static final String REGEXP_PATTERN2 = "\\d+\\s+([a-zA-Z]+|[a-zA-Z]+\\s[a-zA-Z]+)";
    public static final String ADDRESS_LINE1 = "addLine1";
    public static final String ADDRESS_LINE2 = "addLine2";
    public static final String ADDRESS_LINE3 = "addLine3";
    public static final String ADDRESS_LINE4 = "addLine4";

    public static final String COMPANY = "Company";
    
    //HEADER CONSTANTS.
    public static final String PROCESS_API_HEADER_COUNTRY_CODE  = "countrycode";    
    public static final String PROCESS_API_HEADER_INTERFACE_ID  = "interfaceid";    
	public static final String PROCESS_API_HEADER_TRANSACTION_ID = "transactionid";

	//Request Body attributes
	public static final String REQ_BODY_APPL_REF_NO = "applicationReferenceNumber";
	public static final String REQ_BODY_CNTRY_ACCTOPEN = "countryOfAccountOpening";
	public static final String REQ_BODY_CNTRY_EST = "countryOfRegistration";

	
	public static final Map<String, Map<String, String>> chekkcountryMap = new HashMap<String, Map<String, String>>();
	public static final Map<String, Map<String, String>> chekkSSICCodeMap = new HashMap<String, Map<String, String>>();
	public static final Map<String, Map<String, String>> chekkRolecodeMap = new HashMap<String, Map<String, String>>();
	public static final Map<String, Map<String, List<String>>> chekkentityTypeMap = new HashMap<String, Map<String, List<String>>>();
	
	
	//Solace Constants
	public static final String SSL_PROTOCOLS = "tlsv1.2";
    
    public static final String SSL_CIPHER_SUITES_ARGS="TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384, TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256";
    
    public static final String COUNTRY3CODEMAP  = "country3codeMap";
    public static final String COUNTRYDESCMAP  = "countryDescMap";
    public static final String SSICCODEMAP  = "SsicCodeMap";
    public static final String ROLECODEMAP  = "roleCodeMap";
    public static final String ENTITYTYPEMAP  = "entityTypeMap";
    
    public static final String SUCCESS_CODE = "S";
    public static final String FAILURE_CODE = "F";
    public static final String CHK_RESDATA_TYPE_SEARCH = "S";
    public static final String CHK_RESDATA_TYPE_CREATE = "C";
    public static final String CHK_RESDATA_TYPE_GET = "G";
    
    //Used in ApiProcessor for returning multiple objects
    public static final String API_RESPONSE = "API_RESPONSE";
    public static final String PARTY_LIST = "PARTY_LIST";
    public static final String CHEKK_SERVICE_NAME = "CHEKK";
    
    
    
}
