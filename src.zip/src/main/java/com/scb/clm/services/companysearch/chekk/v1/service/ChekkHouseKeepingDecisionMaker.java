package com.scb.clm.services.companysearch.chekk.v1.service;

import java.util.List;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.codesetup.NodesEntity;
import com.scb.clm.common.model.transactions.NodeStatus;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.core.service.DecisionMakerInterface;

public class ChekkHouseKeepingDecisionMaker implements DecisionMakerInterface
{

    @Override
    public void isGoodToProceed(TravellingObject travelObj,NodesEntity nodesEntity,List<NodeServicesEntity> service, NodeStatus nodeStatus)
    {
    	LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "method_name", LogType.APPLICATION.name());

    	try
        {
            for(NodeServicesEntity services :  service) {
                ServiceStatus stat = travelObj.getServiceStatus(services.getId());
                if(!stat.getStatus().equals(BaseConstants.SERVICE_SUCCESS)) {
                	log.println("Service Failed For "+stat.printKey());
					nodeStatus.setProcessToNextNode(false);                    
                }
            }

            log.println("Chekk Housekeep Decision Maker - Service Success Status ["+((nodeStatus.isProcessToNextNode())?"Success":"Failure")+"]");
        }
        catch(Exception e)
        {
        	log.printErrorMessage(e);
        }       
    }

    @Override
    public void buildResponse(TravellingObject travelObj,NodesEntity nodesEntity,List<NodeServicesEntity> service,boolean isSuccess)
    {
    	LoggerUtil log   = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "buildResponse", LogType.APPLICATION.name());
		
        try
        {
        	log.println("Building Response Data ["+isSuccess+"]");
            ServiceStatus serviceStatus = travelObj.getServiceStatus().get("FCHKHSKPG-NCHKHSKPG-SCHKHSKPG");
            if(isSuccess) {
                travelObj.setResponseData(serviceStatus.getResponsePayload());
            } else {
                travelObj.setResponseData("Fail");
            }
        }
        catch(Exception e)
        {
        	log.printErrorMessage(e);
        }
    }    
}
