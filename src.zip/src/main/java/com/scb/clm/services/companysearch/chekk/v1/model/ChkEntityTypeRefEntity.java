package com.scb.clm.services.companysearch.chekk.v1.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "CHK_ENTITY_TYPE_REF")
@Getter
@Setter
public class ChkEntityTypeRefEntity {

	@Id
	@Column(name="le_national_legal_form")
	private String leNationalLegalForm;

	@Column(name="client_entity_type")
	private String clientEntityType;
	
	@Column(name="client_entity_sub_type")
	private String clientEntitySubType;
}
