package com.scb.clm.services.companysearch.chekk.v1.model;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)

public class LinkDataArray {

	@JsonProperty("directPercentage")
	public String directPercentage;
	@JsonProperty("from")
	public String from;
	@JsonProperty("to")
	public String to;
	@JsonProperty("text")
	public String text;
	@JsonProperty("category")
	public String category;
	@JsonProperty("relationship")
	public String relationship;
	@JsonProperty("totalPercentage")
	public String totalPercentage;
}