package com.scb.clm.services.globus.biometric.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSRequestIdCustomers implements Cloneable {




	@JsonProperty("profileId")
	private String profileId;

	@JsonProperty("relationshipNumber")
	private String relationshipNumber;



	public String getProfileId() {
		return profileId;
	}

	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}

	public String getRelationshipNumber() {
		return relationshipNumber;
	}

	public void setRelationshipNumber(String relationshipNumber) {
		this.relationshipNumber = relationshipNumber;
	}

	@Override
	protected Object clone() {
		try {
			return super.clone();
		} catch (CloneNotSupportedException e) {
			return new GBSRequestIdCustomers();
		}
	}


}
