package com.scb.clm.services.globus.pdpa.v1.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.clm.common.config.ApplicationConfiguration;
import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ErrorObject;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.repository.InterfaceRequestTypeRepository;
import com.scb.clm.common.util.JSONUtility;
import com.scb.clm.common.util.StringUtility;
import com.scb.clm.core.service.ServiceAbstract;
import com.scb.clm.core.service.ServiceInterface;
import com.scb.clm.services.globus.pdpa.v1.model.ErrorDetails;
import com.scb.clm.services.globus.pdpa.v1.model.GBSPDPAApplnWrapper;
import com.scb.clm.services.globus.pdpa.v1.model.GBSPDPACustomerWrapper;
import com.scb.clm.services.globus.pdpa.v1.model.GBSPDPAPdpaWrapper;
import com.scb.clm.services.globus.pdpa.v1.model.GBSPDPARequestWrapper;
import com.scb.clm.services.globus.pdpa.v1.model.GBSPDPAResponseWrapper;
import com.scb.clm.services.globus.pdpa.v1.model.ICMErrorDetails;
import com.scb.clm.services.globus.pdpa.v1.model.ICMPDPADatatAttributeWrapper;
import com.scb.clm.services.globus.pdpa.v1.model.ICMPDPADatatWrapper;
import com.scb.clm.services.globus.pdpa.v1.model.ICMPDPARequestWrapper;
import com.scb.clm.services.globus.pdpa.v1.support.PDPAConstant;
import com.scb.clm.services.globus.pdpa.v1.support.PDPADataValidator;

@Service
public class PDPACreateService extends ServiceAbstract implements ServiceInterface
{

    @Autowired
    RestTemplate restTemplate;

    @Autowired
    InterfaceRequestTypeRepository interfaceRequestTypeRepository;

    @Autowired
    PDPADataValidator profileDataValidator;

   


    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object readRequestObject(TravellingObject travellingObject, NodeServicesEntity srvEntity) throws ProcessException 
    {
        List<ErrorObject> errorObjectList = new ArrayList<ErrorObject>();
        LoggerUtil log                    = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "readRequestObject", LogType.APPLICATION.name());

        try
        {
            return JSONUtility.jsonTODomainWrapper(travellingObject.getRequestData(),GBSPDPARequestWrapper.class);
        }
        catch(Exception e)
        {
            log.printErrorMessage(e);
            errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_TECHNICAL, BaseConstants.VALIDATION_ERROR,"INVALID REQUEST FORMAT FOR CDD CREATE SERVICE"));
            ProcessException gbxEx = new ProcessException();
            gbxEx.addAll(errorObjectList);
            throw gbxEx;
        }
        finally
        {
            // N.A
        }
    }


    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public void validateData(TravellingObject travellingObject,NodeServicesEntity srvEntity,Object requestPayload) throws ProcessException 
    {
        List<ErrorObject> errorObjectList = new ArrayList<ErrorObject>();
        LoggerUtil log                    = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateData", LogType.APPLICATION.name());

        try
        {

        	GBSPDPARequestWrapper requestWrapper = (GBSPDPARequestWrapper) requestPayload;

            ObjectMapper mapper = new ObjectMapper();
            log.println("Response :  "+mapper.writeValueAsString(requestWrapper));

            if(requestWrapper == null)
            {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_TECHNICAL, PDPAConstant.INVALID_JSON_FORMAT,"INVALID REQUEST"));
            } 
            else if( (requestWrapper.getGbsPDPAApplnWrapper() == null || !StringUtility.containsData(requestWrapper.getGbsPDPAApplnWrapper().getApplicationReferenceNumber()))) 
            {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, PDPAConstant.INVALID_APPLICATION_REFERENCE_NUMBER,"INVALID APPLICATION REFERENCE NUMBER"));
            } 
            else if(
                  requestWrapper!=null && requestWrapper.getGbsPDPAApplnWrapper().getApplicationReferenceNumber() !=null 
                  && 
                  (
                     !StringUtility.minMaxlength(requestWrapper.getGbsPDPAApplnWrapper().getApplicationReferenceNumber(),"0","50")
                       ||
                     !StringUtility.isAlphaNumeric(requestWrapper.getGbsPDPAApplnWrapper().getApplicationReferenceNumber())
                  )
                )
            {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, PDPAConstant.INVALID_APPLICATION_REFERENCE_NUMBER,"INVALID APPLICATION REFERENCE NUMBER ["+requestWrapper.getGbsPDPAApplnWrapper().getApplicationReferenceNumber()+"] [DATA SHOULD BE ALPHANUMERIC WITH LENGTH 1-50]"));
            }
            else 
            {
                travellingObject.setApplicationReferenceNumber(requestWrapper.getGbsPDPAApplnWrapper().getApplicationReferenceNumber());
            }

            if(requestWrapper != null && requestWrapper.getGbsPDPAApplnWrapper() == null) {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, PDPAConstant.INVALID_JSON_FORMAT,"BASIC INFORMATION ('application') TAG IS NULL"));
            }

            if(requestWrapper != null && requestWrapper.getGbsPDPACustomerWrapper() == null) {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, PDPAConstant.INVALID_JSON_FORMAT,"BASIC INFORMATION ('customers') TAG IS NULL"));
            } 


            if(requestWrapper != null && requestWrapper.getGbsPDPACustomerWrapper() != null) {
                profileDataValidator.validateRequestMessage(requestWrapper.getGbsPDPACustomerWrapper(), errorObjectList);
            }

          

            if(errorObjectList.size()> 0) {
                ProcessException gbxEx = new ProcessException();
                gbxEx.addAll(errorObjectList);
                throw gbxEx;
            }
        } 
        catch (ProcessException e)
        {
            log.println(" Error ["+e.getAllErrors()+"]");
            throw e;
        }
        catch (Exception e)
        {
            log.printErrorMessage(e);
            errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, BaseConstants.VALIDATION_ERROR,"INTERNAL ERROR"));
            ProcessException gbxEx = new ProcessException();
            gbxEx.addAll(errorObjectList);
            throw gbxEx; 
        }
    }

  


    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object constructOutboundObject(TravellingObject travellingObject,NodeServicesEntity srvEntity,Object requestPayload) throws ProcessException
    {
        LoggerUtil log   = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "constructOutboundObject", LogType.APPLICATION.name());
        
        try
        {
            log.println("[PDPA Create/Initiate] [constructOutboundObject] "+requestPayload);

            GBSPDPARequestWrapper requestWrapper = (GBSPDPARequestWrapper) requestPayload;  
            
            ICMPDPARequestWrapper obRequestPDPA = new ICMPDPARequestWrapper();
            
            setData(requestWrapper, obRequestPDPA, travellingObject.getInterfaceId(), srvEntity);
            
            return obRequestPDPA;
        }
        catch (Exception e)
        {
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, BaseConstants.VALIDATION_ERROR," INTERNAL ERROR WHILE PAYLOAD CONSTRUCTION ");
        }
        finally
        {
            //N.A
        }
    }
    
    private void setData(GBSPDPARequestWrapper requestWrapper, ICMPDPARequestWrapper obIcmPdpa, String interfaceId, NodeServicesEntity srvEntity) {
    	
    	GBSPDPAApplnWrapper reqObjAppln = requestWrapper.getGbsPDPAApplnWrapper();
    	GBSPDPACustomerWrapper reqObjCustomer = requestWrapper.getGbsPDPACustomerWrapper();
    	
    	ICMPDPADatatWrapper obIcmPdpaData = new ICMPDPADatatWrapper();    	
    	obIcmPdpaData.setId(null);
    	obIcmPdpaData.setType(PDPAConstant.PDPA_REQUEST_TYPE);
    	
    	ICMPDPADatatAttributeWrapper obIcmPdpaDataAttribute = new ICMPDPADatatAttributeWrapper();
    	obIcmPdpaDataAttribute.setReferenceId(reqObjCustomer.getCustomerMasterReferenceKey());
    	
    	
    	for (GBSPDPAPdpaWrapper dat : reqObjCustomer.getPdpa())
        {
    		
    		
    		if(srvEntity.getServicesEntity().getId().getServiceID().equalsIgnoreCase(PDPAConstant.PDPA_SERVICE_Q001) && dat.getCcqSequence() != null && dat.getCcqSequence().equalsIgnoreCase(PDPAConstant.PDPA_Q001)) {
    		obIcmPdpaDataAttribute.setCcqSequence(dat.getCcqSequence());
    		obIcmPdpaDataAttribute.setCustSelection(dat.getCustSelection());
    		obIcmPdpaDataAttribute.setSenderId(interfaceId);
    		}
    		
    		if(srvEntity.getServicesEntity().getId().getServiceID().equalsIgnoreCase(PDPAConstant.PDPA_SERVICE_Q002) && dat.getCcqSequence() != null && dat.getCcqSequence().equalsIgnoreCase(PDPAConstant.PDPA_Q002)) {
        		obIcmPdpaDataAttribute.setCcqSequence(dat.getCcqSequence());
        		obIcmPdpaDataAttribute.setCustSelection(dat.getCustSelection());
        		obIcmPdpaDataAttribute.setSenderId(interfaceId);
    		}
    		
    		if(srvEntity.getServicesEntity().getId().getServiceID().equalsIgnoreCase(PDPAConstant.PDPA_SERVICE_Q003) && dat.getCcqSequence() != null && dat.getCcqSequence().equalsIgnoreCase(PDPAConstant.PDPA_Q003)) {
        		obIcmPdpaDataAttribute.setCcqSequence(dat.getCcqSequence());
        		obIcmPdpaDataAttribute.setCustSelection(dat.getCustSelection());
        		obIcmPdpaDataAttribute.setSenderId(interfaceId);
        	}
    		
    		if(srvEntity.getServicesEntity().getId().getServiceID().equalsIgnoreCase(PDPAConstant.PDPA_SERVICE_Q004) && dat.getCcqSequence() != null && dat.getCcqSequence().equalsIgnoreCase(PDPAConstant.PDPA_Q004)) {
        		obIcmPdpaDataAttribute.setCcqSequence(dat.getCcqSequence());
        		obIcmPdpaDataAttribute.setCustSelection(dat.getCustSelection());
        		obIcmPdpaDataAttribute.setSenderId(interfaceId);
        	}
    		
        }
    	
    	obIcmPdpaData.setAttributes(obIcmPdpaDataAttribute);    	
    	obIcmPdpa.setData(obIcmPdpaData);
    	
    }
    
  

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object process(TravellingObject travellingObject,NodeServicesEntity srvEntity,ServiceStatus serviceStatus,Object outBoundRequestObject) throws ProcessException
    {
        LoggerUtil log                      = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "process", LogType.APPLICATION.name());
        ICMPDPARequestWrapper resPDPAObj = null;
        ObjectMapper mapper                 = null;
        ResponseEntity<ICMPDPARequestWrapper> responseContent = null;

        try
        {
            String token = ApplicationConfiguration.getInstance().getAccessToken(travellingObject, BaseConstants.ICM_SCOPE);
            serviceStatus.setInterfaceId("PDPA");
            ICMPDPARequestWrapper outBoundData = (ICMPDPARequestWrapper) outBoundRequestObject;
            
            mapper = new ObjectMapper();
            String requestData = mapper.writeValueAsString(outBoundData);
            log.println("Request Payload Data PDPA Initiate: "+requestData);

            HttpHeaders headers = new HttpHeaders();
            //headers.add("X-JWT-Assertion","NO_JWT_VALIDATE");
            headers.add(BaseConstants.CONTENT_TYPE,"application/vnd.api+json; charset=utf-8");
            headers.add(BaseConstants.AUTHORIZATION_HEADER, "Bearer "+ token);
            headers.add(BaseConstants.API_HEADER_COUNTRY_CODE,travellingObject.getCountryCode());
            headers.add(BaseConstants.API_HEADER_COUNTRYCODE,travellingObject.getCountryCode());

            headers.add(BaseConstants.API_HEADER_TRANSACTION_ID, travellingObject.getTransactionID());
            headers.add(BaseConstants.API_HEADER_INTERFACE_ID, travellingObject.getInterfaceId());
            headers.add("tracking-id",travellingObject.getApplicationReferenceNumber());  
            log.println("token here : "+ token+" Country "+travellingObject.getCountryCode()+" Interface "+PDPAConstant.PDBA_INTERFACE_ID+" service "+PDPAConstant.PDBA_SERVICE_ID+", "+"OB"+" - "+BaseConstants.CODE_SETUP_ACTIVE);
            
            
            String hostServiceURL = interfaceRequestTypeRepository.getInterfaceURL(travellingObject.getServiceContext().getCountryCodeWithRegion(),PDPAConstant.PDBA_INTERFACE_ID,PDPAConstant.PDBA_SERVICE_ID,"OB", BaseConstants.CODE_SETUP_ACTIVE);
            log.println("Sending Request to PDPA ["+hostServiceURL+"]"+", Headers : "+headers);
            HttpEntity<ICMPDPARequestWrapper> entity = new HttpEntity<ICMPDPARequestWrapper>(outBoundData,headers);
            responseContent = restTemplate.exchange(hostServiceURL, HttpMethod.POST, entity, ICMPDPARequestWrapper.class);
          
                resPDPAObj = responseContent.getBody();
            String responseData = mapper.writeValueAsString(resPDPAObj);
            log.println("PDBA responseData : "+responseData);
            serviceStatus.setHttpStatus(String.valueOf(responseContent.getStatusCodeValue()));
        }
        catch (HttpStatusCodeException ex) 
        {
            log.println(""+ex.getRawStatusCode());
            log.println(ex.getStatusCode().toString());
            serviceStatus.setHttpStatus(ex.getRawStatusCode()+"");

            log.println(ex.getResponseBodyAsString());

            try 
            {
                mapper = new ObjectMapper();
                mapper.setSerializationInclusion(Include.NON_NULL);
                String requestData = mapper.writeValueAsString(ex.getResponseBodyAsString());
                log.println("Response Payload Data : "+requestData);
                resPDPAObj = mapper.readValue(ex.getResponseBodyAsString(), ICMPDPARequestWrapper.class);
                travellingObject.setResponseData(resPDPAObj);
            } 
            catch (Exception e) 
            {
                log.printErrorMessage(e);
				throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, PDPAConstant.PDPA_REQUEST_ERROR,"INTERNAL ERROR WHILE SERVICE PROCESSING WITH ICM API");
            }
        }
        catch(Exception e)
        {
            serviceStatus.setHttpStatus(String.valueOf(BaseConstants.HTTP_500));
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, PDPAConstant.PDPA_REQUEST_ERROR,"INTERNAL ERROR WHILE SERVICE PROCESSING WITH CLM");
            
        }

        return resPDPAObj;
    }

   

   


    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object constructServiceResponse(TravellingObject travellingObject,NodeServicesEntity srvEntity, Object clmResponseData,ServiceStatus serviceStatus) throws ProcessException
    {        
        LoggerUtil log                          = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "constructServiceResponse", LogType.APPLICATION.name());

        GBSPDPAResponseWrapper resPDPAObj = null;
        
        serviceStatus.setInterfaceId(travellingObject.getInterfaceId());

        if(serviceStatus!=null && serviceStatus.getErrorObject()!=null && serviceStatus.getErrorObject().size() >0)
        { 
        	resPDPAObj = new GBSPDPAResponseWrapper();
            for(ErrorObject errorObject : serviceStatus.getErrorObject())
            {
            	resPDPAObj.addErrors(new ErrorDetails((String)errorObject.getCode(),(String)errorObject.getDescription()));
            }
            serviceStatus.setResponsePayload(resPDPAObj);
            serviceStatus.setStatus("F");
        }    
        
        if(clmResponseData != null) {        	
        	ICMPDPARequestWrapper obICMRes = (ICMPDPARequestWrapper) clmResponseData;
        	ArrayList<ErrorObject> errorObjectList = new ArrayList<ErrorObject>();
        	if(obICMRes != null) {
        		if(obICMRes.getData() != null && obICMRes.getData().getAttributes() != null && obICMRes.getData().getAttributes().getErrorDetails() != null) {
        			if(obICMRes.getData().getAttributes().getErrorDetails().size() >0) {
        				resPDPAObj = new GBSPDPAResponseWrapper();
        				 for(ICMErrorDetails errorObject : obICMRes.getData().getAttributes().getErrorDetails())
        		            {
        					 resPDPAObj.addErrors(new ErrorDetails(errorObject.getErrorCode(),errorObject.getErrorDescription()));
        					 errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_PROCESSING, errorObject.getErrorCode(),errorObject.getErrorDescription()));
        		            }
        				 serviceStatus.setResponsePayload(resPDPAObj);
        				 serviceStatus.setErrorObject(errorObjectList);
        				 serviceStatus.setStatus("F");
        			}
        		}
        	}
        	
        }
        

        if(resPDPAObj != null)
        	return resPDPAObj;
        
        return ResponseEntity.ok();
    }

}
