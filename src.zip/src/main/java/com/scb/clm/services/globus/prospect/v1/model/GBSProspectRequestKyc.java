package com.scb.clm.services.globus.prospect.v1.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSProspectRequestKyc 
{

    @JsonProperty("nationality")
    public List<GBSProspectRequestNationality> nationality;

    public GBSProspectRequestKyc () {       
    }
    
    public List<GBSProspectRequestNationality> getNationality() {
        return nationality;
    }

    public void setNationality(List<GBSProspectRequestNationality> nationality) {
        this.nationality = nationality;
    }

    public void addNationality(GBSProspectRequestNationality nationalityDetail) {
        if(this.nationality == null) {
            this.nationality = new ArrayList<GBSProspectRequestNationality>();
        }
        this.nationality.add(nationalityDetail);
    }
}

