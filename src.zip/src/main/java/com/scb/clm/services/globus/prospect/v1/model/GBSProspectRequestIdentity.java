package com.scb.clm.services.globus.prospect.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSProspectRequestIdentity 
{

    @JsonProperty("deviceType")
    String deviceType;

    @JsonProperty("deviceValue")  
    String deviceValue;

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getDeviceValue() {
        return deviceValue;
    }

    public void setDeviceValue(String deviceValue) {
        this.deviceValue = deviceValue;
    }

}