package com.scb.clm.services.globus.prospect.v1.model;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

/*
 * 
 * @author       1378958
 * @version      1.0
 * @since           
 * @use          
 */
@Embeddable
public class ProspectContactEntityKey implements Serializable,Cloneable
{
    private static final long serialVersionUID = 1103847698360379355L;

    @Column(name = "COUNTRY_CODE", nullable = false ,insertable=false, updatable=false)
    private String countryCode;

    @Column(name = "PROSPECT_ID", nullable = false ,insertable=false, updatable=false)
    private String prospectID;

    @Column(name = "CONTACT_TYPE", nullable = false ,insertable=false, updatable=false)
    private String contactType;


    public ProspectContactEntityKey() {

    }

    public ProspectContactEntityKey (String countryCode,String prospectID,String contactType) {
        this.countryCode    = countryCode;
        this.prospectID     = prospectID;
        this.contactType    = contactType;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getProspectID() {
        return prospectID;
    }

    public void setProspectID(String prospectID) {
        this.prospectID = prospectID;
    }

    public String getContactType() {
        return contactType;
    }

    public void setContactType(String contactType) {
        this.contactType = contactType;
    }

    @Override
    public int hashCode() {
        StringBuilder finalHashCode = new StringBuilder();
        if (this.countryCode != null && this.prospectID != null && this.contactType !=null) 
        {
            finalHashCode.append(countryCode);
            finalHashCode.append(prospectID);
            finalHashCode.append(contactType);
        }
        return finalHashCode.toString().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
        {
            return true;
        }
        if ((obj == null) || (obj.getClass() != this.getClass())) 
        {
            return false;
        }
        ProspectContactEntityKey other = (ProspectContactEntityKey) obj;
        return   Objects.equals(this.countryCode, other.countryCode) 
                && Objects.equals(this.prospectID, other.prospectID)
                && Objects.equals(this.contactType, other.contactType);
    }

    @Override
    public Object clone() {
        try {
            return (ProspectContactEntityKey) super.clone();
        } catch (CloneNotSupportedException e) {
            return new ProspectContactEntityKey(this.getCountryCode(),this.getProspectID(),this.getContactType());
        }
    }    
}
