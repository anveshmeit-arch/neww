package com.scb.clm.services.globus.biometric.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSRequestIdWrapper implements Cloneable {
	
    @JsonProperty("application")
    private GBSRequestIdApplication application;

    @JsonProperty("customers")
    private GBSRequestIdCustomers customers;
    
    public GBSRequestIdApplication getApplication() {
		return application == null ? null : (GBSRequestIdApplication) application.clone();
	}
 
	public void setApplication(GBSRequestIdApplication application) {
		this.application = application == null ? null : (GBSRequestIdApplication) application.clone();
	}

	public GBSRequestIdCustomers getCustomers() {
		return customers == null ? null : (GBSRequestIdCustomers) customers.clone();
	}
	
	public void setCustomers(GBSRequestIdCustomers customers) {
		this.customers = customers == null ? null : (GBSRequestIdCustomers) customers.clone();
	}
	
	@Override
	protected Object clone() {
		try {
			return super.clone();
		} catch (CloneNotSupportedException e) {
			return new GBSRequestIdWrapper();
		}
	}
 


}
