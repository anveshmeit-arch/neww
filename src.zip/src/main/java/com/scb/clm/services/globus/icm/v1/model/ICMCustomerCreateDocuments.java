package com.scb.clm.services.globus.icm.v1.model;

import java.sql.Timestamp;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ICMCustomerCreateDocuments {

    @JsonProperty("id")
    private String guid;

    @JsonProperty("documentCategory")
    private String documentCategory;

    @JsonProperty("reference-id")
    private String profileId;

    @JsonProperty("document-type")
    private String documentType;

    @JsonProperty("document-code")
    private String documentCode;

    @JsonProperty("document-number")
    private String documentNumber;

    @JsonProperty("sequence-number")
    private short seqNo;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @JsonProperty("document-receive-dt")
    private Date documentReceiveDt;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @JsonProperty("document-signatory-dt")
    private Date documentSignatoryDt;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @JsonProperty("document-expiry-dt")
    private Date documentExpDt;

    @JsonProperty("tax-residence-country")
    private String taxResidenceCountry;

    @JsonProperty("w8n-support-document-indicator")
    private String w8nSupportDocumentIndicator;

    @JsonProperty("country-treaty")
    private String countryTreaty;

    @JsonProperty("document-evidence-link")
    private String documentEvidenceLink;

    @JsonProperty("doc-remarks")
    private String docRemarks;

    @JsonProperty("doc-reason-code")
    private String docReasonCode;

    @JsonProperty("expiry-check-override")
    private String expiryCheckOverride;

    @JsonProperty("poi-document")
    private String poiDocument;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @JsonProperty("document-due-date")
    private Date documentDueDt;

    @JsonProperty("sender-id")
    private String senderId;

    @JsonProperty("sender-branch")
    private String senderBranch;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    @JsonProperty("created-at")
    private Timestamp createdAt;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    @JsonProperty("updated-at")
    private Timestamp updatedAt;

    @JsonProperty("status")
    private String status;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    @JsonProperty("status-at")
    private Timestamp statusAt;

    @JsonProperty("country-id")
    private String companyId;

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public String getDocumentCode() {
        return documentCode;
    }

    public void setDocumentCode(String documentCode) {
        this.documentCode = documentCode;
    }

    public String getDocumentNumber() {
        return documentNumber;
    }

    public void setDocumentNumber(String documentNumber) {
        this.documentNumber = documentNumber;
    }

    public short getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(short seqNo) {
        this.seqNo = seqNo;
    }

    public Date getDocumentReceiveDt() {
        return documentReceiveDt;
    }

    public void setDocumentReceiveDt(Date documentReceiveDt) {
        this.documentReceiveDt = documentReceiveDt;
    }

    public Date getDocumentSignatoryDt() {
        return documentSignatoryDt;
    }

    public void setDocumentSignatoryDt(Date documentSignatoryDt) {
        this.documentSignatoryDt = documentSignatoryDt;
    }

    public Date getDocumentExpDt() {
        return documentExpDt;
    }

    public void setDocumentExpDt(Date documentExpDt) {
        this.documentExpDt = documentExpDt;
    }

    public String getTaxResidenceCountry() {
        return taxResidenceCountry;
    }

    public void setTaxResidenceCountry(String taxResidenceCountry) {
        this.taxResidenceCountry = taxResidenceCountry;
    }

    public String getW8nSupportDocumentIndicator() {
        return w8nSupportDocumentIndicator;
    }

    public void setW8nSupportDocumentIndicator(String w8nSupportDocumentIndicator) {
        this.w8nSupportDocumentIndicator = w8nSupportDocumentIndicator;
    }

    public String getCountryTreaty() {
        return countryTreaty;
    }

    public void setCountryTreaty(String countryTreaty) {
        this.countryTreaty = countryTreaty;
    }

    public String getDocumentEvidenceLink() {
        return documentEvidenceLink;
    }

    public void setDocumentEvidenceLink(String documentEvidenceLink) {
        this.documentEvidenceLink = documentEvidenceLink;
    }

    public String getDocRemarks() {
        return docRemarks;
    }

    public void setDocRemarks(String docRemarks) {
        this.docRemarks = docRemarks;
    }

    public String getDocReasonCode() {
        return docReasonCode;
    }

    public void setDocReasonCode(String docReasonCode) {
        this.docReasonCode = docReasonCode;
    }

    public String getExpiryCheckOverride() {
        return expiryCheckOverride;
    }

    public void setExpiryCheckOverride(String expiryCheckOverride) {
        this.expiryCheckOverride = expiryCheckOverride;
    }

    public String getPoiDocument() {
        return poiDocument;
    }

    public void setPoiDocument(String poiDocument) {
        this.poiDocument = poiDocument;
    }

    public Date getDocumentDueDt() {
        return documentDueDt;
    }

    public void setDocumentDueDt(Date documentDueDt) {
        this.documentDueDt = documentDueDt;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public String getSenderBranch() {
        return senderBranch;
    }

    public void setSenderBranch(String senderBranch) {
        this.senderBranch = senderBranch;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getStatusAt() {
        return statusAt;
    }

    public void setStatusAt(Timestamp statusAt) {
        this.statusAt = statusAt;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getDocumentCategory() {
        return documentCategory;
    }
    public void setDocumentCategory(String documentCategory) {
        this.documentCategory = documentCategory;
    }

}
