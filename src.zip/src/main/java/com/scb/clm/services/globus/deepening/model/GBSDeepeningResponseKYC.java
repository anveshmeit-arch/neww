package com.scb.clm.services.globus.deepening.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardCustomerNationaliltyWrapper;

import java.util.List;

public class GBSDeepeningResponseKYC {

    @JsonProperty("birthCountry")
    public String birthCountry;

    @JsonProperty("nationality")
    public List<GBSDeepeningResponseNationalilty> nationality;

    public String getBirthCountry() {
        return birthCountry;
    }

    public void setBirthCountry(String birthCountry) {
        this.birthCountry = birthCountry;
    }

    public List<GBSDeepeningResponseNationalilty> getNationality() {
        return nationality;
    }

    public void setNationality(List<GBSDeepeningResponseNationalilty> nationality) {
        this.nationality = nationality;
    }
}
