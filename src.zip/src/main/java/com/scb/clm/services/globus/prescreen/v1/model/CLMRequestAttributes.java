package com.scb.clm.services.globus.prescreen.v1.model;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CLMRequestAttributes
{
    @JsonProperty("id") 
    String id;
    @JsonProperty("type") 
    String type;
    @JsonProperty("customers") 
    ArrayList<CLMRequestCustomers> customers;

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public ArrayList<CLMRequestCustomers> getCustomers() {
        return customers;
    }
    public void setCustomers(ArrayList<CLMRequestCustomers> customers) {
        this.customers = customers;
    }
    public void addCustomers(CLMRequestCustomers argCustomers) {
        if(this.customers == null) {
            this.customers= new ArrayList<CLMRequestCustomers>();     
        }
        this.customers.add(argCustomers);
    }
}