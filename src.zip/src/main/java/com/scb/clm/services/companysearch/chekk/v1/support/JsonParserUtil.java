package com.scb.clm.services.companysearch.chekk.v1.support;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * An utility class for parsing json objects using Jackson data binding library
 *
 */
public class JsonParserUtil {

	private static ObjectMapper mObjectMapper;

	/**
	 * Creates an {@link ObjectMapper} for mapping json objects. Mapper can be
	 * configured here
	 *
	 * @return created {@link ObjectMapper}
	 */
	private static ObjectMapper getMapper() {
		if (mObjectMapper == null) {
			mObjectMapper = new ObjectMapper();
		}
		return mObjectMapper;
	}

	/**
	 * Maps json string to specified class
	 *
	 * @param json   string to parse
	 * @param tClass class of object in which json will be parsed
	 * @param <T>    generic parameter for tClass
	 * @return mapped T class instance
	 * @throws IOException
	 */
	public static <T> T toObject(String json, Class<T> tClass) {
		T retValue = null;
		try {
			retValue = getMapper().readValue(json, tClass);
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return retValue;
	}

	/**
	 * Writes specified object as string
	 *
	 * @param object object to write
	 * @return result json
	 * @throws IOException
	 */
	public static String toJson(Object object) {
		String retValue = "";
		try {
			retValue = getMapper().writeValueAsString(object);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return retValue;
	}
	
	public static String getNodeValue(String json,String key) {
		String retValue = "";
		try {
			JsonNode node = getMapper().readTree(json);
			JsonNode keyNode = node!=null?node.get(key):null;
			retValue = keyNode!=null?keyNode.asText():"";
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return retValue;
	}
}