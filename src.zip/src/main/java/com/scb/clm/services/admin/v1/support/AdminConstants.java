package com.scb.clm.services.admin.v1.support;

/*
 * 
 * @author      
 * @version    1.0
 * @since      
 * @use        Admin Constants  
 */
public class AdminConstants
{

    /* ADMIN CONSTATNTS */
    public static final String HOUSE_KEEPING_GROUP_ID           = "HOUSEKEEP";
    public static final String INBOUND_HOUSE_KEEP_DAYS          = "INBOUND_HOUSE_KEEP_DAYS";
    public static final String INBOUND_HOUSE_KEEP_BATCH_SIZE    = "INBOUND_HOUSE_KEEP_BATCH_SIZE";
    public static final String OUTBOUND_HOUSE_KEEP_DAYS         = "OUTBOUND_HOUSE_KEEP_DAYS";
    public static final String OUTBOUND_HOUSE_KEEP_BATCH_SIZE   = "OUTBOUND_HOUSE_KEEP_BATCH_SIZE";

    public static final String JOB_STATUS_HOUSE_KEEP_DAYS       = "JOB_STATUS_HOUSE_KEEP_DAYS";
    public static final String JOB_STATUS_HOUSE_KEEP_BATCH_SIZE = "JOB_STATUS_HOUSE_KEEP_BATCH_SIZE";
    
    public static final String INVALID_CONFIGURATION            = "AD000001";  


}