package com.scb.clm.services.globus.deepening.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardBankInternalInfoWrapper;

public class GBSDeepeningRequestCustomers {

    public GBSDeepeningRequestCustomers() {
    }

    @JsonProperty("bankInternalInfo")
    private GBSDeepeningRequestBankInternalInfo bankInternalInfo;

    public GBSDeepeningRequestBankInternalInfo getBankInternalInfo() {
        return bankInternalInfo;
    }

    public void setBankInternalInfo(GBSDeepeningRequestBankInternalInfo bankInternalInfo) {
        this.bankInternalInfo = bankInternalInfo;
    }
}
