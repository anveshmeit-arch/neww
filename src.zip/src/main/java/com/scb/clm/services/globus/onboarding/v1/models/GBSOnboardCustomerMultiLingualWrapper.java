package com.scb.clm.services.globus.onboarding.v1.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSOnboardCustomerMultiLingualWrapper {

	@JsonProperty("mfirstName")
	private String mfirstName;
	
	@JsonProperty("mlastName")
	private String mlastName;
	
	@JsonProperty("mfullName")
	private String mfullName;
	
	@JsonProperty("mmiddleName")
	private String mmiddleName;
	
	@JsonProperty("memployerName")
	private String memployerName;
	
	@JsonProperty("mpreferredName")
	private String mpreferredName;
	
	@JsonProperty("mplaceOfBirth")
	private String mplaceOfBirth;

    public String getMfirstName() {
        return mfirstName;
    }

    public void setMfirstName(String mfirstName) {
        this.mfirstName = mfirstName;
    }

    public String getMlastName() {
        return mlastName;
    }

    public void setMlastName(String mlastName) {
        this.mlastName = mlastName;
    }

    public String getMfullName() {
        return mfullName;
    }

    public void setMfullName(String mfullName) {
        this.mfullName = mfullName;
    }

    public String getMmiddleName() {
        return mmiddleName;
    }

    public void setMmiddleName(String mmiddleName) {
        this.mmiddleName = mmiddleName;
    }

    public String getMemployerName() {
        return memployerName;
    }

    public void setMemployerName(String memployerName) {
        this.memployerName = memployerName;
    }

    public String getMpreferredName() {
        return mpreferredName;
    }

    public void setMpreferredName(String mpreferredName) {
        this.mpreferredName = mpreferredName;
    }

    public String getMplaceOfBirth() {
        return mplaceOfBirth;
    }

    public void setMplaceOfBirth(String mplaceOfBirth) {
        this.mplaceOfBirth = mplaceOfBirth;
    }


}
