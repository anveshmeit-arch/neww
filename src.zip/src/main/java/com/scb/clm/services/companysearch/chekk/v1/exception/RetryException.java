package com.scb.clm.services.companysearch.chekk.v1.exception;

public class RetryException extends RuntimeException {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String className;
    private String methodName;
    private String message;

    public RetryException(String className, String methodName, String message) {
        this.className = className;
        this.methodName = methodName;
        this.message = message;
    }

    public RetryException(String msg) {
        message = msg;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        if (className != null && methodName != null && message != null) {
            sb.append("\n--- Exception ---\n").append(" Class Name:").append(className).append("\n Method Name:")
                    .append(methodName).append("\n Message:").append(message);
        }
        return sb.toString();
    }

    @Override
    public String getMessage() {
        return message;
    }
}