package com.scb.clm.services.companysearch.chekk.v1.service;

import java.util.Map;

import org.springframework.util.StringUtils;

import com.scb.clm.services.companysearch.chekk.v1.model.ChekkPartyEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.process.Address;
import com.scb.clm.services.companysearch.chekk.v1.model.process.Association;
import com.scb.clm.services.companysearch.chekk.v1.model.process.Document;
import com.scb.clm.services.companysearch.chekk.v1.model.process.Organisation;
import com.scb.clm.services.companysearch.chekk.v1.support.AddressSplit;
import com.scb.clm.services.companysearch.chekk.v1.support.PartyMapperUtil;
import com.scb.clm.services.companysearch.chekk.v1.support.ProcessApiConstants;

public class EntityPartyMapper implements PartyMapperInterface {
    private ChekkPartyEntity party;
    private ChkTableReferences refData;

    public EntityPartyMapper(ChekkPartyEntity party, ChkTableReferences refData) {
        this.party = party;
        this.refData = refData;
    }

    @Override
    public Address createAddress() {
        Address address = null;
        String intermediateFullAddress = party.getIntermediateIdFullAddress();

        if (intermediateFullAddress != null && !"".equals(intermediateFullAddress)) {
            address = new Address();
            address.setPartyIdentifier(party.getUniqueId());
            address.setAddressType(RESIDENTIAL_ADDRESS);
            addAddressLines(address, party.getIntermediateIdFullAddress());
            address.setPostalCode(party.getIntermediateIdZip());
            address.setCity(party.getIntermediateIdCity());
            address.setState(party.getIntermediateIdState());
            address.setCountry(party.getIntermediateIdCountry());
        }
        return address;
    }

    @Override
    public Association createAssociation() {
        Association association = new Association();
        association.setAssociatedID(party.getUniqueId());
        association.setAssociatedToIDs(party.getAssociatedToId());

        association.setAssociationType(PartyMapperUtil.updateRoleDescription(party.getIntermediateIdRole(), refData));
        association.setPartyRole(party.getIntermediateIdRole());

        association.setOwnershipPercentage(party.getShTotalPercentage());
        association.setSharesAmount(party.getIntermediateShSharesAmount());
        association.setPercentageOfParent(party.getParentPercentage());
        return association;
    }

    @Override
    public String getDuplicateKeyId() {
        StringBuilder duplicateKeyIdBuilder = new StringBuilder();
        if (StringUtils.hasText(party.getPartyType())) {
            duplicateKeyIdBuilder.append(party.getPartyType());
        }
        if (StringUtils.hasText(party.getIntermediateIdCompanyName())) {
            duplicateKeyIdBuilder.append(party.getIntermediateIdCompanyName());
        }
        if (StringUtils.hasText(party.getIntermediateIdCountry())) {
            duplicateKeyIdBuilder.append(party.getIntermediateIdCountry());
        }
        return duplicateKeyIdBuilder.toString();
    }

    /**
     * This is not applicable for Entity Party Type. So default implementation is
     * added.
     * 
     * @param address
     * @param addressStr
     */
    @Override
    public Document createDocument() {
        return null;
    }

    public Organisation createOrganization() {
        Organisation organisation = new Organisation();
        organisation.setLegal(party.getIntermediateIdCompanyName());
        organisation.setOrganisationID(party.getUniqueId());
        organisation.setRegistrationNumber(party.getIntermediateIdCompanyNumber());
        organisation.setCountryOfEstablishment(party.getIntermediateIdCountry());
        organisation.setPercentageOfOwnershipAgainstParent(party.getParentPercentage());

        return organisation;
    }

    public static void addAddressLines(Address address, String addressStr) {
        Map<String, String> map = AddressSplit.addressSplit(addressStr);
        if (!map.get(ProcessApiConstants.ADDRESS_LINE1).equals(""))
            address.setAddressL1(map.get(ProcessApiConstants.ADDRESS_LINE1));
        if (!map.get(ProcessApiConstants.ADDRESS_LINE2).equals(""))
            address.setAddressL2(map.get(ProcessApiConstants.ADDRESS_LINE2));
        if (!map.get(ProcessApiConstants.ADDRESS_LINE3).equals(""))
            address.setAddressL3(map.get(ProcessApiConstants.ADDRESS_LINE3));
    }


}
