package com.scb.clm.services.companysearch.chekk.v1.service;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.util.StringUtils;

import com.scb.clm.services.companysearch.chekk.v1.model.ChekkPartyEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.Regulators;
import com.scb.clm.services.companysearch.chekk.v1.model.process.Address;
import com.scb.clm.services.companysearch.chekk.v1.model.process.Association;
import com.scb.clm.services.companysearch.chekk.v1.model.process.Document;
import com.scb.clm.services.companysearch.chekk.v1.model.process.External;
import com.scb.clm.services.companysearch.chekk.v1.model.process.Group;
import com.scb.clm.services.companysearch.chekk.v1.model.process.IndustryClassifications;
import com.scb.clm.services.companysearch.chekk.v1.model.process.IssuedShares;
import com.scb.clm.services.companysearch.chekk.v1.model.process.Names;
import com.scb.clm.services.companysearch.chekk.v1.model.process.Product;
import com.scb.clm.services.companysearch.chekk.v1.model.process.ValidationStatus;
import com.scb.clm.services.companysearch.chekk.v1.support.AddressSplit;
import com.scb.clm.services.companysearch.chekk.v1.support.DataUtility;
import com.scb.clm.services.companysearch.chekk.v1.support.Log;
import com.scb.clm.services.companysearch.chekk.v1.support.MainEntityFieldNames;
import com.scb.clm.services.companysearch.chekk.v1.support.ProcessApiConstants;

public class MainEntityPartyMapper implements PartyMapperInterface {
    private static final String REGULATOR_NAME = "ACRA";
    private ChekkPartyEntity party;
    private ChkTableReferences refData;

    public MainEntityPartyMapper(ChekkPartyEntity party, ChkTableReferences refData) {
        this.party = party;
        this.refData = refData;

    }

    /**
     * ENTITY_TYPE_CODE and ENTITY_SUBTYPE_CODE values are derieved from
     * leNationalLegalForm values
     * 
     * @param fieldName
     * @return
     */
    public String getValue(MainEntityFieldNames fieldName) {
        String retValue = null;
        switch (fieldName) {
        case ENID:
            retValue = party.getUniqueId();
            break;
        case ENTITY_TYPE_CODE:
            String typeCode = refData.getEntityType(party.getLeNationalLegalForm());
            retValue = (typeCode == null || typeCode.isEmpty()) ? party.getLeNationalLegalForm() : typeCode;
            break;
        case ENTITY_SUBTYPE_CODE:
            retValue = refData.getEntitySubType(party.getLeNationalLegalForm());
            break;
        case REGISTRATION_DATE:
            retValue = getFormattedDate(party.getLeRegistrationDate());
            break;
        case PRIMARY_COUNTRY_OF_OPERATION:
            retValue = party.getIdFullOperatingAddressCountry();
            break;
        case IS_UNWRAPPING_COMPLETED:
            /**
             * TODO: calculated value
             */
            break;
        case TOTAL_UNWRAPPING_PERCENTAGE:
            /**
             * TODO: calculated value
             */
            break;
        case ID_COMMENCEMENT_DATE:
            retValue = getFormattedDate(party.getIdCommencementDate());
            break;
        case ID_RENEWAL_CUTOFF_DATE:
            retValue = getFormattedDate(party.getIdRenewalCutOffDate());
            break;
        case ID_EXPIRY_DATE:
            retValue = getFormattedDate(party.getIdExpiryDate());
            break;
        default:
            break;
        }
        return retValue;
    }

    @Override
    public Address createAddress() {
        Address address = null;
        if (Boolean.TRUE.equals(Boolean.valueOf(party.getIdAddressIsValid()))
                && StringUtils.hasText(party.getIdFullOperatingAddress())) {
            address = new Address();
            address.setPartyIdentifier(party.getUniqueId());
            address.setAddressType(ADDRESS_TYPE_OA);
            addAddressLines(address, party.getIdFullOperatingAddress());
            address.setPostalCode(party.getIdFullOperatingAddressZip());
            address.setCity(party.getIdFullOperatingAddressCity());
            address.setState(party.getIdFullOperatingAddressState());
            address.setCountry(party.getIdFullOperatingAddressCountry());
            try {
                address.setAddressEffectiveDate(
                        DataUtility.parseDate(party.getIdAddressEffectiveDate(), ProcessApiConstants.TARGET_DT_FORMAT));
            } catch (Exception ex) {
                Log.error("MainEntityPartyMapper#createAddress: Exception occured while parsing date" + ex.getMessage(),
                        ex);
            }
        }
        return address;
    }

    public Address createAddressRa() {
        Address address = null;
        if (Boolean.valueOf(party.getIdAddressIsValid()) && StringUtils.hasText(party.getIdFullAddress())) {
            address = new Address();
            address.setPartyIdentifier(party.getUniqueId());
            address.setAddressType(RESIDENTIAL_ADDRESS);
            addAddressLines(address, party.getIdFullAddress());
            address.setPostalCode(party.getIdZip());
            address.setCity(party.getIdCity());
            address.setState(party.getIdState());
            address.setCountry(party.getIdCountry());
            try {
                address.setAddressEffectiveDate(
                        DataUtility.parseDate(party.getIdAddressEffectiveDate(), ProcessApiConstants.TARGET_DT_FORMAT));
            } catch (Exception ex) {
                Log.error(
                        "MainEntityPartyMapper#createAddressRa: Exception occured while parsing date" + ex.getMessage(),
                        ex);
            }
        }
        return address;
    }

    @Override
    public Association createAssociation() {
        return null;
    }

    @Override
    public String getDuplicateKeyId() {
        return null;
    }

    @Override
    public Document createDocument() {
        return null;
    }

    public static void addAddressLines(Address address, String addressStr) {
        Map<String, String> map = AddressSplit.addressSplit(addressStr);
        if (!map.get(ProcessApiConstants.ADDRESS_LINE1).equals("")) {
            address.setAddressL1(map.get(ProcessApiConstants.ADDRESS_LINE1));
        }
        if (!map.get(ProcessApiConstants.ADDRESS_LINE2).equals("")) {
            address.setAddressL2(map.get(ProcessApiConstants.ADDRESS_LINE2));
        }
        if (!map.get(ProcessApiConstants.ADDRESS_LINE3).equals("")) {
            address.setAddressL3(map.get(ProcessApiConstants.ADDRESS_LINE3));
        }
    }

    public List<IssuedShares> createIssuedShares() {
        MainEntSharesTypeMapper sharesTypeMapper = new MainEntSharesTypeMapper(party);
        return sharesTypeMapper.createIssuedShares();
    }

    public ValidationStatus createValidationStatus() {
        ValidationStatus validationStatus = new ValidationStatus();
        validationStatus.setStatusCode(party.getIdStatus());
        String formatEffDate = null;
        try {
            formatEffDate = DataUtility.parseDate(party.getIdStatusEffectiveDate(),
                    ProcessApiConstants.TARGET_DT_FORMAT);
        } catch (Exception ex) {
            Log.error("MainEntityPartyMapper#createValidationStatus: Exception occured while parsing date"
                    + ex.getMessage(), ex);
        }
        validationStatus.setStatusEffectiveDateTime(formatEffDate);
        return validationStatus;
    }

    public Names createNames() {
        Names names = new Names();
        names.setLegal(party.getIdCompanyName());
        names.setAlias1(party.getIdFormernames());
        // CR-5636496
        String formatEffDate = null;
        try {
            formatEffDate = DataUtility.parseDate(party.getIdNameEffectiveDate(), ProcessApiConstants.TARGET_DT_FORMAT);
        } catch (Exception ex) {
            Log.error("MainEntityPartyMapper#createNames: Exception occured while parsing date" + ex.getMessage(), ex);
        }
        names.setNameEffectiveDate(formatEffDate);
        return names;
    }

    public External createExternal() {
        External external = new External();
        external.setRegistrationNumber(party.getIdCompanyNumber());
        return external;
    }

    /**
     * ISIC code is not obtained from Chekk, it is derieved based on SSIC code value
     * received from chekk.
     * 
     * @return
     */
    public IndustryClassifications createIndustryClassification() {
        IndustryClassifications indClassifications = new IndustryClassifications();
        indClassifications.setNace(party.getIdNaceCode());
        indClassifications.setNaics(party.getIdNaicsCode());

        indClassifications.setSsic(party.getIdPrimarySsicCode());
        if (StringUtils.hasText(party.getIdSecondarySsicCode())) {
            indClassifications.setOtherSSIC(Arrays.asList(party.getIdSecondarySsicCode()));
        }

        indClassifications.setIsic(refData.getIsicFromSsicCode(party.getIdPrimarySsicCode()));
        if (StringUtils.hasText(party.getIdSecondarySsicCode())) {
            indClassifications
                    .setOtherISIC(Arrays.asList(refData.getIsicFromSsicCode((party.getIdSecondarySsicCode()))));
        }

        indClassifications.setIdPrimaryIndustryLabel(party.getIdPrimarySsicLabel());
        indClassifications.setIdSecondaryIndustryLabel(party.getIdSecondarySsicLabel());
        indClassifications.setIdPrimarySsicOtherDescription(party.getIdPrimarySsicOtherDescription());
        indClassifications.setIdSecondarySsicOtherDescription(party.getIdSecondarySsicOtherDescription());
        return indClassifications;
    }

    public Group createGroup() {
        Group group = null;
        if (StringUtils.hasText(party.getIdHomeCompanyName())) {
            group = new Group();
            group.setGroupName(party.getIdHomeCompanyName());
        }
        return group;
    }

    public Product createProduct() {
        Product product = null;
        if (StringUtils.hasText(party.getFiRevenue()) || StringUtils.hasText(party.getFiAccountCurrency())
                || StringUtils.hasText(party.getLeNationalLegalForm())) {
            product = new Product();
            product.setSalesTurnoverAnnual(
                    StringUtils.hasText(party.getFiRevenue()) ? Integer.valueOf(party.getFiRevenue()) : null);
            product.setSalesCurrency(party.getFiCompanyCurrency());
            product.setComments(party.getLeNationalLegalForm());
        }
        return product;
    }

    public Regulators createRegulator() {
        Regulators regulators = new Regulators();
        regulators.setRequestPulledDatetime(party.getCreationDate());
        regulators.setRegulatorName(REGULATOR_NAME);
        return regulators;
    }

    private String getFormattedDate(String dateValue) {
        String formattedDate = null;
        try {
            formattedDate = DataUtility.parseDate(dateValue, ProcessApiConstants.TARGET_DT_FORMAT);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return formattedDate;
    }

}