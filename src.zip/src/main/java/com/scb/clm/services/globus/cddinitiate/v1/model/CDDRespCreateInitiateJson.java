package com.scb.clm.services.globus.cddinitiate.v1.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)  
public class CDDRespCreateInitiateJson {

    @JsonProperty("id")
    private String id;

    @JsonProperty("applicant-reference-key")
    private String applicant_reference_key;

    @JsonProperty("risk-rating")
    private String risk_rating;

    @JsonProperty("cdd-status")
    private String cdd_status;

    @JsonProperty("stp-flag")
    private String stp_flag;

    @JsonProperty("onboarding-reference-key")
    private String onboarding_reference_key;

    @JsonProperty("name-screening-hit")
    private String name_screening_hit;

    @JsonProperty("name-screening-alert-id")
    private String name_screening_alert_id;

    @JsonProperty("account-references")
    private List<CDDRespAccountReferencesInitiateJson> account_references; 

    @JsonProperty("errors")
    private List<CDDRespErrorsInitiateJson> errors_references;

    @JsonProperty("errorExists")
    private boolean errorExists;

    @JsonProperty("errorsAsJSON")
    private String errorsAsJSON;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getApplicant_reference_key() {
        return applicant_reference_key;
    }

    public void setApplicant_reference_key(String applicant_reference_key) {
        this.applicant_reference_key = applicant_reference_key;
    }

    public String getRisk_rating() {
        return risk_rating;
    }

    public void setRisk_rating(String risk_rating) {
        this.risk_rating = risk_rating;
    }

    public String getCdd_status() {
        return cdd_status;
    }

    public void setCdd_status(String cdd_status) {
        this.cdd_status = cdd_status;
    }

    public String getStp_flag() {
        return stp_flag;
    }

    public void setStp_flag(String stp_flag) {
        this.stp_flag = stp_flag;
    }

    public String getOnboarding_reference_key() {
        return onboarding_reference_key;
    }

    public void setOnboarding_reference_key(String onboarding_reference_key) {
        this.onboarding_reference_key = onboarding_reference_key;
    }

    public String getName_screening_hit() {
        return name_screening_hit;
    }

    public void setName_screening_hit(String name_screening_hit) {
        this.name_screening_hit = name_screening_hit;
    }

    public String getName_screening_alert_id() {
        return name_screening_alert_id;
    }

    public void setName_screening_alert_id(String name_screening_alert_id) {
        this.name_screening_alert_id = name_screening_alert_id;
    }

    public List<CDDRespAccountReferencesInitiateJson> getAccount_references() {
        return account_references;
    }

    public void setAccount_references(List<CDDRespAccountReferencesInitiateJson> account_references) {
        this.account_references = account_references;
    }

    public List<CDDRespErrorsInitiateJson> getErrors_references() {
        return errors_references;
    }

    public void setErrors_references(List<CDDRespErrorsInitiateJson> errors_references) {
        this.errors_references = errors_references;
    }

    public boolean isErrorExists() {
        return errorExists;
    }

    public void setErrorExists(boolean errorExists) {
        this.errorExists = errorExists;
    }

    public String getErrorsAsJSON() {
        return errorsAsJSON;
    }

    public void setErrorsAsJSON(String errorsAsJSON) {
        this.errorsAsJSON = errorsAsJSON;
    } 
}
