package com.scb.clm.services.globus.deepening.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSDeepeningRequestBankInternalInfo {
    @JsonProperty("coreBankingReferenceKey")
    private String coreBankingReferenceKey;

    @JsonProperty("customerMasterReferenceKey")
    private String customerMasterReferenceKey;

    public GBSDeepeningRequestBankInternalInfo() {
    }

    public String getCoreBankingReferenceKey() {
        return coreBankingReferenceKey;
    }

    public void setCoreBankingReferenceKey(String coreBankingReferenceKey) {
        this.coreBankingReferenceKey = coreBankingReferenceKey;
    }

    public String getCustomerMasterReferenceKey() {
        return customerMasterReferenceKey;
    }

    public void setCustomerMasterReferenceKey(String customerMasterReferenceKey) {
        this.customerMasterReferenceKey = customerMasterReferenceKey;
    }
}
