package com.scb.clm.services.companysearch.chekk.v1.service;

import java.util.List;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.codesetup.NodesEntity;
import com.scb.clm.common.model.transactions.NodeStatus;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.core.service.DecisionMakerInterface;
import com.scb.clm.services.companysearch.chekk.v1.support.Log;

public class SearchCompanyDecisionMaker implements DecisionMakerInterface {

    @Override
    public void isGoodToProceed(TravellingObject travelObj, NodesEntity nodesEntity, List<NodeServicesEntity> service,
            NodeStatus nodeStatus) {
        Log.info("SearchCompanyDecisionMaker#isGoodToProceed: Inside SearchCompanyDecisionMaker.isGoodToProceed");
        try {
            for (NodeServicesEntity services : service) {
                ServiceStatus stat = travelObj.getServiceStatus(services.getId());
                if (!stat.getStatus().equals(BaseConstants.SERVICE_SUCCESS)) {
                    Log.info("SearchCompanyDecisionMaker#isGoodToProceed: service Failed For " + stat.printKey());
                    nodeStatus.setProcessToNextNode(false);
                }
            }
            Log.info(
                    "SearchCompanyDecisionMaker#isGoodToProceed: searchCompany Decision Maker - Service Failure Status ["
                            + ((nodeStatus.isProcessToNextNode()) ? "Success" : "Failure") + "]");
        } catch (Exception e) {
            Log.error("SearchCompanyDecisionMaker#isGoodToProceed: Exception - " + e.getMessage(), e);
        }

    }

    @Override
    public void buildResponse(TravellingObject travelObj, NodesEntity nodesEntity, List<NodeServicesEntity> service,
            boolean isSuccess) throws ProcessException {
        Log.info("SearchCompanyDecisionMaker#buildResponse: Building Response Data search company[" + isSuccess + "]");
        // FSRCH-NSRCH-SSRCH
        ServiceStatus serviceStatus = travelObj.getServiceStatus().get("FSRCH-NSRCH-SSRCH");
        travelObj.setResponseData(serviceStatus.getResponsePayload());
    }
}
