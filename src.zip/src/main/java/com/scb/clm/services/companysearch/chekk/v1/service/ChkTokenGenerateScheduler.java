package com.scb.clm.services.companysearch.chekk.v1.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Service;

import com.scb.clm.common.util.SystemUtility;
import com.scb.clm.services.companysearch.chekk.v1.support.ChkConfigProperties;
import com.scb.clm.services.companysearch.chekk.v1.support.Log;
import com.scb.clm.services.companysearch.chekk.v1.support.ProcessApiConstants;

import jakarta.annotation.PostConstruct;

@Service

public class ChkTokenGenerateScheduler {
    @Autowired
    private TaskScheduler tokenTaskSchduler;
    @Autowired
    private ChkConfigProperties configProperties;
    @Autowired
    private ChkTokenManager tknManager;

    @PostConstruct
    public void schduleJobs() {
        String serviceName = SystemUtility.getServiceName();
        if (ProcessApiConstants.CHEKK_SERVICE_NAME.equalsIgnoreCase(serviceName)) {
            Runnable task1 = this::regenerateTokens;
            tokenTaskSchduler.schedule(task1, new CronTrigger(configProperties.getTokenRefreshScheduler()));
        } else {
            Log.info("ChkTokenGenerateScheduler#schduleJobs: ChkTokenGenerateScheduler services not started for this service "
                    + serviceName);
        }
    }

    public void regenerateTokens() {
        Log.debug("ChkTokenGenerateScheduler: Invoking Token Refresh Scheduler");
        tknManager.generateToken(configProperties.getTokenRefreshIntervalInMts());
        Log.debug("ChkTokenGenerateScheduler:regenerateTokens: Token generation completed");
    }

}
