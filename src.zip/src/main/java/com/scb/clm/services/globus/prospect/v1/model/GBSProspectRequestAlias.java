package com.scb.clm.services.globus.prospect.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSProspectRequestAlias 
{

    @JsonProperty("aliasType")
    private String aliasType;
    
    @JsonProperty("aliasName")
    private String aliasName;
    
    @JsonProperty("sequenceNumber")
    private short sequenceNumber;
    
    @JsonProperty("langId")
    private String langId;

    public GBSProspectRequestAlias () {       
    }

    public String getAliasType() {
        return aliasType;
    }

    public void setAliasType(String aliasType) {
        this.aliasType = aliasType;
    }

    public String getAliasName() {
        return aliasName;
    }

    public void setAliasName(String aliasName) {
        this.aliasName = aliasName;
    }

    public short getSequenceNumber() {
        return sequenceNumber;
    }

    public void setSequenceNumber(short sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public String getLangId() {
        return langId;
    }

    public void setLangId(String langId) {
        this.langId = langId;
    }


}

