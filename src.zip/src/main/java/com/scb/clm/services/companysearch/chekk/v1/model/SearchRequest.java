package com.scb.clm.services.companysearch.chekk.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SearchRequest {

	@JsonProperty("applicationReferenceNumber")
	private String ApplicationReferenceNumber;

	@JsonProperty("entityName")
	private String entityName;

	@JsonProperty("countryOfAccountOpening")
	private String countryOfAccountOpening;

	@JsonProperty("registrationID")
	private String registrationID;

	@JsonProperty("clientEntityType")
	private String clientEntityType;

	@JsonProperty("countryOfRegistration")
	private String countryOfRegistration;

	@JsonProperty("searchDepth")
	private String searchDepth;
}
