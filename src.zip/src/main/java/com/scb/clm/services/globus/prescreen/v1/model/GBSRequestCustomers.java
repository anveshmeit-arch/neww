package com.scb.clm.services.globus.prescreen.v1.model;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSRequestCustomers 
{
    @JsonProperty("firstName")
    String firstName;

    @JsonProperty("middleName")
    String middleName;

    @JsonProperty("lastName")
    String lastName;

    @JsonProperty("fullName")
    String fullName;

    @JsonProperty("dateOfBirth")
    String dateOfBirth;

    @JsonProperty("contacts")
    ArrayList<GBSRequestContacts> dedupeContacts;

    @JsonProperty("documents")
    ArrayList<GBSRequestDocuments> dedupeDocuments;

    @JsonProperty("address")
    ArrayList<GBSRequestAddress> dedupeAddress;

    @JsonProperty("digitalIdentity")
    ArrayList<GBSRequestIdentity> dedupeDigitalIdentity;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public ArrayList<GBSRequestContacts> getDedupeContacts() {
        return dedupeContacts;
    }

    public void setDedupeContacts(ArrayList<GBSRequestContacts> dedupeContacts) {
        this.dedupeContacts = dedupeContacts;
    }

    public ArrayList<GBSRequestDocuments> getDedupeDocuments() {
        return dedupeDocuments;
    }

    public void setDedupeDocuments(ArrayList<GBSRequestDocuments> dedupeDocuments) {
        this.dedupeDocuments = dedupeDocuments;
    }

    public ArrayList<GBSRequestAddress> getDedupeAddress() {
        return dedupeAddress;
    }

    public void setDedupeAddress(ArrayList<GBSRequestAddress> dedupeAddress) {
        this.dedupeAddress = dedupeAddress;
    }

    public ArrayList<GBSRequestIdentity> getDedupeDigitalIdentity() {
        return dedupeDigitalIdentity;
    }

    public void setDedupeDigitalIdentity(ArrayList<GBSRequestIdentity> dedupeDigitalIdentity) {
        this.dedupeDigitalIdentity = dedupeDigitalIdentity;
    }

    public void addContacts(GBSRequestContacts argContacts) {
        if(this.dedupeContacts == null) {
            this.dedupeContacts = new ArrayList<GBSRequestContacts>();     
        }
        this.dedupeContacts.add(argContacts);
    }

    public void addDocuments(GBSRequestDocuments argDocuments) {
        if(this.dedupeDocuments == null) {
            this.dedupeDocuments= new ArrayList<GBSRequestDocuments>();     
        }
        this.dedupeDocuments.add(argDocuments);
    }
}