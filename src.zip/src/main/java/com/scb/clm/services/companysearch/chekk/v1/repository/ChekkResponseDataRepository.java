package com.scb.clm.services.companysearch.chekk.v1.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.scb.clm.services.companysearch.chekk.v1.model.ChekkResponseDataEntity;

@Repository
public interface ChekkResponseDataRepository extends JpaRepository<ChekkResponseDataEntity, String> { 

    @Override
    public <S extends ChekkResponseDataEntity> S save(S entity);

    @Override
    public <S extends ChekkResponseDataEntity> S saveAndFlush(S entity);
    
    @Override
    public ChekkResponseDataEntity getOne(String arg0);
    
    public ChekkResponseDataEntity findByRequestIdAndSearchEntityIdAndResTypeAndStatus(String reqId, String searchId, String resType, String status);
    
//TODO remove this duplicate method
    ChekkResponseDataEntity findByResTypeAndStatusAndSearchEntityIdAndRequestId(String resType, String status, String searchEntityId, String requestId);

}