package com.scb.clm.services.globus.prescreen.v1.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.scb.clm.common.config.ApplicationConfiguration;
import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.config.ContactServerInfo;
import com.scb.clm.common.exception.ErrorObject;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.repository.InterfaceRequestTypeRepository;
import com.scb.clm.common.util.DateTimeUtility;
import com.scb.clm.common.util.JSONUtility;
import com.scb.clm.common.util.ServiceParameterUtility;
import com.scb.clm.common.util.StringUtility;
import com.scb.clm.core.service.ServiceAbstract;
import com.scb.clm.core.service.ServiceInterface;
import com.scb.clm.services.globus.icm.v1.model.CLMResponsesAttributes;
import com.scb.clm.services.globus.icm.v1.model.ICMResponseWrapper;
import com.scb.clm.services.globus.icm.v1.support.ICMConstants;
import com.scb.clm.services.globus.prescreen.v1.model.CLMRequestAttributes;
import com.scb.clm.services.globus.prescreen.v1.model.CLMRequestContacts;
import com.scb.clm.services.globus.prescreen.v1.model.CLMRequestCustomers;
import com.scb.clm.services.globus.prescreen.v1.model.CLMRequestData;
import com.scb.clm.services.globus.prescreen.v1.model.CLMRequestDocuments;
import com.scb.clm.services.globus.prescreen.v1.model.CLMRequestWrapper;
import com.scb.clm.services.globus.prescreen.v1.model.CLMResponseContacts;
import com.scb.clm.services.globus.prescreen.v1.model.CLMResponseCustomers;
import com.scb.clm.services.globus.prescreen.v1.model.CLMResponseDocuments;
import com.scb.clm.services.globus.prescreen.v1.model.CLMResponseErrorDetails;
import com.scb.clm.services.globus.prescreen.v1.model.CLMResponseWrapper;
import com.scb.clm.services.globus.prescreen.v1.model.GBSRequestContacts;
import com.scb.clm.services.globus.prescreen.v1.model.GBSRequestCustomers;
import com.scb.clm.services.globus.prescreen.v1.model.GBSRequestDocuments;
import com.scb.clm.services.globus.prescreen.v1.model.GBSRequestWrapper;
import com.scb.clm.services.globus.prescreen.v1.model.GBSResponseContacts;
import com.scb.clm.services.globus.prescreen.v1.model.GBSResponseDedupMatch;
import com.scb.clm.services.globus.prescreen.v1.model.GBSResponseDedupeStatus;
import com.scb.clm.services.globus.prescreen.v1.model.GBSResponseDigitalIdentity;
import com.scb.clm.services.globus.prescreen.v1.model.GBSResponseDocuments;
import com.scb.clm.services.globus.prescreen.v1.model.GBSResponseWrapper;
import com.scb.clm.services.globus.prescreen.v1.support.PrescreenConstants;

@Service
public class PrescreenService extends ServiceAbstract implements ServiceInterface
{

    @Autowired
    InterfaceRequestTypeRepository interfaceRequestTypeRepository;

    @Autowired
    RestTemplate restTemplate;
    
    @Autowired
    ApplicationConfiguration appConfiguration;
    
	

     
 
     
	
    
   
   
    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object readRequestObject(TravellingObject travellingObject, NodeServicesEntity srvEntity) throws ProcessException
    {
        try
        {
            return JSONUtility.jsonTODomainWrapper(travellingObject.getRequestData(),GBSRequestWrapper.class);
        }
        catch(Exception e) 
        {
            ProcessException gbxEx = new ProcessException();
            gbxEx.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, BaseConstants.VALIDATION_ERROR,"INVALID REQUEST MESSAGE FORMAT FOR PROSPECT SERVICE"));
            throw gbxEx;
        }
        finally
        {
            // N.A
        }
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public void validateData(TravellingObject travellingObject,NodeServicesEntity srvEntity,Object requestPayload) throws ProcessException 
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateData", LogType.APPLICATION.name());
        List<ErrorObject> errorObjectList = new ArrayList<ErrorObject>();

        try 
        {
            log.println("[Validating] [Pre-Screening] [Thread "+Thread.currentThread()+"]");

            GBSRequestWrapper requestWrapper    =   (GBSRequestWrapper) requestPayload;
            GBSRequestCustomers customers       =   null;

            if(requestWrapper == null) 
            {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, PrescreenConstants.INVALID_JSON_FORMAT,"INVALID REQUEST"));
                throw new Exception();
            } 
            else if( (requestWrapper.getApplication() == null || !StringUtility.containsData(requestWrapper.getApplication().getApplicationReferenceNumber()))) 
            {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, PrescreenConstants.INVALID_APPLICATION_REFERENCE_NUMBER,"INVALID APPLICATION REFERENCE NUMBER"));
            }

            if(!StringUtility.minMaxlength(requestWrapper.getApplication().getApplicationReferenceNumber(),"0","50"))
            {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, PrescreenConstants.INVALID_APPLICATION_REFERENCE_NUMBER,"INVALID APPLICATION REFERENCE NUMBER ["+requestWrapper.getApplication().getApplicationReferenceNumber()+"] [DATA LENGTH SHOULD BE IN RANGE 1-50]"));
            }
            else 
            {
            	travellingObject.setApplicationReferenceNumber(requestWrapper.getApplication().getApplicationReferenceNumber());
            }
            
            /*** Customer Data Validation **/
            if(requestWrapper != null && requestWrapper.getCustomers() != null) {
                customers = requestWrapper.getCustomers();
            }

            if(customers==null) {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, PrescreenConstants.INVALID_JSON_FORMAT,"INVALID CUSTOMER DATA BLOCK"));
            }
            else {
                if(!StringUtility.minMaxlength(customers.getFirstName(),"0","35")) {
                    errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, PrescreenConstants.INVALID_FIRST_NAME,"INVALID FIRST NAME ["+customers.getFirstName()+"]"));
                }
    
                if(!StringUtility.minMaxlength(customers.getMiddleName(),"0","35")) {
                    errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, PrescreenConstants.INVALID_MIDDLE_NAME,"INVALID MIDDLE NAME ["+customers.getMiddleName()+"]"));
                }
    
                if(!StringUtility.minMaxlength(customers.getLastName(),"0","35")) {
                    errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, PrescreenConstants.INVALID_LAST_NAME,"INVALID LAST NAME ["+customers.getLastName()+"]"));
                }
    
                if(!StringUtility.minMaxlength(customers.getFullName(),"0","110")) {
                    errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, PrescreenConstants.INVALID_FULL_NAME,"INVALID FULL NAME ["+customers.getFullName()+"]"));                
                }
    
                if(StringUtility.containsData(customers.getDateOfBirth()) && !DateTimeUtility.isValidFormat("yyyy-MM-dd",customers.getDateOfBirth()) && !DateTimeUtility.isValidDateRegex(customers.getDateOfBirth())) {
                    errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, PrescreenConstants.INVALID_DATE_OF_BIRTH,"INVALID DATE OF BIRTH ["+customers.getDateOfBirth()+"]"));
                }
            }

            /** MANDATORY VALIDATIONS **/
            HashMap<String,String> mandatoryData = ServiceParameterUtility.getParameterList(srvEntity.getNodeServicesMapper(), PrescreenConstants.MANDATORY_PARAMETER_GROUP);
            if(isMandatory(mandatoryData,PrescreenConstants.MANDATORY_FIRST_NAME) && !StringUtility.containsData(customers.getFirstName())) {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, PrescreenConstants.FIRST_NAME_MANDATORY,"FIRST NAME IS MANDATORY"));
            }
            if(isMandatory(mandatoryData,PrescreenConstants.MANDATORY_FULL_NAME) && !StringUtility.containsData(customers.getFullName())) {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, PrescreenConstants.FULL_NAME_MANDATORY,"FULL NAME IS MANDATORY"));
            }
            if(isMandatory(mandatoryData,PrescreenConstants.MANDATORY_DATE_OF_BIRTH) && !StringUtility.containsData(customers.getDateOfBirth())) {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, PrescreenConstants.DATE_OF_BIRTH_MANDATORY,"DATE OF BIRTH IS MANDATORY"));
            }
            if(isMandatory(mandatoryData,PrescreenConstants.MANDATORY_DOCUMENT) && customers.getDedupeDocuments()!=null && customers.getDedupeDocuments().size()==0) {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, PrescreenConstants.DOCUMENT_DATA_MANDATORY,"MINIMUM ONE DOCUMENT IS MANDATORY"));  
            }
            
            // CONTACTS 
            if(customers.getDedupeContacts() != null) 
            {
                for(GBSRequestContacts con :customers.getDedupeContacts())
                {
                    if(!StringUtility.minMaxlength(con.getContactTypeCode(),"1","3")) {
                        errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, PrescreenConstants.INVALID_CONTACT_TYPE,"INVALID CONTACT TYPE CODE ["+con.getContactTypeCode()+"]"));                
                    }
                    
                    if(!StringUtility.minMaxlength(con.getContact(),"1","50")) {
                        errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, PrescreenConstants.INVALID_CONTACT,"INVALID CONTACT ["+con.getContact()+"]"));                
                    }
                }
            }

            // DOCUMENTS
            if(customers.getDedupeDocuments() != null)
            {
                for(GBSRequestDocuments doc :customers.getDedupeDocuments())
                {
                    if(!StringUtility.minMaxlength(doc.getDocumentType(),"1","3")) {
                        errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, PrescreenConstants.INVALID_DOCUMENT_TYPE,"INVALID DOCUMENT TYPE CODE ["+doc.getDocumentType()+"]"));
                    }
                    if(!StringUtility.minMaxlength(doc.getDocumentNumber(),"1","30")) {
                        errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, PrescreenConstants.INVALID_DOCUMENT_NUMBER,"INVALID CONTACT ["+doc.getDocumentNumber()+"]"));         
                    }
                }
            }
            
            if(errorObjectList.size()> 0) {
                ProcessException gbxEx = new ProcessException();
                gbxEx.addAll(errorObjectList);
                throw gbxEx;
            }
        }
        catch (ProcessException e)
        {
            log.println(" Error ["+e.getAllErrors()+"]");
            throw e;
        }
        catch (Exception e)
        {
            log.printErrorMessage(e);
            errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_TECHNICAL, PrescreenConstants.DEDUPE_INTERNAL_ERROR,"INTERNAL ERROR"));
            ProcessException gbxEx = new ProcessException();
            gbxEx.addAll(errorObjectList);
            throw gbxEx; 
        }
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object constructOutboundObject(TravellingObject travellingObject,NodeServicesEntity srvEntity,Object requestPayload) throws ProcessException
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "constructOutboundObject", LogType.APPLICATION.name());
        try
        {
            log.println("[PrescreenService] [constructOutboundObject] ");

            GBSRequestWrapper requestWrapper = (GBSRequestWrapper) requestPayload;

            if(requestWrapper == null || requestWrapper.getCustomers() == null)
            {
                throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, BaseConstants.VALIDATION_ERROR,"BASIC INFORMATION ('customers') TAG IS NULL");
            }

            CLMRequestCustomers customers  = new CLMRequestCustomers();
            customers.setFirstname(requestWrapper.getCustomers().getFirstName());
            customers.setMiddlename(requestWrapper.getCustomers().getMiddleName());
            customers.setLastname(requestWrapper.getCustomers().getLastName());
            customers.setFullname(requestWrapper.getCustomers().getFullName());
            customers.setDateofbirth(requestWrapper.getCustomers().getDateOfBirth());

            if(requestWrapper != null && requestWrapper.getCustomers() != null && requestWrapper.getCustomers().getDedupeContacts() != null) {
            for(GBSRequestContacts con :requestWrapper.getCustomers().getDedupeContacts())
            {
                CLMRequestContacts cont = new CLMRequestContacts();
                cont.setContacttypecode(con.getContactTypeCode());
                cont.setContact(con.getContact());
                customers.addContacts(cont);
            }
            }

            if(requestWrapper != null && requestWrapper.getCustomers() != null && requestWrapper.getCustomers().getDedupeDocuments() != null) {
            for(GBSRequestDocuments doc :requestWrapper.getCustomers().getDedupeDocuments())
            {
                CLMRequestDocuments  docs = new CLMRequestDocuments();
                docs.setDocumenttype(doc.getDocumentType());
                docs.setDocumentnumber(doc.getDocumentNumber());
                customers.addDocuments(docs);
            }
            }

            CLMRequestAttributes attributes  = new CLMRequestAttributes();
            attributes.addCustomers(customers);

            CLMRequestData requestData  = new CLMRequestData();
            requestData.setAttributes(attributes);
            requestData.setId(null);
            requestData.setType("customerDedup");

            CLMRequestWrapper clmRequestWrapper = new CLMRequestWrapper();
            clmRequestWrapper.setData(requestData);

            log.println("GLOBUS Request JSON # "+JSONUtility.domainWrapperToJSON(requestWrapper));

            return clmRequestWrapper;
        }
        catch (Exception e)
        {
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, PrescreenConstants.VALIDATION_ERROR," INTERNAL ERROR WHILE PAYLOAD CONSTRUCTION ");
        }
        finally
        {
            //N.A
        }
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object process(TravellingObject travellingObject,NodeServicesEntity srvEntity,ServiceStatus serviceStatus,Object outBoundRequestObject) throws ProcessException
    {
        LoggerUtil log                          = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "process", LogType.APPLICATION.name());
        CLMResponseWrapper dedupeResponseData   = null;

        try
       {
            serviceStatus.setInterfaceId(PrescreenConstants.DEDUPE_INTERFACE_ID);

            CLMRequestWrapper outBoundData = (CLMRequestWrapper) outBoundRequestObject;
            String jsonString = (String)JSONUtility.domainWrapperToJSON(outBoundData, CLMRequestWrapper.class);
            
            log.println("Request Orchestrated to ICM : "+ jsonString);
            log.println("Country Region : "+ travellingObject.getServiceContext().getCountryCodeWithRegion());

            String hostServiceURL = interfaceRequestTypeRepository.getInterfaceURL(travellingObject.getServiceContext().getCountryCodeWithRegion(),BaseConstants.INERFACE_ICM,BaseConstants.SERVICE_DEDUP,"OB", BaseConstants.CODE_SETUP_ACTIVE);
            log.println("Dedupe URL # "+ hostServiceURL);
            
            ContactServerInfo contactServerInfo = new ContactServerInfo(travellingObject.getCountryCode(),hostServiceURL, BaseConstants.ICM_SCOPE, travellingObject.getTransactionID(), travellingObject.getInterfaceId(), jsonString, BaseConstants.POST_PROTOCOL, null);
            contactServerInfo = ApplicationConfiguration.getInstance().contactServer(contactServerInfo,travellingObject);
            
            log.println("[ICM Raw Response] \n "+contactServerInfo.getResponseMessage()); 
            dedupeResponseData = (CLMResponseWrapper) JSONUtility.jsonTODomainWrapper(contactServerInfo.getResponseMessage(), CLMResponseWrapper.class);
            
            log.println("[CLM Response Data] \n - "+JSONUtility.domainWrapperToJSON(dedupeResponseData));
            serviceStatus.setHttpStatus(contactServerInfo.getHttpResponseCode()+"");
            
            if(contactServerInfo!=null && contactServerInfo.getHttpResponseCode()!=null && contactServerInfo.getHttpResponseCode().charAt(0)!='2') 
            {
                if(contactServerInfo.getHttpResponseCode().charAt(0) == BaseConstants.HTTP_4XX_SERIES) 
                {
                    throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,PrescreenConstants.CLM_REQUEST_ERROR,"CLM RETURNED TECHNICAL ERROR");
                }
                else if(contactServerInfo.getHttpResponseCode().charAt(0) == BaseConstants.HTTP_5XX_SERIES)
                {
                    throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,PrescreenConstants.CLM_REQUEST_ERROR,"CLM CONNECTIVITY ERROR - RETRY");
                }
                else
                {
                    throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,PrescreenConstants.CLM_REQUEST_ERROR,"CLM CONNECTIVITY ERROR");
                }
            } 
            else {
                //N.A
            }

        }
        catch (HttpStatusCodeException ex) 
        {
            log.println("Raw Code ["+ex.getRawStatusCode()+"] Status Code ["+ex.getStatusCode().toString()+"]");
            serviceStatus.setHttpStatus(""+ex.getRawStatusCode());
            log.println(ex.getResponseBodyAsString());
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, PrescreenConstants.CLM_REQUEST_ERROR," INTERNAL ERROR WHILE SERVICE PROCESSING WITH CLM [HTTP ERROR]");
        }
        catch(ProcessException e)
        {
            throw e;
        }
        catch(Exception e)
        {
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, PrescreenConstants.CLM_REQUEST_ERROR," INTERNAL ERROR WHILE SERVICE PROCESSING WITH CLM");
        }
		
        return dedupeResponseData;
    }


   
   
   
    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object constructServiceResponse(TravellingObject travellingObject,NodeServicesEntity srvEntity, Object clmResponseData,ServiceStatus serviceStatus) throws ProcessException
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "constructServiceResponse", LogType.APPLICATION.name());
        GBSResponseWrapper dedupeResponse = new GBSResponseWrapper();
        ArrayList<GBSResponseDedupMatch> exactmatch = new ArrayList<GBSResponseDedupMatch>(); 
        ArrayList<GBSResponseDedupMatch> likelyMatch  = new ArrayList<GBSResponseDedupMatch>(); 
        
        try
        {          
            log.println("\n Service Status "+JSONUtility.domainWrapperToJSON(serviceStatus));
            serviceStatus.setInterfaceId(PrescreenConstants.DEDUPE_INTERFACE_ID);

            if(serviceStatus!=null && serviceStatus.getErrorObject()!=null && serviceStatus.getErrorObject().size() > 0 )
            {
                log.println("\n serviceStatus "+JSONUtility.domainWrapperToJSON(serviceStatus));
                GBSResponseDedupeStatus stat = new GBSResponseDedupeStatus();
                stat.setDedupeStatus(PrescreenConstants.REJECT);
                stat.setRemarks((String) serviceStatus.getErrorObject().get(0).getDescription());
                dedupeResponse.setDedupeStatus(stat);
            }
            else 
            {  
                CLMResponseWrapper wrap = (CLMResponseWrapper) clmResponseData;
                log.println("\n"+JSONUtility.domainWrapperToJSON(wrap));

                boolean isError = false;

                if(wrap!=null && wrap.getData()!=null && wrap.getData().getAttributes()!=null &&
                        wrap.getData().getAttributes().getErrordetails()!=null &&
                        wrap.getData().getAttributes().getErrordetails().size()>0 )
                {
                    if( wrap.getData().getAttributes().getErrordetails().get(0)!=null && 
                            wrap.getData().getAttributes().getErrordetails().get(0).getErrorcode()!=null &&
                            !wrap.getData().getAttributes().getErrordetails().get(0).getErrorcode().equals(PrescreenConstants.ERROR_CODE_NO_MATCH_FOUND)) {
                        isError = true;
                    }
                }
                else if(wrap!=null && wrap.getData()!=null && wrap.getData().getAttributes()!=null && 
                        wrap.getData().getAttributes().getCustomers()!=null)
                {
                    for(CLMResponseCustomers obj1 : wrap.getData().getAttributes().getCustomers())
                    {
                        GBSResponseDedupMatch profileData = constructProfileData(travellingObject,obj1,srvEntity);
                        if(profileData.getMatchCategoryText().equalsIgnoreCase(PrescreenConstants.EXACT_MATCH))
                        {
                            exactmatch.add(profileData);
                        } 
                        else if(profileData.getMatchCategoryText().equalsIgnoreCase(PrescreenConstants.LIKELY_MATCH)) 
                        {
                            likelyMatch.add(profileData);
                        }
                    }

                    dedupeResponse.getExactmatch().addAll(exactmatch);
                    dedupeResponse.getLikelyMatch().addAll(likelyMatch);                
                }

                if(exactmatch!=null && exactmatch.size() >0) {
                    GBSResponseDedupeStatus stat = new GBSResponseDedupeStatus();
                    stat.setDedupeStatus(PrescreenConstants.EXACT_MATCH);
                    stat.setRemarks("");
                    dedupeResponse.setDedupeStatus(stat);
                } else if(likelyMatch!=null && likelyMatch.size() >0) {
                    GBSResponseDedupeStatus stat = new GBSResponseDedupeStatus();
                    stat.setDedupeStatus(PrescreenConstants.LIKELY_MATCH);
                    stat.setRemarks("");
                    dedupeResponse.setDedupeStatus(stat);
                } else if (isError) {
                    GBSResponseDedupeStatus stat = new GBSResponseDedupeStatus();
                    stat.setDedupeStatus(PrescreenConstants.REJECT);
                    stat.setRemarks("["+wrap.getData().getAttributes().getErrordetails().get(0).getErrorcode()+"] ["+wrap.getData().getAttributes().getErrordetails().get(0).getErrordescription()+"]");
                    dedupeResponse.setDedupeStatus(stat);
                    
                    for(CLMResponseErrorDetails dat : wrap.getData().getAttributes().getErrordetails()) {
                        serviceStatus.addErrorObject(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS,dat.getErrorcode(),dat.getErrordescription()));
                    }
                    
                    
                } else {
                    GBSResponseDedupeStatus stat = new GBSResponseDedupeStatus();
                    stat.setDedupeStatus(PrescreenConstants.NOMATCH);
                    stat.setRemarks("");
                    dedupeResponse.setDedupeStatus(stat);
                }
                log.println("Final \n");
                log.println(""+JSONUtility.domainWrapperToJSON(dedupeResponse));
            }
        }catch(ProcessException ex)
        {
        	
            serviceStatus.addErrorObject(new ErrorObject(ex.getErrorList().get(0).getType(),(String)ex.getErrorList().get(0).getCode(),(String) ex.getErrorList().get(0).getDescription()));
        
        	GBSResponseDedupeStatus stat = new GBSResponseDedupeStatus();
            stat.setDedupeStatus(PrescreenConstants.REJECT);
            stat.setRemarks((String)ex.getErrorList().get(0).getDescription());
            dedupeResponse.setDedupeStatus(stat);


        }
        catch(Exception e)
        {
            log.printErrorMessage(e);
           serviceStatus.addErrorObject(new ErrorObject(BaseConstants.ERROR_TYPE_TECHNICAL,PrescreenConstants.CLM_REQUEST_ERROR,
            		"CLM PROCESSING ERROR"));
            GBSResponseDedupeStatus stat = new GBSResponseDedupeStatus();
            stat.setDedupeStatus(PrescreenConstants.REJECT);
            stat.setRemarks("CLM PROCESSING ERROR");
            dedupeResponse.setDedupeStatus(stat);



        }
        finally
        {
            //N.A
        }
        return dedupeResponse;
    }
 

 
    /**
     * <Description>
     * <p> 
     * <p> 
     * @param travellingObject 
     *  
     * @param 
     * @return
     * @throws ProcessException 
     * @exception
     * @see
     * @since
     */

     private GBSResponseDedupMatch constructProfileData(TravellingObject travellingObject, CLMResponseCustomers cust,NodeServicesEntity srvEntity) throws ProcessException 
     {
        HashMap<String, String> dedupeCategory = new HashMap<>();
        dedupeCategory.put("1", PrescreenConstants.EXACT_MATCH);
        dedupeCategory.put("2", PrescreenConstants.LIKELY_MATCH);

         LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "constructProfileData", LogType.APPLICATION.name());

         try 
         {
            GBSResponseDedupMatch obj = new GBSResponseDedupMatch();
            populateProfileData(obj, cust);

             String categoryOneCodes = ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(), "DEDUPE_CATEGORY", "CATEGORY_ONE_CODES");

             String category = cust.getCategory();
             if (category != null) 
             {
                if (isCategoryOne(category, categoryOneCodes)) 
                {
                    obj.setMatchCategoryText(dedupeCategory.get("1"));
                    setCategoryOneFlags(travellingObject, cust, srvEntity, obj);  
                }
                else if (isCategoryTwo(category, categoryOneCodes)) 
                {
                    obj.setMatchCategoryText(dedupeCategory.get("2"));
                } 
                else 
                {
                    obj.setMatchCategoryText(dedupeCategory.get(PrescreenConstants.NOMATCH));
                }
            } else {
                obj.setMatchCategoryText(dedupeCategory.get(PrescreenConstants.NOMATCH));
            }
        obj.setDigitalidentity(createDefaultDigitalIdentity());
        obj.setContacts(createContactDetails(cust));
        obj.setDocuments(createDocumentDetails(cust));        return obj;
        } 
        catch (ProcessException e) 
        {
            throw e;
        } catch (Exception e) {
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, PrescreenConstants.CLM_REQUEST_ERROR,"INTERNAL ERROR WHILE CONSTRUCTING SERVICE RESPONSE WITH CLM");
        }
    }   
    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @throws Exception 
     * @exception
     * @see
     * @since
     */
    private void populateProfileData(GBSResponseDedupMatch obj, CLMResponseCustomers cust) 
    {
        obj.setProfileId(cust.getReferenceid());
        obj.setRelationshipNumber(cust.getPreviousCoreBankingId());
        obj.setFirstName(cust.getFirstname());
        obj.setMiddleName(cust.getMiddlename());
        obj.setLastName(cust.getLastname());
        obj.setFullName(cust.getFullname());
        obj.setProfileType(cust.getProfiletype());
        obj.setProfileStatus(cust.getRelationshipstatus());
        obj.setMatchCategory(cust.getCategory());
        obj.setDateOfBirth(cust.getDateofbirth());
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @throws Exception 
     * @exception
     * @see
     * @since
     */
    private boolean isCategoryOne(String category, String categoryOneCodes) 
    {
        return (categoryOneCodes == null && category.contains("1")) || 
            (categoryOneCodes != null && findMatchingCategory(categoryOneCodes, category));
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @throws Exception 
     * @exception
     * @see
     * @since
     */
    private boolean isCategoryTwo(String category, String categoryOneCodes) 
    {
        return category.contains("2") || 
            (categoryOneCodes != null && findMatchingCategory(categoryOneCodes, category));
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @throws Exception 
     * @exception
     * @see
     * @since
     */
    public static boolean findMatchingCategory(String catOneSetup, String profCategory) 
    {
        List<String> listCatOneSetup = Arrays.asList(catOneSetup.split(","));
        List<String> listProfCategory = Arrays.asList(profCategory.split(","));

        for (String substringProfCategory : listProfCategory) 
        {
            if (substringProfCategory.startsWith("1") && listCatOneSetup.contains(substringProfCategory)) {
                return true; 
            }
        }
        return false;
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @throws Exception 
     * @exception
     * @see
     * @since
     */
    private ArrayList<GBSResponseDigitalIdentity> createDefaultDigitalIdentity() 
    {
        GBSResponseDigitalIdentity digi = new GBSResponseDigitalIdentity();
        digi.setIdType(null);
        digi.setIdValue(null);
        ArrayList<GBSResponseDigitalIdentity> arr = new ArrayList<>();
        arr.add(digi);
        return arr;
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @throws Exception
     * @exception
     * @see
     * @since
     */
    public ArrayList<GBSResponseContacts> createContactDetails(CLMResponseCustomers cust)
    {
        if(cust==null || cust.getContacts().size()==0) {
            return null;
        }

        ArrayList<GBSResponseContacts> arr = new ArrayList<>();
        for(CLMResponseContacts conts : cust.getContacts())
        {
            GBSResponseContacts contacts = new GBSResponseContacts();
            contacts.setContactTypeCode(conts.getContacttypecode());
            contacts.setCountryCode(conts.getCountrycode());
            contacts.setContactclassificationcode(conts.getContactclassificationcode());
 			contacts.setAlertrequiredforcontactamendment(conts.getAlertrequiredforcontactamendment());
			contacts.setAlertsuppressreasoncode(conts.getAlertrequiredforcontactamendment());
			contacts.setAreacode(conts.getAreacode());
			contacts.setAttentionparty(conts.getAttentionparty());
			contacts.setCreatedat(conts.getCreatedat());
			contacts.setCustomcontactno(conts.getCustomcontactno());
			contacts.setCustomcontactno(conts.getCustomcontactno());
			contacts.setDonotdisturbexpirydate(conts.getDonotdisturbexpirydate());
			contacts.setDonotdisturblastupdateddate(conts.getDonotdisturblastupdateddate());
			contacts.setDonotdisturbregistry(conts.getDonotdisturbregistry());
			contacts.setExtensiondet(conts.getExtensiondet());
			contacts.setHomeofficeidentifier(conts.getHomeofficeidentifier());
			contacts.setId(conts.getId());
			contacts.setIsdcontactcountrycode(conts.getIsdcontactcountrycode());
			contacts.setPreferredcontact(conts.getPreferredcontact());
			contacts.setReference(conts.getReference());
	        contacts.setContact(conts.getContact());
			contacts.setReferenceid(conts.getReferenceid());
			contacts.setSenderbranch(conts.getSenderbranch());
			contacts.setSenderid(conts.getSenderid());
			contacts.setSequencenumber(conts.getSequencenumber());
			contacts.setStatus(conts.getStatus());
			contacts.setStatusat(conts.getStatusat());
			contacts.setUpdatedat(conts.getUpdatedat());
            
            arr.add(contacts);
        }

        return arr;
    }
    
    
    public ArrayList<GBSResponseDocuments> createDocumentDetails(CLMResponseCustomers cust)
    {
        if(cust==null || cust.getDocuments().size()==0) {
            return null;
        }

        ArrayList<GBSResponseDocuments> arr = new ArrayList<>();
        for(CLMResponseDocuments doc : cust.getDocuments())
        {
            GBSResponseDocuments document = new GBSResponseDocuments();
            document.setCountrytreaty(doc.getCountrytreaty());
            document.setCreatedat(doc.getCreatedat());
            document.setDocreasoncode(doc.getDocreasoncode());
            document.setDocremarks(doc.getDocremarks());
            document.setDocumentcode(doc.getDocumentcode());
            document.setDocumentduedate(doc.getDocumentduedate());
            document.setDocumentevidencelink(doc.getDocumentevidencelink());
            document.setDocumentexpirydt(doc.getDocumentexpirydt());
            document.setDocumentnumber(doc.getDocumentnumber());
            document.setDocumentreceivedt(doc.getDocumentreceivedt());
            document.setDocumentsignatorydt(doc.getDocumentsignatorydt());
            document.setDocumenttype(doc.getDocumenttype());
            document.setExpirycheckoverride(doc.getExpirycheckoverride());
            document.setId(doc.getId());
            document.setPoidocument(doc.getPoidocument());
            document.setReferenceid(doc.getReferenceid());
            document.setSenderbranch(doc.getSenderbranch());
            document.setSenderid(doc.getSenderid());
            document.setStatus(doc.getStatus());
            document.setStatusat(doc.getStatusat());
            document.setTaxresidencecountry(doc.getTaxresidencecountry());
            document.setUpdatedat(doc.getUpdatedat());
            document.setW8nsupportdocumentindicator(doc.getW8nsupportdocumentindicator());
            
            
            arr.add(document);
        }
        

        return arr;
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @throws Exception 
     * @exception
     * @see
     * @since
     */
    public boolean isMandatory(HashMap<String,String> mandatoryData,String paramName) throws Exception
    {
        try 
        {
            if(mandatoryData==null) {
                return false;
            }
            return (mandatoryData.get(paramName)!=null && mandatoryData.get(paramName).equals("Y"))?true:false;
        } 
        catch (Exception e)
        {
            throw new Exception();
        }
    }
    
    public void setCategoryOneFlags(TravellingObject travellingObject, CLMResponseCustomers cust,
    		NodeServicesEntity srvEntity, GBSResponseDedupMatch obj) throws ProcessException {
    	LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "setCategoryOneFlags",
    			LogType.APPLICATION.name());
    	try {

    		String hostServiceURL = interfaceRequestTypeRepository.getInterfaceURL(travellingObject. getServiceContext().getCountryCodeWithRegion(),BaseConstants.INERFACE_ICM,"icmenquiry", "OB", BaseConstants.CODE_SETUP_ACTIVE);
    		if (!StringUtility.containsData(hostServiceURL))
    		{ 
    			return; 
    		}
    		hostServiceURL = hostServiceURL +cust.getReferenceid()+"&include=cdd,pdpa";
    		log.info("ICM Enquiry URL # " + hostServiceURL);
    		
    		ContactServerInfo contactServerInfo = new ContactServerInfo();
    		contactServerInfo.setCountryCode(travellingObject.getCountryCode());
    		contactServerInfo.setProtocolMethod(BaseConstants.GET_REQUEST);
    		contactServerInfo.setScope(BaseConstants.ICM_SCOPE);
    		contactServerInfo.setInterfaceId(travellingObject.getInterfaceId());
    		contactServerInfo.setSrvEntity(srvEntity);
    		contactServerInfo.setServiceUrl(hostServiceURL);
    		contactServerInfo.setTrackingId(travellingObject.getTransactionID());
    		contactServerInfo = appConfiguration.contactServer(contactServerInfo,travellingObject);

    		if (contactServerInfo.getHttpResponseCode().charAt(0) == BaseConstants.HTTP_4XX_SERIES) {
    			throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL, ICMConstants.INVALID_REQUEST,
    					"ICM RETURNED TECHNICAL ERROR");

    		} else if (contactServerInfo.getHttpResponseCode().charAt(0) == BaseConstants.HTTP_5XX_SERIES) {
    			throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL, ICMConstants.CLM_REQUEST_ERROR,
    					"ICM CONNECTIVITY ERROR - RETRY");
    		}

    		else {
      			ICMResponseWrapper req = (ICMResponseWrapper) JSONUtility.jsonTODomainWrapper(contactServerInfo.getResponseMessage(),
    					ICMResponseWrapper.class);
    			if (req != null) {
    				if (req.getData() != null) {
    					CLMResponsesAttributes clmResponse = req.getData().get(0) != null
    							? req.getData().get(0).getAttributes()
    									: null;
                    setDeepingAndOnboardingAllowed(cust, obj, clmResponse);
    				}

    				if ( req.getIncluded() != null) {
    					CLMResponsesAttributes clmResponse = req.getIncluded().get(0) != null
    							? req.getIncluded().get(0).getAttributes()
    									: null;
    					obj.setCddReferenceKey(clmResponse != null ? clmResponse.getIcddReferenceNumber() : null);
    				}
    			}
    		}

    	} catch (ProcessException e) {
    		throw e;
    	} catch (Exception ex) {
    		log.printErrorMessage(ex);
    		throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, PrescreenConstants.CLM_REQUEST_ERROR,
    				" INTERNAL ERROR WHILE CONSTRUCT SERVICE RESPONSE WITH CLM");
    	}
    	return;
    }

    public void setDeepingAndOnboardingAllowed(CLMResponseCustomers cust, GBSResponseDedupMatch obj,
            CLMResponsesAttributes clmResponse) {
        if (clmResponse != null) {
            obj.setIsDeepeningAllowed(clmResponse.getDeepeningFlag());
            if ("N".equals(clmResponse.getDeepeningFlag())
                    || ("C".equals(cust.getProfiletype()) && "A".equals(cust.getRelationshipstatus()))) {
                obj.setAllowedForOnboarding("N");
            } else {
                String condition = clmResponse.getDeepeningFlag() + cust.getProfiletype()
                        + cust.getRelationshipstatus();
                obj.setAllowedForOnboarding(PrescreenConstants.ONBOARDING_STATUS_COMBO.get(condition));
            }
        }
    }
 	}