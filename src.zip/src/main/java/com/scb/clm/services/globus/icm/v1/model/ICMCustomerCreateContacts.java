package com.scb.clm.services.globus.icm.v1.model;

import java.sql.Timestamp;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ICMCustomerCreateContacts {


    @JsonProperty("id")
    private String guid;

    @JsonProperty("reference-id")
    private String profileId;

    @JsonProperty("contact")
    private String contact;

    @JsonProperty("sequence-number")
    private short seqNo;

    @JsonProperty("contact-classification-code")
    private String contactClassificationCode;

    @JsonProperty("contact-type-code")
    private String contactTypeCode;

    @JsonProperty("country-code")
    private String countryCode;

    @JsonProperty("area-code")
    private String areaCode;

    @JsonProperty("home-office-identifier")
    private String homeOfficeIdentifier;

    @JsonProperty("extension-det")
    private String extensionDet;

    @JsonProperty("reference")
    private String reference;

    @JsonProperty("preferred-contact")
    private String preferredContact;

    @JsonProperty("primary-contact")
    private String primaryContact;

    @JsonProperty("contact-invalid-indicator")
    private String invalidIndicator;

    @JsonProperty("alert-required-for-contact-amendment")
    private String conAmendAlertInd;

    @JsonProperty("alert-suppress-reason-code")
    private String alertSuppressReasonCode;

    @JsonProperty("do-not-disturb-registry")
    private String dndRegistry;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @JsonProperty("do-not-disturb-last-updated-date")
    private Date dndLastUpdatedDt;

    @JsonIgnore
    private short recordStatus;

    @JsonProperty("country-id")
    private String companyId;

    @JsonProperty("custom-contact-no")
    private String customContactNo;

    @JsonProperty("isd-contact-country-code")
    private String isdCountryCode;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @JsonProperty("do-not-disturb-expiry-date")
    private Date dndExpiryDt;

    @JsonProperty("attention-party")
    private String attentionParty;

    @JsonProperty("sender-id")
    private String senderId;

    @JsonProperty("sender-branch")
    private String senderBranch;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    @JsonProperty("created-at")
    private Timestamp createdAt;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    @JsonProperty("updated-at")
    private Timestamp updatedAt;

    @JsonProperty("status")
    private String status;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    @JsonProperty("status-at")
    private Timestamp statusAt;

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public short getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(short seqNo) {
        this.seqNo = seqNo;
    }

    public String getContactClassificationCode() {
        return contactClassificationCode;
    }

    public void setContactClassificationCode(String contactClassificationCode) {
        this.contactClassificationCode = contactClassificationCode;
    }

    public String getContactTypeCode() {
        return contactTypeCode;
    }

    public void setContactTypeCode(String contactTypeCode) {
        this.contactTypeCode = contactTypeCode;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode;
    }

    public String getHomeOfficeIdentifier() {
        return homeOfficeIdentifier;
    }

    public void setHomeOfficeIdentifier(String homeOfficeIdentifier) {
        this.homeOfficeIdentifier = homeOfficeIdentifier;
    }

    public String getExtensionDet() {
        return extensionDet;
    }

    public void setExtensionDet(String extensionDet) {
        this.extensionDet = extensionDet;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getPreferredContact() {
        return preferredContact;
    }

    public void setPreferredContact(String preferredContact) {
        this.preferredContact = preferredContact;
    }

    public String getPrimaryContact() {
        return primaryContact;
    }

    public void setPrimaryContact(String primaryContact) {
        this.primaryContact = primaryContact;
    }

    public String getInvalidIndicator() {
        return invalidIndicator;
    }

    public void setInvalidIndicator(String invalidIndicator) {
        this.invalidIndicator = invalidIndicator;
    }

    public String getConAmendAlertInd() {
        return conAmendAlertInd;
    }

    public void setConAmendAlertInd(String conAmendAlertInd) {
        this.conAmendAlertInd = conAmendAlertInd;
    }

    public String getAlertSuppressReasonCode() {
        return alertSuppressReasonCode;
    }

    public void setAlertSuppressReasonCode(String alertSuppressReasonCode) {
        this.alertSuppressReasonCode = alertSuppressReasonCode;
    }

    public String getDndRegistry() {
        return dndRegistry;
    }

    public void setDndRegistry(String dndRegistry) {
        this.dndRegistry = dndRegistry;
    }

    public Date getDndLastUpdatedDt() {
        return dndLastUpdatedDt;
    }

    public void setDndLastUpdatedDt(Date dndLastUpdatedDt) {
        this.dndLastUpdatedDt = dndLastUpdatedDt;
    }

    public short getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(short recordStatus) {
        this.recordStatus = recordStatus;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getCustomContactNo() {
        return customContactNo;
    }

    public void setCustomContactNo(String customContactNo) {
        this.customContactNo = customContactNo;
    }

    public String getIsdCountryCode() {
        return isdCountryCode;
    }

    public void setIsdCountryCode(String isdCountryCode) {
        this.isdCountryCode = isdCountryCode;
    }

    public Date getDndExpiryDt() {
        return dndExpiryDt;
    }

    public void setDndExpiryDt(Date dndExpiryDt) {
        this.dndExpiryDt = dndExpiryDt;
    }

    public String getAttentionParty() {
        return attentionParty;
    }

    public void setAttentionParty(String attentionParty) {
        this.attentionParty = attentionParty;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public String getSenderBranch() {
        return senderBranch;
    }

    public void setSenderBranch(String senderBranch) {
        this.senderBranch = senderBranch;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getStatusAt() {
        return statusAt;
    }

    public void setStatusAt(Timestamp statusAt) {
        this.statusAt = statusAt;
    }
}
