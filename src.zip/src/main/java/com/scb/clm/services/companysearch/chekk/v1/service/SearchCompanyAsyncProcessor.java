package com.scb.clm.services.companysearch.chekk.v1.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.services.companysearch.chekk.v1.exception.ApplicationException;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkPartyEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkRequestsEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkSearchEntityQEntity;
import com.scb.clm.services.companysearch.chekk.v1.support.ChkProcessTime;
import com.scb.clm.services.companysearch.chekk.v1.support.Log;
import com.scb.clm.services.companysearch.chekk.v1.support.ProcessApiConstants;

/**
 * 
 */

@Service
public class SearchCompanyAsyncProcessor {
	@Autowired
	private ChkApiProcessor apiProcessor;
	//private LoggerUtil log = LoggerUtil.getInstance("Company_Search", SearchCompanyAsyncProcessor.class.getName(), "execute", "APPLICATION");

	@Async("SearchCompanyQueue")
	public void processAndSendFinalMessage(Map<String, String> requestHeader, ChekkRequestsEntity chekkRequestsEntity,
			ChekkSearchEntityQEntity chekkSearchEntityQEntity, ChkApiResponse searchApiResponse) {
		Log.info("SearchCompanyAsyncProcessor#processAndSendFinalMessage() method invoked... ");
		ChkProcessTime logTime = new ChkProcessTime();
		try {
			logTime.setRequestId(chekkRequestsEntity.getRequestId());
			logTime.setRegistrationId(chekkRequestsEntity.getRegistrationId());
			logTime.setApplicationRefNo(chekkRequestsEntity.getApplicationReference());

			logTime.setStartTime();
			Map<String, Object> createResponse = processApi(chekkSearchEntityQEntity, searchApiResponse);
			logTime.setCreateApiTime();
			Map<String, Object> getResponse = processApi(chekkSearchEntityQEntity, getApiResponse(createResponse));
			logTime.setGetApiTime();
			String finalResponseJson = generateFinalResponse(chekkRequestsEntity, getResponse, requestHeader);
			logTime.setFinalResponseTime();
			Log.info("Final Response at SearchComapanyAsyncProcessor = "+finalResponseJson);
			
			boolean msgSendStatus = sendFinalResponse(chekkSearchEntityQEntity,finalResponseJson, chekkRequestsEntity.getCountryCode(),
					requestHeader.get(ProcessApiConstants.PROCESS_API_HEADER_INTERFACE_ID));
		
			logTime.setMsgSendTime();
			logTime.printProcessingTime();
			Log.info("Level1 Processing Time using Asyc Processor >> " + logTime.printProcessingTime());
		} catch (ApplicationException ae) {
			// construct error object and send it to solace topic and update chk_requests,
			// searchEntityQ tables with appropriate status
			Log.error("Error in processing request id "+chekkRequestsEntity.getRequestId());
		} finally {
			// send finalresponse here for success and error scenarios
		}
		Log.info("SearchCompanyAsyncProcessor#processAndSendFinalMessage() method Ended... ");
	}

	private ChkApiResponse getApiResponse(Map<String, Object> responseObj) {
		if (responseObj == null) {
			throw new ApplicationException();
		}
		return (ChkApiResponse) responseObj.get(ProcessApiConstants.API_RESPONSE);
	}

	private List<ChekkPartyEntity> getPartyList(Map<String, Object> responseObj) {
		if (responseObj == null) {
			throw new ApplicationException();
		}

		List<ChekkPartyEntity> parties = (List<ChekkPartyEntity>) responseObj.get(ProcessApiConstants.PARTY_LIST);

		if (parties == null || parties.isEmpty()) {
			throw new ApplicationException();
		}

		return parties;
	}

	private Map<String, Object> processApi(ChekkSearchEntityQEntity chekkSearchEntityQEntity,
			ChkApiResponse previousApiResponse) {
		Map<String, Object> currentResponseObjects;
		if (previousApiResponse.isSuccess()) {
			currentResponseObjects = apiProcessor.processApi(chekkSearchEntityQEntity, previousApiResponse, false);
		} else {
			throw new ApplicationException();
		}
		return currentResponseObjects;
	}

	private String generateFinalResponse(ChekkRequestsEntity chekkRequestsEntity, Map<String, Object> getResponseObj,
			Map<String, String> requestHdr) {
		String finalResponseJson = null;
		ChkApiResponse getApiResponse = getApiResponse(getResponseObj);
		List<ChekkPartyEntity> partyList = getPartyList(getResponseObj);
		if ((getApiResponse != null && getApiResponse.isSuccess()) && (partyList != null && !partyList.isEmpty())) {
			finalResponseJson = apiProcessor.generateFinalResponse(requestHdr, chekkRequestsEntity, partyList);
		} else {
			Log.info("GET API failed for [requestid , registrationid] = ["+chekkRequestsEntity.getRequestId() +" , "+chekkRequestsEntity.getRegistrationId()+"]");
			throw new ApplicationException();
		}
		return finalResponseJson;
	}

	private boolean sendFinalResponse(ChekkSearchEntityQEntity chekkSearchEntityQEntity,String finalResponseJson, String countryCode, String interfaceId) {
		return apiProcessor.sendMessageToSolaceTopic(chekkSearchEntityQEntity.getRequestId(),finalResponseJson, countryCode, interfaceId);

	}
}
