package com.scb.clm.services.companysearch.chekk.v1.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.util.JSONUtility;
import com.scb.clm.common.util.ServiceParameterUtility;
import com.scb.clm.core.service.ServiceAbstract;
import com.scb.clm.core.service.ServiceInterface;
import com.scb.clm.services.admin.v1.support.AdminConstants;
import com.scb.clm.services.admin.v1.support.AdminUtility;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkRequestsHKEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.HKRequestData;
import com.scb.clm.services.companysearch.chekk.v1.repository.ChekkRequestsHKRepository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

@Service
@Configurable
public class ChekkHouseKeepingService extends ServiceAbstract implements ServiceInterface
{
    @Autowired 
    private EntityManager em;

    @Autowired
    ChekkRequestsHKRepository chekkRequestsHKRepository;
    
	@Autowired
	ObjectMapper objectMapper;
	
	LoggerUtil log = null;

    @Override
    public Object readRequestObject(TravellingObject travellingObject, NodeServicesEntity srvEntity) throws ProcessException 
    {        
        log = LoggerUtil.getInstance("Housekeep API", ChekkHouseKeepingService.class.getName(), "execute", "APPLICATION");
        log.println("Inside SearchCompanyService.readRequestObject");
       try{
       	return JSONUtility.jsonTODomainWrapper(travellingObject.getRequestData(),HKRequestData.class);
       }catch(Exception e) {       	
       		log.println("Error in readRequestObject method ");
	    	log.printErrorMessage(e);
           ProcessException gbxEx = new ProcessException();           
           throw gbxEx;
       }
        
    }

    @Override
    public void validateData(TravellingObject travellingObject, NodeServicesEntity srvEntity, Object requestPayload) throws ProcessException 
    {
    	log = LoggerUtil.getInstance("Housekeep API", ChekkHouseKeepingService.class.getName(), "validateData", "APPLICATION");        
    	log.println("Validate House Keeping ");
    }

    @Override
    public Object constructOutboundObject(TravellingObject travellingObject, NodeServicesEntity srvEntity,Object requestPayload) throws ProcessException 
    {
    	log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "constructOutboundObject", LogType.APPLICATION.name());    	
    	log.println("Outbound House Keeping ");
        return null;
    }

    @Override
    public Object process(TravellingObject travellingObject, NodeServicesEntity srvEntity, ServiceStatus serviceStatus,Object obj) throws ProcessException 
    {
    	log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "process", LogType.APPLICATION.name());
    	log.println("Process House Keeping ");

        try 
        {
        	houseKeepChekkTableData(travellingObject, srvEntity, serviceStatus, obj);

        } catch (Exception e) {        	
        	log.printErrorMessage(e);
        	throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL, AdminConstants.INVALID_CONFIGURATION,
					e.getMessage());
        }

        return null;
    }

    @Override
    public Object constructServiceResponse(TravellingObject travellingObject, NodeServicesEntity srvEntity, Object obj,ServiceStatus serviceStatus) throws ProcessException 
    {
    	log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "constructServiceResponse", LogType.APPLICATION.name());
       	log.println("Inbound House Keeping ");
        return "SUCCESS";
    }
  
	private void houseKeepChekkTableData(TravellingObject travellingObject, NodeServicesEntity srvEntity,
			ServiceStatus serviceStatus, Object obj) throws ProcessException {
		log   = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "houseKeepChekkTableData", LogType.APPLICATION.name());	       
		HKRequestData requestData = (HKRequestData) serviceStatus.getRequestPayload();
		try {
			HashMap<String, String> purgeDaysMap = ServiceParameterUtility
					.getParameterList(srvEntity.getNodeServicesMapper(), "CHKPURGE");
			String purgeDays = purgeDaysMap.get("PURGE_DAYS");
			if (AdminUtility.isValidDay(purgeDays)) {
				try {
	
					log.println("Deleting Chekk Request Data - Days less than " +purgeDays
							+ " days from date [" + requestData.getFromDate() + "]");
					DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
					LocalDate date = LocalDate.parse(requestData.getFromDate(), formatter);
					LocalDate purgeDate = date.minusDays(Long.parseLong(purgeDays));
					java.sql.Date fromDate = java.sql.Date.valueOf(purgeDate);
					TypedQuery<ChekkRequestsHKEntity> query = em.createQuery(
							"SELECT i FROM ChekkRequestsHKEntity i WHERE  CAST(i.createdOn AS DATE) < CAST(:fromDate AS DATE)",
							ChekkRequestsHKEntity.class); 
					query.setParameter("fromDate", fromDate);
					
					List<ChekkRequestsHKEntity> chekkRequestsHKEntityList = query.getResultList();
	
					deleteData(chekkRequestsHKEntityList);
				} catch (Exception e) {					
					log.printErrorMessage(e);
					throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL, AdminConstants.INVALID_CONFIGURATION,
							e.getMessage());
				}
				log.println("Deleting Chekk Data Completed");
			} else {
				throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL, AdminConstants.INVALID_CONFIGURATION,
						"INVALID DAYS PASSED FOR CHEKK HOUSE KEEPING DAYS");
			}
		} catch (Exception e) {			
			log.printErrorMessage(e);
			throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL, AdminConstants.INVALID_CONFIGURATION,
					e.getMessage());
		}
	}
    
    @Transactional
    private void deleteData(List<ChekkRequestsHKEntity> chekkRequestsHKEntityList) throws ProcessException {   
    	log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "deleteData",
				LogType.APPLICATION.name());
		try {
			log.println("Deleting Chekk Data as bulk");
			chekkRequestsHKRepository.deleteAll(chekkRequestsHKEntityList);
			log.println("Deleting Chekk Data as bulk completed");
		} catch (Exception e) {
			log.println("Deleting Chekk Data as bulk failed check the below error");
			log.printError(e.getMessage());
			log.println("Initiating deleting chekk data as individual");
			for (ChekkRequestsHKEntity chekkRequestsHKEntity : chekkRequestsHKEntityList) {
				try {
					chekkRequestsHKRepository.deleteById(chekkRequestsHKEntity.getId());
				} catch (Exception ex) {					
					log.printError("Deleting chekk data as individula failed for the record :"
							+ chekkRequestsHKEntity.getId() + "Errored because of "+ ex.getMessage());
				}
			}
			log.println("Deleting chekk data as individual completed");

		}    	
    }	
}
