package com.scb.clm.services.globus.cleanup.v1.service;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.util.ServiceParameterUtility;
import com.scb.clm.core.service.ServiceAbstract;
import com.scb.clm.core.service.ServiceInterface;
import com.scb.clm.services.globus.cleanup.v1.support.CleanupConstants;
import com.scb.clm.services.globus.cleanup.v1.support.CleanupUtility;
import com.scb.clm.services.globus.prospect.v1.model.ProspectEntity;
import com.scb.clm.services.globus.prospect.v1.repository.ProspectsRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.time.Duration;
import java.time.LocalDate;
import java.util.List;

@Service
@Configurable
public class CleanupService extends ServiceAbstract implements ServiceInterface {
    @Autowired
    private EntityManager em;

    @Autowired
    ProspectsRepository prospectsRepository;

    @Override
    public Object readRequestObject(TravellingObject travellingObject, NodeServicesEntity srvEntity) throws ProcessException {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "readRequestObject", LogType.APPLICATION.name());
        log.println("Read Request Cleanup ");
        return null;
    }

    @Override
    public void validateData(TravellingObject travellingObject, NodeServicesEntity srvEntity, Object requestPayload) throws ProcessException {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateData", LogType.APPLICATION.name());
        log.println("Validate Cleanup ");
    }

    @Override
    public Object constructOutboundObject(TravellingObject travellingObject, NodeServicesEntity srvEntity, Object requestPayload) throws ProcessException {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "constructOutboundObject", LogType.APPLICATION.name());
        log.println("Outbound Cleanup ");
        return null;
    }

    @Override
    public Object process(TravellingObject travellingObject, NodeServicesEntity srvEntity, ServiceStatus serviceStatus, Object obj) throws ProcessException {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "process", LogType.APPLICATION.name());
        log.println("Process Cleanup ");

        try {
            cleanupProspectData(travellingObject, srvEntity, serviceStatus, obj);
        }catch (ProcessException e) {
            log.printErrorMessage(e);
            throw e;
        }
        catch (Exception e) {
            log.printErrorMessage(e);
            throw new ProcessException();
        }

        return null;
    }

    @Override
    public Object constructServiceResponse(TravellingObject travellingObject, NodeServicesEntity srvEntity, Object obj, ServiceStatus serviceStatus) throws ProcessException {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "constructServiceResponse", LogType.APPLICATION.name());
        log.println("Inbound Cleanup ");
        return null;
    }

    @Transactional(rollbackFor = Exception.class)  // Rollback for any exception
    private void cleanupProspectData(TravellingObject travellingObject, NodeServicesEntity srvEntity, ServiceStatus serviceStatus, Object obj) throws ProcessException{
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "cleanupProcessData", LogType.APPLICATION.name());
        String purgeDays = "999";
        String batchSize = "0";
        try {
            purgeDays = ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(), CleanupConstants.CLEANUP_GROUP_ID, CleanupConstants.PROSPECT_CLEANUP_DAYS);
            batchSize = ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(), CleanupConstants.CLEANUP_GROUP_ID, CleanupConstants.PROSPECT_CLEANUP_BATCH_SIZE);

            if (CleanupUtility.isValidDay(purgeDays) && CleanupUtility.isValidBatchSize(batchSize)) {
                log.println("Checking Prospect Data - Days less than " + purgeDays + " days / Batch Size [" + batchSize + "]");

                while (true) {
                    TypedQuery<ProspectEntity> query = em.createQuery("SELECT i FROM ProspectEntity i WHERE  i.lastUpdatedDate < :thresholdDate  " +
                            "AND i.muleIndicator ='N'", ProspectEntity.class);

                    // Prepare the query to fetch data based on threshold date
                    Timestamp timestamp = Timestamp.valueOf(getThresholdDays(purgeDays).atStartOfDay());
                    query.setParameter("thresholdDate", timestamp);
                    query.setMaxResults(Integer.parseInt(batchSize));

                    // Fetch the result list
                    List<ProspectEntity> prospectEntityList = query.getResultList();
                    log.println("Checking Prospect Data - Size : " + (prospectEntityList == null ? 0 : prospectEntityList.size()));
                    if (prospectEntityList == null || prospectEntityList.size() == 0) {
                        log.println("Breaking Prospect Loop");
                        break;
                    }
                    try {
                        // Process and delete each prospect entity
                        for (ProspectEntity prospectEntity : prospectEntityList) {
                            if (prospectEntity != null && prospectEntity.getId() != null) {
                                log.println("Deleting Prospect data with MULE_INDICATOR: N with Prospect ID: "+prospectEntity.getId().getProspectID());
                                prospectsRepository.deleteById(prospectEntity.getId());
                            }
                        }
                    }

                    catch (Exception e) {
                        // Handle any other exceptions and trigger rollback
                        log.printErrorMessage(e);
                        log.println("[FATAL] Cleanup Rolled Back for GBS_PROSPECT_PROFILES");
                        throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,CleanupConstants.CLEANUP_ROLL_BACK,"ROLL BACK");
                    }
                    log.println("Deleting NOT MULE Prospect Data Completed");
                }

            }
            else {
                throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL, CleanupConstants.INVALID_CONFIGURATION, "INVALID DAYS / BATCH SIZE CONFIGURED FOR PROSPECT CLEANUP DAYS");
            }
        } catch(ProcessException e){
            throw e;
        }
        catch (Exception e) {
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL, CleanupConstants.INVALID_CONFIGURATION,"INVALID REQUEST");
        }
    }


    public LocalDate getThresholdDays(String purgeDays) {
        Duration duration = Duration.ofDays(Integer.valueOf(purgeDays));
        LocalDate currentDate = LocalDate.now();
        return currentDate.minusDays(duration.toDays());
    }
}
