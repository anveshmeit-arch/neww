package com.scb.clm.services.globus.cddinitiate.v1.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
@JsonInclude(JsonInclude.Include.NON_NULL)  
public class CDDReqCreateInitiateDocuments {

    @JsonProperty("document-type")
    private String document_type;

    @JsonProperty("document-number")
    private String document_number;

    @JsonProperty("document-expiry-date")
    private String document_expiry_date;

    @JsonProperty("country-of-tax-residence")
    private String country_of_tax_residence;



    public String getDocument_type() {
        return document_type;
    }

    public void setDocument_type(String document_type) {
        this.document_type = document_type;
    }

    public String getDocument_number() {
        return document_number;
    }

    public void setDocument_number(String document_number) {
        this.document_number = document_number;
    }

    public String getDocument_expiry_date() {
        return document_expiry_date;
    }

    public void setDocument_expiry_date(String document_expiry_date) {
        this.document_expiry_date = document_expiry_date;
    }

    @Override
    public String toString() {
        return "CDDReq_Create_Iniate_Documents [document_type=" + document_type + ", document_number=" + document_number
                + ", document_expiry_date=" + document_expiry_date + "]";
    }

    public String getCountry_of_tax_residence() {
        return country_of_tax_residence;
    }

    public void setCountry_of_tax_residence(String country_of_tax_residence) {
        this.country_of_tax_residence = country_of_tax_residence;
    }

}
