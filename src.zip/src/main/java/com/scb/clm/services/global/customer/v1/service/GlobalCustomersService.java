package com.scb.clm.services.global.customer.v1.service;

import java.util.ArrayList;
import java.util.List;

import com.scb.clm.services.idsafe.biometric.v1.model.IdentitySafeEntity;
import com.scb.clm.services.idsafe.biometric.v1.model.IdentitySafeRequestWrapper;
import com.scb.clm.services.idsafe.biometric.v1.support.IdentitySafeConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.stereotype.Service;

import com.scb.clm.common.config.ApplicationConfiguration;
import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ErrorObject;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.CountryCodeEntity;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.repository.CountryCodeRepository;
import com.scb.clm.common.util.DateTimeUtility;
import com.scb.clm.common.util.JSONUtility;
import com.scb.clm.common.util.StringUtility;
import com.scb.clm.core.service.ServiceAbstract;
import com.scb.clm.core.service.ServiceInterface;
import com.scb.clm.services.global.customer.v1.model.GlobalCustomersEntity;
import com.scb.clm.services.global.customer.v1.model.GlobalCustomersRequestCustomers;
import com.scb.clm.services.global.customer.v1.model.GlobalCustomersRequestWrapper;
import com.scb.clm.services.global.customer.v1.model.GlobalCustomersResponseErrorDetails;
import com.scb.clm.services.global.customer.v1.model.GlobalCustomersResponseWrapper;
import com.scb.clm.services.global.customer.v1.repository.GlobalCustomersRepository;
import com.scb.clm.services.global.customer.v1.support.GlobalCustomersConstants;


import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;

@Service
@Configurable
public class GlobalCustomersService extends ServiceAbstract implements ServiceInterface
{

    @Autowired
    CountryCodeRepository countryCodeRepository;

    @Autowired
    GlobalCustomersRepository globalCustomersRepository;

    @Autowired 
    private EntityManager entityManager;

    private static final int GLB_CUSTOMERS_SEQNO_FIX_LENGTH = 13;

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object readRequestObject(TravellingObject travellingObject, NodeServicesEntity srvEntity) throws ProcessException 
    {
        List<ErrorObject> errorObjectList = new ArrayList<ErrorObject>();
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "readRequestObject", LogType.APPLICATION.name());

        try
        {
            log.println("GlobalCustomers Thread : "+Thread.currentThread());
            GlobalCustomersRequestWrapper glbCustomerRequestObj = (GlobalCustomersRequestWrapper) JSONUtility.jsonTODomainWrapper(travellingObject.getRequestData(),GlobalCustomersRequestWrapper.class);
            if(glbCustomerRequestObj==null) {
                throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL, GlobalCustomersConstants.INVALID_ID_SAFE_REQUEST_FORMAT,"GLOBAL CUSTOMER REQUEST MESSAGE IS INCOMPATABLE");
            }

            return glbCustomerRequestObj;
        }
        catch(Exception e)
        {
            log.printErrorMessage(e);
            errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_TECHNICAL, GlobalCustomersConstants.INVALID_ID_SAFE_REQUEST_FORMAT,"Invalid Request Format for Global Customer Service"));
            ProcessException gbxEx = new ProcessException();
            gbxEx.addAll(errorObjectList);
            throw gbxEx;
        }
        finally
        {
            // N.A
        }
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public void validateData(TravellingObject travellingObject,NodeServicesEntity srvEntity,Object requestPayload)  throws ProcessException 
    {
        List<ErrorObject> errorObjectList = new ArrayList<ErrorObject>();
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateData", LogType.APPLICATION.name());

        try 
        {
            GlobalCustomersRequestWrapper requestWrapper = (GlobalCustomersRequestWrapper) requestPayload;

            log.println("Request Wrapper : "+JSONUtility.domainWrapperToJSON(requestWrapper));

            if(requestWrapper.getApplication() == null || !StringUtility.containsData(requestWrapper.getApplication().getApplicationReferenceNumber()))
            {
                throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, IdentitySafeConstants.INVALID_APPLICATION_REFERENCE_NUMBER,"INVALID APPLICATION REFERENCE NUMBER");
            }

            if(!StringUtility.minMaxlength(requestWrapper.getApplication().getApplicationReferenceNumber(),"0","50"))
            {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, IdentitySafeConstants.INVALID_APPLICATION_REFERENCE_NUMBER,"INVALID APPLICATION REFERENCE NUMBER ["+requestWrapper.getApplication().getApplicationReferenceNumber()+"] [DATA LENGTH SHOULD BE IN RANGE 1-50]"));
            } else {
                travellingObject.setApplicationReferenceNumber(requestWrapper.getApplication().getApplicationReferenceNumber());
            }

            GlobalCustomersRequestCustomers customers = requestWrapper.getCustomers();

            if(customers == null)
            {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.INVALID_CUSTOMER_BLOCK,"BASIC INFORMATION [CUSTOMER] BLOCK IS NULL"));
            }
            else
            {
                validateFieldLength(customers.getGlobalIdentifier(), "0", "20", errorObjectList, BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.INVALID_GLOBAL_IDENTIFIER, "");
                validateFieldLength(customers.getBaseCountry(), "2", "2", errorObjectList, BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.INVALID_BASE_COUNTRY_CODE, "INVALID BASE COUNTRY CODE");
                validateFieldLength(customers.getRelationshipCountry(), "1", "2", errorObjectList, BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.INVALID_RELATIONSHIP_COUNTRY_CODE, "INVALID RELATIONSHIP COUNTRY CODE");
                validateFieldLength(customers.getProfileId(), "0", "20", errorObjectList, BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.INVALID_PROFILE_ID, "INVALID PROFILE ID");
                validateFieldLength(customers.getRelationshipId(), "0", "20", errorObjectList, BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.INVALID_RELATIONSHIP_NUMBER, "INVALID RELATIONSHIP NUMBER");                
                validateFieldLength(customers.getValidatedBy(), "0", "1", errorObjectList, BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.INVALID_RELATIONSHIP_NUMBER, "INVALID VALIDATED-BY");
            }

            if(errorObjectList.size()> 0)
            {
                ProcessException gbxEx = new ProcessException();
                gbxEx.addAll(errorObjectList);
                throw gbxEx;
            }

        }
        catch(ProcessException e)
        {
            log.println(" Error ["+e.getAllErrors()+"]");
            throw e;
        }
        catch(Exception e)
        {
            log.printErrorMessage(e);
            errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_TECHNICAL, GlobalCustomersConstants.INTERNAL_PROCESSING_ERROR,"Internal Error"));
            ProcessException gbxEx = new ProcessException();
            gbxEx.addAll(errorObjectList);
            throw gbxEx; 
        }
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object constructOutboundObject(TravellingObject travellingObject,NodeServicesEntity srvEntity,Object requestPayload) throws ProcessException
    {
        GlobalCustomersRequestWrapper requestWrapper = null;
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "constructServiceResponse", LogType.APPLICATION.name());
        try 
        {
            requestWrapper = (GlobalCustomersRequestWrapper) requestPayload;
        }
        catch (Exception e) 
        {
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL, GlobalCustomersConstants.INVALID_ID_SAFE_REQUEST_FORMAT,"GLOBAL CUSTOMER REQUEST MESSAGE IS INCOMPATABLE");
        }
        finally
        {

        }
        return requestWrapper;
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object process(TravellingObject travellingObject,NodeServicesEntity srvEntity,ServiceStatus serviceStatus,Object processPayload) throws ProcessException
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "process", LogType.APPLICATION.name());

        GlobalCustomersRequestWrapper requestWrapper;
        log.println("Global Customer Service");
        try
        {
            requestWrapper = (GlobalCustomersRequestWrapper) processPayload;
            if(getHttpMethod(travellingObject).equalsIgnoreCase(BaseConstants.HTTP_POST))
            {
                doCreate(travellingObject,requestWrapper);
            }
            else if(getHttpMethod(travellingObject).equalsIgnoreCase(BaseConstants.HTTP_PATCH))
            {
                doUpdate(travellingObject,requestWrapper);
            }
            else if(getHttpMethod(travellingObject).equalsIgnoreCase(BaseConstants.HTTP_DELETE))
            {
                doDelete(travellingObject,requestWrapper);
            }
            else 
            {
                throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL, GlobalCustomersConstants.INVALID_HTTP_STATUS,"INVALID HTTP STATUS ["+getHttpMethod(travellingObject)+"]");
            }

            serviceStatus.setHttpStatus(String.valueOf(BaseConstants.HTTP_200));
            serviceStatus.setInterfaceId(travellingObject.getInterfaceId());
            log.println("GLOBAL CUSTOMER JSON "+JSONUtility.domainWrapperToJSON(processPayload));
        }
        catch (ProcessException e)
        {
            log.printErrorMessage(e);
            throw e;
        }
        catch (Exception e)
        {
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL, GlobalCustomersConstants.INTERNAL_PROCESSING_ERROR," INTERNAL ERROR WHILE SERVICE PROCESSING");
        }
        return requestWrapper;
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object constructServiceResponse(TravellingObject travellingObject,NodeServicesEntity srvEntity,Object processedData,ServiceStatus serviceStatus) throws ProcessException 
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "constructServiceResponse", LogType.APPLICATION.name());

        GlobalCustomersResponseWrapper globalCustomersResponseWrapper = new GlobalCustomersResponseWrapper();

        try
        {
            GlobalCustomersRequestWrapper processedWrapper = (GlobalCustomersRequestWrapper) processedData;

            if(serviceStatus!=null && serviceStatus.getErrorObject()!=null && serviceStatus.getErrorObject().size() >0)
            { 
                for(ErrorObject errorObject : serviceStatus.getErrorObject())
                {
                    globalCustomersResponseWrapper.addErrors(new GlobalCustomersResponseErrorDetails((String)errorObject.getCode(),(String)errorObject.getDescription()));
                }
            }

            if(processedWrapper!=null) {
                globalCustomersResponseWrapper.setGlobalIdentifier(processedWrapper.getCustomers().getGlobalIdentifier());
            } else {
                //N.A
            }
        }
        catch(Exception e)
        {
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.RESPONSE_CONSTRUCTION_ERROR," INTERNAL ERROR WHILE RESPONSE CONSTRUCTION");
        }
        finally
        {
            //N.A
        }
        return globalCustomersResponseWrapper;
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    private String generateGlobalSequenceNumber(TravellingObject travellingObject) throws ProcessException
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "generateGlobalSequenceNumber", LogType.APPLICATION.name());

        StringBuffer sequenceNumber         = new StringBuffer();
        try
        {
            log.println("Generating Global Sequence Number");
            CountryCodeEntity countryCodeEntity = countryCodeRepository.getOne(travellingObject.getCountryCode());

            if(countryCodeEntity==null || countryCodeEntity.getIsoCountryCode()==null) 
            {
                throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.ISO_COUNTRY_CODE_EMPTY,"Invalid ISO Code for Country Code ["+travellingObject.getCountryCode()+"]"); 
            } 
            else 
            {
                //NA
            }

            sequenceNumber.append(countryCodeEntity.getIsoCountryCode());

            Query qry = null;
            String dataBaseType   = ApplicationConfiguration.getInstance().getHashicorpValutedProperties(BaseConstants.DATABASE_TYPE);

            if(dataBaseType != null && dataBaseType.equalsIgnoreCase(BaseConstants.ORACLE)) {
                qry = entityManager.createNativeQuery("SELECT GLOBAL_CUSTOMER_DB_SEQUENCE.NEXTVAL FROM DUAL");
            } else {
                qry = entityManager.createNativeQuery("SELECT NEXTVAL('GLOBAL_CUSTOMER_DB_SEQUENCE')");
            }

            sequenceNumber.append(StringUtility.padLeft(String.valueOf(qry.getResultList().get(0)), GLB_CUSTOMERS_SEQNO_FIX_LENGTH,"0"));

            log.println("Generate Global Customer Database Sequence Number  ["+sequenceNumber.toString()+"]");
            if(sequenceNumber.toString()!=null && sequenceNumber.toString().trim().length()==0)
            {
                throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.INVALID_ID_VAULT_ID,"UNABLE TO GENERATE VAULT ID"); 
            }

            return sequenceNumber.toString();
        }
        catch(Exception e)
        {
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.VAULT_ID_GENERATION_ERROR,"UNABLE TO GENERATE VAULT ID"); 
        }
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    private GlobalCustomersEntity readContent(TravellingObject travellingObject,GlobalCustomersRequestWrapper requestWrapper,GlobalCustomersEntity globalCustomersEntity) throws ProcessException
    {
        GlobalCustomersEntity newGlbCustomersEntity = new GlobalCustomersEntity(globalCustomersEntity.getSequenceNumber());
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "readContent", LogType.APPLICATION.name());
        try
        {
            GlobalCustomersRequestCustomers customerData = requestWrapper.getCustomers();

            if(customerData==null) {
                throw new Exception();
            }

            newGlbCustomersEntity.setGlobalIdentifier(customerData.getGlobalIdentifier());
            newGlbCustomersEntity.setBaseCountry(customerData.getBaseCountry());
            newGlbCustomersEntity.setRelationshipCountry(customerData.getRelationshipCountry());
            newGlbCustomersEntity.setProfileId(customerData.getProfileId());
            newGlbCustomersEntity.setRelationshipId(customerData.getRelationshipId());
            newGlbCustomersEntity.setValidatedBy(customerData.getValidatedBy());
            newGlbCustomersEntity.setStatusFlag(customerData.getStatusFlag());
            newGlbCustomersEntity.setCreatedBy(customerData.getCreatedBy());
            newGlbCustomersEntity.setUpdatedDate(DateTimeUtility.getTimeByCountryCode(customerData.getBaseCountry()));
            newGlbCustomersEntity.setCreatedDate(globalCustomersEntity.getCreatedDate()==null?DateTimeUtility.getTimeByCountryCode(customerData.getBaseCountry()):globalCustomersEntity.getCreatedDate());
            newGlbCustomersEntity.setApplicationReferenceNumber(requestWrapper.getApplication().getApplicationReferenceNumber());
 
            if(getHttpMethod(travellingObject).equals(BaseConstants.HTTP_POST)) 
            {
                newGlbCustomersEntity.setStatusFlag(GlobalCustomersConstants.STATUS_ACTIVE);
            }
        }
        catch(Exception e)
        {
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.DATA_READING_ERROR,"UNABLE TO READ MESSAGE");
        }
        finally
        {
            //N.A
        }
        return newGlbCustomersEntity;
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    private String getHttpMethod(TravellingObject trObj) {
        String httpMethod = trObj.getServiceContext().getHttpMethod();
        if(httpMethod == null || httpMethod.equalsIgnoreCase(BaseConstants.HTTP_GET)) {
            return BaseConstants.HTTP_GET;
        } else if(httpMethod.equalsIgnoreCase(BaseConstants.HTTP_POST)) {
            return BaseConstants.HTTP_POST;
        } else if(httpMethod.equalsIgnoreCase(BaseConstants.HTTP_PATCH)) {
            return BaseConstants.HTTP_PATCH;
        } else if(httpMethod.equalsIgnoreCase(BaseConstants.HTTP_DELETE)) {
            return BaseConstants.HTTP_DELETE;
        } else if(httpMethod.equalsIgnoreCase(BaseConstants.HTTP_PUT)) {
            return BaseConstants.HTTP_PUT;
        }
        return "";
    }

    /**
    * <Description>
    * <p> 
    * <p> 
    *  
    * @param 
    * @return
    * @throws ProcessException
    * @exception
    * @see
    * @since
    */
    private void doCreate(TravellingObject trObj,GlobalCustomersRequestWrapper requestWrapper) throws ProcessException
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "doCreate", LogType.APPLICATION.name());

        if(requestWrapper.getApplication().getApplicationReferenceNumber() == null || requestWrapper.getApplication().getApplicationReferenceNumber().trim().length() ==0) {
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.INVALID_APPLICATION_REFERENCE_NUMBER_CREATE,"APPLICATION REFERENCE NUMBER MANDATORY FOR CREATE");
        }
        GlobalCustomersEntity globalCustomersEntity = globalCustomersRepository.findByBaseCountryAndApplicationReferenceNumber(requestWrapper.getCustomers().getBaseCountry(),requestWrapper.getApplication().getApplicationReferenceNumber());


        //GlobalCustomersEntity globalCustomersEntity = null; //globalCustomersRepository.findByCountryCodeAndApplicationReferenceNumber(requestWrapper.getCustomers().getBaseCountry(),requestWrapper.getApplication().getApplicationReferenceNumber());

        if(globalCustomersEntity==null) {
            globalCustomersEntity = new GlobalCustomersEntity(generateGlobalSequenceNumber(trObj));
            globalCustomersEntity.setCreatedDate(DateTimeUtility.getTimeByCountryCode(requestWrapper.getCustomers().getBaseCountry()));
        }

        GlobalCustomersEntity newGlobalCustomersEntity = readContent(trObj,requestWrapper,globalCustomersEntity);
        
        globalCustomersEntity.synchronizeThisWith(newGlobalCustomersEntity);
        try 
        {
            log.println("Global Customer Service - Creating Entry - ID #"+globalCustomersEntity.getSequenceNumber()+"# Application Number #"+requestWrapper.getApplication().getApplicationReferenceNumber());;
            globalCustomersRepository.save(globalCustomersEntity);
        } 
        catch (Exception e) 
        {
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.ID_SAFE_DELETE_ERROR,"UNABLE TO DELETE GLOBAL CUSTOMER ENTRY");
        } 
        finally
        {
            //N.A
        } 
    }

    /**
    * <Description>
    * <p> 
    * <p> 
    *  
    * @param 
    * @return
    * @throws ProcessException 
    * @exception
    * @see
    * @since
    */
    private void doUpdate(TravellingObject trObj,GlobalCustomersRequestWrapper requestWrapper) throws ProcessException    
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "doDelete", LogType.APPLICATION.name());

        if(requestWrapper == null || requestWrapper.getCustomers() == null) {
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.INVALID_UPDATE_PAYLOAD,"INVALID UPDATE PAYLOAD DATA");
        }

        GlobalCustomersEntity globalCustomersEntity = null;

        try 
        {            
            globalCustomersEntity = findByApplicationReferenceNumber(trObj,requestWrapper);

            if (globalCustomersEntity == null) {
                globalCustomersEntity = findByGlobalIdentifier(trObj,requestWrapper);
            }

            if (globalCustomersEntity == null) {
                globalCustomersEntity = findByRelationshipNumber(trObj,requestWrapper);
            }

            if (globalCustomersEntity == null) {
                globalCustomersEntity = findByProfileId(trObj,requestWrapper);
            }

        }
        catch(ProcessException e) {
            throw e;
        }

        if(globalCustomersEntity==null)
        {
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.INVAID_ID_SEARCH_ID,"UNABLE TO FIND ENTRY FOR GLOBAL CUSTOMER ID ["+requestWrapper.getCustomers().getBaseCountry()+"] ");
        }

        GlobalCustomersEntity newGlobalCustomersEntity = readContent(trObj,requestWrapper,globalCustomersEntity);
        globalCustomersEntity.synchronizeThisWith(newGlobalCustomersEntity);

        try 
        {
            log.println("GLOBAL CUSTOMER Service - Updating Entry - ID #"+globalCustomersEntity.getSequenceNumber()+"# Application Number #"+globalCustomersEntity.getApplicationReferenceNumber());
            globalCustomersRepository.save(globalCustomersEntity);
        } 
        catch (Exception e) 
        {
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.ID_SAFE_UPDATE_ERROR,"UNABLE TO UPDATE GLOBAL CUSTOMER ENTRY");
        } 
        finally
        {
            //N.A
        } 
    }

    /**
    * <Description>
    * <p> 
    * <p> 
    *  
    * @param 
    * @return
    * @throws ProcessException 
    * @exception
    * @see
    * @since
    */
    public void doDelete(TravellingObject trObj,GlobalCustomersRequestWrapper requestWrapper) throws ProcessException
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "doDelete", LogType.APPLICATION.name());

        try
        {
            GlobalCustomersEntity globalCustomersEntity = findByApplicationReferenceNumber(trObj,requestWrapper);

            if (globalCustomersEntity == null) {
                globalCustomersEntity = findByGlobalIdentifier(trObj,requestWrapper);
            }

            if (globalCustomersEntity == null) {
                globalCustomersEntity = findByRelationshipNumber(trObj,requestWrapper);
            }

            if (globalCustomersEntity == null) {
                globalCustomersEntity = findByProfileId(trObj,requestWrapper);
            }

            if(globalCustomersEntity!=null)
            {
                log.println("Global Customer Service - Deleting Entry - ID #"+globalCustomersEntity.getApplicationReferenceNumber()+"# Application Number #");
                globalCustomersRepository.delete(globalCustomersEntity);
            }    
            else {
                log.println("Global Customer Service - Entry Not Found For Application Number # "+((requestWrapper.getCustomers().getBaseCountry())+" - "+requestWrapper.getApplication().getApplicationReferenceNumber()));
            } 
        } 
        catch (ProcessException e) 
        {
            throw e;
        }        
        catch (Exception e) 
        {
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.ID_SAFE_DELETE_ERROR,"UNABLE TO DELETE GLOBAL CUSTOMER ENTRY");
        } 
        finally
        {
            //N.A
        } 
    }

    /**
    * <Description>
    * <p> 
    * <p> 
    *  
    * @param 
    * @return
    * @throws ProcessException 
    * @exception
    * @see
    * @since
    */
    private GlobalCustomersEntity findByApplicationReferenceNumber(TravellingObject trObj, GlobalCustomersRequestWrapper requestWrapper) throws ProcessException
    {
        try
        {
            if (requestWrapper.getApplication().getApplicationReferenceNumber() != null)
            {
                return globalCustomersRepository.findByBaseCountryAndApplicationReferenceNumber(
                        requestWrapper.getCustomers().getBaseCountry(),
                        requestWrapper.getApplication().getApplicationReferenceNumber()
                );
            }
        } catch (IncorrectResultSizeDataAccessException e) {
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.DUPLICATE_RECORDS_EXIST,"DUPLICATE RECORDS EXIST FOR APPLICATION ID ["+requestWrapper.getApplication().getApplicationReferenceNumber()+"]");
        }
        return null;
    }

    private GlobalCustomersEntity findByGlobalIdentifier(TravellingObject trObj,GlobalCustomersRequestWrapper requestWrapper) throws ProcessException
    {
        try 
        {
            if (requestWrapper.getCustomers() != null && requestWrapper.getCustomers().getGlobalIdentifier() != null) 
            {
                return globalCustomersRepository.findByGlobalIdentifier(requestWrapper.getCustomers().getGlobalIdentifier());
            }
        } catch (IncorrectResultSizeDataAccessException e) {
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.DUPLICATE_RECORDS_EXIST,"DUPLICATE RECORDS EXIST FOR GLOBAL ID ["+requestWrapper.getCustomers().getGlobalIdentifier()+"]");
        }
        return null;
    }

    /**
    * <Description>
    * <p> 
    * <p> 
    *  
    * @param 
    * @return
    * @throws ProcessException 
    * @exception
    * @see
    * @since
    */
    private GlobalCustomersEntity findByRelationshipNumber(TravellingObject trObj,GlobalCustomersRequestWrapper requestWrapper) throws ProcessException
    {
        try 
        {
            if (requestWrapper.getCustomers().getRelationshipId() != null) 
            {
                return globalCustomersRepository.findByBaseCountryAndRelationshipId(
                    requestWrapper.getCustomers().getBaseCountry(),
                    requestWrapper.getCustomers().getRelationshipId()
                );
            }
        } catch (IncorrectResultSizeDataAccessException e) {
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.DUPLICATE_RECORDS_EXIST,"DUPLICATE RECORDS EXIST FOR RELATIONSHIP ID ["+requestWrapper.getCustomers().getRelationshipId()+"]");
        }
        return null;
    }

    /**
    * <Description>
    * <p> 
    * <p> 
    *  
    * @param 
    * @return
    * @throws ProcessException 
    * @exception
    * @see
    * @since
    */
    private GlobalCustomersEntity findByProfileId(TravellingObject trObj,GlobalCustomersRequestWrapper requestWrapper) throws ProcessException
    {
        try
        {
            if (requestWrapper.getCustomers().getProfileId() != null) 
            {
                return globalCustomersRepository.findByBaseCountryAndProfileId(
                    requestWrapper.getCustomers().getBaseCountry(),
                    requestWrapper.getCustomers().getProfileId()
                );
            }
        } catch (IncorrectResultSizeDataAccessException e) {
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.DUPLICATE_RECORDS_EXIST,"DUPLICATE RECORDS EXIST FOR PROFILE ID ["+requestWrapper.getCustomers().getProfileId()+"]");
        }
        return null;
    }

    /**
    * <Description>
    * <p> 
    * <p> 
    *  
    * @param 
    * @return
    * @throws ProcessException 
    * @exception
    * @see
    * @since
    */
    private void validateFieldLength(String fieldValue, String minLength, String maxLength, List<ErrorObject> errorObjectList, String errorType, String errorCode, String errorMessage) 
    {
        if (!StringUtility.minMaxlength(fieldValue, minLength, maxLength)) {
            errorObjectList.add(new ErrorObject(errorType, errorCode, errorMessage + " [" + fieldValue + "] [DATA LENGTH SHOULD BE BETWEEN " + minLength + " AND " + maxLength + "]"));
        }
    }
}
