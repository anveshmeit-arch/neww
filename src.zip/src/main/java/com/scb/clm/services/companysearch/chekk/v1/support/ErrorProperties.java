package com.scb.clm.services.companysearch.chekk.v1.support;

public enum ErrorProperties {

	CK001("Ck001","Duplicate request found"),
	CK002("Ck002","Mandatory field - Registered ID missing in the Request"),
	CK003("Ck003","Mandatory field - Country of Registration missing in the Request"),
	CK004("Ck004","Mandatory field - Search Depth missing in the Request"),
	CK005("Ck005","Mandatory field - Application reference number missing in the Request"),
	CK006("Ck006","Mandatory field - Country of account opening missing in the Request");
    
    public final String code;
    public final String msg;

    ErrorProperties(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

}
