package com.scb.clm.services.globus.deepening.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;

public class GBSDeepeningResponseCDD {
    @JsonProperty("cddRiskRating")
    private String cddRiskRating;

    @JsonProperty("cddLastReviewDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date cddLastReviewDate;

    @JsonProperty("cddNextReviewDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date cddNextReviewDate;

    @JsonProperty("cddReviewStatus")
    private String cddReviewStatus;

    @JsonProperty("cddReason")
    private String cddReason;

    @JsonProperty("sddEligibleStatus")
    private String sddEligibleStatus;

    @JsonProperty("sddEligibleDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date sddEligibleDate;

    @JsonProperty("cddRiskRatingDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date cddRiskRatingDate;

    @JsonProperty("countryLastReviewDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date countryLastReviewDate;

    @JsonProperty("countryNextReviewDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date countryNextReviewDate;

    @JsonProperty("countryReviewStatus")
    private String countryReviewStatus;

    @JsonProperty("cddReviewedFlag")
    private String cddReviewedFlag;

    @JsonProperty("cddLastReviewedBy")
    private String cddLastReviewedBy;

    @JsonProperty("senderId")
    private String senderId;

    @JsonProperty("senderBranch")
    private String senderBranch;

    @JsonProperty("icddReference")
    private String icddReference;

    @JsonProperty("cupidReference")
    private String cupidReference;

    @JsonProperty("crsReference")
    private String crsReference;

    @JsonProperty("crsStatus")
    private String crsStatus;

    @JsonProperty("crsRemarks")
    private String crsRemarks;

    @JsonProperty("crsCreatedTimeStamp")
    private String crsCreatedTimeStamp;

    @JsonProperty("crsUpdatedTimeStamp")
    private String crsUpdatedTimeStamp;

    public GBSDeepeningResponseCDD() {
    }

    public String getCddRiskRating() {
        return cddRiskRating;
    }

    public void setCddRiskRating(String cddRiskRating) {
        this.cddRiskRating = cddRiskRating;
    }

    public Date getCddLastReviewDate() {
        return cddLastReviewDate;
    }

    public void setCddLastReviewDate(Date cddLastReviewDate) {
        this.cddLastReviewDate = cddLastReviewDate;
    }

    public Date getCddNextReviewDate() {
        return cddNextReviewDate;
    }

    public void setCddNextReviewDate(Date cddNextReviewDate) {
        this.cddNextReviewDate = cddNextReviewDate;
    }

    public String getCddReviewStatus() {
        return cddReviewStatus;
    }

    public void setCddReviewStatus(String cddReviewStatus) {
        this.cddReviewStatus = cddReviewStatus;
    }

    public String getCddReason() {
        return cddReason;
    }

    public void setCddReason(String cddReason) {
        this.cddReason = cddReason;
    }

    public String getSddEligibleStatus() {
        return sddEligibleStatus;
    }

    public void setSddEligibleStatus(String sddEligibleStatus) {
        this.sddEligibleStatus = sddEligibleStatus;
    }

    public Date getSddEligibleDate() {
        return sddEligibleDate;
    }

    public void setSddEligibleDate(Date sddEligibleDate) {
        this.sddEligibleDate = sddEligibleDate;
    }

    public Date getCddRiskRatingDate() {
        return cddRiskRatingDate;
    }

    public void setCddRiskRatingDate(Date cddRiskRatingDate) {
        this.cddRiskRatingDate = cddRiskRatingDate;
    }

    public Date getCountryLastReviewDate() {
        return countryLastReviewDate;
    }

    public void setCountryLastReviewDate(Date countryLastReviewDate) {
        this.countryLastReviewDate = countryLastReviewDate;
    }

    public Date getCountryNextReviewDate() {
        return countryNextReviewDate;
    }

    public void setCountryNextReviewDate(Date countryNextReviewDate) {
        this.countryNextReviewDate = countryNextReviewDate;
    }

    public String getCountryReviewStatus() {
        return countryReviewStatus;
    }

    public void setCountryReviewStatus(String countryReviewStatus) {
        this.countryReviewStatus = countryReviewStatus;
    }

    public String getCddReviewedFlag() {
        return cddReviewedFlag;
    }

    public void setCddReviewedFlag(String cddReviewedFlag) {
        this.cddReviewedFlag = cddReviewedFlag;
    }

    public String getCddLastReviewedBy() {
        return cddLastReviewedBy;
    }

    public void setCddLastReviewedBy(String cddLastReviewedBy) {
        this.cddLastReviewedBy = cddLastReviewedBy;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public String getSenderBranch() {
        return senderBranch;
    }

    public void setSenderBranch(String senderBranch) {
        this.senderBranch = senderBranch;
    }

    public String getIcddReference() {
        return icddReference;
    }

    public void setIcddReference(String icddReference) {
        this.icddReference = icddReference;
    }

    public String getCupidReference() {
        return cupidReference;
    }

    public void setCupidReference(String cupidReference) {
        this.cupidReference = cupidReference;
    }

    public String getCrsReference() {
        return crsReference;
    }

    public void setCrsReference(String crsReference) {
        this.crsReference = crsReference;
    }

    public String getCrsStatus() {
        return crsStatus;
    }

    public void setCrsStatus(String crsStatus) {
        this.crsStatus = crsStatus;
    }

    public String getCrsRemarks() {
        return crsRemarks;
    }

    public void setCrsRemarks(String crsRemarks) {
        this.crsRemarks = crsRemarks;
    }

    public String getCrsCreatedTimeStamp() {
        return crsCreatedTimeStamp;
    }

    public void setCrsCreatedTimeStamp(String crsCreatedTimeStamp) {
        this.crsCreatedTimeStamp = crsCreatedTimeStamp;
    }

    public String getCrsUpdatedTimeStamp() {
        return crsUpdatedTimeStamp;
    }

    public void setCrsUpdatedTimeStamp(String crsUpdatedTimeStamp) {
        this.crsUpdatedTimeStamp = crsUpdatedTimeStamp;
    }
}
