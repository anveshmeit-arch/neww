package com.scb.clm.services.ekyc.pushekycdata.v1.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)  
public class PusheKYCData
{
    @JsonProperty("body")
    private PusheKYCBodyData pusheKYCBodyData;
    
	public PusheKYCBodyData getPusheKYCBodyData() {
		return pusheKYCBodyData;
	}

	public void setPusheKYCBodyData(PusheKYCBodyData pusheKYCBodyData) {
		this.pusheKYCBodyData = pusheKYCBodyData;
	}

	

}

