package com.scb.clm.services.global.customer.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.scb.clm.services.idsafe.biometric.v1.model.IdentitySafeRequestApplication;

public class GlobalCustomersRequestWrapper
{

    @JsonProperty("application")
    private GlobalCustomersRequestApplication application;
    @JsonProperty("customers")
    private GlobalCustomersRequestCustomers customers;

    public GlobalCustomersRequestWrapper() {        
    }

    public GlobalCustomersRequestApplication getApplication()
    {
        return application;
    }

    public void setApplication(GlobalCustomersRequestApplication application)
    {
        this.application = application;
    }


    public GlobalCustomersRequestCustomers getCustomers() 
    {
        return customers;
    }

    public void setCustomers(GlobalCustomersRequestCustomers customers) 
    {
        this.customers = customers;
    }

}