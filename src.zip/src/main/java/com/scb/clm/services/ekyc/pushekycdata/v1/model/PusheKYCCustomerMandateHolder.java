package com.scb.clm.services.ekyc.pushekycdata.v1.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PusheKYCCustomerMandateHolder {
	
	@JsonProperty("mandateHolder")
	private List<PusheKYCCustomerMandateHolderList> listMandateHold;
	

	public List<PusheKYCCustomerMandateHolderList> getListMandateHold() {
		return listMandateHold;
	}

	public void setListMandateHold(List<PusheKYCCustomerMandateHolderList> listMandateHold) {
		this.listMandateHold = listMandateHold;
	}

}
