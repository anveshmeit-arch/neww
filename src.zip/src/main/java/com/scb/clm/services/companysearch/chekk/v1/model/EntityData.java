package com.scb.clm.services.companysearch.chekk.v1.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

/**
 * This class is used to construct Initial Response.
 */
@Getter
@Setter
public class EntityData {

	@JsonProperty("countryOfEstablishment")
	private String countryOfEstablishment;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	@JsonProperty("names")
	private Names names;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	@JsonProperty("external")
	private External external;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	@JsonProperty("validationStatus")
	private ValidationStatus validationStatus;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	@JsonProperty("addresses")
	private Addresses addresses;

}
