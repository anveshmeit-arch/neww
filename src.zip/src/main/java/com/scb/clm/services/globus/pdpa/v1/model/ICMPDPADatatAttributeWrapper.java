package com.scb.clm.services.globus.pdpa.v1.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ICMPDPADatatAttributeWrapper {
	
	@JsonProperty("reference-id")
	private String referenceId;
	
	@JsonProperty("cust-selection")
	private String custSelection;
	
	@JsonProperty("ccq-sequence")
	private String ccqSequence;
	
	@JsonProperty("sender-id")
	private String senderId;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty("errorDetails")
	private List<ICMErrorDetails> errorDetails;

	public String getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	public String getCustSelection() {
		return custSelection;
	}

	public void setCustSelection(String custSelection) {
		this.custSelection = custSelection;
	}

	public String getCcqSequence() {
		return ccqSequence;
	}

	public void setCcqSequence(String ccqSequence) {
		this.ccqSequence = ccqSequence;
	}

	public String getSenderId() {
		return senderId;
	}

	public void setSenderId(String senderId) {
		this.senderId = senderId;
	}

	public List<ICMErrorDetails> getErrorDetails() {
		return errorDetails;
	}

	public void setErrorDetails(List<ICMErrorDetails> errorDetails) {
		this.errorDetails = errorDetails;
	}

}
