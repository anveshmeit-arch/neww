package com.scb.clm.services.globus.biometric.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSRequestApplication implements Cloneable{

	@JsonProperty("applicationReferenceNumber")
	String applicationReferenceNumber;

	public String getApplicationReferenceNumber() {
		return applicationReferenceNumber;
	}

	public void setApplicationReferenceNumber(String applicationReferenceNumber) {
		this.applicationReferenceNumber = applicationReferenceNumber;
	}

	@Override
	protected Object clone() {
		try {
			return super.clone();
		} catch (CloneNotSupportedException e) {
			return new GBSRequestApplication();
		}
	}
}