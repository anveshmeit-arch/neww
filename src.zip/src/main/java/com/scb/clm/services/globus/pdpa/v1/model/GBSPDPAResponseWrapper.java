package com.scb.clm.services.globus.pdpa.v1.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;



public class GBSPDPAResponseWrapper {
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty("errorDetails")
    private List<ErrorDetails> errordetails;

	public List<ErrorDetails> getErrordetails() {
		return errordetails;
	}

	public void setErrordetails(List<ErrorDetails> errordetails) {
		this.errordetails = errordetails;
	}
	
	 public void addErrors(ErrorDetails argErrors) {
	        if(this.errordetails == null) {
	            this.errordetails= new ArrayList<ErrorDetails>();     
	        }
	        this.errordetails.add(argErrors);
	    }

}
