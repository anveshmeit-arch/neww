package com.scb.clm.services.ekyc.pushekycdata.v1.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PusheKYCJointProfileData {
	
	@JsonProperty("stakeholders")
	private PusheKYCJointCustomerStakeHolders objJointCustStakesHolder;

	@JsonProperty("purposeOfAccount")
	private String purposeOfAccount;

	@JsonProperty("nextOfKin")
	private String nextOfKin;
	
	@JsonProperty("IBAN")
	private String iBan;
	
	@JsonProperty("accountTitle")
	private String accountTitle;
	
	@JsonProperty("accountType")
	private String accountType;
	
	@JsonProperty("mandateHolder")
	private PusheKYCCustomerMandateHolder objMinorCustomerMandateHolder;

	public PusheKYCJointCustomerStakeHolders getObjJointCustStakesHolder() {
		return objJointCustStakesHolder;
	}

	public void setObjJointCustStakesHolder(PusheKYCJointCustomerStakeHolders objJointCustStakesHolder) {
		this.objJointCustStakesHolder = objJointCustStakesHolder;
	}

	public String getPurposeOfAccount() {
		return purposeOfAccount;
	}

	public void setPurposeOfAccount(String purposeOfAccount) {
		this.purposeOfAccount = purposeOfAccount;
	}

	public String getNextOfKin() {
		return nextOfKin;
	}

	public void setNextOfKin(String nextOfKin) {
		this.nextOfKin = nextOfKin;
	}

	public String getiBan() {
		return iBan;
	}

	public void setiBan(String iBan) {
		this.iBan = iBan;
	}

	public String getAccountTitle() {
		return accountTitle;
	}

	public void setAccountTitle(String accountTitle) {
		this.accountTitle = accountTitle;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public PusheKYCCustomerMandateHolder getObjMinorCustomerMandateHolder() {
		return objMinorCustomerMandateHolder;
	}

	public void setObjMinorCustomerMandateHolder(PusheKYCCustomerMandateHolder objMinorCustomerMandateHolder) {
		this.objMinorCustomerMandateHolder = objMinorCustomerMandateHolder;
	}

}
