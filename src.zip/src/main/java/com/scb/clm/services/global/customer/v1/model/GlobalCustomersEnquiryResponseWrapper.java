package com.scb.clm.services.global.customer.v1.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

public class GlobalCustomersEnquiryResponseWrapper
{
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty("customers")
    private List<GlobalCustomersEnquiryContent> customers;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty("errorDetails")
    private ArrayList<GlobalCustomersEnquiryErrorDetails> errorDetails;


    public void addErrors(GlobalCustomersEnquiryErrorDetails argErrors) 
    {
        if(this.errorDetails == null) 
        {
            this.errorDetails= new ArrayList<GlobalCustomersEnquiryErrorDetails>();     
        }
        this.errorDetails.add(argErrors);
    }

    public List<GlobalCustomersEnquiryContent> getCustomers() 
    {
        return customers;
    }

    public void setCustomers(List<GlobalCustomersEnquiryContent> customers) 
    {
        this.customers = customers;
    }

    public ArrayList<GlobalCustomersEnquiryErrorDetails> getErrorDetails() 
    {
        return errorDetails;
    }

    public void setErrorDetails(ArrayList<GlobalCustomersEnquiryErrorDetails> errorDetails) 
    {
        this.errorDetails = errorDetails;
    }
}