package com.scb.clm.services.companysearch.chekk.v1.model.process;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class Address {

	@JsonProperty("partyIdentifier")
	public String partyIdentifier;
	@JsonProperty("addressType")
	public String addressType;
	@JsonProperty("addressL1")
	public String addressL1;
	@JsonProperty("addressL2")
	public String addressL2;
	@JsonProperty("addressL3")
	public String addressL3;
	@JsonProperty("landmark")
	public String landmark;
	@JsonProperty("city")
	public String city;
	@JsonProperty("state")
	public String state;
	@JsonProperty("postalCode")
	public String postalCode;
	@JsonProperty("poBox")
	public String poBox;
	@JsonProperty("country")
	public String country;
	@JsonProperty("addressEffectiveDate")
	public String addressEffectiveDate;
}