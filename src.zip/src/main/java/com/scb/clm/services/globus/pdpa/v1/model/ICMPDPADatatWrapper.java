package com.scb.clm.services.globus.pdpa.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ICMPDPADatatWrapper {
	
	@JsonProperty("id")
	private String id;
	
	@JsonProperty("type")
	private String type;
	
	@JsonProperty("attributes")
	private ICMPDPADatatAttributeWrapper attributes;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public ICMPDPADatatAttributeWrapper getAttributes() {
		return attributes;
	}

	public void setAttributes(ICMPDPADatatAttributeWrapper attributes) {
		this.attributes = attributes;
	}
}
