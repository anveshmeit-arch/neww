package com.scb.clm.services.companysearch.chekk.v1.service;

import java.util.Arrays;
import java.util.Map;

import org.springframework.util.StringUtils;

import com.scb.clm.services.companysearch.chekk.v1.model.ChekkPartyEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.process.Address;
import com.scb.clm.services.companysearch.chekk.v1.model.process.Association;
import com.scb.clm.services.companysearch.chekk.v1.model.process.Document;
import com.scb.clm.services.companysearch.chekk.v1.model.process.Individual;
import com.scb.clm.services.companysearch.chekk.v1.support.AddressSplit;
import com.scb.clm.services.companysearch.chekk.v1.support.PartyMapperUtil;
import com.scb.clm.services.companysearch.chekk.v1.support.ProcessApiConstants;

public class IndividualPartyMapper implements PartyMapperInterface {
    private ChekkPartyEntity party;

    private ChkTableReferences refData;

    public IndividualPartyMapper(ChekkPartyEntity party, ChkTableReferences refData) {
        this.party = party;
        this.refData = refData;
    }

    @Override
    public Address createAddress() {
        Address address = null;
        if (StringUtils.hasText(party.getIndAdress())) {
            address = new Address();
            address.setPartyIdentifier(party.getUniqueId());
            address.setAddressType(ADDRESS_TYPE_RES);
            addAddressLines(address, party.getIndAdress());
            address.setPostalCode(party.getPersonalZipCode());
            address.setCity(party.getPersonalAddressCity());
            // address.setState(""); //No Mapping available in the sheet.
            address.setCountry(party.getPersonalAddressCountry());
        }
        return address;
    }

    @Override
    public Association createAssociation() {
        Association association = new Association();
        association.setAssociatedID(party.getUniqueId());
        association.setAssociatedToIDs(party.getAssociatedToId());

        association.setAssociationType(PartyMapperUtil.updateRoleDescription(party.getIndRole(), refData));
        association.setPartyRole(party.getIndRole());

        association.setOwnershipPercentage(party.getShTotalPercentage());
        association.setSharesAmount(party.getIndSharesAmount());
        association.setShareCurrency(party.getIndSharesCurrency());
        association.setShareType(party.getIndSharesType());

        association.setPercentageOfParent(party.getParentPercentage());
        return association;
    }

    @Override
    public String getDuplicateKeyId() {
        StringBuilder duplicateKeyId = new StringBuilder();
        if (StringUtils.hasText(party.getPartyType())) {
            duplicateKeyId.append(party.getPartyType());
        }
        if (StringUtils.hasText(party.getIndIndividualNumber())) {
            duplicateKeyId.append(party.getIndIndividualNumber());
        }
        if (StringUtils.hasText(party.getIndName())) {
            duplicateKeyId.append(party.getIndName());
        }
        if (StringUtils.hasText(party.getIndBiography())) {
            duplicateKeyId.append(party.getIndBiography());
        }
        return duplicateKeyId.toString();
    }

    @Override
    public Document createDocument() {
        Document document = new Document();
        document.setPartyIdentifier(party.getUniqueId());
        document.setDocumentId(party.getPersonalSgpId());
        document.setDocumentName(party.getPersonalSgpIdType());
        document.setDocumentExpiryDate(party.getIdCmpRegExpDate()); // No such field in nodeData to populate
        return document;
    }

    public Individual createIndividual() {
        Individual individual = new Individual();
        individual.setIndividualID(party.getUniqueId());
        individual.setFirstName(party.getIndName());
        individual.setCountryOfResidence(party.getPersonalAddressCountry());
        individual.setNationality(Arrays.asList(party.getIndBiography()));
        individual.setPercentageOfOwnershipAgainstParent(party.getParentPercentage());
        return individual;
    }

    public static void addAddressLines(Address address, String addressStr) {
        Map<String, String> map = AddressSplit.addressSplit(addressStr);
        if (!map.get(ProcessApiConstants.ADDRESS_LINE1).equals(""))
            address.setAddressL1(map.get(ProcessApiConstants.ADDRESS_LINE1));
        if (!map.get(ProcessApiConstants.ADDRESS_LINE2).equals(""))
            address.setAddressL2(map.get(ProcessApiConstants.ADDRESS_LINE2));
        if (!map.get(ProcessApiConstants.ADDRESS_LINE3).equals(""))
            address.setAddressL3(map.get(ProcessApiConstants.ADDRESS_LINE3));
    }

}
