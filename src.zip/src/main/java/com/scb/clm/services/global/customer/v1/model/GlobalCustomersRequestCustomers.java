package com.scb.clm.services.global.customer.v1.model;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GlobalCustomersRequestCustomers 
{

    @JsonProperty("globalIdentifier")
    private String globalIdentifier;
    
    @JsonProperty("baseCountry")
    private String baseCountry;

    @JsonProperty("relationshipCountry")
    private String relationshipCountry;

    @JsonProperty("profileId")
    private String profileId;

    @JsonProperty("relationshipId")
    private String relationshipId;

    @JsonProperty("validatedBy")
    private String validatedBy;

    @JsonProperty("statusFlag")
    private String statusFlag;

    @JsonProperty("createdDate")
    private Timestamp createdDate;

    @JsonProperty("createdBy")
    private String createdBy;
    
    @JsonProperty("updatedDate")
    private Timestamp updatedDate;

    public String getGlobalIdentifier() {
        return globalIdentifier;
    }

    public void setGlobalIdentifier(String globalIdentifier) {
        this.globalIdentifier = globalIdentifier;
    }

    public String getBaseCountry() {
        return baseCountry;
    }

    public void setBaseCountry(String baseCountry) {
        this.baseCountry = baseCountry;
    }

    public String getRelationshipCountry() {
        return relationshipCountry;
    }

    public void setRelationshipCountry(String relationshipCountry) {
        this.relationshipCountry = relationshipCountry;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getRelationshipId() {
        return relationshipId;
    }

    public void setRelationshipId(String relationshipId) {
        this.relationshipId = relationshipId;
    }

    public String getValidatedBy() {
        return validatedBy;
    }

    public void setValidatedBy(String validatedBy) {
        this.validatedBy = validatedBy;
    }

    public String getStatusFlag() {
        return statusFlag;
    }

    public void setStatusFlag(String statusFlag) {
        this.statusFlag = statusFlag;
    }

    public Timestamp getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Timestamp createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }
   

}