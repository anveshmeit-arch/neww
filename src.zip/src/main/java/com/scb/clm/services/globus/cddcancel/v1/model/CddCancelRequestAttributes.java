package com.scb.clm.services.globus.cddcancel.v1.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;


public class CddCancelRequestAttributes {


    @JsonProperty("applicant-reference-key")
    private String applicantReferenceKey;

    @JsonProperty("customer-master-reference-key")
    public String customerMasterReferenceKey;

    @JsonProperty("core-banking-reference-key")
    public String coreBankingReferenceKey;

    @JsonProperty("onboarding-reference-key")
    public String onboardingReferenceKey;

    @JsonProperty("account-references")
    private List<CddCancelAccountReference> accountReferences; 

    @JsonProperty("reject-reason")
    private String rejectReason;

    @JsonProperty("onboarding-status")
    private String onboardingStatus;

    public String getApplicantReferenceKey() {
        return applicantReferenceKey;
    }

    public void setApplicantReferenceKey(String applicantReferenceKey) {
        this.applicantReferenceKey = applicantReferenceKey;
    }

    public String getCustomerMasterReferenceKey() {
        return customerMasterReferenceKey;
    }

    public void setCustomerMasterReferenceKey(String customerMasterReferenceKey) {
        this.customerMasterReferenceKey = customerMasterReferenceKey;
    }

    public String getCoreBankingReferenceKey() {
        return coreBankingReferenceKey;
    }

    public void setCoreBankingReferenceKey(String coreBankingReferenceKey) {
        this.coreBankingReferenceKey = coreBankingReferenceKey;
    }

    public String getOnboardingReferenceKey() {
        return onboardingReferenceKey;
    }

    public void setOnboardingReferenceKey(String onboardingReferenceKey) {
        this.onboardingReferenceKey = onboardingReferenceKey;
    }

    public List<CddCancelAccountReference> getAccountReferences() {
        return accountReferences;
    }

    public void setAccountReferences(List<CddCancelAccountReference> accountReferences) {
        this.accountReferences = accountReferences;
    }

    public String getRejectReason() {
        return rejectReason;
    }

    public void setRejectReason(String rejectReason) {
        this.rejectReason = rejectReason;
    }

    public String getOnboardingStatus() {
        return onboardingStatus;
    }

    public void setOnboardingStatus(String onboardingStatus) {
        this.onboardingStatus = onboardingStatus;
    }
}
