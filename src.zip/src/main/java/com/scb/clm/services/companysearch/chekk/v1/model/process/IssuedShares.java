package com.scb.clm.services.companysearch.chekk.v1.model.process;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class IssuedShares {

	@JsonProperty("shareType")
	public String shareType;
	@JsonProperty("sharesNumberOther")
	public String sharesNumberOther;
	@JsonProperty("sharesNumberSgDp")
	public String sharesNumberSgDp;
	@JsonProperty("sharesNumberUsAd")
	public String sharesNumberUsAd;
	
	@JsonProperty("issuedShareCapitalOther")
	public String issuedShareCapitalOther;
	@JsonProperty("issuedShareCapitalSgDp")
	public String issuedShareCapitalSgDp;
	@JsonProperty("issuedShareCapitalUsAd")
	public String issuedShareCapitalUsAd;

	@JsonProperty("paidupShareCapitalOther")
	public String paidUpShareCapitalOther;
	@JsonProperty("paidupShareCapitalSgDp")
	public String paidUpShareCapitalSgDp;
	@JsonProperty("paidupShareCapitalUsAd")
	public String paidUpShareCapitalUsAd;
	
}
