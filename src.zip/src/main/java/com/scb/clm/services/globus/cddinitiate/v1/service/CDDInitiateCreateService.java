package com.scb.clm.services.globus.cddinitiate.v1.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.clm.common.config.ApplicationConfiguration;
import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ErrorObject;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.repository.InterfaceRequestTypeRepository;
import com.scb.clm.common.util.JSONUtility;
import com.scb.clm.common.util.ServiceParameterUtility;
import com.scb.clm.common.util.StringUtility;
import com.scb.clm.core.service.ServiceAbstract;
import com.scb.clm.core.service.ServiceInterface;
import com.scb.clm.services.globus.cddinitiate.v1.model.CDDCreateInitiateAliases;
import com.scb.clm.services.globus.cddinitiate.v1.model.CDDCreateInitiateJointApplicants;
import com.scb.clm.services.globus.cddinitiate.v1.model.CDDCreateInitiateSourceOfWealth;
import com.scb.clm.services.globus.cddinitiate.v1.model.CDDReqCreateInitiateAddress;
import com.scb.clm.services.globus.cddinitiate.v1.model.CDDReqCreateInitiateAppliedProducts;
import com.scb.clm.services.globus.cddinitiate.v1.model.CDDReqCreateInitiateContacts;
import com.scb.clm.services.globus.cddinitiate.v1.model.CDDReqCreateInitiateDocuments;
import com.scb.clm.services.globus.cddinitiate.v1.model.CDDReqCreateInitiateEmployment;
import com.scb.clm.services.globus.cddinitiate.v1.model.CDDReqCreateInitiateJsonWrapper;
import com.scb.clm.services.globus.cddinitiate.v1.model.CDDReqCreateInitiateVerifyStatus;
import com.scb.clm.services.globus.cddinitiate.v1.model.CDDRespAccountReferencesInitiateJson;
import com.scb.clm.services.globus.cddinitiate.v1.model.CDDRespCreateInitiateJson;
import com.scb.clm.services.globus.cddinitiate.v1.model.CDDRespErrorsInitiateJson;
import com.scb.clm.services.globus.cddinitiate.v1.model.ErrorResponseDetails;
import com.scb.clm.services.globus.cddinitiate.v1.support.CDDConstants;
import com.scb.clm.services.globus.cddinitiate.v1.support.ProfileDataValidator;
import com.scb.clm.services.globus.onboarding.v1.models.ErrorDetails;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardAddressesWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardAliasesWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardAppliedProductsWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardContactsWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardCustomerNationaliltyWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardCustomerWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardDocumentsWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardEmploymentsMandatoryWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardJointApplicantsWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardReqWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardResponseAccountReference;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardResponseCDDRiskDetails;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardResponseNameScreeningResults;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardResponseOnboardingStatusReason;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardResponseWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardSourceOfWealthWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardVerificationStatusWrapper;

@Service
public class CDDInitiateCreateService extends ServiceAbstract implements ServiceInterface
{

    @Autowired
    RestTemplate restTemplate;

    @Autowired
    InterfaceRequestTypeRepository interfaceRequestTypeRepository;

    @Autowired
    ProfileDataValidator profileDataValidator;

    public static final String CDD_REASON_PRO                  = "PRO";
    public static final String CDD_REASON_NSP                  = "NSP";
    public static final String CDD_REASON_HRC                  = "HRC";
    public static final String CDD_REASON_NSH                  = "NSH";


    /**
     * <Description>
     * <p> 
     * <p> 
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object readRequestObject(TravellingObject travellingObject, NodeServicesEntity srvEntity) throws ProcessException
    {
        List<ErrorObject> errorObjectList = new ArrayList<ErrorObject>();
        LoggerUtil log                    = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "readRequestObject", LogType.APPLICATION.name());

        try
        {
            return JSONUtility.jsonTODomainWrapper(travellingObject.getRequestData(),GBSOnboardReqWrapper.class);
        }
        catch(Exception e)
        {
            log.printErrorMessage(e);
            errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_TECHNICAL, BaseConstants.VALIDATION_ERROR,"INVALID REQUEST FORMAT FOR CDD CREATE SERVICE"));
            ProcessException gbxEx = new ProcessException();
            gbxEx.addAll(errorObjectList);
            throw gbxEx;
        }
        finally
        {
            // N.A
        }
    }


    /**
     * <Description>
     * <p> 
     * <p> 
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public void validateData(TravellingObject travellingObject,NodeServicesEntity srvEntity,Object requestPayload) throws ProcessException
    {
        List<ErrorObject> errorObjectList = new ArrayList<ErrorObject>();
        LoggerUtil log                    = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateData", LogType.APPLICATION.name());

        try
        {

            GBSOnboardReqWrapper requestWrapper = (GBSOnboardReqWrapper) requestPayload;

            ObjectMapper mapper = new ObjectMapper();
            log.println("Response :  "+mapper.writeValueAsString(requestWrapper));

            if(requestWrapper == null)
            {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_TECHNICAL, CDDConstants.INVALID_JSON_FORMAT,"INVALID REQUEST"));
            } else if( (requestWrapper.getGbs_Onboard_ApplnWrapper() == null || !StringUtility.containsData(requestWrapper.getGbs_Onboard_ApplnWrapper().getApplicationReferenceNumber()))) {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_APPLICATION_REFERENCE_NUMBER,"INVALID APPLICATION REFERENCE NUMBER"));
            } else {
                travellingObject.setApplicationReferenceNumber(requestWrapper.getGbs_Onboard_ApplnWrapper().getApplicationReferenceNumber());
            }

            if(requestWrapper != null && requestWrapper.getGbs_Onboard_ApplnWrapper() == null) {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_JSON_FORMAT,"BASIC INFORMATION ('application') TAG IS NULL"));
            }

            if(requestWrapper != null && requestWrapper.getGbs_Onboard_CustomerWrapper() == null) {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_JSON_FORMAT,"BASIC INFORMATION ('customers') TAG IS NULL"));
            }


            if(requestWrapper != null && requestWrapper.getGbs_Onboard_CustomerWrapper() != null) {
                profileDataValidator.validateRequestMessage(requestWrapper.getGbs_Onboard_CustomerWrapper(), errorObjectList);
            }

            if(requestWrapper!=null && requestWrapper.getGbs_Onboard_ApplnWrapper()!=null && !StringUtility.minMaxlength(requestWrapper.getGbs_Onboard_ApplnWrapper().getApplicationReferenceNumber(),"0","50"))
            {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_APPLICATION_REFERENCE_NUMBER,"INVALID APPLICATION REFERENCE NUMBER ["+requestWrapper.getGbs_Onboard_ApplnWrapper().getApplicationReferenceNumber()+"] [DATA LENGTH SHOULD BE IN RANGE 1-50]"));
            }

            if(errorObjectList.size()> 0) {
                ProcessException gbxEx = new ProcessException();
                gbxEx.addAll(errorObjectList);
                throw gbxEx;
            }
        }
        catch (ProcessException e)
        {
            log.println(" Error ["+e.getAllErrors()+"]");
            throw e;
        }
        catch (Exception e)
        {
            log.printErrorMessage(e);
            errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, BaseConstants.VALIDATION_ERROR,"INTERNAL ERROR"));
            ProcessException gbxEx = new ProcessException();
            gbxEx.addAll(errorObjectList);
            throw gbxEx;
        }
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    public void setDocumentsList(List<GBSOnboardDocumentsWrapper> listDocumentsWrapper,CDDReqCreateInitiateJsonWrapper obRequestCDD)
    {
        List<CDDReqCreateInitiateDocuments> documentsList = new ArrayList<CDDReqCreateInitiateDocuments>();
        for (GBSOnboardDocumentsWrapper objForDoc : listDocumentsWrapper)
        {
            if(getRequestPayloadData(objForDoc.getDocumentType()).equalsIgnoreCase("CRS")) {
                continue;
            }

            CDDReqCreateInitiateDocuments document = new CDDReqCreateInitiateDocuments();
            document.setDocument_type(getRequestPayloadData(objForDoc.getDocumentType()));
            document.setDocument_number(getRequestPayloadData(objForDoc.getDocumentNumber()));
            document.setDocument_expiry_date(getRequestPayloadDate(objForDoc.getDocumentExpiryDate()));
            document.setCountry_of_tax_residence(getRequestPayloadData(objForDoc.getTaxResidenceCountry()));
            documentsList.add(document);
        }
        if(documentsList != null && documentsList.size() >0)
        {
            obRequestCDD.setDocuments(documentsList);
        }
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    public void setSourceOfWealth(GBSOnboardSourceOfWealthWrapper objSourceOnboard,CDDReqCreateInitiateJsonWrapper obRequestCDD)
    {
        if(getRequestPayloadData(objSourceOnboard.getPrimarySource()) != null)
        {
            CDDCreateInitiateSourceOfWealth source_of_wealth = new CDDCreateInitiateSourceOfWealth();
            source_of_wealth.setPrimary_source(getRequestPayloadData(objSourceOnboard.getPrimarySource()));
            source_of_wealth.setOccupation_code(getRequestPayloadData(objSourceOnboard.getOccupationCode()));
            source_of_wealth.setEmployer_name(getRequestPayloadData(objSourceOnboard.getEmployerName()));
            source_of_wealth.setEmployer_address(getRequestPayloadData(objSourceOnboard.getEmployerAddress()));
            source_of_wealth.setEmployment_income(getRequestPayloadData(objSourceOnboard.getEmploymentIncome()));
            source_of_wealth.setEmployment_income_currency(getRequestPayloadData(objSourceOnboard.getEmploymentIncomeCurrency()));
            source_of_wealth.setBusiness_type(getRequestPayloadData(objSourceOnboard.getBusinessType()));
            source_of_wealth.setBusiness_name(getRequestPayloadData(objSourceOnboard.getBusinessName()));
            source_of_wealth.setBusiness_address(getRequestPayloadData(objSourceOnboard.getBusinessAddress()));
            source_of_wealth.setBusiness_income(getRequestPayloadData(objSourceOnboard.getBusinessIncome()));
            source_of_wealth.setBusiness_income_currency(getRequestPayloadData(objSourceOnboard.getBusinessIncomeCurrency()));
            source_of_wealth.setInvestments((objSourceOnboard.getInvestments()));
            source_of_wealth.setSavings_from((objSourceOnboard.getSavingsFrom()));
            source_of_wealth.setPrevious_company_name(getRequestPayloadData(objSourceOnboard.getPreviousCompanyName()));
            source_of_wealth.setRelationship_with_funding_member(getRequestPayloadData(objSourceOnboard.getRelationshipWithFundingMember()));
            source_of_wealth.setFunding_member_employee_name(getRequestPayloadData(objSourceOnboard.getFundingMemberEmployeeName()));
            source_of_wealth.setRelationship_with_benefactor(getRequestPayloadData(objSourceOnboard.getRelationshipWithBenefactor()));
            source_of_wealth.setBenefactor_employee_name(getRequestPayloadData(objSourceOnboard.getBenefactorEmployeeName()));
            obRequestCDD.setSourceOfWealth(source_of_wealth);
        }
    }

    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    public void setEmployment(GBSOnboardEmploymentsMandatoryWrapper objEmploymentOnboard,CDDReqCreateInitiateJsonWrapper obRequestCDD, NodeServicesEntity srvEntity)
    {
        CDDReqCreateInitiateEmployment employment = new CDDReqCreateInitiateEmployment();
        employment.setIndustrycode(getRequestPayloadData(objEmploymentOnboard.getIndustryCode()));
        employment.setWork_type(getRequestPayloadData(objEmploymentOnboard.getWorkType()));
        employment.setOccupationcode(getRequestPayloadData(objEmploymentOnboard.getCustomerOccupation()));
        if(getRequestPayloadData(objEmploymentOnboard.getWorkType()) != null) {
            if(getRequestPayloadData(objEmploymentOnboard.getCustomerOccupation()) == null) {
                String occupationCode = ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),"OCCUPATION",objEmploymentOnboard.getWorkType());
                employment.setOccupationcode(occupationCode);
            }
        }
        //		employment.setEmployee_banking_employer_code(getRequestPayloadData(objEmploymentOnboard.getIndustry_code()));
        employment.setStaff_employee_id(getRequestPayloadData(objEmploymentOnboard.getStaffEmpId()));
        employment.setAnnual_declared_income(getRequestPayloadData(""+objEmploymentOnboard.getDeclaredIncome()));
        employment.setAnnual_declared_income_currency(getRequestPayloadData(objEmploymentOnboard.getDeclaredIncomeCurrency()));
        obRequestCDD.setEmployment(employment);
    }

    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    public void setAliases(List<GBSOnboardAliasesWrapper> listAliases,CDDReqCreateInitiateJsonWrapper obRequestCDD)
    {
        List<CDDCreateInitiateAliases> aliasesList = new ArrayList<CDDCreateInitiateAliases>();
        for (GBSOnboardAliasesWrapper objForAliases : listAliases)
        {
            if(getRequestPayloadData(objForAliases.getAliasType()) != null || getRequestPayloadData(objForAliases.getAliasName()) != null)
            {
                CDDCreateInitiateAliases aliases = new CDDCreateInitiateAliases();
                aliases.setAlias_type(getRequestPayloadData(objForAliases.getAliasType()));
                aliases.setAlias_name(getRequestPayloadData(objForAliases.getAliasName()));
                aliasesList.add(aliases);
            }
        }

        if(aliasesList != null && aliasesList.size() >0) {
            obRequestCDD.setAliases(aliasesList);
        }

    }

    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    private void setContacts(List<GBSOnboardContactsWrapper> listContacts,CDDReqCreateInitiateJsonWrapper obRequestCDD)
    {
        LoggerUtil log                                  = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "setContacts", LogType.APPLICATION.name());
        List<CDDReqCreateInitiateContacts> contactList  = new ArrayList<CDDReqCreateInitiateContacts>();

        for (GBSOnboardContactsWrapper objForContacts : listContacts)
        {
            CDDReqCreateInitiateContacts contact = new CDDReqCreateInitiateContacts();

            log.println("objForContacts.getContact_type_code() "+objForContacts.getContactTypeCode()+", "+getMapContactType().get(getRequestPayloadData(objForContacts.getContactTypeCode())));

            contact.setContact_type(getMapContactType().get(getRequestPayloadData(objForContacts.getContactClassificationCode())));
            contact.setCountry_code(getRequestPayloadData(objForContacts.getIsdContactCountryCode()));
            contact.setContact_type_code(getRequestPayloadData(objForContacts.getContactTypeCode()));
            contact.setContact(getRequestPayloadData(objForContacts.getContact()));
            contact.setArea_code(getRequestPayloadData(objForContacts.getAreaCode()));
            contact.setCountry_isd_code(getRequestPayloadData(objForContacts.getCountryCode()));
            contactList.add(contact);
        }

        if(contactList != null && contactList.size() >0) {
            obRequestCDD.setContact(contactList);
        }
    }

    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since

    private HashMap<String, String> getMapContactTypeCode()
    {
    HashMap<String, String> mapContactTypeCode = new HashMap<String, String>();
    mapContactTypeCode.put("EMP", "EMR");
    mapContactTypeCode.put("LMP", "MOB");
    return mapContactTypeCode;
    }
     */
    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    private HashMap<String, String> getMapContactType()
    {
        HashMap<String, String> mapContactType = new HashMap<String, String>();
        mapContactType.put("E", "email");
        mapContactType.put("M", "phone");
        return mapContactType;
    }

    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    private void setAppliedProducts(List<GBSOnboardAppliedProductsWrapper> listAppliedProducts,CDDReqCreateInitiateJsonWrapper obRequestCDD)
    {
        List<CDDReqCreateInitiateAppliedProducts> applied_productsList = new ArrayList<CDDReqCreateInitiateAppliedProducts>();

        for (GBSOnboardAppliedProductsWrapper objForContacts : listAppliedProducts)
        {
            CDDReqCreateInitiateAppliedProducts applied_products = new CDDReqCreateInitiateAppliedProducts();
            applied_products.setProduct_reference_key(getRequestPayloadData(objForContacts.getProductReferenceKey()));
            applied_products.setApplicant_role(getRequestPayloadData(objForContacts.getApplicantRole()));
            applied_products.setAccount_currency(getRequestPayloadData(objForContacts.getAccountCurrency()));
            applied_products.setProduct_name(getRequestPayloadData(objForContacts.getProductCode()));
            applied_products.setSub_product_code(getRequestPayloadData(objForContacts.getSubProductCode()));
            applied_products.setPurpose_of_account_opening(getRequestPayloadData(objForContacts.getPurposeOfAccountOpening()));
            applied_products.setPurpose_onshore_others(getRequestPayloadData(objForContacts.getPurposeOfAccountOpeningOthers()));
            applied_products.setAmount_initial_deposit(getRequestPayloadData(objForContacts.getAmountInitialDeposit()));
            applied_products.setCurrency_initial_deposit(getRequestPayloadData(objForContacts.getCurrencyInitialDeposit()));
            applied_products.setChannel_reference_key(getRequestPayloadData(objForContacts.getChannelReferenceKey()));
            applied_productsList.add(applied_products);
        }
        if(applied_productsList != null && applied_productsList.size() >0)
        {
            obRequestCDD.setAppliedProducts(applied_productsList);
        }
    }

    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    private void setJointsApplicants(List<GBSOnboardJointApplicantsWrapper> listJointApplicants,CDDReqCreateInitiateJsonWrapper obRequestCDD)
    {
        List<CDDCreateInitiateJointApplicants> jointApplicantsList = new ArrayList<CDDCreateInitiateJointApplicants>();

        for (GBSOnboardJointApplicantsWrapper objjointApplicants : listJointApplicants)
        {
            CDDCreateInitiateJointApplicants jointapplicants = new CDDCreateInitiateJointApplicants();
            jointapplicants.setRelated_applicant_reference_key(getRequestPayloadData(objjointApplicants.getRelatedApplicantReferenceKey()));
            jointapplicants.setProfile_role(getRequestPayloadData(objjointApplicants.getProfileRole()));
            if(getRequestPayloadData(objjointApplicants.getProfileRole()) != null || objjointApplicants.getRelatedApplicantReferenceKey() != null)
            {
                jointApplicantsList.add(jointapplicants);
            }
        }
        if(jointApplicantsList != null && jointApplicantsList.size() >0)
        {
            obRequestCDD.setJointApplicants(jointApplicantsList);
        }

    }

    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    private HashMap<String, String> getMapAddressType()
    {
        HashMap<String, String> mapAddressType = new HashMap<String, String>();
        mapAddressType.put("RES", "R");
        mapAddressType.put("AL1", "A");
        mapAddressType.put("CSA", "C");
        return mapAddressType;
    }

    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    private void setAddresses(List<GBSOnboardAddressesWrapper> listAddress,CDDReqCreateInitiateJsonWrapper obRequestCDD, NodeServicesEntity srvEntity)
    {
        List<CDDReqCreateInitiateAddress> addressesList = new ArrayList<CDDReqCreateInitiateAddress>();

        String csaAddressType = ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),"CSA","CSA_ADDRESS_TYPE");
        boolean csaAddressTypeAlreadyExist = false;
        if(csaAddressType != null && csaAddressType.equalsIgnoreCase("Y")) {
            for (GBSOnboardAddressesWrapper objAddress : listAddress)
            {
                if(getRequestPayloadData(objAddress.getAddressType()) != null && getRequestPayloadData(objAddress.getAddressType()).equalsIgnoreCase("CSA")){

                    csaAddressTypeAlreadyExist = true;
                }
            }
        }

        for (GBSOnboardAddressesWrapper objAddress : listAddress)
        {
            if(csaAddressType != null && csaAddressType.equalsIgnoreCase("Y")) {
                if(!csaAddressTypeAlreadyExist) {
                    if(objAddress.getIsMailingAddress() != null && objAddress.getIsMailingAddress().equalsIgnoreCase("Y")) {
                        addAddress(objAddress, addressesList, true);
                        addAddress(objAddress, addressesList, false);
                    }
                }else {
                    addAddress(objAddress, addressesList, false);
                }

            }else {
                addAddress(objAddress, addressesList, false);
            }

        }
        if(addressesList != null && addressesList.size() >0) {
            obRequestCDD.setAddress(addressesList);
        }

    }

    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    private void addAddress(GBSOnboardAddressesWrapper objAddress, List<CDDReqCreateInitiateAddress> addressesList, boolean isCSAType ) {
        CDDReqCreateInitiateAddress address = new CDDReqCreateInitiateAddress();
        if(!isCSAType) {
            address.setAddress_type(getMapAddressType().get(getRequestPayloadData(objAddress.getAddressType())));
        }else {
            address.setAddress_type("C");
        }

        address.setAddress_line1(getRequestPayloadData(objAddress.getAddressLine1()));
        address.setAddress_line2(getRequestPayloadData(objAddress.getAddressLine2()));
        address.setAddress_line3(getRequestPayloadData(objAddress.getAddressLine3()));
        address.setNearest_landmark(getRequestPayloadData(objAddress.getNearestLandMark()));
        address.setCity_name(getRequestPayloadData(objAddress.getCityName()));
        address.setState(getRequestPayloadData(objAddress.getState()));
        address.setCountry_code(getRequestPayloadData(objAddress.getCountryCode()));
        address.setPostal_code(getRequestPayloadData(objAddress.getPostalCode()));
        address.setPo_box(getRequestPayloadData(objAddress.getPostBoxNo()));
        addressesList.add(address);
    }

    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    private void setVerificationStatus(List<GBSOnboardVerificationStatusWrapper> listVerificationStatus,CDDReqCreateInitiateJsonWrapper obRequestCDD)
    {
        CDDReqCreateInitiateVerifyStatus verificationstatus = new CDDReqCreateInitiateVerifyStatus();

        for (GBSOnboardVerificationStatusWrapper objVerificationStatus : listVerificationStatus)
        {
            verificationstatus.setApplicant_details_verified(getRequestPayloadData(objVerificationStatus.getApplicantDetailsVerified()));
            verificationstatus.setVerification_date_time(getRequestPayloadData(objVerificationStatus.getVerificationDateTime()));
            verificationstatus.setMode_of_verification(getRequestPayloadData(objVerificationStatus.getModeOfVerification()));
            verificationstatus.setVerified_by(getRequestPayloadData(objVerificationStatus.getVerifiedBy()));
            verificationstatus.setName_of_verification(getRequestPayloadData(objVerificationStatus.getNameOfVerification()));
            verificationstatus.setDate_of_birth_verification(getRequestPayloadData(objVerificationStatus.getDateOfBirthVerification()));
            verificationstatus.setResidence_address_verification(getRequestPayloadData(objVerificationStatus.getResidenceAddressVerification()));
            verificationstatus.setId_number_verification(getRequestPayloadData(objVerificationStatus.getIdNumberVerification()));
            verificationstatus.setNationality_verification(getRequestPayloadData(objVerificationStatus.getNationalityVerification()));
            verificationstatus.setCountry_specific_1_verification(getRequestPayloadData(objVerificationStatus.getCountrySpecificOneCerification()));
            verificationstatus.setCountry_specific_2_verification(getRequestPayloadData(objVerificationStatus.getCountrySpecificTwoVerification()));
            verificationstatus.setIs_manual_verification(objVerificationStatus.getIsManualVerification());
        }

        obRequestCDD.setVerificationstatus(verificationstatus);

    }

    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    private void setNationality( GBSOnboardCustomerWrapper gbsOnboardCustomerWrapper, CDDReqCreateInitiateJsonWrapper obRequestCDD)
    {
        if(gbsOnboardCustomerWrapper != null && gbsOnboardCustomerWrapper.getObjOnboard_KYCWrapper() != null && gbsOnboardCustomerWrapper.getObjOnboard_KYCWrapper().getNationality() != null) {
            List<String> nationality =new ArrayList<String>();

            for (GBSOnboardCustomerNationaliltyWrapper objNationality : gbsOnboardCustomerWrapper.getObjOnboard_KYCWrapper().getNationality())
            {
                nationality.add(getRequestPayloadData(objNationality.getNationalityCode()));
            }
            if(nationality != null && nationality.size() >0)
            {
                obRequestCDD.setNationality(nationality);
            }
        }
    }

    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    private void setCustomers(GBSOnboardCustomerWrapper requestCustomer, CDDReqCreateInitiateJsonWrapper obRequestCDD, String application_reference_number, String countryCode)
    {
        obRequestCDD.setSalutationCode(getRequestPayloadData(requestCustomer.getSalutationCode()));
        if(countryCode != null && countryCode.equalsIgnoreCase("HK")) {
            obRequestCDD.setFirstName(getRequestPayloadData(requestCustomer.getFullName()));
        }else {
            obRequestCDD.setFirstName(getRequestPayloadData(requestCustomer.getFirstName()));
        }
        obRequestCDD.setMiddleName(getRequestPayloadData(requestCustomer.getMiddleName()));
        obRequestCDD.setLastName(getRequestPayloadData(requestCustomer.getLastName()));
        obRequestCDD.setGender(getRequestPayloadData(requestCustomer.getGender()));
        obRequestCDD.setDateOfBirth(getRequestPayloadDate(requestCustomer.getDateOfBirth()));
        obRequestCDD.setMinorFlag(null);
        obRequestCDD.setBirthCountry(getRequestPayloadData(requestCustomer.getBirthCountry()));
        setNationality(requestCustomer, obRequestCDD);
        obRequestCDD.setCountryCode(getRequestPayloadData(countryCode));
        obRequestCDD.setAccountOpeningCountry(getRequestPayloadData(requestCustomer.getAccountOpeningCountry()));

        obRequestCDD.setOnboardingReferenceKey(getRequestPayloadData(application_reference_number));

        if(requestCustomer.getObjBankInternalInfo() != null)
        {
            obRequestCDD.setArmCode(getRequestPayloadData(requestCustomer.getObjBankInternalInfo().getArmCode()));
            obRequestCDD.setSegmentCode(getRequestPayloadData(requestCustomer.getObjBankInternalInfo().getSegmentCode()));
            obRequestCDD.setSubSegmentCode(getRequestPayloadData(requestCustomer.getObjBankInternalInfo().getSubSegmentCode()));
            obRequestCDD.setCaseOwnerPsId(getRequestPayloadData(requestCustomer.getObjBankInternalInfo().getCaseOwnerPsid()));
            obRequestCDD.setAcquisitionChannel(getRequestPayloadData(requestCustomer.getObjBankInternalInfo().getAcquisitionChannel()));
            obRequestCDD.setCoreBankingReferenceKey(getRequestPayloadData(requestCustomer.getObjBankInternalInfo().getCoreBankingReferenceKey()));
            obRequestCDD.setCustomerMasterReferenceKey(getRequestPayloadData(requestCustomer.getObjBankInternalInfo().getCustomerMasterReferenceKey()));
            obRequestCDD.setProfileType(CDDConstants.PROFILE_CLIENT);
            obRequestCDD.setClienttype(getRequestPayloadData(requestCustomer.getObjBankInternalInfo().getClientType()));
            obRequestCDD.setHomeBranch(getRequestPayloadData(requestCustomer.getObjBankInternalInfo().getHomeBranch()));
        }

        if(requestCustomer.getObjSuspiciousFlags() != null)
        {
            obRequestCDD.setAdverseFlag(getRequestPayloadData(requestCustomer.getObjSuspiciousFlags().getAdverseFlag()));
            obRequestCDD.setPepFlag(getRequestPayloadData(requestCustomer.getObjSuspiciousFlags().getPepFlag()));
            obRequestCDD.setPepDeclarationReason(getRequestPayloadData(requestCustomer.getObjSuspiciousFlags().getPepDetails()));
            obRequestCDD.setSanctionFlag(getRequestPayloadData(requestCustomer.getObjSuspiciousFlags().getSanctionFlag()));
        }

        if(requestCustomer.getObjCddCompliance() != null)
        {
            obRequestCDD.setNumberOfDeposits(getRequestPayloadData(requestCustomer.getObjCddCompliance().getNumberOfDeposits()));
            obRequestCDD.setValueOfDeposits(getRequestPayloadData(requestCustomer.getObjCddCompliance().getValueOfDeposits()));
            obRequestCDD.setNumberOfWithdrawals(getRequestPayloadData(requestCustomer.getObjCddCompliance().getNumberOfWithdrawals()));
            obRequestCDD.setValueOfWithdrawals(getRequestPayloadData(requestCustomer.getObjCddCompliance().getValueOfWithdrawals()));
            obRequestCDD.setClientSourceOfFund(getRequestPayloadData(requestCustomer.getObjCddCompliance().getClientSourceOfFund()));
            obRequestCDD.setClientSourceOfFundOth(getRequestPayloadData(requestCustomer.getObjCddCompliance().getClientSourceOfFundOth()));
            obRequestCDD.setPurposeOffshoreRelationship(getRequestPayloadData(requestCustomer.getObjCddCompliance().getPurposeOfAccountOpeningOffshore()));
            obRequestCDD.setPurposeOffshoreRelationshipOthers(getRequestPayloadData(requestCustomer.getObjCddCompliance().getPurposeOfAccountOpeningOffshoreOthers()));
        }

        if(requestCustomer.getObjOnboard_SourceOfWealthWrapper()!=null){
            obRequestCDD.setSowArticulation(getRequestPayloadData(requestCustomer.getObjOnboard_SourceOfWealthWrapper().getSowArticulation()));
        }

//         employment.setPosition_title(getRequestPayloadData(objEmploymentOnboard.getPositionTitle()));

        if(requestCustomer.getObjOnboard_EmploymentsMandatoryWrapper()!=null){
            obRequestCDD.setPositionTitle(getRequestPayloadData(requestCustomer.getObjOnboard_EmploymentsMandatoryWrapper().getPositionTitle()));
        }

    }


    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object constructOutboundObject(TravellingObject travellingObject,NodeServicesEntity srvEntity,Object requestPayload) throws ProcessException
    {
        LoggerUtil log   = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "constructOutboundObject", LogType.APPLICATION.name());

        try
        {
            log.println("[CDD Create/Initiate] [constructOutboundObject] "+requestPayload);

            GBSOnboardReqWrapper requestWrapper = (GBSOnboardReqWrapper) requestPayload;
            CDDReqCreateInitiateJsonWrapper obRequestCDD = new CDDReqCreateInitiateJsonWrapper();

            setCustomers(requestWrapper.getGbs_Onboard_CustomerWrapper(), obRequestCDD,
                    requestWrapper.getGbs_Onboard_ApplnWrapper().getApplicationReferenceNumber(), travellingObject.getCountryCode());

            if(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjOnboard_DocumentsWrapper() != null && requestWrapper.getGbs_Onboard_CustomerWrapper().getObjOnboard_DocumentsWrapper().size() >0) {
                setDocumentsList(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjOnboard_DocumentsWrapper(), obRequestCDD);
            }

            if(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjOnboard_SourceOfWealthWrapper() != null) {
                setSourceOfWealth(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjOnboard_SourceOfWealthWrapper(), obRequestCDD);
            }

            if(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjOnboard_EmploymentsMandatoryWrapper() != null) {
                setEmployment(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjOnboard_EmploymentsMandatoryWrapper(), obRequestCDD, srvEntity);
            }

            if(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjOnboard_ContactsWrapper() != null) {
                setContacts(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjOnboard_ContactsWrapper(), obRequestCDD);
            }

            if(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjOnboard_AppliedProductsWrapper() != null) {
                setAppliedProducts(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjOnboard_AppliedProductsWrapper(), obRequestCDD);
            }

            if(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjOnboard_JointApplicantsWrapper() != null) {
                log.println("requestWrapper.getGbs_Onboard_CustomerWrapper().getObjOnboard_JointApplicantsWrapper() "+requestWrapper.getGbs_Onboard_CustomerWrapper().getObjOnboard_JointApplicantsWrapper().size());
                setJointsApplicants(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjOnboard_JointApplicantsWrapper(), obRequestCDD);
            }

            if(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjOnboard_AddressesWrapper() != null) {
                setAddresses(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjOnboard_AddressesWrapper(), obRequestCDD, srvEntity);
            }

            if(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjOnboard_VerificationStatusWrapper() != null) {
                setVerificationStatus(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjOnboard_VerificationStatusWrapper(), obRequestCDD);
            }

            return obRequestCDD;
        }
        catch (Exception e)
        {
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, BaseConstants.VALIDATION_ERROR," INTERNAL ERROR WHILE PAYLOAD CONSTRUCTION ");
        }
        finally
        {
            //N.A
        }
    }

    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    private String getRequestPayloadDate(Date reqPayloadDate)
    {
        if(reqPayloadDate != null)
        {
            SimpleDateFormat DateFor = new SimpleDateFormat("yyyy-MM-dd");
            return DateFor.format(reqPayloadDate);
        }

        return null;
    }

    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    private String getRequestPayloadData(String reqPayloadData)
    {
        if(reqPayloadData != null && !reqPayloadData.trim().equalsIgnoreCase("")) {
            return reqPayloadData.trim();
        }
        return null;
    }

    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    private String getCDDReferenceNumber(TravellingObject travellingObject) {

        if(travellingObject != null) {

            JSONUtility.jsonTODomainWrapper(travellingObject.getRequestData(),GBSOnboardReqWrapper.class);

            GBSOnboardReqWrapper requestWrapper = (GBSOnboardReqWrapper) JSONUtility.jsonTODomainWrapper(travellingObject.getRequestData(),GBSOnboardReqWrapper.class);

            if(requestWrapper != null && requestWrapper.getGbs_Onboard_CustomerWrapper() != null && requestWrapper.getGbs_Onboard_CustomerWrapper().getObjBankInternalInfo() != null) {
                if(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjBankInternalInfo().getIcddReference() != null) {
                    return getRequestPayloadData(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjBankInternalInfo().getIcddReference());
                }
            }

        }

        return null;
    }

    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object process(TravellingObject travellingObject,NodeServicesEntity srvEntity,ServiceStatus serviceStatus,Object outBoundRequestObject) throws ProcessException
    {
        LoggerUtil log                      = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "process", LogType.APPLICATION.name());
        CDDRespCreateInitiateJson resCDDObj = null;
        ObjectMapper mapper                 = null;
        ResponseEntity<CDDRespCreateInitiateJson> responseContent = null;

        try
        {
            String token = ApplicationConfiguration.getInstance().getAccessToken(travellingObject, BaseConstants.ICDD_SCOPE );
            
            serviceStatus.setInterfaceId("ICDD");
            CDDReqCreateInitiateJsonWrapper outBoundData = (CDDReqCreateInitiateJsonWrapper) outBoundRequestObject;
            String icddReferencenumber = getCDDReferenceNumber(travellingObject);
            mapper = new ObjectMapper();
            String requestData = mapper.writeValueAsString(outBoundData);
            log.println("Request Payload Data CDD Initiate: "+requestData);


            HttpHeaders headers = new HttpHeaders();
            //headers.add("X-JWT-Assertion","NO_JWT_VALIDATE");
            headers.add(BaseConstants.CONTENT_TYPE,"application/vnd.api+json; charset=utf-8");
            headers.add(BaseConstants.AUTHORIZATION_HEADER, "Bearer "+ token);
            headers.add(BaseConstants.API_HEADER_COUNTRY_CODE,travellingObject.getCountryCode());

            headers.add(BaseConstants.API_HEADER_TRANSACTION_ID, travellingObject.getTransactionID());
            headers.add(BaseConstants.API_HEADER_INTERFACE_ID, travellingObject.getInterfaceId());
            headers.add("tracking-id",travellingObject.getApplicationReferenceNumber());
            headers.add(BaseConstants.API_HEADER_MESSSAGE_SENDER, travellingObject.getInterfaceId());
            log.println("token here : "+ token);
            log.println("Region "+travellingObject.getServiceContext().getCountryCodeWithRegion());


            String hostServiceURL = interfaceRequestTypeRepository.getInterfaceURL(travellingObject.getServiceContext().getCountryCodeWithRegion(),CDDConstants.CDD_INITIATE_INTERFACE_ID,CDDConstants.CDD_INITIATE_SERVICE_ID,"OB", BaseConstants.CODE_SETUP_ACTIVE);
            log.println("Sending Request to ICDD Initiate ["+hostServiceURL+"]"+", Headers : "+headers);
            HttpEntity<CDDReqCreateInitiateJsonWrapper> entity = new HttpEntity<CDDReqCreateInitiateJsonWrapper>(outBoundData,headers);


            boolean icddCreate = isCDDCreate(travellingObject);

            if (getRequestPayloadData(icddReferencenumber) == null || icddCreate == true) 
            {
                log.println("InitiateCDD using the new ICDD Reference Number [POST] ["+hostServiceURL+"]");
                responseContent = restTemplate.exchange(hostServiceURL, HttpMethod.POST, entity, CDDRespCreateInitiateJson.class);
            }
            else 
            {
                hostServiceURL = hostServiceURL + "/" + icddReferencenumber;
                log.println("InitiateCDD using the same ICDD Reference Number [PATCH] ["+hostServiceURL+"]");
                responseContent = restTemplate.exchange(hostServiceURL, HttpMethod.PATCH, entity, CDDRespCreateInitiateJson.class);
            }

            resCDDObj = responseContent.getBody();
            String responseData = mapper.writeValueAsString(resCDDObj);
            log.println("responseData : "+responseData);
            serviceStatus.setHttpStatus(String.valueOf(responseContent.getStatusCodeValue()));
        }
        catch (HttpStatusCodeException ex)
        {
            log.println("HTTP Status Code ["+ex.getStatusCode().toString()+"] Raw HTTP Code ["+ex.getRawStatusCode()+"]");
            serviceStatus.setHttpStatus(ex.getRawStatusCode()+"");
            log.println("Exception Response "+ex.getResponseBodyAsString());

            try 
            {
                mapper = new ObjectMapper();
                mapper.setSerializationInclusion(Include.NON_NULL);
                String requestData = mapper.writeValueAsString(ex.getResponseBodyAsString());
                log.println("Response Payload Data : "+requestData);
                resCDDObj = mapper.readValue(ex.getResponseBodyAsString(), CDDRespCreateInitiateJson.class);
                travellingObject.setResponseData(resCDDObj);
            }
            catch (Exception e)
            {
                log.printErrorMessage(e);
                throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.CDD_REQUEST_ERROR,"INVALID CDD RESPONSE");
            }
        }
        catch(ProcessException e)
        {
            throw e;
        }
        catch(Exception e)
        {
            serviceStatus.setHttpStatus(String.valueOf(BaseConstants.HTTP_500));
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.CDD_REQUEST_ERROR,"CDD PROCESS-INTERNAL ERROR");
        }

        return resCDDObj;
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    private void addCDDReasonCodes(CDDRespCreateInitiateJson resCDDObj, List<GBSOnboardResponseOnboardingStatusReason> cddStatusReasonlist, NodeServicesEntity srvEntity) {

        if(resCDDObj.getRisk_rating() != null) {
            if(resCDDObj.getRisk_rating().equalsIgnoreCase("P")) {
                cddStatusReasonlist.add(new GBSOnboardResponseOnboardingStatusReason(CDD_REASON_PRO, ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),"CDD",CDD_REASON_PRO)));
            }
            if(resCDDObj.getStp_flag() != null && resCDDObj.getStp_flag().equalsIgnoreCase("N")) {
                if(resCDDObj.getRisk_rating().equalsIgnoreCase("A") || resCDDObj.getRisk_rating().equalsIgnoreCase("B")) {
                    cddStatusReasonlist.add(new GBSOnboardResponseOnboardingStatusReason(CDD_REASON_NSP, ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),"CDD",CDD_REASON_NSP)));
                }
            }

            if(resCDDObj.getRisk_rating().equalsIgnoreCase("C") || resCDDObj.getRisk_rating().equalsIgnoreCase("D") ||
                    resCDDObj.getRisk_rating().equalsIgnoreCase("E") || resCDDObj.getRisk_rating().equalsIgnoreCase("P")) {
                cddStatusReasonlist.add(new GBSOnboardResponseOnboardingStatusReason(CDD_REASON_HRC, ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),"CDD",CDD_REASON_HRC)));
            }
        }

        if(resCDDObj.getName_screening_hit() != null && resCDDObj.getName_screening_hit().trim().equalsIgnoreCase("Y")) {
            cddStatusReasonlist.add(new GBSOnboardResponseOnboardingStatusReason(CDD_REASON_NSH, ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),"CDD",CDD_REASON_NSH)));
        }
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    private void setResponseValues(CDDRespCreateInitiateJson resCDDObj, GBSOnboardResponseWrapper resOnboardObj, ServiceStatus serviceStatus, NodeServicesEntity srvEntity)
    {
        if(resCDDObj != null)
        {
            ArrayList<ErrorObject> errorObjectList = new ArrayList<ErrorObject>();
            List<GBSOnboardResponseOnboardingStatusReason> cddStatusReasonlist = new ArrayList<GBSOnboardResponseOnboardingStatusReason>();
            if(resCDDObj.getStp_flag() != null && resCDDObj.getStp_flag().equalsIgnoreCase("N"))
            {
                resOnboardObj.setOnboardingStatus("WIP");
                serviceStatus.setStatus("S");
                serviceStatus.addServiceParams("STP_FLAG", "N");
                resOnboardObj.setCddReferenceKey(resCDDObj.getApplicant_reference_key());
                

            }

            if(resCDDObj.getName_screening_hit() != null && !resCDDObj.getName_screening_hit().trim().equalsIgnoreCase("")) {

                resOnboardObj.setNameScreeningResults(new GBSOnboardResponseNameScreeningResults(resCDDObj.getName_screening_hit(), resCDDObj.getName_screening_alert_id()));
            }

            if(resCDDObj.getRisk_rating() != null) {
                resOnboardObj.setCddRiskDetails(new GBSOnboardResponseCDDRiskDetails(resCDDObj.getRisk_rating(), resCDDObj.getCdd_status()));

            }

            addCDDReasonCodes(resCDDObj, cddStatusReasonlist, srvEntity);

            if(cddStatusReasonlist.size() > 0) {
                resOnboardObj.setOnboardingStatusReason(cddStatusReasonlist);
            }

            if(resCDDObj.getAccount_references() != null && resCDDObj.getAccount_references().size() > 0) {
                List<GBSOnboardResponseAccountReference> accountReferences = new ArrayList<GBSOnboardResponseAccountReference>();

                for(CDDRespAccountReferencesInitiateJson reference : resCDDObj.getAccount_references()) {
                    accountReferences.add(new GBSOnboardResponseAccountReference(reference.getProduct_reference_key(), reference.getAccount_key()));
                }
                if(accountReferences.size() > 0) {
                    resOnboardObj.setAccountReferences(accountReferences);
                }
            }

            if(resCDDObj.isErrorExists())
            {
                if(resCDDObj.getErrors_references() != null)
                {
                    List<ErrorDetails> errordetails = new ArrayList<ErrorDetails>();
                    for (CDDRespErrorsInitiateJson objForErr: resCDDObj.getErrors_references())
                    {

                        doProcessDisplayError(objForErr, errordetails);
                        serviceStatus.setStatus("F");
                    }
                    if(errordetails != null && errordetails.size() > 0) {
                        resOnboardObj.setErrordetails(errordetails);
                    }
                }
            }
            serviceStatus.setResponsePayload(resOnboardObj);
        }
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    public void doProcessDisplayError(CDDRespErrorsInitiateJson objForErr, List<ErrorDetails> errordetails)
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "doProcessDisplayError", LogType.APPLICATION.name());
        try
        {
            ObjectMapper mapper = null;
            mapper = new ObjectMapper();
            mapper.setSerializationInclusion(Include.NON_NULL);
            if(objForErr != null && objForErr.getDetail() != null)
            {
                log.println("Array List ====>  detail : "+objForErr.getDetail());
                String details = objForErr.getDetail().replaceAll("Request Payload Validation Failed:", "").replaceAll("null:", "");
                ErrorResponseDetails[] errorResponseDetails = mapper.readValue(details, ErrorResponseDetails[].class);

                for(int i =0; i<errorResponseDetails.length; i++)
                {
                    ErrorDetails objErr = new ErrorDetails();
                    objErr.setErrorCode(errorResponseDetails[i].getStatus());
                    objErr.setErrorDescription(errorResponseDetails[i].getDetail());
                    errordetails.add(objErr);
                }
            }
            else if(objForErr != null && objForErr.getStatus() != null && objForErr.getDescription() != null)
            {
                ErrorDetails objErr = new ErrorDetails();
                objErr.setErrorCode(objForErr.getStatus());
                objErr.setErrorDescription(objForErr.getDescription());
                errordetails.add(objErr);
            }
        }
        catch (Exception e)
        {
            ErrorDetails objErr = new ErrorDetails();
            objErr.setErrorCode("OB000000");
            objErr.setErrorDescription("INTERNAL ERROR / PROCESSING ERROR");
            errordetails.add(objErr);
        }
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    private void doUpdateRelidProfileid(TravellingObject travellingObject, GBSOnboardResponseWrapper resOnboardObj) {

        if(travellingObject != null) {
            JSONUtility.jsonTODomainWrapper(travellingObject.getRequestData(),GBSOnboardReqWrapper.class);

            GBSOnboardReqWrapper requestWrapper = (GBSOnboardReqWrapper) JSONUtility.jsonTODomainWrapper(travellingObject.getRequestData(),GBSOnboardReqWrapper.class);

            if(requestWrapper != null && requestWrapper.getGbs_Onboard_CustomerWrapper() != null) {
                if(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjBankInternalInfo() != null && requestWrapper.getGbs_Onboard_CustomerWrapper().getObjBankInternalInfo().getCoreBankingReferenceKey() != null) {
                    resOnboardObj.setCoreBankingReferenceKey(getRequestPayloadData(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjBankInternalInfo().getCoreBankingReferenceKey()));
                }

                if(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjBankInternalInfo() != null && requestWrapper.getGbs_Onboard_CustomerWrapper().getObjBankInternalInfo().getCustomerMasterReferenceKey() != null) {
                    resOnboardObj.setCustomerMasterReferenceKey(getRequestPayloadData(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjBankInternalInfo().getCoreBankingReferenceKey()));
                }
            }

        }
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object constructServiceResponse(TravellingObject travellingObject,NodeServicesEntity srvEntity, Object clmResponseData,ServiceStatus serviceStatus) throws ProcessException
    {
        LoggerUtil log                          = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "constructServiceResponse", LogType.APPLICATION.name());
        GBSOnboardResponseWrapper resOnboardObj = new GBSOnboardResponseWrapper();
        serviceStatus.setInterfaceId("ICDD");
        CDDRespCreateInitiateJson obRes = null;

        handleServiceStatusErrors(serviceStatus, resOnboardObj);

        doUpdateRelidProfileid(travellingObject, resOnboardObj);

        if(clmResponseData != null)
        {
            obRes = (CDDRespCreateInitiateJson) clmResponseData;
            if(obRes != null)
            {
                setResponseValues(obRes, resOnboardObj, serviceStatus, srvEntity);

                List<GBSOnboardResponseOnboardingStatusReason> cddStatusReasonlist = new ArrayList<GBSOnboardResponseOnboardingStatusReason>();
                resOnboardObj.setCddReferenceKey(obRes.getApplicant_reference_key());
                setNameScreeningResults(obRes, resOnboardObj);
                setRiskDetails(obRes, resOnboardObj);
                setAccountReferences(obRes, resOnboardObj);
                setCDDReasonCodes(obRes, resOnboardObj, srvEntity);
                setSTPFlag(obRes, serviceStatus);
                
                
                addCDDReasonCodes(obRes, cddStatusReasonlist, srvEntity); 

                if(cddStatusReasonlist.size() > 0) {
                    resOnboardObj.setOnboardingStatusReason(cddStatusReasonlist);
                }

                if(obRes.getStp_flag() != null && obRes.getStp_flag().equalsIgnoreCase("Y"))
                {
                    serviceStatus.addServiceParams("STP_FLAG", "Y");
                    serviceStatus.setStatus("S");
                }
            }
        }
        else
        {
            resOnboardObj.addErrors(new ErrorDetails(CDDConstants.CDD_REQUEST_ERROR,"CDD INTERNAL ERROR"));
            resOnboardObj.setOnboardingStatus("Rejected");
            return resOnboardObj;
        }

       processErrorDetails(resOnboardObj, serviceStatus);

        log.println("CDD Service Status "+JSONUtility.domainWrapperToJSON(serviceStatus));

        if(srvEntity.getId().getFlowIdentifier().equalsIgnoreCase(CDDConstants.FLOW_ONBOARD_CDD))
        {
            if(resOnboardObj.getErrordetails() !=null && resOnboardObj.getErrordetails().size()>0) 
            {
                resOnboardObj.setOnboardingStatus("Rejected");
            }
            else 
            {  
                resOnboardObj.setOnboardingStatus("WIP");
            }
            return resOnboardObj;
        } 
        else 
        {
            return obRes;
        }

    }
    
    private void processErrorDetails(GBSOnboardResponseWrapper resOnboardObj, ServiceStatus serviceStatus) {
        if (hasErrorDetails(resOnboardObj)) {
            addErrorObjectsToServiceStatus(resOnboardObj, serviceStatus);
        }
    }

    private boolean hasErrorDetails(GBSOnboardResponseWrapper resOnboardObj) {
        return resOnboardObj.getErrordetails() != null && !resOnboardObj.getErrordetails().isEmpty();
    }

    private void addErrorObjectsToServiceStatus(GBSOnboardResponseWrapper resOnboardObj, ServiceStatus serviceStatus) {
        for (ErrorDetails errorDetails : resOnboardObj.getErrordetails()) {
            serviceStatus.addErrorObject(new ErrorObject(BaseConstants.ERROR_TYPE_VALIDATION, errorDetails.getErrorCode(), errorDetails.getErrorDescription()));
        }
    }

    private void handleServiceStatusErrors(ServiceStatus serviceStatus, GBSOnboardResponseWrapper resOnboardObj) {
        if (isServiceStatusErrorPresent(serviceStatus)) {
            addErrorDetailsToResponse(serviceStatus, resOnboardObj);
            serviceStatus.setResponsePayload(resOnboardObj);
        }
    }

    private boolean isServiceStatusErrorPresent(ServiceStatus serviceStatus) {
        return serviceStatus != null && serviceStatus.getErrorObject() != null && !serviceStatus.getErrorObject().isEmpty();
    }

    private void addErrorDetailsToResponse(ServiceStatus serviceStatus, GBSOnboardResponseWrapper resOnboardObj) {
        for (ErrorObject errorObject : serviceStatus.getErrorObject()) {
            resOnboardObj.addErrors(new ErrorDetails((String) errorObject.getCode(), (String) errorObject.getDescription()));
        }
    }
    private void setRiskDetails(CDDRespCreateInitiateJson obRes, GBSOnboardResponseWrapper resOnboardObj) {
        if (obRes.getRisk_rating() != null) {
            resOnboardObj.setCddRiskDetails(new GBSOnboardResponseCDDRiskDetails(obRes.getRisk_rating(), obRes.getCdd_status()));
        }
    }

    private void setAccountReferences(CDDRespCreateInitiateJson obRes, GBSOnboardResponseWrapper resOnboardObj) {
        if (obRes.getAccount_references() != null && !obRes.getAccount_references().isEmpty()) {
            List<GBSOnboardResponseAccountReference> accountReferences = new ArrayList<>();
            for (CDDRespAccountReferencesInitiateJson reference : obRes.getAccount_references()) {
                accountReferences.add(new GBSOnboardResponseAccountReference(reference.getProduct_reference_key(), reference.getAccount_key()));
            }
            if (!accountReferences.isEmpty()) {
                resOnboardObj.setAccountReferences(accountReferences);
            }
        }
    }

    private void setCDDReasonCodes(CDDRespCreateInitiateJson obRes, GBSOnboardResponseWrapper resOnboardObj, NodeServicesEntity srvEntity) {
        List<GBSOnboardResponseOnboardingStatusReason> cddStatusReasonlist = new ArrayList<>();
        addCDDReasonCodes(obRes, cddStatusReasonlist, srvEntity);
        if (!cddStatusReasonlist.isEmpty()) {
            resOnboardObj.setOnboardingStatusReason(cddStatusReasonlist);
        }
 }
    
    
    private void setNameScreeningResults(CDDRespCreateInitiateJson obRes, GBSOnboardResponseWrapper resOnboardObj) {
        if (obRes.getName_screening_hit() != null && !obRes.getName_screening_hit().trim().equalsIgnoreCase("")) {
            resOnboardObj.setNameScreeningResults(new GBSOnboardResponseNameScreeningResults(obRes.getName_screening_hit(), obRes.getName_screening_alert_id()));
        }
    }

private void setSTPFlag(CDDRespCreateInitiateJson obRes, ServiceStatus serviceStatus) {
    if ("Y".equalsIgnoreCase(obRes.getStp_flag())) {
        serviceStatus.addServiceParams("STP_FLAG", "Y");
        serviceStatus.setStatus("S");
    }
}
    /**
     * <Description>
     * <p> 
     * <p> 
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    private boolean isCDDCreate(TravellingObject travellingObject) 
    {
        LoggerUtil log        = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "constructServiceResponse", LogType.APPLICATION.name());
        String profileStatus  = null;
        String profileType    = null;

        GBSOnboardReqWrapper requestWrapper = (GBSOnboardReqWrapper) JSONUtility.jsonTODomainWrapper(travellingObject.getRequestData(), GBSOnboardReqWrapper.class);
        if (requestWrapper != null && requestWrapper.getGbs_Onboard_CustomerWrapper() != null && requestWrapper.getGbs_Onboard_CustomerWrapper().
        		getObjBankInternalInfo() != null) 
        {
            if (requestWrapper.getGbs_Onboard_CustomerWrapper().getObjBankInternalInfo().getProfileType() != null) 
            {
                profileType   = getRequestPayloadData(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjBankInternalInfo().getProfileType());
                profileStatus = getRequestPayloadData(requestWrapper.getGbs_Onboard_CustomerWrapper().getObjBankInternalInfo().getProfileStatus());
            }
        }
        log.println("Profile Type ["+profileType+"] Profile Status ["+profileStatus+"]");
     
        if (profileType != null && profileStatus != null) 
        {
            if ((profileType.equalsIgnoreCase("C") && profileStatus.equalsIgnoreCase("N"))
                    || (profileType.equalsIgnoreCase("R") && profileStatus.equalsIgnoreCase("N"))
                    ||(profileType.equalsIgnoreCase("N"))) 
            {
                return true;
            }
            else if ((profileType.equalsIgnoreCase("R") && profileStatus.equalsIgnoreCase("A"))
                    || (profileType.equalsIgnoreCase("C") && profileStatus.equalsIgnoreCase("O"))) 
            {
                return false;
            }
        }
        return false;

    }
}
