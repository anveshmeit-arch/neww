package com.scb.clm.services.companysearch.chekk.v1.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.clm.common.util.DateTimeUtility;
import com.scb.clm.services.companysearch.chekk.v1.exception.ApplicationException;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkPartyEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkRequestsEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkSearchEntityQEntity;
import com.scb.clm.services.companysearch.chekk.v1.support.DBUtility;
import com.scb.clm.services.companysearch.chekk.v1.support.DataUtility;
import com.scb.clm.services.companysearch.chekk.v1.support.ProcessApiConstants;

/**
 * <ul>
 * Read all request id's in UP (Unwrap Pending) status from Chk_request table
 * </ul>
 * <ul>
 * Read all max(level) EntitySearchQ records for each request id
 * 
 * <li>Group by (requestid, <searchEntQ Maxlevel> ) map records.</li>
 * <li>iterate amp and check for each requestId if all searchQ records are
 * completed or failed or in progress</li>
 * <li>completed-> move to next level or mark as closed based on condition check
 * </li>
 * <li>All failed - mark iteration failed at chk_req table with reason</li>
 * <li>in progress - skip</li>
 * </ul>
 * <ul>
 * Check if processing completed for currentLevel for all searchQ records or not
 * </ul>
 * <ul>
 * if completed, check if it is eligible for next level or not. if eligible for
 * next level then read all entity party records and add it to searchQ table for
 * unwrapping with status as SP
 * 
 * </ul>
 * <ul>
 * if Not completed, ie, if any records in GP, CP, SP , UP status (pending
 * status) or not in XC, XF, SF, CF, GF status then skip this record and
 * continue for next one.
 * </ul>
 * <ul>
 * check for searchQRecords for a request id where all are in failed status
 * </ul>
 */

@Service
public class EntitySearchUnwrapper {

	@Autowired
	private ChkSchedulerDao schedulerDao;

	@Autowired
	DBUtility dbUtility;

	private final BigDecimal MAX_PERCENTAGE = new BigDecimal("91.0000");

	public void unwrapSearchEntityQ(List<ChekkSearchEntityQEntity> searchEntityQList) {
		if (searchEntityQList == null || searchEntityQList.isEmpty())
			return;
		try {
			Map<String, List<ChekkSearchEntityQEntity>> upORucORfailedReq = groupByRequestIdAndFilterSearchCompleted(
					searchEntityQList);

			for (Map.Entry<String, List<ChekkSearchEntityQEntity>> entry : upORucORfailedReq.entrySet()) {
				String requestId = entry.getKey();
				List<ChekkSearchEntityQEntity> searchEntQForProcesing = entry.getValue();
				completeOrIterateToNextLevel(requestId, searchEntQForProcesing);
			}

		} catch (ApplicationException ae) {
			throw new ApplicationException();
		}
	}

	private void completeOrIterateToNextLevel(String requestId, List<ChekkSearchEntityQEntity> searchEntQForProcesing) {
		boolean isErrorOccurred = false;
		List<ChekkSearchEntityQEntity> filterUPRequests = filterUnwrapPendingRecords(searchEntQForProcesing);
		
		try {
			if (canMarkAsCompleted(requestId, searchEntQForProcesing)) {
				markAsCompleted(requestId, filterUPRequests);
			} else {
				unwrapToNextLevel(requestId, filterUPRequests);
			}

		} catch (ApplicationException ae) {
			isErrorOccurred = true;
		} catch (Exception e) {
			isErrorOccurred = true;
		} finally {
			// TODO update error code for unwrapping failed
			if (isErrorOccurred) {
				markAsUnwrappingFailed(requestId, filterUPRequests);
			}
		}
	}

	private void unwrapToNextLevel(String requestId, List<ChekkSearchEntityQEntity> filterUPRequests) {
		boolean isNextLevelAddedForRequestId = false;
		for (ChekkSearchEntityQEntity searchEntityRecord : filterUPRequests) {
			try {
				String searchEntityId = searchEntityRecord.getSearchEntityId();
				String srchRequestId = searchEntityRecord.getRequestId();
				int currentLevel = searchEntityRecord.getLevel();

				List<ChekkPartyEntity> intermediateEntityParties = readIntermediateEntityParties(srchRequestId,
						searchEntityId);
				if (intermediateEntityParties == null || intermediateEntityParties.isEmpty()
						|| isOnlyMainEntity(intermediateEntityParties)) {
					schedulerDao.updateSearchEntityQStatus(ProcessApiConstants.STATUS_UNWRAPPING_COMPLETED,
							searchEntityId, srchRequestId);
				} else {
					isNextLevelAddedForRequestId = true;
					addEntitiesToSearchQ(requestId, currentLevel + 1, intermediateEntityParties,searchEntityId);
				}

			} catch (ApplicationException ae) {

			} catch (Exception e) {

			}
		}

		if (!isNextLevelAddedForRequestId) {
			schedulerDao.updateChkRequestSatus(requestId, ProcessApiConstants.STATUS_UNWRAPPING_COMPLETED);
		}
	}
	
	private boolean isOnlyMainEntity(List<ChekkPartyEntity> intermediateEntityParties) {
		return (intermediateEntityParties.size() == 1
				&& DataUtility.getAsNumber(intermediateEntityParties.get(0).getDistanceFromRoot()) == 0
				&& DataUtility.getAsNumber(intermediateEntityParties.get(0).getKey()) == 1);
	}

	private void addEntitiesToSearchQ(String requestId, int nextLevel,
			List<ChekkPartyEntity> intermediateEntityParties,String parentEntity) {
		List<ChekkSearchEntityQEntity> chekkSearchEntityQLst = new ArrayList<>();
		for (ChekkPartyEntity anEntityParty : intermediateEntityParties) {
			if (Integer.parseInt(anEntityParty.getDistanceFromRoot()) == 1
					&& Integer.parseInt(anEntityParty.getKey()) > 1) {
				Map<String, String> statusOrError = validateStatusSPorXF(anEntityParty);
				ChekkSearchEntityQEntity chekkSearchEntityQEntity = new ChekkSearchEntityQEntity();
				chekkSearchEntityQEntity.setRequestId(requestId);
				chekkSearchEntityQEntity.setSearchEntityId(dbUtility.generateChkSearchEntityId());
				chekkSearchEntityQEntity.setEntityName(anEntityParty.getIntermediateIdCompanyName());
				chekkSearchEntityQEntity.setRegistrationID(anEntityParty.getIntermediateIdCompanyNumber());
				chekkSearchEntityQEntity.setCountryOfRegistration(anEntityParty.getIntermediateIdCountry());
				chekkSearchEntityQEntity.setCreatedOn(DateTimeUtility.getCurrentTime());
				chekkSearchEntityQEntity.setUpdatedOn(DateTimeUtility.getCurrentTime());
				chekkSearchEntityQEntity.setLevel(nextLevel);
				chekkSearchEntityQEntity.setPartyId(anEntityParty.getPartyId());
				chekkSearchEntityQEntity.setStatus(statusOrError.get("status"));
				chekkSearchEntityQEntity.setErrorCode(statusOrError.get("errorCode"));
				chekkSearchEntityQLst.add(chekkSearchEntityQEntity);
			}
		}
		schedulerDao.addNextLevelParyAndUpdateParentEntity(chekkSearchEntityQLst, requestId, parentEntity);

	}

	private Map<String, String> validateStatusSPorXF(ChekkPartyEntity checkPartyObj) {
		Map<String, String> statusErrorMap = new HashMap<String, String>();
		String cntryOfReg = checkPartyObj.getIntermediateIdCountry();
		String registrationId = checkPartyObj.getIntermediateIdCompanyNumber();
		String entityName = checkPartyObj.getIntermediateIdCompanyName();
		if (cntryOfReg != null && !cntryOfReg.equalsIgnoreCase(ProcessApiConstants.EMPTY_STRING)) {
			if ((registrationId == null || registrationId.equalsIgnoreCase(ProcessApiConstants.EMPTY_STRING))
					&& (entityName == null || entityName.equalsIgnoreCase(ProcessApiConstants.EMPTY_STRING))) {
				statusErrorMap.put("status", ProcessApiConstants.STATUS_PUBLISH_FAILED);
				statusErrorMap.put("errorCode", "Ck002");
			} else {
				statusErrorMap.put("status", ProcessApiConstants.STATUS_SEARCH_PENDING);
				statusErrorMap.put("errorCode", ProcessApiConstants.EMPTY_STRING);
			}
		} else {
			statusErrorMap.put("status", ProcessApiConstants.STATUS_PUBLISH_FAILED);
			statusErrorMap.put("errorCode", "Ck003");
		}
		return statusErrorMap;
	}

	private List<ChekkPartyEntity> readIntermediateEntityParties(String searchRequestId, String searchEntityId) {
		return schedulerDao.readEntityParties(searchRequestId, searchEntityId);

	}

	private void markAsCompleted(String requestId, List<ChekkSearchEntityQEntity> searchEntQForProcesing) {
		schedulerDao.updateRequestAsCompleted(requestId, searchEntQForProcesing);
	}

	private List<ChekkSearchEntityQEntity> filterUnwrapPendingRecords(
			List<ChekkSearchEntityQEntity> searchEntQForProcesing) {
		return searchEntQForProcesing.stream()
				.filter(s -> ProcessApiConstants.STATUS_UNWRAP_PENDING.equalsIgnoreCase(s.getStatus())).toList();
	}

	private void markAsUnwrappingFailed(String requestId, List<ChekkSearchEntityQEntity> filterUPRequests) {
		schedulerDao.updateRequestAsFailed(requestId, filterUPRequests);
	}

	private boolean canMarkAsCompleted(String requestId, List<ChekkSearchEntityQEntity> searchEntQForProcesing) {
		return (reachedMaximulLevel(requestId, searchEntQForProcesing) || reachedMaximumPercentage(requestId));
	}

	public Map<String, List<ChekkSearchEntityQEntity>> groupByRequestId(
			List<ChekkSearchEntityQEntity> searchEntityQList) {
		return searchEntityQList.stream().collect(Collectors.groupingBy(ChekkSearchEntityQEntity::getRequestId));
	}

	public boolean anySearchRequstInProgress(List<ChekkSearchEntityQEntity> searchList) {
		List<String> pendingStatus = Arrays.asList("CP", "SP", "GP");
		boolean hasInProgressRequests = searchList.stream().map(ChekkSearchEntityQEntity::getStatus)
				.anyMatch(pendingStatus::contains);
		return hasInProgressRequests;
	}

	/**
	 * Search completed indicates all requests for which all chekk API calls are
	 * completed and ready for next level processing.
	 * 
	 * @param searchEntityQList
	 * @return
	 */
	public Map<String, List<ChekkSearchEntityQEntity>> groupByRequestIdAndFilterSearchCompleted(
			List<ChekkSearchEntityQEntity> searchEntityQList) {
		return searchEntityQList.stream().collect(Collectors.groupingBy(ChekkSearchEntityQEntity::getRequestId))
				.entrySet().stream().filter(e -> !anySearchRequstInProgress(e.getValue()))
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

	}

	private boolean reachedMaximulLevel(String requestId, List<ChekkSearchEntityQEntity> searchEntityQs) {
		int maxSearchDepth = getMaxSearchDepth(requestId);
		int currentLevel = getCurrentLevel(searchEntityQs);
		return (currentLevel > maxSearchDepth - 1);
	}

	private boolean reachedMaximumPercentage(String requestId) {
		BigDecimal totalPercentage = schedulerDao.sumOfIndividualPercentage(requestId);

		boolean status = false;
		if (totalPercentage.compareTo(MAX_PERCENTAGE) > 0) {
			status = true;
		}

		return status;
	}

	private int getCurrentLevel(List<ChekkSearchEntityQEntity> searchEntityQs) {
		if (searchEntityQs == null || searchEntityQs.isEmpty()) {
			throw new ApplicationException("Internal Error", "", "Request Id not found ");
		}
		ChekkSearchEntityQEntity aSrchEntity = searchEntityQs.get(0);
		return aSrchEntity.getLevel();
	}

	private int getMaxSearchDepth(String requestId) {
		ChekkRequestsEntity requestEntity = schedulerDao.getChkRequest(requestId);
		if (requestEntity == null) {
			throw new ApplicationException("Internal Error", "", "Request Id not found ");
		}
		return requestEntity.getSearchDepth();
	}

}
