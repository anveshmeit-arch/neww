package com.scb.clm.services.globus.icm.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ICMCustomerCreateResponseData {

    @JsonProperty("id")
    public String 	id="CommandAPI";

    @JsonProperty("type") 
    String type;

    @JsonProperty("attributes") 
    private ICMCustomerCreateResponseAttributes attributes;

    @JsonProperty("links") 
    private APILinks links;



    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id==null?"CommandAPI":id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }



    public void setAttributes(ICMCustomerCreateResponseAttributes attributes) {
        this.attributes = attributes;
    }
    public ICMCustomerCreateResponseAttributes getAttributes() {
        return attributes;
    }
    public APILinks getLinks() {
        return links;
    }
    public void setLinks(APILinks links) {
        this.links = links;
    }
}
