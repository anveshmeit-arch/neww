package com.scb.clm.services.globus.mule.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSMuleRequestApplication 
{

    @JsonProperty("application-reference-number")  
    private String applicationReferenceNumber;

    public String getApplicationReferenceNumber() {
        return applicationReferenceNumber;
    }

    public void setApplicationReferenceNumber(String applicationReferenceNumber) {
        this.applicationReferenceNumber = applicationReferenceNumber;
    }
    
}