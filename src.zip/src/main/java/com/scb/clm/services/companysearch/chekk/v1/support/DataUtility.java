package com.scb.clm.services.companysearch.chekk.v1.support;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.util.StringUtils;

public class DataUtility {

	public static boolean containsData(String str) {
		return (str != null && str.trim().length() > 0);
	}

	public static String getCountryCode(String country) {
		if (StringUtils.hasText(country) && country.length() >= 3) {
			return country.substring(0, 2);
		} else {
			return country;
		}
	}

	public static String parseDate(String date, String targetFormat) throws Exception {
		if (date == null)
			return date;

		SimpleDateFormat frmt = new SimpleDateFormat("yyyy/MM/dd");
		Date dt = frmt.parse(date);

		SimpleDateFormat frmt1 = new SimpleDateFormat(targetFormat);
		String parsedDate = frmt1.format(dt);
		return parsedDate;
	}

	public static int getAsNumber(String value) {
		int retValue = 0;
		if(value!=null && !value.isEmpty()) {
			try {
				retValue = Integer.parseInt(value);
			}catch(NumberFormatException nfe) {

			}
		}
		return retValue;
	}

	public static boolean isDevProfile() {
		String env = System.getProperty("spring.profiles.active");
		boolean isDev = false;
		if (env.toUpperCase().startsWith("DEV")) {
			isDev = true;
		}
		return isDev;
	}

	public static String capitalizeFirstLetter(String str) {
		if(str==null || str.length()==0) {
			return str;
		}
		return Character.toUpperCase(str.charAt(0))+str.substring(1);
	}
}
