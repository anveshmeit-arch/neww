package com.scb.clm.services.globus.biometric.v1.support;

public class BiometricConstants {
	public static final String ONBOARD_FLOW                         = "FONBRD";
	public static final String CLM_REQUEST_ERROR                    = "ID000008";
	public static final String INVALID_APPLICATION_REFERENCE_NUMBER = "ID000009";
	public static final String INTERNAL_PROCESSING_ERROR            = "ID000010";
	public static final String INVALID_JSON_FORMAT                  = "ID000001";
	public static final String REQUEST_TYPE                         = "idsafe";
}
