package com.scb.clm.services.companysearch.chekk.v1.model.process;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class IndustryClassifications {

	@JsonProperty("ISIC")
	public String isic;
	@JsonProperty("NAICS")
	public String naics;
	@JsonProperty("NACE")
	public String nace;
	@JsonProperty("otherISIC")
	public List<String> otherISIC;
	@JsonProperty("SSIC")
	public String ssic;
	@JsonProperty("otherSSIC")
	public List<String> otherSSIC;
	@JsonProperty("primaryIndustryLabel")
	public String idPrimaryIndustryLabel;
	@JsonProperty("secondaryIndustryLabel")
	public String idSecondaryIndustryLabel;	
	@JsonProperty("primarySSICOtherDescription")
	public String idPrimarySsicOtherDescription;
	@JsonProperty("secondarySSICOtherDescription")
	public String idSecondarySsicOtherDescription;
    
}