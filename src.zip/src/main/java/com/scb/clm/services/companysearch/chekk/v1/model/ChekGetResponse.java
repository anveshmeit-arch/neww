package com.scb.clm.services.companysearch.chekk.v1.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)

public class ChekGetResponse {

	@JsonProperty("nodeDataArray")
	public List<NodeDataArray> nodeDataArray;
	@JsonProperty("linkDataArray")
	public List<LinkDataArray> linkDataArray;
	@JsonProperty("warning")
	public String warning;
	@JsonProperty("status")
	public String status;
	@JsonProperty("creationDate")
	public String creationDate;
}
