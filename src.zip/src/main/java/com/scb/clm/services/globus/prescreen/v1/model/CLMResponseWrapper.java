package com.scb.clm.services.globus.prescreen.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CLMResponseWrapper
{
    @JsonProperty("data")
    CLMResponseData data;

    public CLMResponseData getData() {
        return data;
    }
    public void setData(CLMResponseData data) {
        this.data = data;
    }
}