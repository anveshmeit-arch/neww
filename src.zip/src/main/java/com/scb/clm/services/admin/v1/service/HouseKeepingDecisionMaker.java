package com.scb.clm.services.admin.v1.service;

import java.util.List;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.codesetup.NodeServicesEntityKey;
import com.scb.clm.common.model.codesetup.NodesEntity;
import com.scb.clm.common.model.transactions.NodeStatus;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.util.JSONUtility;
import com.scb.clm.core.service.DecisionMakerInterface;

public class HouseKeepingDecisionMaker implements DecisionMakerInterface
{

	@Override
	public void isGoodToProceed(TravellingObject travelObj,NodesEntity nodesEntity,List<NodeServicesEntity> service,NodeStatus nodeStatus)
	{
        LoggerUtil log   = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "isGoodToProceed", LogType.APPLICATION.name());
		try
		{
			for(NodeServicesEntity services :  service) 
			{
				ServiceStatus stat = travelObj.getServiceStatus(services.getId());
				if(!stat.getStatus().equals(BaseConstants.SERVICE_SUCCESS)) 
				{
				    log.println("Service Failed For "+stat.printKey());
					nodeStatus.setProcessToNextNode(false);
				}
			}
			log.println("House Keeping Decision Maker - Service Success Status ["+((nodeStatus.isProcessToNextNode())?"Success":"Failure")+"]");
		}
		catch(Exception e)
		{
		}
	}

	@Override
	public void buildResponse(TravellingObject travelObj,NodesEntity nodesEntity,List<NodeServicesEntity> service,boolean isSuccess)
	{
        LoggerUtil log   = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "buildResponse", LogType.APPLICATION.name());
		try
		{
		    log.println("Building Response Data ["+isSuccess+"]");
			if(isSuccess) {
				travelObj.setResponseData(buildSuccessResponse(travelObj,nodesEntity,service));
			} else {
				travelObj.setResponseData(buildFailureResponse(travelObj,nodesEntity,service));
			}
		}
		catch(Exception e)
		{
		}
	}

	private Object buildSuccessResponse(TravellingObject travelObj,NodesEntity nodesEntity,List<NodeServicesEntity> service)
	{
        LoggerUtil log   = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "buildSuccessResponse", LogType.APPLICATION.name());
		try
		{
		    log.println("Success - "+JSONUtility.domainWrapperToJSON(travelObj));

			return (travelObj.getServiceStatus(new NodeServicesEntityKey(
					service.get(0).getId().getCountryCode(), 
					service.get(0).getId().getFlowIdentifier(), 
					service.get(0).getId().getNodeIdentifier(), 
					service.get(0).getId().getServiceIdentifier()))).getResponsePayload();
		}
		catch(Exception e)
		{ 
		}
		return null;
	}

	private Object buildFailureResponse(TravellingObject travelObj,NodesEntity nodesEntity,List<NodeServicesEntity> service)
	{
        LoggerUtil log   = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "buildFailureResponse", LogType.APPLICATION.name());
		try
		{
		    log.println("Fail -"+JSONUtility.domainWrapperToJSON(travelObj));
			return (travelObj.getServiceStatus(new NodeServicesEntityKey(
					service.get(0).getId().getCountryCode(), 
					service.get(0).getId().getFlowIdentifier(), 
					service.get(0).getId().getNodeIdentifier(), 
					service.get(0).getId().getServiceIdentifier()))).getResponsePayload();
		}
		catch(Exception e)
		{
		}
		return null;
	}
}
