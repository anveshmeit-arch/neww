package com.scb.clm.services.globus.prescreen.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;


public class CLMRequestData
{
    @JsonProperty("id") 
    String id;
    @JsonProperty("type") 
    String type;
    @JsonProperty("attributes") 
    CLMRequestAttributes attributes;
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public CLMRequestAttributes getAttributes() {
        return attributes;
    }
    public void setAttributes(CLMRequestAttributes attributes) {
        this.attributes = attributes;
    }
}
