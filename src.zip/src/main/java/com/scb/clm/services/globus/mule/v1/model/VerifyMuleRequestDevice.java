package com.scb.clm.services.globus.mule.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class VerifyMuleRequestDevice 
{

	@JsonProperty("deviceID")
	private String deviceID;
	
    @JsonProperty("deviceType")
    private String deviceType;

    @JsonProperty("ipAddress")
    private String ipAddress;

    @JsonProperty("deviceBrand")
	private String deviceBrand;
    
	@JsonProperty("deviceModel")
	private String deviceModel;
	
    public VerifyMuleRequestDevice() {
        
    }
    
    public String getDeviceID() {
        return deviceID;
    }

    public void setDeviceID(String deviceID) {
        this.deviceID = deviceID;
    }
    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

	public String getDeviceBrand() {
		return deviceBrand;
	}

	public void setDeviceBrand(String deviceBrand) {
		this.deviceBrand = deviceBrand;
	}

	public String getDeviceModel() {
		return deviceModel;
	}

	public void setDeviceModel(String deviceModel) {
		this.deviceModel = deviceModel;
	}

}

