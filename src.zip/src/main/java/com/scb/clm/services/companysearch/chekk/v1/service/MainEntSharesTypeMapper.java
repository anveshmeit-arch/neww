package com.scb.clm.services.companysearch.chekk.v1.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.StringUtils;

import com.scb.clm.services.companysearch.chekk.v1.model.ChekkPartyEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.process.IssuedShares;

public class MainEntSharesTypeMapper {
	private ChekkPartyEntity party;

	enum SharesType {
		ORSH, PRSH, TRSH, OTSH
	};

	public MainEntSharesTypeMapper(ChekkPartyEntity party) {
		this.party = party;
	}

	public List<IssuedShares> createIssuedShares() {
		List<IssuedShares> issuedShares = new ArrayList<>();

		IssuedShares orsh = createORSHType();
		IssuedShares prsh = createPRSHType();
		IssuedShares trsh = createTRSHType();
		IssuedShares otsh = createOTSHType();
		if (orsh != null) {
			issuedShares.add(orsh);
		}
		if (prsh != null) {
			issuedShares.add(prsh);
		}
		if (trsh != null) {
			issuedShares.add(trsh);
		}
		if (otsh != null) {
			issuedShares.add(otsh);
		}
		return issuedShares;
	}

	private IssuedShares createORSHType() {
		IssuedShares orshIssuedShares = null;
		if (StringUtils.hasText(party.getOrshSharesNumberOther())
				|| StringUtils.hasText(party.getOrshSharesNumberSgdp())
				|| StringUtils.hasText(party.getOrshSharesNumberUsad())
				|| StringUtils.hasText(party.getOrshIssuedShareCapitalOther())
				|| StringUtils.hasText(party.getOrshIssuedShareCapitalSgpd())
				|| StringUtils.hasText(party.getOrshIssuedShareCapitalUsad())
				|| StringUtils.hasText(party.getOrshPaidUpShareCapitalOther())
				|| StringUtils.hasText(party.getOrshPaidUpShareCapitalSgpd())
				|| StringUtils.hasText(party.getOrshPaidUpShareCapitalUsad())) {
			orshIssuedShares = new IssuedShares();
			orshIssuedShares.setShareType(SharesType.ORSH.name());
			orshIssuedShares.setSharesNumberOther(party.getOrshSharesNumberOther());
			orshIssuedShares.setSharesNumberSgDp(party.getOrshSharesNumberSgdp());
			orshIssuedShares.setSharesNumberUsAd(party.getOrshSharesNumberUsad());

			orshIssuedShares.setIssuedShareCapitalOther(party.getOrshIssuedShareCapitalOther());
			orshIssuedShares.setIssuedShareCapitalSgDp(party.getOrshIssuedShareCapitalSgpd());
			orshIssuedShares.setIssuedShareCapitalUsAd(party.getOrshIssuedShareCapitalUsad());

			orshIssuedShares.setPaidUpShareCapitalOther(party.getOrshPaidUpShareCapitalOther());
			orshIssuedShares.setPaidUpShareCapitalSgDp(party.getOrshPaidUpShareCapitalSgpd());
			orshIssuedShares.setPaidUpShareCapitalUsAd(party.getOrshPaidUpShareCapitalUsad());
		}
		return orshIssuedShares;
	}

	private IssuedShares createPRSHType() {
		IssuedShares prshIssuedShares = null;
		if (StringUtils.hasText(party.getPrshSharesNumberOther())
				|| StringUtils.hasText(party.getPrshSharesNumberSgdp())
				|| StringUtils.hasText(party.getPrshSharesNumberUsad())
				|| StringUtils.hasText(party.getPrshIssuedShareCapitalOther())
				|| StringUtils.hasText(party.getPrshIssuedShareCapitalSgpd())
				|| StringUtils.hasText(party.getPrshIssuedShareCapitalUsad())
				|| StringUtils.hasText(party.getPrshPaidUpShareCapitalOther())
				|| StringUtils.hasText(party.getPrshPaidUpShareCapitalSgpd())
				|| StringUtils.hasText(party.getPrshPaidUpShareCapitalUsad())) {

			prshIssuedShares = new IssuedShares();
			prshIssuedShares.setShareType(SharesType.PRSH.name());
			prshIssuedShares.setSharesNumberOther(party.getPrshSharesNumberOther());
			prshIssuedShares.setSharesNumberSgDp(party.getPrshSharesNumberSgdp());
			prshIssuedShares.setSharesNumberUsAd(party.getPrshSharesNumberUsad());

			prshIssuedShares.setIssuedShareCapitalOther(party.getPrshIssuedShareCapitalOther());
			prshIssuedShares.setIssuedShareCapitalSgDp(party.getPrshIssuedShareCapitalSgpd());
			prshIssuedShares.setIssuedShareCapitalUsAd(party.getPrshIssuedShareCapitalUsad());

			prshIssuedShares.setPaidUpShareCapitalOther(party.getPrshPaidUpShareCapitalOther());
			prshIssuedShares.setPaidUpShareCapitalSgDp(party.getPrshPaidUpShareCapitalSgpd());
			prshIssuedShares.setPaidUpShareCapitalUsAd(party.getPrshPaidUpShareCapitalUsad());
		}
		return prshIssuedShares;
	}

	private IssuedShares createTRSHType() {
		IssuedShares trshIssuedShares = null;
		if (StringUtils.hasText(party.getTrshSharesNumberOther())
				|| StringUtils.hasText(party.getTrshSharesNumberSgdp())
				|| StringUtils.hasText(party.getTrshSharesNumberUsad())
				|| StringUtils.hasText(party.getTrshIssuedShareCapitalOther())
				|| StringUtils.hasText(party.getTrshIssuedShareCapitalSgpd())
				|| StringUtils.hasText(party.getTrshIssuedShareCapitalUsad())
				|| StringUtils.hasText(party.getTrshPaidUpShareCapitalOther())
				|| StringUtils.hasText(party.getTrshPaidUpShareCapitalSgpd())
				|| StringUtils.hasText(party.getTrshPaidUpShareCapitalUsad())) {

			trshIssuedShares = new IssuedShares();
			trshIssuedShares.setShareType(SharesType.TRSH.name());
			trshIssuedShares.setSharesNumberOther(party.getTrshSharesNumberOther());
			trshIssuedShares.setSharesNumberSgDp(party.getTrshSharesNumberSgdp());
			trshIssuedShares.setSharesNumberUsAd(party.getTrshSharesNumberUsad());

			trshIssuedShares.setIssuedShareCapitalOther(party.getTrshIssuedShareCapitalOther());
			trshIssuedShares.setIssuedShareCapitalSgDp(party.getTrshIssuedShareCapitalSgpd());
			trshIssuedShares.setIssuedShareCapitalUsAd(party.getTrshIssuedShareCapitalUsad());

			trshIssuedShares.setPaidUpShareCapitalOther(party.getTrshPaidUpShareCapitalOther());
			trshIssuedShares.setPaidUpShareCapitalSgDp(party.getTrshPaidUpShareCapitalSgpd());
			trshIssuedShares.setPaidUpShareCapitalUsAd(party.getTrshPaidUpShareCapitalUsad());
		}
		return trshIssuedShares;
	}

	private IssuedShares createOTSHType() {
		IssuedShares otshIssuedShares = null;
		if (StringUtils.hasText(party.getOtshSharesNumberOther())
				|| StringUtils.hasText(party.getOtshSharesNumberSgdp())
				|| StringUtils.hasText(party.getOtshSharesNumberUsad())
				|| StringUtils.hasText(party.getOtshIssuedShareCapitalOther())
				|| StringUtils.hasText(party.getOtshIssuedShareCapitalSgpd())
				|| StringUtils.hasText(party.getOtshIssuedShareCapitalUsad())
				|| StringUtils.hasText(party.getOtshPaidUpShareCapitalOther())
				|| StringUtils.hasText(party.getOtshPaidUpShareCapitalSgpd())
				|| StringUtils.hasText(party.getOtshPaidUpShareCapitalUsad())) {

			otshIssuedShares = new IssuedShares();
			otshIssuedShares.setShareType(SharesType.OTSH.name());
			otshIssuedShares.setSharesNumberOther(party.getOtshSharesNumberOther());
			otshIssuedShares.setSharesNumberSgDp(party.getOtshSharesNumberSgdp());
			otshIssuedShares.setSharesNumberUsAd(party.getOtshSharesNumberUsad());

			otshIssuedShares.setIssuedShareCapitalOther(party.getOtshIssuedShareCapitalOther());
			otshIssuedShares.setIssuedShareCapitalSgDp(party.getOtshIssuedShareCapitalSgpd());
			otshIssuedShares.setIssuedShareCapitalUsAd(party.getOtshIssuedShareCapitalUsad());

			otshIssuedShares.setPaidUpShareCapitalOther(party.getOtshPaidUpShareCapitalOther());
			otshIssuedShares.setPaidUpShareCapitalSgDp(party.getOtshPaidUpShareCapitalSgpd());
			otshIssuedShares.setPaidUpShareCapitalUsAd(party.getOtshPaidUpShareCapitalUsad());

		}
		return otshIssuedShares;
	}

}
