package com.scb.clm.services.globus.cddcancel.v1.support;

/*
 * 
 * @author      
 * @version    1.0
 * @since      
 * @use        CDD Cancel Constants  
 */
public class CDDCancelConstants
{
    public static final String ICM_INTERFACE_ID                     = "ICM";
    public static final String ICM_DEDUPE_SERVICE_ID                = "SDEDUP"; 

    /* CDD CONSTATNTS */
    public static final String INVALID_JSON_FORMAT                  = "CC000001";  
    public static final String INVALID_APPLICATION_REFERENCE_NUMBER = "CC000002";  


}