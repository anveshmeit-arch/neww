package com.scb.clm.services.globus.prospect.v1.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSProspectRequestContacts 
{

    @JsonProperty("contactTypeCode")
    String contactTypeCode;

    @JsonProperty("contactClassificationCode")
    String contactClassificationCode;

    @JsonProperty("contact")
    String contact;

    @JsonProperty("countryCode")
    String countryCode;
    
    @JsonProperty("areaCode")
    String areaCode;
    
    @JsonProperty("extensionDetail")
    String extensionDetail;
    
    @JsonProperty("preferredContact")
    String preferredContact;
    
    @JsonProperty("primaryContact")
    String primaryContact;
    
    @JsonProperty("doNotDisturbRegistry")
    String doNotDisturbRegistry;
    
    @JsonProperty("doNotDisturbExpiryDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    Date doNotDisturbExpiryDate;
    
    @JsonProperty("attentionParty")
    String attentionParty;
    
    @JsonProperty("isdContactCountryCode")
    String isdContactCountryCode;
    
    public GBSProspectRequestContacts() {
        
    }
    
    public String getContactTypeCode() {
        return contactTypeCode;
    }

    public void setContactTypeCode(String contactTypeCode) {
        this.contactTypeCode = contactTypeCode;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getContactClassificationCode() {
        return contactClassificationCode;
    }

    public void setContactClassificationCode(String contactClassificationCode) {
        this.contactClassificationCode = contactClassificationCode;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode;
    }

    public String getExtensionDetail() {
        return extensionDetail;
    }

    public void setExtensionDetail(String extensionDetail) {
        this.extensionDetail = extensionDetail;
    }

    public String getPreferredContact() {
        return preferredContact;
    }

    public void setPreferredContact(String preferredContact) {
        this.preferredContact = preferredContact;
    }

    public String getPrimaryContact() {
        return primaryContact;
    }

    public void setPrimaryContact(String primaryContact) {
        this.primaryContact = primaryContact;
    }

    public String getDoNotDisturbRegistry() {
        return doNotDisturbRegistry;
    }

    public void setDoNotDisturbRegistry(String doNotDisturbRegistry) {
        this.doNotDisturbRegistry = doNotDisturbRegistry;
    }

    public Date getDoNotDisturbExpiryDate() {
        return doNotDisturbExpiryDate;
    }

    public void setDoNotDisturbExpiryDate(Date doNotDisturbExpiryDate) {
        this.doNotDisturbExpiryDate = doNotDisturbExpiryDate;
    }

    public String getAttentionParty() {
        return attentionParty;
    }

    public void setAttentionParty(String attentionParty) {
        this.attentionParty = attentionParty;
    }

    public String getIsdContactCountryCode() {
        return isdContactCountryCode;
    }

    public void setIsdContactCountryCode(String isdContactCountryCode) {
        this.isdContactCountryCode = isdContactCountryCode;
    }

}

