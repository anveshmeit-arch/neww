package com.scb.clm.services.globus.cleanup.v1.support;

import com.scb.clm.common.util.StringUtility;

/*
 * 
 * @author      
 * @version    1.0
 * @since      
 * @use        Admin Utility  
 */
public class CleanupUtility
{
    public static boolean isValidDay(String day) 
    {
        if(!StringUtility.isValidNumber(day) || Integer.parseInt(day)<1)
        {
            return false;
        } 
        return true;
    }

    public static boolean isValidBatchSize(String batchSize) 
    {
        if(!StringUtility.isValidNumber(batchSize) || Integer.parseInt(batchSize)<1)
        {
            return false;
        } 
        return true;
    }
}