package com.scb.clm.services.globus.cddinitiate.v1.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CDDReqCreateInitiateAppliedProducts {

    @JsonProperty("product-reference-key")
    private String product_reference_key;

    @JsonProperty("applicant-role")
    private String applicant_role;

    @JsonProperty("maker-psid")
    private String maker_psid;

    @JsonProperty("account-currency")
    private String account_currency;

    @JsonProperty("product-name")
    private String product_name;

    @JsonProperty("sub-product-code")
    private String sub_product_code;

    @JsonProperty("applied-limit")
    private String applied_limit;

    @JsonProperty("currency-applied-limit")
    private String currency_applied_limit;

    @JsonProperty("purpose-of-account-opening")
    private String purpose_of_account_opening;

    @JsonProperty("source-initial-deposit")
    private String source_initial_deposit;

    @JsonProperty("amount-initial-deposit")
    private String amount_initial_deposit;

    @JsonProperty("currency-initial-deposit")
    private String currency_initial_deposit;

    @JsonProperty("country-initial-deposit")
    private String country_initial_deposit;

    @JsonProperty("channel-reference-key")
    private String channel_reference_key;

    @JsonProperty("purpose-onshore-others")
    private String purpose_onshore_others;

    public String getProduct_reference_key() {
        return product_reference_key;
    }

    public void setProduct_reference_key(String product_reference_key) {
        this.product_reference_key = product_reference_key;
    }

    public String getApplicant_role() {
        return applicant_role;
    }

    public void setApplicant_role(String applicant_role) {
        this.applicant_role = applicant_role;
    }

    public String getAccount_currency() {
        return account_currency;
    }

    public void setAccount_currency(String account_currency) {
        this.account_currency = account_currency;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public String getSub_product_code() {
        return sub_product_code;
    }

    public void setSub_product_code(String sub_product_code) {
        this.sub_product_code = sub_product_code;
    }

    public String getPurpose_of_account_opening() {
        return purpose_of_account_opening;
    }

    public void setPurpose_of_account_opening(String purpose_of_account_opening) {
        this.purpose_of_account_opening = purpose_of_account_opening;
    }

    public String getChannel_reference_key() {
        return channel_reference_key;
    }

    public void setChannel_reference_key(String channel_reference_key) {
        this.channel_reference_key = channel_reference_key;
    }

    @Override
    public String toString() {
        return "CDDReq_Create_Iniate_AppliedProducts [product_reference_key=" + product_reference_key
                + ", applicant_role=" + applicant_role + ", account_currency=" + account_currency + ", product_name="
                + product_name + ", sub_product_code=" + sub_product_code + ", purpose_of_account_opening="
                + purpose_of_account_opening + ", channel_reference_key=" + channel_reference_key + "]";
    }

    public String getMaker_psid() {
        return maker_psid;
    }

    public void setMaker_psid(String maker_psid) {
        this.maker_psid = maker_psid;
    }

    public String getApplied_limit() {
        return applied_limit;
    }

    public void setApplied_limit(String applied_limit) {
        this.applied_limit = applied_limit;
    }

    public String getCurrency_applied_limit() {
        return currency_applied_limit;
    }

    public void setCurrency_applied_limit(String currency_applied_limit) {
        this.currency_applied_limit = currency_applied_limit;
    }

    public String getSource_initial_deposit() {
        return source_initial_deposit;
    }

    public void setSource_initial_deposit(String source_initial_deposit) {
        this.source_initial_deposit = source_initial_deposit;
    }

    public String getAmount_initial_deposit() {
        return amount_initial_deposit;
    }

    public void setAmount_initial_deposit(String amount_initial_deposit) {
        this.amount_initial_deposit = amount_initial_deposit;
    }

    public String getCurrency_initial_deposit() {
        return currency_initial_deposit;
    }

    public void setCurrency_initial_deposit(String currency_initial_deposit) {
        this.currency_initial_deposit = currency_initial_deposit;
    }

    public String getCountry_initial_deposit() {
        return country_initial_deposit;
    }

    public void setCountry_initial_deposit(String country_initial_deposit) {
        this.country_initial_deposit = country_initial_deposit;
    }

    public String getPurpose_onshore_others() {
        return purpose_onshore_others;
    }
    public void setPurpose_onshore_others(String purpose_onshore_others) {
        this.purpose_onshore_others = purpose_onshore_others;
    }
}
