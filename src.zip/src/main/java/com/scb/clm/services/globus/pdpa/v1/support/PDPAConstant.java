package com.scb.clm.services.globus.pdpa.v1.support;

public class PDPAConstant {

	public static final String INVALID_JSON_FORMAT                                 = "DD000001";
	public static final String PDPA_REQUEST_TYPE                                 = "pdpa";
	public static final String PDPA_Q001                                 = "Q001";
	public static final String PDPA_Q002                                 = "Q002";  
	public static final String PDPA_Q003                                 = "Q003";  
	public static final String PDPA_Q004                                 = "Q004";  
	public static final String PDBA_INTERFACE_ID								 = "ICM"; 
	public static final String PDBA_SERVICE_ID          = "SPDPA";
    public static final String INVALID_APPLICATION_REFERENCE_NUMBER                = "DD000002";  
    public static final String PDPA_REQUEST_ERROR                                   = "PDPA000001";
    public static final String INVALID_DATA                                        = "PDPA00000X";
    public static final String INVALID_CUSTOMER_COMMUNICATION_QUESTION                                        = "PDPA000002";
    public static final String INVALID_CUSTOMER_COMMUNICATION_ANSWER                                        = "PDPA000003";
    
    public static final String PDPA_SERVICE_Q001                                 = "SPDPE";
    public static final String PDPA_SERVICE_Q002                                 = "SPDPM";
    public static final String PDPA_SERVICE_Q003                                 = "SPDPP";
    public static final String PDPA_SERVICE_Q004                                 = "SPDPC";
    
    
}
