package com.scb.clm.services.companysearch.chekk.v1.support;

public class ChkProcessTime {
	
	private String requestId;
	private String registrationId;
	private String applicationRefNo;
	private String transactionId;
	
	private long startTime;
	private long createApiTime;
	private long getApiTime;
	private long finalResponseTime;
	private long msgSendTime;
	
	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getRegistrationId() {
		return registrationId;
	}

	public void setRegistrationId(String registrationId) {
		this.registrationId = registrationId;
	}

	public String getApplicationRefNo() {
		return applicationRefNo;
	}

	public void setApplicationRefNo(String applicationRefNo) {
		this.applicationRefNo = applicationRefNo;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public void setStartTime() {
		this.startTime = System.currentTimeMillis();
	}

	public void setCreateApiTime() {
		this.createApiTime = System.currentTimeMillis();
	}

	public void setGetApiTime() {
		this.getApiTime = System.currentTimeMillis();
	}

	public void setFinalResponseTime() {
		this.finalResponseTime = System.currentTimeMillis();
	}

	public void setMsgSendTime() {
		this.msgSendTime = System.currentTimeMillis();
	}

	public long difference(long startTime, long endTime) {
		return endTime - startTime;
	}
	
	public String printProcessingTime() {
		StringBuilder timeTaken = new StringBuilder();
		timeTaken.append(requestId);
		timeTaken.append("|");
		timeTaken.append(applicationRefNo);
		timeTaken.append("|");
		timeTaken.append(registrationId);
		timeTaken.append("|");
		timeTaken.append(difference(startTime, createApiTime));
		timeTaken.append("|");
		timeTaken.append(difference(createApiTime, getApiTime));
		timeTaken.append("|");
		timeTaken.append(difference(getApiTime, finalResponseTime));
		timeTaken.append("|");
		timeTaken.append(difference(finalResponseTime, msgSendTime));
		timeTaken.append("|");
		timeTaken.append(difference(startTime, msgSendTime));
		return timeTaken.toString();
	}
}
