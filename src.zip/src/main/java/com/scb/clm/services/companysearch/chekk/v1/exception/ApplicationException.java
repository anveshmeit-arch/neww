package com.scb.clm.services.companysearch.chekk.v1.exception;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.scb.clm.common.exception.ErrorObject;

/*
 * 
 * @author     1378958
 * @version    1.0  
 * @since        
 * @use        Intended to carry the Predefined Exception Information
 */
public class ApplicationException extends RuntimeException
{
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unused")
    private String errorType;

    @SuppressWarnings("unused")
    private String errorCode;

    @SuppressWarnings("unused")
    private String message;

    private List<ErrorObject> errorObject;

    public ApplicationException() {
    }

    public ApplicationException(String errorType, String errorCode, String message)
    {
        super();
        this.errorType = errorType;
        this.errorCode = errorCode;
        this.message = message;
        if(errorObject == null)
        {
            errorObject = new ArrayList<ErrorObject>();
        }
        errorObject.add(new ErrorObject(errorType, errorCode, message));
    }

    public List<ErrorObject> getErrorList() {
        return this.errorObject==null?null:this.errorObject.stream().collect(Collectors.toList());
    }

    public void setErrorList(List<ErrorObject> errorObject) {
        this.errorObject = errorObject==null?null:errorObject.stream().collect(Collectors.toList());
    }

    public void add(ErrorObject newErrorObject) {
        if (errorObject == null) {
            errorObject = new ArrayList<ErrorObject>();
        }
        errorObject.add(newErrorObject);
    }

    public void addAll(List<ErrorObject> errorList) {
        for (ErrorObject errorObject : errorList) {
            add(errorObject);
        }
    }

    public String getAllErrors() {
        if(this.errorObject!=null && this.errorObject.size() >0) {
            StringBuilder str = new StringBuilder();
            str.append("Errors listed are :- \n");
            for(ErrorObject err : this.errorObject) {
                str.append(err.getType()).
                append(" - "+err.getCode()).
                append(" - "+err.getDescription()).
                append("\n");
            }
            return str.toString(); 
        } else {
            return null;
        }
    }
}