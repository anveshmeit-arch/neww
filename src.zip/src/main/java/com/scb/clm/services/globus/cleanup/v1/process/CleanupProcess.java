package com.scb.clm.services.globus.cleanup.v1.process;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.JobScheduleEntity;
import com.scb.clm.core.controller.BaseController;
import com.scb.clm.core.service.ScheduleServiceAbstract;
import com.scb.clm.core.service.ScheduleServiceInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Map;


@Service
@Configurable
public class CleanupProcess extends ScheduleServiceAbstract implements ScheduleServiceInterface
{
    
    @Autowired
    BaseController baseController;


    @Override
    public ResponseEntity<Object> executeService(JobScheduleEntity jobScheduleEntity, Map<String, String> header) 
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "executeService", LogType.APPLICATION.name());
        try
        {
            log.println("Cleanup Execution Started - Process ");
            return baseController.processRequest("", header, jobScheduleEntity.getApiVersion(), jobScheduleEntity.getPathIdentifier(),null);
        }
        catch(Exception e)
        {
            return null;
        }        
    }

}
