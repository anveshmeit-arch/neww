package com.scb.clm.services.globus.cddinitiate.v1.model;

public class ErrorResponseDetails {

	public String description;
    public String detail;
    public String status;
    
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "testing [description=" + description + ", detail=" + detail + ", status=" + status + "]";
	}
}
