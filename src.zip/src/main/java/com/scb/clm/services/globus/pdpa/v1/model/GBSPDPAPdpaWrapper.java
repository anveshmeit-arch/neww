package com.scb.clm.services.globus.pdpa.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSPDPAPdpaWrapper {
	
	@JsonProperty("ccqSequence")
	private String ccqSequence;
	
	@JsonProperty("custSelection")
	private String custSelection;

	public String getCcqSequence() {
		return ccqSequence;
	}

	public void setCcqSequence(String ccqSequence) {
		this.ccqSequence = ccqSequence;
	}

	public String getCustSelection() {
		return custSelection;
	}

	public void setCustSelection(String custSelection) {
		this.custSelection = custSelection;
	}

	

}
