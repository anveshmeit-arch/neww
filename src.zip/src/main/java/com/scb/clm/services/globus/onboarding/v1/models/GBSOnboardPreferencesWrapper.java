package com.scb.clm.services.globus.onboarding.v1.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSOnboardPreferencesWrapper {

    @JsonProperty("prefLangForComm")
    private String prefLangForComm;

    @JsonProperty("preferredStatementLanguage")
    private String preferredStatementLanguage;

    @JsonProperty("preferredAtmLanguage")
    private String preferredAtmLanguage;

    @JsonProperty("preferredPhoneLanguage")
    private String preferredPhoneLanguage;

    @JsonProperty("ibankingRegistered")
    private String ibankingRegistered;

    @JsonProperty("phoneBankingRegistered")
    private String phoneBankingRegistered;

    @JsonProperty("smsBankingRegistered")
    private String smsBankingRegistered;

    public String getPrefLangForComm() {
        return prefLangForComm;
    }

    public void setPrefLangForComm(String prefLangForComm) {
        this.prefLangForComm = prefLangForComm;
    }

    public String getPreferredStatementLanguage() {
        return preferredStatementLanguage;
    }

    public void setPreferredStatementLanguage(String preferredStatementLanguage) {
        this.preferredStatementLanguage = preferredStatementLanguage;
    }

    public String getPreferredAtmLanguage() {
        return preferredAtmLanguage;
    }

    public void setPreferredAtmLanguage(String preferredAtmLanguage) {
        this.preferredAtmLanguage = preferredAtmLanguage;
    }

    public String getPreferredPhoneLanguage() {
        return preferredPhoneLanguage;
    }

    public void setPreferredPhoneLanguage(String preferredPhoneLanguage) {
        this.preferredPhoneLanguage = preferredPhoneLanguage;
    }

    public String getIbankingRegistered() {
        return ibankingRegistered;
    }

    public void setIbankingRegistered(String ibankingRegistered) {
        this.ibankingRegistered = ibankingRegistered;
    }

    public String getPhoneBankingRegistered() {
        return phoneBankingRegistered;
    }

    public void setPhoneBankingRegistered(String phoneBankingRegistered) {
        this.phoneBankingRegistered = phoneBankingRegistered;
    }

    public String getSmsBankingRegistered() {
        return smsBankingRegistered;
    }

    public void setSmsBankingRegistered(String smsBankingRegistered) {
        this.smsBankingRegistered = smsBankingRegistered;
    }


}
