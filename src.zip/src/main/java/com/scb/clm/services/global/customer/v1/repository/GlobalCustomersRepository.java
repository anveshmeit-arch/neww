package com.scb.clm.services.global.customer.v1.repository;

import com.scb.clm.services.idsafe.biometric.v1.model.IdentitySafeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.scb.clm.services.global.customer.v1.model.GlobalCustomersEntity;

@Repository
public interface GlobalCustomersRepository extends JpaRepository<GlobalCustomersEntity, String>,GlobalCustomersEnquiryRepositoryCustom 
{ 

    @Override
    public <S extends GlobalCustomersEntity> S save(S entity);

    @Override
    public GlobalCustomersEntity getOne(String arg0);

    public GlobalCustomersEntity findByBaseCountryAndApplicationReferenceNumber(String baseCountry, String applicationReferenceNumber);
    public GlobalCustomersEntity findByGlobalIdentifier(String globalIdentifier);
    public GlobalCustomersEntity findByBaseCountryAndRelationshipId(String baseCountry,String relationshipId);
    public GlobalCustomersEntity findByBaseCountryAndProfileId(String baseCountry,String profileId);

}