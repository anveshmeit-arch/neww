package com.scb.clm.services.companysearch.chekk.v1.model.process;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class Document {

	@JsonProperty("partyIdentifier")
	public String partyIdentifier;
	@JsonProperty("documentId")
	public String documentId;
	@JsonProperty("documentName")
	public String documentName;
	@JsonProperty("documentExpiryDate")
	public String documentExpiryDate;

}