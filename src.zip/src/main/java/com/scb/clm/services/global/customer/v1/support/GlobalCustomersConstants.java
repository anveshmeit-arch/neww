package com.scb.clm.services.global.customer.v1.support;

/*
 * 
 * @author     1378958 
 * @version    1.0
 * @since      
 * @use        Identity Safe Constants  
 */
public class GlobalCustomersConstants
{
    public static final String INVALID_ID_SAFE_REQUEST_FORMAT        = "GL000001";
    public static final String INTERNAL_PROCESSING_ERROR             = "GL000002"; 
    public static final String INVALID_APPLICATION_REFERENCE_NUMBER  = "GL000003";
    public static final String INVALID_CUSTOMER_BLOCK                = "GL000004";
    public static final String INVALID_BASE_COUNTRY_CODE             = "GL000005";
    public static final String INVALID_RELATIONSHIP_COUNTRY_CODE     = "GL000006";
    public static final String INVALID_GLOBAL_IDENTIFIER             = "GL000006";//cORRECT SEQ NO 
    public static final String INVALID_RELATIONSHIP_NUMBER           = "GL000007";
    public static final String INVALID_PROFILE_ID                    = "GL000008";
    public static final String INVALID_CUPID_REFERENCE_NUMBER        = "GL000009";
    public static final String INVALID_IMAGE_DATA                    = "GL000010";
    public static final String INVALID_ID_VAULT_ID                   = "GL000011";
    public static final String VAULT_ID_GENERATION_ERROR             = "GL000012";
    public static final String ISO_COUNTRY_CODE_EMPTY                = "GL000013";
    public static final String DATA_READING_ERROR                    = "GL000014";
    public static final String RESPONSE_CONSTRUCTION_ERROR           = "GL000015";
    public static final String ID_SAFE_DELETE_ERROR                  = "GL000016";
    public static final String INVALID_HTTP_STATUS                   = "GL000017";
    public static final String INVAID_ID_SEARCH_ID                   = "GL000018";
    public static final String INVALID_APPLICATION_REFERENCE_NUMBER_CREATE  = "GL000019";
    public static final String MANDATORY_IMAGE                       = "GL000020";
    public static final String DUPLICATE_RECORDS_EXIST               = "GL000021";
    public static final String INVALID_UPDATE_PAYLOAD                = "GL000022";
    public static final String ID_SAFE_UPDATE_ERROR                  = "GL000023";

    public static final String INVALID_FILTER_CONDITION              = "GL000500";
    public static final String COUNTRY_CODE_MANDATORY_ENQUIRY        = "GL000501";
    public static final String INVALID_COUNTRY_CODE_SIZE_ENQUIRY     = "GL000502";
    public static final String ENQUIRY_EXTRACTION_ERROR              = "GL000503";

    public static final String STATUS_ACTIVE                         = "A";


    public static final int MAX_FILTER_DATA_POINTS                   = 20;


}