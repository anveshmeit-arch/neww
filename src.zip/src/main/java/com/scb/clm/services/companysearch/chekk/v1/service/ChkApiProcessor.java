package com.scb.clm.services.companysearch.chekk.v1.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.google.common.util.concurrent.AbstractScheduledService.Scheduler;
import com.scb.clm.services.companysearch.chekk.v1.exception.ApplicationException;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekGetResponse;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkPartyEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkRequestsEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkResponseDataEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkSearchEntityQEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChkCreateResponse;
import com.scb.clm.services.companysearch.chekk.v1.model.ChkGetRequest;
import com.scb.clm.services.companysearch.chekk.v1.model.ChkSearchResponse;
import com.scb.clm.services.companysearch.chekk.v1.model.process.FinalResponse;
import com.scb.clm.services.companysearch.chekk.v1.service.FinalResponseMapper.FinalResponseMapBuilder;
import com.scb.clm.services.companysearch.chekk.v1.support.ChkApiType;
import com.scb.clm.services.companysearch.chekk.v1.support.ChkConfigProperties;
import com.scb.clm.services.companysearch.chekk.v1.support.DBUtility;
import com.scb.clm.services.companysearch.chekk.v1.support.JsonParserUtil;
import com.scb.clm.services.companysearch.chekk.v1.support.Log;
import com.scb.clm.services.companysearch.chekk.v1.support.ProcessApiConstants;
import com.scb.clm.services.companysearch.chekk.v1.support.SolaceConnectionUtil;

@Service
public class ChkApiProcessor {
    @Autowired
    private ChkApiClient apiClient;
    @Autowired
    private ChkSchedulerDao scheudlerDao;

    @Autowired
    private ChkConfigProperties configProps;

    @Autowired
    private ResponseToEntityConverter entityConverter;

    @Autowired
    private ChkTableReferences refData;

    @Autowired
    private SolaceConnectionUtil solaceConnectionUtil;

    /**
     * <p>
     * if <code>isMultiLevel</code> is false then GET API is invoked with delay
     * otherwise without delay. By default, all API responses are stored at db for
     * multilevel = true cases.
     * </p>
     * 
     * <p>
     * For searchDepth=1 or isMultiLevel=false scenarios responses are stored based
     * on SaveLevel1Response flag value defined at application.properties file for
     * performance reasons.
     * </p>
     * 
     * @param chkSrchEntity
     * @param previousApiResponse
     * @param isMultiLevel
     * @return
     */
    public Map<String, Object> processApi(ChekkSearchEntityQEntity chkSrchEntity, ChkApiResponse previousApiResponse,
            boolean isMultiLevel) {
        int intervalBetweenApiCallsInSecs = configProps.getIntervalBetweenApiCallsInSecs();
        Map<String, Object> retvalue = new HashMap<>();
        List<ChekkPartyEntity> partyList = null;
        ChkApiResponse currentApiResponse = null;
        ChekkResponseDataEntity responseData = null;
        boolean isErrorOccurred = false;
        String searchEntityQStatus = "";
        try {
            if (previousApiResponse == null) {
                currentApiResponse = apiClient.invokeSearchApi(ChkReqResConverter.toSearchRequest(chkSrchEntity));
            } else if (previousApiResponse.getApiType() == ChkApiType.SEARCH) {
                ChkSearchResponse searchResponse = previousApiResponse.getResponse(ChkSearchResponse.class);
                currentApiResponse = apiClient.invokeCreateApi(ChkReqResConverter.toCreateRequest(searchResponse));
            } else if (previousApiResponse.getApiType() == ChkApiType.CREATE) {
                ChkCreateResponse createResponse = previousApiResponse.getResponse(ChkCreateResponse.class);

                ChkGetRequest getReqeuest = ChkReqResConverter.toGetRequest(createResponse);
                currentApiResponse = (isMultiLevel || intervalBetweenApiCallsInSecs == 0) ? invokeGetAPI(getReqeuest)
                        : delayedScheduler(getReqeuest);
                partyList = populateChkPartyData(chkSrchEntity, currentApiResponse);
                retvalue.put(ProcessApiConstants.PARTY_LIST, partyList);
            }

            searchEntityQStatus = (currentApiResponse == null) ? ProcessApiConstants.STATUS_PUBLISH_FAILED
                    : currentApiResponse.getSearchEntQUpdateStatus(isMultiLevel);

        } catch (ApplicationException e) {
            isErrorOccurred = true;
            Log.error("ChkApiProcessor#processApi: ApplicationException occurred - "+e.getMessage(), e);
            /**
             * TODO set error code here and store it in db for problem analysis
             */
        } catch (Exception e) {
            isErrorOccurred = true;
            Log.error("ChkApiProcessor#processApi: Excetion occurred - "+e.getMessage(), e);
            /**
             * TODO add runtime error code and store it in db for problem analsyis
             */
        } finally {
            retvalue.put(ProcessApiConstants.API_RESPONSE, currentApiResponse);

            if (isErrorOccurred) {
                /**
                 * TODO check and add error code here
                 */
                searchEntityQStatus = "XF";
            }
            if (isMultiLevel || "Y".equalsIgnoreCase(configProps.getSaveLevel1Response())) {
                saveData(searchEntityQStatus, chkSrchEntity, currentApiResponse, partyList);
            }
        }

        return retvalue;
    }

    public Map<String, Object> processApiNewMultilevel(ChekkSearchEntityQEntity chkSrchEntity,
            ChkApiResponse previousApiResponse, boolean isMultiLevel) {
        Map<String, Object> retvalue;
        ChkApiType apiTypeToSearch = null;
        if (previousApiResponse == null) {
            apiTypeToSearch = ChkApiType.SEARCH;
        } else if (previousApiResponse.getApiType() == ChkApiType.SEARCH) {
            apiTypeToSearch = ChkApiType.CREATE;
        } else if (previousApiResponse.getApiType() == ChkApiType.CREATE) {
            apiTypeToSearch = ChkApiType.GET;
        }
        String previousRespnoseJson = (previousApiResponse != null) ? previousApiResponse.getResponseData() : null;

        retvalue = processApi(chkSrchEntity, apiTypeToSearch, previousRespnoseJson, isMultiLevel);
        return retvalue;
    }

    public Map<String, Object> processApi(ChekkSearchEntityQEntity chkSrchEntity, ChkApiType apiTypeToSearch,
            String previousApiResponseJson, boolean isMultiLevel) {
        int intervalBetweenApiCallsInSecs = configProps.getIntervalBetweenApiCallsInSecs();
        Map<String, Object> retvalue = new HashMap<>();
        List<ChekkPartyEntity> partyList = null;
        ChkApiResponse currentApiResponse = null;
        boolean isErrorOccurred = false;
        String searchEntityQStatus = "";
        try {
            if (apiTypeToSearch == ChkApiType.SEARCH) {
                currentApiResponse = apiClient.invokeSearchApi(ChkReqResConverter.toSearchRequest(chkSrchEntity));

            } else if (apiTypeToSearch == ChkApiType.CREATE) {
                ChkSearchResponse chkSearchResponse = JsonParserUtil.toObject(previousApiResponseJson,
                        ChkSearchResponse.class);
                currentApiResponse = apiClient.invokeCreateApi(ChkReqResConverter.toCreateRequest(chkSearchResponse));

            } else if (apiTypeToSearch == ChkApiType.GET) {
                ChkCreateResponse createResponse = JsonParserUtil.toObject(previousApiResponseJson,
                        ChkCreateResponse.class);
                ChkGetRequest getReqeuest = ChkReqResConverter.toGetRequest(createResponse);
                currentApiResponse = (isMultiLevel || intervalBetweenApiCallsInSecs == 0) ? invokeGetAPI(getReqeuest)
                        : delayedScheduler(getReqeuest);
                partyList = populateChkPartyData(chkSrchEntity, currentApiResponse);
                retvalue.put(ProcessApiConstants.PARTY_LIST, partyList);
            }

            searchEntityQStatus = (currentApiResponse == null) ? ProcessApiConstants.STATUS_PUBLISH_FAILED
                    : currentApiResponse.getSearchEntQUpdateStatus(isMultiLevel);

        } catch (ApplicationException e) {
            isErrorOccurred = true;
            Log.error("ApplicationException occurred in ChkApiProcessor#processApi " + e.getMessage(), e);
            /**
             * TODO set error code here and store it in db for problem analysis
             */
        } catch (Exception e) {
            isErrorOccurred = true;
            Log.error("Exception occurred in ChkApiProcessor#processApi " + e.getMessage(), e);
            /**
             * TODO add runtime error code and store it in db for problem analsyis
             */
        } finally {
            retvalue.put(ProcessApiConstants.API_RESPONSE, currentApiResponse);

            if (isErrorOccurred) {
                /**
                 * TODO check and add error code here
                 * 
                 */
                searchEntityQStatus = "XF";
            }
            if (isMultiLevel || "Y".equalsIgnoreCase(configProps.getSaveLevel1Response())) {
                saveData(searchEntityQStatus, chkSrchEntity, currentApiResponse, partyList);
            }
        }

        return retvalue;
    }

    public void saveData(String searchEntityQStatus, ChekkSearchEntityQEntity chkSrchEntity,
            ChkApiResponse currentApiResponse, List<ChekkPartyEntity> partyList) {
        String chkResDataId = scheudlerDao.generateChkRespDataID();
        ChekkResponseDataEntity responseData = entityConverter.constructChekkResponseEnity(chkResDataId,
                chkSrchEntity.getRequestId(), chkSrchEntity.getSearchEntityId(), currentApiResponse);

        if (partyList != null) {
            scheudlerDao.saveApiResults(searchEntityQStatus, chkSrchEntity, responseData, partyList);
        } else {
            scheudlerDao.saveApiResults(chkSrchEntity.getRequestId(), chkSrchEntity.getSearchEntityId(),
                    searchEntityQStatus, responseData);
        }

    }

    private ChkApiResponse delayedScheduler(ChkGetRequest request) {
        int intervalBetweenApiCallsInSecs = configProps.getIntervalBetweenApiCallsInSecs();
        ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();
        Log.info("Initializing Scheduler service");
        ChkApiResponse getResponse = null;
        Future<ChkApiResponse> future = executorService.schedule(() -> invokeGetAPI(request),
                intervalBetweenApiCallsInSecs, TimeUnit.SECONDS);
        Log.debug("ChkApiProcessor#delayedScheduler: Scheduler service invoked and awaiting for process to complete");

        try {
            //this blocks until the task is done
            getResponse = future.get(); 
            Log.debug("ChkApiProcessor#delayedScheduler: Scheduler service completed and ready to execute next line.");
        } catch (InterruptedException e) {
            Log.error("ChkApiProcessor#delayedScheduler: InerruptedException occurred. " + e.getMessage(), e);
            ;
        } catch (ExecutionException e) {
            Log.error("ChkApiProcessor#delayedScheduler: ExecutionException occurred. " + e.getMessage(), e);
        } finally {
            executorService.shutdown();
        }
        Log.info("ChkApiProcessor#delayedScheduler: Scheduler service After shutdown");
        return getResponse;
    }

    private ChkApiResponse invokeGetAPI(ChkGetRequest getRequest) {
        return apiClient.invokeGetApi(getRequest);
    }

    private List<ChekkPartyEntity> populateChkPartyData(ChekkSearchEntityQEntity chekkSearchEntityQEntity,
            ChkApiResponse getApiResponse) {
        List<ChekkPartyEntity> parties = null;
        if (getApiResponse != null && getApiResponse.isSuccess()) {
            parties = entityConverter.populateChkPartyData(chekkSearchEntityQEntity,
                    getApiResponse.getResponse(ChekGetResponse.class));
        }
        return parties;
    }

    public String generateFinalResponse(Map<String, String> requestHeader, ChekkRequestsEntity chekkRequestsEntity,
            List<ChekkPartyEntity> chekkPartyEntityLst) {
        FinalResponseMapper finalResMapper = new FinalResponseMapBuilder(chekkPartyEntityLst,
                entityConverter.populateRequestHeader(requestHeader)).refData(refData)
                .requestBody(entityConverter.populateRequstBody(chekkRequestsEntity))
                .thresholdPercentage(configProps.getMaxThresholdPercentage())
                .unwrappingIncompleteReasons(getReasonForIncompleteUnwrap(chekkRequestsEntity.getRequestId())).build();
        FinalResponse finalConsolidatedResponse = finalResMapper.generate();
        String finalResInJsonStr = JsonParserUtil.toJson(finalConsolidatedResponse);

        saveFinalResponse(finalResInJsonStr, chekkRequestsEntity.getRequestId());

        return finalResInJsonStr;
    }

    private String[] getReasonForIncompleteUnwrap(String requestId) {
        String[] errorCodeArr = null;
        try {
            List<ChekkSearchEntityQEntity> searchQErrorLst = scheudlerDao.getFailedSearchEntityQRecords(requestId);
            if (searchQErrorLst != null && !searchQErrorLst.isEmpty()) {
                errorCodeArr = searchQErrorLst.stream().map(ChekkSearchEntityQEntity::getErrorCode)
                        .toArray(size -> new String[size]);
            }
        } catch (ApplicationException ae) {
            Log.error("ChkApiProcessor#getReasonForIncompleteUnwrap: Error in ApplicationException block"
                    + ae.getMessage(), ae);
        } catch (Exception e) {
            Log.error("ChkApiProcessor#getReasonForIncompleteUnwrap: Error in Exception block" + e.getMessage(), e);

        }
        return errorCodeArr;
    }

    public boolean sendMessageToSolaceTopic(String requestId, String finalResponseJson, String countryCode,
            String interfaceId) {

        boolean msgStatus = solaceConnectionUtil.postMessagetoTopic(finalResponseJson, countryCode, interfaceId);
        String requestFinalStatus = msgStatus ? ProcessApiConstants.STATUS_PUBLISH_COMPLETED
                : ProcessApiConstants.STATUS_MSG_SEND_FAILED;

        scheudlerDao.updateChkRequestSatus(requestId, requestFinalStatus);

        return msgStatus;
    }

    private void saveFinalResponse(String response, String requestId) {
        try {

            if ("Y".equals(configProps.getSaveFinalResponse()) && !"".equals(response)) {
                ChekkResponseDataEntity chkRespData = new ChekkResponseDataEntity();
                String chkResDataId = scheudlerDao.generateChkRespDataID();
                chkRespData.setId(chkResDataId);
                chkRespData.setRequestId(requestId);
                chkRespData.setSearchEntityId("0");
                chkRespData.setResType("F");
                chkRespData.setResData(response);
                chkRespData.setStatus("S");
                scheudlerDao.saveChkResData(chkRespData);
            }
        } catch (Exception ex) {
            Log.error("ChkApiProcessor#saveFinalResponse:" + ex.getMessage(), ex);
        }
    }
}
