package com.scb.clm.services.companysearch.chekk.v1.support;

public enum ChkApiType {
	COGNITO, LOGIN, SEARCH, CREATE, GET;

	public String getResponseType() {
		String resType = "";
		if (this == ChkApiType.SEARCH) {
			resType = "S";
		} else if (this == ChkApiType.CREATE) {
			resType = "C";

		} else if (this == ChkApiType.GET) {
			resType = "G";

		}
		return resType;
	}

	public String responseTypeCode() {
		switch (this) {
		case SEARCH:
			return "S";
		case CREATE:
			return "C";
		case GET:
			return "G";
		default:
			return null;
		}
	}
}
