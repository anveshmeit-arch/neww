package com.scb.clm.services.globus.prescreen.v1.model;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;


public class CLMResponseCustomers 
{
    @JsonProperty("id") 
    String id;

    @JsonProperty("reference-id")
    String referenceid;

    @JsonProperty("previous-core-banking-id")
    String previousCoreBankingId;

    @JsonProperty("max-response-record") 
    int maxresponserecord;

    @JsonProperty("first-name") 
    String firstname;

    @JsonProperty("middle-name") 
    String middlename ;

    @JsonProperty("last-name") 
    String lastname;

    @JsonProperty("full-name") 
    String fullname;

    @JsonProperty("date-of-birth") 
    String dateofbirth;   

    @JsonProperty("profile-type") 
    String profiletype;

    @JsonProperty("category") 
    String category;

    @JsonProperty("bsbda-flag") 
    String bsbdaflag;

    @JsonProperty("relationship-status")
    String relationshipstatus;

    @JsonProperty("last-name-override") 
    String lastnameoverride;

    @JsonProperty("contacts") 
    ArrayList<CLMResponseContacts> contacts;

    @JsonProperty("documents") 
    ArrayList<CLMResponseDocuments> documents;

    @JsonProperty("risks") 
    ArrayList<CLMResponseRisks> risks;

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getReferenceid() {
        return referenceid;
    }
    public void setReferenceid(String referenceid) {
        this.referenceid = referenceid;
    }
    public String getPreviousCoreBankingId() {
        return previousCoreBankingId;
    }
    public void setPreviousCoreBankingId(String previousCoreBankingId) {
        this.previousCoreBankingId = previousCoreBankingId;
    }
    public int getMaxresponserecord() {
        return maxresponserecord;
    }
    public void setMaxresponserecord(int maxresponserecord) {
        this.maxresponserecord = maxresponserecord;
    }
    public String getFirstname() {
        return firstname;
    }
    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }
    public String getMiddlename() {
        return middlename;
    }
    public void setMiddlename(String middlename) {
        this.middlename = middlename;
    }
    public String getLastname() {
        return lastname;
    }
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }
    public String getFullname() {
        return fullname;
    }
    public void setFullname(String fullname) {
        this.fullname = fullname;
    }
    public String getDateofbirth() {
        return dateofbirth;
    }
    public void setDateofbirth(String dateofbirth) {
        this.dateofbirth = dateofbirth;
    }
    public String getProfiletype() {
        return profiletype;
    }
    public void setProfiletype(String profiletype) {
        this.profiletype = profiletype;
    }
    public String getCategory() {
        return category;
    }
    public void setCategory(String category) {
        this.category = category;
    }
    public String getBsbdaflag() {
        return bsbdaflag;
    }
    public void setBsbdaflag(String bsbdaflag) {
        this.bsbdaflag = bsbdaflag;
    }
    public String getRelationshipstatus() {
        return relationshipstatus;
    }
    public void setRelationshipstatus(String relationshipstatus) {
        this.relationshipstatus = relationshipstatus;
    }
    public String getLastnameoverride() {
        return lastnameoverride;
    }
    public void setLastnameoverride(String lastnameoverride) {
        this.lastnameoverride = lastnameoverride;
    }
    public ArrayList<CLMResponseContacts> getContacts() {
        return contacts;
    }
    public void setContacts(ArrayList<CLMResponseContacts> contacts) {
        this.contacts = contacts;
    }
    public ArrayList<CLMResponseDocuments> getDocuments() {
        return documents;
    }
    public void setDocuments(ArrayList<CLMResponseDocuments> documents) {
        this.documents = documents;
    }
    public ArrayList<CLMResponseRisks> getRisks() {
		return risks;
	}
	public void setRisks(ArrayList<CLMResponseRisks> risks) {
		this.risks = risks;
	}
	public void addContacts(CLMResponseContacts argContacts) {
        if(this.contacts == null) {
            this.contacts = new ArrayList<CLMResponseContacts>();     
        }
        this.contacts.add(argContacts);
    }
    public void addDocuments(CLMResponseDocuments argContacts) {
        if(this.documents == null) {
            this.documents= new ArrayList<CLMResponseDocuments>();     
        }
        this.documents.add(argContacts);
    }
}
