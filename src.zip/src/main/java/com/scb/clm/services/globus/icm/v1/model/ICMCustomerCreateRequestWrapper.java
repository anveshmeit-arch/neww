package com.scb.clm.services.globus.icm.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ICMCustomerCreateRequestWrapper {

    @JsonProperty("data")
    private ICMCustomerCreateRequestData data;

    public ICMCustomerCreateRequestData getData() {
        return data;
    }

    public void setData(ICMCustomerCreateRequestData data) {
        this.data = data;
    }
}
