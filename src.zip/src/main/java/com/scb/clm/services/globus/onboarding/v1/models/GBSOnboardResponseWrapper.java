package com.scb.clm.services.globus.onboarding.v1.models;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

//@JsonInclude(JsonInclude.Include.NON_NULL)  
public class GBSOnboardResponseWrapper {

    @JsonProperty("onboardingStatus")	
    private String onboardingStatus;

    @JsonProperty("coreBankingReferenceKey")	
    private String coreBankingReferenceKey;
    
    @JsonProperty("cddReferenceKey")	
    private String cddReferenceKey;

    @JsonProperty("customerMasterReferenceKey")	
    private String customerMasterReferenceKey;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty("errorDetails")
    private List<ErrorDetails> errordetails;
    
    @JsonProperty("onboardingStatusReason")
    private List<GBSOnboardResponseOnboardingStatusReason> onboardingStatusReason;
    
    @JsonProperty("nameScreeningResults")
    private GBSOnboardResponseNameScreeningResults nameScreeningResults;
    
    @JsonProperty("cddRiskDetails")
    private GBSOnboardResponseCDDRiskDetails cddRiskDetails;
    
    @JsonProperty("accountReferences")
    private List<GBSOnboardResponseAccountReference> accountReferences;

    public String getOnboardingStatus() {
        return onboardingStatus;
    }

    public void setOnboardingStatus(String onboardingStatus) {
        this.onboardingStatus = onboardingStatus;
    }

    public String getCoreBankingReferenceKey() {
        return coreBankingReferenceKey;
    }

    public void setCoreBankingReferenceKey(String coreBankingReferenceKey) {
        this.coreBankingReferenceKey = coreBankingReferenceKey;
    }

    public String getCustomerMasterReferenceKey() {
        return customerMasterReferenceKey;
    }

    public void setCustomerMasterReferenceKey(String customerMasterReferenceKey) {
        this.customerMasterReferenceKey = customerMasterReferenceKey;
    }

    public List<ErrorDetails> getErrordetails() {
        return (errordetails == null)?null:(errordetails.stream().collect(Collectors.toList()));
    }

    public void setErrordetails(List<ErrorDetails> errordetails) {
        this.errordetails = errordetails;
    }

	public String getCddReferenceKey() {
		return cddReferenceKey;
	}

	public void setCddReferenceKey(String cddReferenceKey) {
		this.cddReferenceKey = cddReferenceKey;
	}
	
    public void addErrors(ErrorDetails argErrors) {
        if(this.errordetails == null) {
            this.errordetails= new ArrayList<ErrorDetails>();     
        }
        this.errordetails.add(argErrors);
    }

	public List<GBSOnboardResponseOnboardingStatusReason> getOnboardingStatusReason() {
		return onboardingStatusReason;
	}

	public void setOnboardingStatusReason(List<GBSOnboardResponseOnboardingStatusReason> onboardingStatusReason) {
		this.onboardingStatusReason = onboardingStatusReason;
	}

	public GBSOnboardResponseNameScreeningResults getNameScreeningResults() {
		return nameScreeningResults;
	}

	public void setNameScreeningResults(GBSOnboardResponseNameScreeningResults nameScreeningResults) {
		this.nameScreeningResults = nameScreeningResults;
	}

	public GBSOnboardResponseCDDRiskDetails getCddRiskDetails() {
		return cddRiskDetails;
	}

	public void setCddRiskDetails(GBSOnboardResponseCDDRiskDetails cddRiskDetails) {
		this.cddRiskDetails = cddRiskDetails;
	}

	public List<GBSOnboardResponseAccountReference> getAccountReferences() {
		return accountReferences;
	}

	public void setAccountReferences(List<GBSOnboardResponseAccountReference> accountReferences) {
		this.accountReferences = accountReferences;
	}
}
