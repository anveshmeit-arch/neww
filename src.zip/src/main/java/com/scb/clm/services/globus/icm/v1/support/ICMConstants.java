package com.scb.clm.services.globus.icm.v1.support;

/*
 * 
 * @author     1378958 
 * @version    1.0
 * @since      
 * @use        ICM Constants  
 */
public class ICMConstants
{
    public static final String ICM_INTERFACE_ID       = "ICM";
    public static final String ICM_DEDUPE_SERVICE_ID  = "SDEDUP"; 

    /* ICM CONSTATNTS */
    public static final String INVALID_JSON_FORMAT              		= "IC000001";  
    public static final String CDD_VALIDATION_NSTP_ERROR        		= "IC000002";  
    public static final String ICM_REQUEST_ERROR                		= "IC000003";

    public static final String ICM_REQUEST_RISK_CONSTRUCTION_ERROR      = "IC000004";
    public static final String ICM_REQUEST_AUXILIARY_CONSTRUCTION_ERROR = "IC000005";
    public static final String INVALID_REQUEST							= "IC000006";    
    public static final String INVALID_APPLICATION_REFERENCE_NUMBER		= "IC000007";
    
    public static final String CLM_REQUEST_ERROR                        = "IC000008"; 
    public static final String PROFILE_CLIENT                           = "C";
}