package com.scb.clm.services.ekyc.pushekycdata.v1.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)  
public class PusheKYCBodyData {
	
	@JsonProperty("profile")
	private String profile;
	@JsonProperty("identityType")
	private String identityType;
	@JsonProperty("id")
	private String id;
	@JsonProperty("isLegacy")
	private boolean isLegacy;
	@JsonProperty("bankUser")
	private String bankUser;
	
	@JsonProperty("request")
    private Object pusheKYCRequestData;
	
	public Object getPusheKYCRequestData() {
		return pusheKYCRequestData;
	}

	public void setPusheKYCRequestData(Object pusheKYCRequestData) {
		this.pusheKYCRequestData = pusheKYCRequestData;
	}
	
	public String getProfile() {
		return profile;
	}

	public void setProfile(String profile) {
		this.profile = profile;
	}

	public String getIdentityType() {
		return identityType;
	}

	public void setIdentityType(String identityType) {
		this.identityType = identityType;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public boolean getIsLegacy() {
		return isLegacy;
	}

	public void setIsLegacy(boolean isLegacy) {
		this.isLegacy = isLegacy;
	}

	public String getBankUser() {
		return bankUser;
	}

	public void setBankUser(String bankUser) {
		this.bankUser = bankUser;
	}
}
