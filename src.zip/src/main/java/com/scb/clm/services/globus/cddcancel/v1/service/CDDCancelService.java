package com.scb.clm.services.globus.cddcancel.v1.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.clm.common.config.ApplicationConfiguration;
import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.config.StartUpConfigurations;
import com.scb.clm.common.exception.ErrorObject;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.repository.InterfaceRequestTypeRepository;
import com.scb.clm.common.util.JSONUtility;
import com.scb.clm.common.util.StringUtility;
import com.scb.clm.core.service.ServiceAbstract;
import com.scb.clm.core.service.ServiceInterface;
import com.scb.clm.services.globus.cddcancel.v1.model.CddCancelAccountReference;
import com.scb.clm.services.globus.cddcancel.v1.model.CddCancelRequest;
import com.scb.clm.services.globus.cddcancel.v1.model.CddCancelRequestAttributes;
import com.scb.clm.services.globus.cddcancel.v1.model.CddCancelRequestWrapper;
import com.scb.clm.services.globus.cddinitiate.v1.model.CDDRespAccountReferencesInitiateJson;
import com.scb.clm.services.globus.cddinitiate.v1.model.CDDRespCreateInitiateJson;
import com.scb.clm.services.globus.cddinitiate.v1.support.CDDConstants;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardReqWrapper;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardResponseWrapper;

@Service
public class CDDCancelService extends ServiceAbstract implements ServiceInterface
{

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */

    @Autowired
    InterfaceRequestTypeRepository interfaceRequestTypeRepository;

    @Autowired
    ApplicationConfiguration applicationConfiguration;

    @Autowired
    RestTemplate restTemplate;

    private static final String CDD_INITIATE_INTERFACE_ID        = "ICDD";
    private static final String CDD_CANCEL_SERVICE_ID            = "SCNCDD";


    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object readRequestObject(TravellingObject travellingObject, NodeServicesEntity srvEntity) throws ProcessException 
    {
        List<ErrorObject> errorObjectList = new ArrayList<ErrorObject>();

        try
        {
            return JSONUtility.jsonTODomainWrapper(travellingObject.getRequestData(),GBSOnboardReqWrapper.class);
        }
        catch(Exception e)
        {
            errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_TECHNICAL, BaseConstants.VALIDATION_ERROR,"Invalid Request Format for CDD Cancel Service"));
            ProcessException gbxEx = new ProcessException();
            gbxEx.addAll(errorObjectList);
            throw gbxEx;
        }
        finally
        {
            // N.A
        }
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public void validateData(TravellingObject travellingObject,NodeServicesEntity srvEntity,Object requestPayload) throws ProcessException 
    {
        List<ErrorObject> errorObjectList   = new ArrayList<ErrorObject>();
        LoggerUtil log                      = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateData", LogType.APPLICATION.name());

        try
        {
            GBSOnboardReqWrapper requestWrapper = (GBSOnboardReqWrapper) requestPayload;

            if(requestWrapper == null)
            {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_TECHNICAL, CDDConstants.INVALID_JSON_FORMAT,"INVALID REQUEST"));
            } 
            else if( (requestWrapper.getGbs_Onboard_ApplnWrapper() == null || !StringUtility.containsData(requestWrapper.getGbs_Onboard_ApplnWrapper().getApplicationReferenceNumber()))) 
            {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, CDDConstants.INVALID_APPLICATION_REFERENCE_NUMBER,"INVALID APPLICATION REFERENCE NUMBER"));
            } 
            else 
            {
                travellingObject.setApplicationReferenceNumber(requestWrapper.getGbs_Onboard_ApplnWrapper().getApplicationReferenceNumber());
            }

            if(errorObjectList.size()> 0) 
            {
                ProcessException gbxEx = new ProcessException();
                gbxEx.addAll(errorObjectList);
                throw gbxEx;
            }
        } 
        catch (ProcessException e)
        {
            log.println(" Error ["+e.getAllErrors()+"]");
            throw e;
        }
        catch (Exception e)
        {
            log.printErrorMessage(e);
            errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, BaseConstants.VALIDATION_ERROR,"INTERNAL ERROR"));
            ProcessException gbxEx = new ProcessException();
            gbxEx.addAll(errorObjectList);
            throw gbxEx; 
        }
    }


    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object constructOutboundObject(TravellingObject travellingObject,NodeServicesEntity srvEntity,Object requestPayload) throws ProcessException
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "constructOutboundObject", LogType.APPLICATION.name());
        try
        {
            log.println("[CDD Cancel] [constructOutboundObject] "+requestPayload);
            GBSOnboardReqWrapper requestWrapper = (GBSOnboardReqWrapper) requestPayload;  
            return requestWrapper;
        }
        catch (Exception e)
        {
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, BaseConstants.VALIDATION_ERROR," INTERNAL ERROR WHILE PAYLOAD CONSTRUCTION ");
        }

    }


    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object process(TravellingObject travellingObject,NodeServicesEntity srvEntity,ServiceStatus serviceStatus,Object outBoundRequestObject) throws ProcessException
    {

        CDDRespCreateInitiateJson resCDDObj     = null;
        ObjectMapper mapper                     = null;
        ResponseEntity<String> responseContent  = null;
        LoggerUtil log                          = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "constructOutboundObject", LogType.APPLICATION.name());

        serviceStatus.setInterfaceId("ICDD"); 
        log.println("[CDD CANCEL]");

        ServiceStatus serviceStatusCDD = travellingObject.getServiceStatus().get(BaseConstants.ONBOARD_CREATECDD_SRV);
        ServiceStatus serviceStatusICM = travellingObject.getServiceStatus().get(BaseConstants.ONBOARD_CREATEICM_SRV);

        try 
        {
            String responseICM = (serviceStatusICM==null)?"":getResponseAsString(serviceStatusICM.getResponsePayload());
            String responseICDD = (serviceStatusCDD==null)?"":getResponseAsString(serviceStatusCDD.getResponsePayload());

            mapper = new ObjectMapper();
            mapper.setSerializationInclusion(Include.NON_NULL);

            GBSOnboardResponseWrapper responseICMCreate = mapper.readValue(responseICM, GBSOnboardResponseWrapper.class);
            if(responseICMCreate != null && responseICMCreate.getOnboardingStatus() != null && responseICMCreate.getOnboardingStatus().equalsIgnoreCase("Rejected") && 
                    (responseICMCreate.getCustomerMasterReferenceKey() == null || responseICMCreate.getCustomerMasterReferenceKey().trim().equalsIgnoreCase("")))  
            {
                log.println("ResponseICMCreate.getOnboardingStatus  # \n"+responseICMCreate.getOnboardingStatus());

                CDDRespCreateInitiateJson cddResponse = mapper.readValue(responseICDD, CDDRespCreateInitiateJson.class);

                CddCancelRequestWrapper cddCancelRequestObj =  getCddCancelRequestWrapper(cddResponse);

                if(cddCancelRequestObj != null & cddCancelRequestObj.getData() != null && cddCancelRequestObj.getData().getId() != null) 
                {
                    HttpHeaders headers = new HttpHeaders();
                    //headers.add("X-JWT-Assertion","NO_JWT_VALIDATE");
                    headers.add("Content-Type","application/vnd.api+json");
                    headers.add("Accept","application/vnd.api+json");
                    headers.add("tracking-id",travellingObject.getApplicationReferenceNumber());
                    headers.add("message-sender",travellingObject.getInterfaceId());
                    String token = applicationConfiguration.getAccessToken(travellingObject, BaseConstants.ICDDSERVICE);
                    log.println("token here : "+ token);

                    headers.add("Authorization", "Bearer "+ token); 
                    headers.add(BaseConstants.API_HEADER_COUNTRY_CODE,travellingObject.getCountryCode());
                    log.println("applicant-external API URL from DB :"+ interfaceRequestTypeRepository.getInterfaceURL(travellingObject.getServiceContext().getCountryCodeWithRegion(),CDD_INITIATE_INTERFACE_ID,CDD_CANCEL_SERVICE_ID,"OB", BaseConstants.CODE_SETUP_ACTIVE));

                    String interfaceURL = interfaceRequestTypeRepository.getInterfaceURL(travellingObject.getServiceContext().getCountryCodeWithRegion(),CDD_INITIATE_INTERFACE_ID,CDD_CANCEL_SERVICE_ID,"OB", BaseConstants.CODE_SETUP_ACTIVE);
                    log.println("Sending Reqeust ["+interfaceURL+cddCancelRequestObj.getData().getId()+"]");
                    String requestData = mapper.writeValueAsString(cddCancelRequestObj);
                    log.println("requestData cdd cancel : "+requestData);

                    HttpEntity<CddCancelRequestWrapper> entity = new HttpEntity<CddCancelRequestWrapper>(cddCancelRequestObj,headers);
                    log.println("entity : "+ entity);
                    responseContent = restTemplate.exchange(interfaceURL+cddCancelRequestObj.getData().getId(), HttpMethod.PATCH, entity, String.class);

                    String response = responseContent.getBody();
                    serviceStatus.setHttpStatus(String.valueOf(responseContent.getStatusCodeValue()));
                    log.println("Response from CDDCancelService : "+ response);
                    log.println("Response from cancel update : "+response);
                }
            }else {
            	serviceStatus.setStatus(BaseConstants.NOT_ATTEMPTED);
            }
        } 
        catch (HttpStatusCodeException ex) 
        {
            log.println("Raw Code ["+ex.getRawStatusCode()+"] Status Code ["+ex.getStatusCode().toString()+"]");
            serviceStatus.setHttpStatus(ex.getRawStatusCode()+"");
            log.println(ex.getResponseBodyAsString());
            log.println("Response from CDD Cancel "+ex.getResponseBodyAsString());
        }
        catch (Exception e1) 
        {
            e1.printStackTrace();
        }
        return resCDDObj;
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    private CddCancelRequestWrapper getCddCancelRequestWrapper(CDDRespCreateInitiateJson cddResponse) 
    {
        CddCancelRequestWrapper ob = new CddCancelRequestWrapper();
        CddCancelRequest data = new CddCancelRequest();
        data.setId(cddResponse.getId());

        CddCancelRequestAttributes reqobj = new CddCancelRequestAttributes();
        reqobj.setApplicantReferenceKey(cddResponse.getApplicant_reference_key());
        reqobj.setOnboardingReferenceKey(cddResponse.getOnboarding_reference_key());        //onboarding-reference-key
        reqobj.setRejectReason("CUSTOMER PROFILE ALREADY EXIST IN ICM");
        reqobj.setOnboardingStatus("CANCELLED");

        List<CddCancelAccountReference> accountReferencesList = new ArrayList<CddCancelAccountReference>();
        for (CDDRespAccountReferencesInitiateJson account_references : cddResponse.getAccount_references()) 
        {
            CddCancelAccountReference obaccountReference = new CddCancelAccountReference();
            obaccountReference.setAccountKey(account_references.getAccount_key());
            obaccountReference.setAccountNumber("");
            accountReferencesList.add(obaccountReference);
        }

        reqobj.setAccountReferences(accountReferencesList);
        data.setAttributes(reqobj);
        ob.setData(data);

        return ob;
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    private String getResponseAsString(Object serviceResponse) 
    {
        LoggerUtil log                      =   LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "getResponseAsString", LogType.APPLICATION.name());

        ObjectMapper mapper = null;
        String requestData = null;

        mapper = new ObjectMapper();
        mapper.setSerializationInclusion(Include.NON_NULL);
        try 
        {
            requestData = mapper.writeValueAsString(serviceResponse);
        } 
        catch (JsonProcessingException e) 
        {
            log.printErrorMessage(e);
        }

        return requestData;
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object constructServiceResponse(TravellingObject travellingObject, NodeServicesEntity srvEntity, Object obj,ServiceStatus serviceStatus) throws ProcessException 
    {
        serviceStatus.setInterfaceId("ICDD");         
        return null;
    }

}
