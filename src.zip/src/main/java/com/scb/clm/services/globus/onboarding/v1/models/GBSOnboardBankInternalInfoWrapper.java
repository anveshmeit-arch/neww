package com.scb.clm.services.globus.onboarding.v1.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSOnboardBankInternalInfoWrapper {
	
	@JsonProperty("homeBranch")
    private String homeBranch;
	
	@JsonProperty("profileType")
    private String profileType;
	
	@JsonProperty("clientType")
	private String clientType; 
	 
	@JsonProperty("bsbdaFlag")
	private String bsbdaFlag;
	
	@JsonProperty("armCode")
	private String armCode;
	
	@JsonProperty("segmentCode")
	private String segmentCode;
	
	@JsonProperty("subSegmentCode")
	private String subSegmentCode;
	
	@JsonProperty("serviceIndicatorCode")
	private String serviceIndicatorCode;
	
	@JsonProperty("acquisitionChannel")
	private String acquisitionChannel;
	
	@JsonProperty("checkerDepartmentCode")
	private String checkerDepartmentCode;	
	
	@JsonProperty("caseOwnerPsid")
	private String caseOwnerPsid;
	
	@JsonProperty("coreBankingReferenceKey")
	private String coreBankingReferenceKey;
	
	@JsonProperty("customerMasterReferenceKey")
	private String customerMasterReferenceKey;
	
	@JsonProperty("cddReferenceKey")
	private String icddReference;
	
	 @JsonProperty("profileStatus")
	 private String profileStatus;
	
	@JsonProperty("referralId")
	private String referralId;
	
	@JsonProperty("sourcingId")
	private String sourcingId;
	
	@JsonProperty("closingId")
	private String closingId;
	
	public String getReferralId() {
		return referralId;
	}

	public void setReferralId(String referralId) {
		this.referralId = referralId;
	}

	public String getSourcingId() {
		return sourcingId;
	}

	public void setSourcingId(String sourcingId) {
		this.sourcingId = sourcingId;
	}

	public String getClosingId() {
		return closingId;
	}

	public void setClosingId(String closingId) {
		this.closingId = closingId;
	}

	public String getIcddReference() {
		return icddReference;
	}

	public void setIcddReference(String icddReference) {
		this.icddReference = icddReference;
	}
	
	public String getClientType() {
        return clientType;
    }

    public void setClientType(String client_type) {
        this.clientType = client_type;
    }
    
	public String getProfileType() {
        return profileType;
    }

    public void setProfileType(String profile_type) {
        this.profileType = profile_type;
    }
    
	public String getHomeBranch() {
        return homeBranch;
    }

    public void setHomeBranch(String homeBranch) {
        this.homeBranch = homeBranch;
    }

    public String getBsbdaFlag() {
        return bsbdaFlag;
    }

    public void setBsbdaFlag(String bsbdaFlag) {
        this.bsbdaFlag = bsbdaFlag;
    }

    public String getArmCode() {
        return armCode;
    }

    public void setArmCode(String armCode) {
        this.armCode = armCode;
    }

    public String getSegmentCode() {
        return segmentCode;
    }

    public void setSegmentCode(String segmentCode) {
        this.segmentCode = segmentCode;
    }

    public String getSubSegmentCode() {
        return subSegmentCode;
    }

    public void setSubSegmentCode(String subSegmentCode) {
        this.subSegmentCode = subSegmentCode;
    }

    public String getServiceIndicatorCode() {
        return serviceIndicatorCode;
    }

    public void setServiceIndicatorCode(String serviceIndicatorCode) {
        this.serviceIndicatorCode = serviceIndicatorCode;
    }

    public String getAcquisitionChannel() {
        return acquisitionChannel;
    }

    public void setAcquisitionChannel(String acquisitionChannel) {
        this.acquisitionChannel = acquisitionChannel;
    }

    public String getCheckerDepartmentCode() {
        return checkerDepartmentCode;
    }

    public void setCheckerDepartmentCode(String checkerDepartmentCode) {
        this.checkerDepartmentCode = checkerDepartmentCode;
    }

    public String getCaseOwnerPsid() {
        return caseOwnerPsid;
    }

    public void setCaseOwnerPsid(String caseOwnerPsid) {
        this.caseOwnerPsid = caseOwnerPsid;
    }

    public String getCoreBankingReferenceKey() {
        return coreBankingReferenceKey;
    }

    public void setCoreBankingReferenceKey(String coreBankingReferenceKey) {
        this.coreBankingReferenceKey = coreBankingReferenceKey;
    }

    public String getCustomerMasterReferenceKey() {
        return customerMasterReferenceKey;
    }

    public void setCustomerMasterReferenceKey(String customerMasterReferenceKey) {
        this.customerMasterReferenceKey = customerMasterReferenceKey;
    }

	public String getProfileStatus() {
		return profileStatus;
	}

	public void setProfileStatus(String profileStatus) {
		this.profileStatus = profileStatus;
	}
    
    


}
