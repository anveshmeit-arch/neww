package com.scb.clm.services.companysearch.chekk.v1.model;


import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ChekkLoginResponse {

	@JsonProperty("id")
    private String id;
	
	@JsonProperty("username")
    private String userName;
    
	@JsonProperty("access_token")
    private String accessToken;

    @JsonProperty("token_type")
    private String tokenType;

    @JsonProperty("refresh_token")
    private String refreshToken;

    @JsonProperty("expires_in")
    private String expiresIn;

    @JsonProperty("scope")
    private String scope;

    
}
