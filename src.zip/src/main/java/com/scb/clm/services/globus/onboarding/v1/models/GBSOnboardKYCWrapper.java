package com.scb.clm.services.globus.onboarding.v1.models;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.scb.clm.common.util.WrapperUtility;

public class GBSOnboardKYCWrapper {

    @JsonProperty("qualificationCode")
    private String qualificationCode;

    @JsonProperty("maritalStatus")
    private String maritalStatus;

    @JsonProperty("noOfDependent")
    private int noOfDependent;

    @JsonProperty("placeOfBirth")
    private String placeOfBirth;

    @JsonProperty("aiStatus")
    private String aiStatus;

    @JsonProperty("aiExpiryDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date aiExpiryDate;

    @JsonProperty("aiOptIn")
    private String aiOptIn;

    @JsonProperty("motherMaidenName")
    private String motherMaidenName;
    
    @JsonProperty("nationality")
    public List<GBSOnboardCustomerNationaliltyWrapper> nationality;
    
    @JsonProperty("customerLink")
    private List<GBSOnboardCustomerLinkWrapper> objOnboard_Customer_LinkWrapper;
    
    public List<GBSOnboardCustomerLinkWrapper> getObjOnboard_Customer_LinkWrapper() {
        return objOnboard_Customer_LinkWrapper;
    }

    public void setObjOnboard_Customer_LinkWrapper(List<GBSOnboardCustomerLinkWrapper> objOnboard_Customer_LinkWrapper) {
        this.objOnboard_Customer_LinkWrapper = objOnboard_Customer_LinkWrapper;
    }
    
    public List<GBSOnboardCustomerNationaliltyWrapper> getNationality() {
        return nationality;
    }

    public void setNationality(List<GBSOnboardCustomerNationaliltyWrapper> nationality) {
        this.nationality = nationality;
    }

    public String getQualificationCode() {
        return qualificationCode;
    }

    public void setQualificationCode(String qualificationCode) {
        this.qualificationCode = qualificationCode;
    }

    public String getMaritalStatus() {
        return maritalStatus;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public int getNoOfDependent() {
        return noOfDependent;
    }

    public void setNoOfDependent(int noOfDependent) {
        this.noOfDependent = noOfDependent;
    }

    public String getPlaceOfBirth() {
        return placeOfBirth;
    }

    public void setPlaceOfBirth(String placeOfBirth) {
        this.placeOfBirth = placeOfBirth;
    }

    public String getAiStatus() {
        return aiStatus;
    }

    public void setAiStatus(String aiStatus) {
        this.aiStatus = aiStatus;
    }

    public Date getAiExpiryDate() {
        return aiExpiryDate;
    }

    public void setAiExpiryDate(Date aiExpiryDate) {
        this.aiExpiryDate = WrapperUtility.cloneData(aiExpiryDate);
    }

    public String getAiOptIn() {
        return aiOptIn;
    }

    public void setAiOptIn(String aiOptIn) {
        this.aiOptIn = aiOptIn;
    }

    public String getMotherMaidenName() {
        return motherMaidenName;
    }

    public void setMotherMaidenName(String motherMaidenName) {
        this.motherMaidenName = motherMaidenName;
    }


}
