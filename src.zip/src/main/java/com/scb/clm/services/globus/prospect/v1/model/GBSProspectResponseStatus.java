package com.scb.clm.services.globus.prospect.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSProspectResponseStatus {

    @JsonProperty("prospectStatus")
    private String prospectStatus;

    public String getProspectStatus() {
        return prospectStatus;
    }

    public void setProspectStatus(String prospectStatus) {
        this.prospectStatus = prospectStatus;
    }

}
