package com.scb.clm.services.globus.prescreen.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSRequestWrapper
{
    @JsonProperty("application")
    private GBSRequestApplication application;

    @JsonProperty("customers")
    private GBSRequestCustomers customers;

    public GBSRequestApplication getApplication() {
        return application;
    }

    public void setApplication(GBSRequestApplication application) {
        this.application = application;
    }

    public GBSRequestCustomers getCustomers() {
        return customers;
    }

    public void setCustomers(GBSRequestCustomers customers) {
        this.customers = customers;
    }

}