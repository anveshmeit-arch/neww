package com.scb.clm.services.globus.onboarding.v1.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSOnboardApplnWrapper {

    @JsonProperty("applicationReferenceNumber")
    private String applicationReferenceNumber;

    @JsonProperty("flowIdentifier")
    String flowIdentifier;

    @JsonProperty("baseLocation")
    String baseLocation;

    @JsonProperty("countryOfAccountOpening")
    List<GBSOnboardAppCountries> countryOfAccountOpening;

    public String getApplicationReferenceNumber() {
        return applicationReferenceNumber;
    }

    public void setApplicationReferenceNumber(String applicationReferenceNumber) {
        this.applicationReferenceNumber = applicationReferenceNumber;
    }

    public String getFlowIdentifier() {
        return flowIdentifier;
    }
    
    public void setFlowIdentifier(String flowIdentifier) {
        this.flowIdentifier = flowIdentifier;
    }

    public String getBaseLocation() {
        return baseLocation;
    }

    public void setBaseLocation(String baseLocation) {
        this.baseLocation = baseLocation;
    }

    public List<GBSOnboardAppCountries> getCountryOfAccountOpening() {
        return countryOfAccountOpening;
    }

    public void setCountryOfAccountOpening(List<GBSOnboardAppCountries> countryOfAccountOpening) {
        this.countryOfAccountOpening = countryOfAccountOpening;
    }
}
