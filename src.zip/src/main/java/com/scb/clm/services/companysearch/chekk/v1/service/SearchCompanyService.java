package com.scb.clm.services.companysearch.chekk.v1.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ErrorObject;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.util.DateTimeUtility;
import com.scb.clm.common.util.JSONUtility;
import com.scb.clm.common.util.StringUtility;
import com.scb.clm.common.util.SystemUtility;
import com.scb.clm.core.service.ServiceAbstract;
import com.scb.clm.core.service.ServiceInterface;
import com.scb.clm.services.companysearch.chekk.v1.exception.ApplicationException;
import com.scb.clm.services.companysearch.chekk.v1.model.Addresses;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkRequestsEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkResponseDataEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkSearchEntityQEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChkSearchRequest;
import com.scb.clm.services.companysearch.chekk.v1.model.ChkSearchResponse;
import com.scb.clm.services.companysearch.chekk.v1.model.EntityData;
import com.scb.clm.services.companysearch.chekk.v1.model.ErrorDetails;
import com.scb.clm.services.companysearch.chekk.v1.model.External;
import com.scb.clm.services.companysearch.chekk.v1.model.InitialResponse;
import com.scb.clm.services.companysearch.chekk.v1.model.Names;
import com.scb.clm.services.companysearch.chekk.v1.model.SearchRequest;
import com.scb.clm.services.companysearch.chekk.v1.model.ValidationStatus;
import com.scb.clm.services.companysearch.chekk.v1.repository.ChekkRequestsRepository;
import com.scb.clm.services.companysearch.chekk.v1.support.DBUtility;
import com.scb.clm.services.companysearch.chekk.v1.support.ErrorProperties;
import com.scb.clm.services.companysearch.chekk.v1.support.Log;
import com.scb.clm.services.companysearch.chekk.v1.support.ProcessApiConstants;

import jakarta.transaction.Transactional;

@Service
public class SearchCompanyService extends ServiceAbstract implements ServiceInterface {

    @Autowired
    private ChekkRequestsRepository chekkRequestsRepository;

    @Autowired
    private DBUtility dbUtility;

    @Autowired
    private ChkApiClient apiClient;

    @Autowired
    private SearchCompanyAsyncProcessor searchAsynchProcessor;

    @Override
    public Object readRequestObject(TravellingObject travellingObject, NodeServicesEntity srvEntity)
            throws ProcessException {
        Log.info("SearchCompanyService#readRequestObject Inside SearchCompanyService.readRequestObject");
        try {
            return JSONUtility.jsonTODomainWrapper(travellingObject.getRequestData(), SearchRequest.class);
        } catch (Exception e) {
            Log.error("SearchCompanyService#readRequestObject: Exception occured - " + e.getMessage(), e);
            ProcessException gbxEx = new ProcessException();
            throw gbxEx;
        }
    }

    @Override
    public void validateData(TravellingObject travellingObject, NodeServicesEntity srvEntity, Object requestPayload)
            throws ProcessException {
        Log.info("Inside SearchCompanyService.validateData");

        try {
            validateRequestFields(requestPayload);

        } catch (ProcessException ex) {
            Log.error("Error in validateData method ", ex);
            throw ex;
        }
    }

    @Override
    public Object constructOutboundObject(TravellingObject travellingObject, NodeServicesEntity srvEntity,
            Object requestPayload) throws ProcessException {
        ChkSearchRequest chksrchReq = new ChkSearchRequest();
        try {
            Log.info("Inside SearchCompanyService.constructOutboundObject");

            SearchRequest srcRequest = (SearchRequest) requestPayload;

            chksrchReq.setJurisdiction(srcRequest.getCountryOfRegistration());
            chksrchReq.setCode(srcRequest.getRegistrationID());

        } catch (Exception ex) {
            Log.error("Error in constructOutboundObject method ", ex);
        }
        return chksrchReq;
    }

    @Override
    public Object process(TravellingObject travellingObject, NodeServicesEntity srvEntity, ServiceStatus serviceStatus,
            Object processPayload) throws ProcessException {
        Log.info("Inside SearchCompanyService.process");
        ChkApiResponse apiResponse;
        InitialResponse initialResponse;
        try {
            String requestId = travellingObject.getInBoundLogSequenceNumber();
            Map<String, String> requestHeaders = travellingObject.getRequestHeaders();
            SearchRequest requestDataFrmConsumer = (SearchRequest) serviceStatus.getRequestPayload();

            ChkSearchRequest chkSearchReq = (ChkSearchRequest) processPayload;
            apiResponse = apiClient.invokeSearchApi(chkSearchReq);

            ChekkRequestsEntity chekkRequestsEntity = constructChekkRequestEnity(requestId, requestHeaders,
                    requestDataFrmConsumer, apiResponse.isSuccess());
            ChekkSearchEntityQEntity chekkSearchEntityQEntity = constructChekkSearchEnityQueueData(requestId,
                    requestDataFrmConsumer, apiResponse.isSuccess());

            ChekkResponseDataEntity chekkResponseDataEntity = constructChekkResponseEnity(requestId,
                    chekkSearchEntityQEntity.getSearchEntityId(), apiResponse);
            saveSearchResults(chekkRequestsEntity, chekkSearchEntityQEntity, chekkResponseDataEntity);
            if (!apiResponse.isSuccess()) {
                /**
                 * TODO Add static exception handler class for throwing exception
                 */
                ProcessException processException = new ProcessException();
                processException.add(apiResponse.getErrObj());
                throw processException;
            }
            initialResponse = transformIntialResponse(apiResponse);
            if (isLevel1(requestDataFrmConsumer.getSearchDepth())) {
                searchAsynchProcessor.processAndSendFinalMessage(requestHeaders, chekkRequestsEntity,
                        chekkSearchEntityQEntity, apiResponse);
            }
        } catch (ApplicationException ex) {
            Log.error("SearchCompanyService#process: " + ex.getMessage(), ex);
            /**
             * TODO convert this to process exception and return
             */
            throw ex;
        }
        return initialResponse;
    }

    private boolean isLevel1(String searchDepth) {
        boolean retValue = false;
        if (searchDepth == null || "".equals(searchDepth)) {
            return retValue;
        }
        try {
            int level = Integer.parseInt(searchDepth);
            retValue = level == 1;
        } catch (NumberFormatException nfe) {
            nfe.printStackTrace();
        }

        return retValue;
    }

    @Override
    @Transactional
    public Object constructServiceResponse(TravellingObject travellingObject, NodeServicesEntity srvEntity, Object obj,
            ServiceStatus serviceStatus) throws ProcessException {
        Log.info("Inside SearchCompanyService.constructInboundObject");
        InitialResponse initialResponse = null;

        try {
            if (obj == null && serviceStatus != null && serviceStatus.getErrorObject() != null
                    && !serviceStatus.getErrorObject().isEmpty()) {
                initialResponse = new InitialResponse();
                initialResponse.setErrordetails(getErrorDetails(serviceStatus.getErrorObject()));
            }
        } catch (Exception ex) {
            Log.error("SearchCompanyService#constructServiceResponse: Error in constructServiceResponse method "
                    + ex.getMessage(), ex);
            /**
             * TODO convert this error to ProcessException and return
             */
        }
        return (initialResponse == null ? obj : initialResponse);
    }

    @Transactional
    private void saveSearchResults(ChekkRequestsEntity chkReqests, ChekkSearchEntityQEntity searchEntityQ,
            ChekkResponseDataEntity responseData) {
        dbUtility.saveChkReqData(chkReqests);
        dbUtility.saveChkSearchEntityQueueData(searchEntityQ);
        dbUtility.saveChkResData(responseData);

    }

    private void validateRequestFields(Object payload) throws ProcessException {

        ProcessException ex = null;
        SearchRequest searchReq = (SearchRequest) payload;
        List<ErrorObject> errors = new ArrayList<>();
        try {
            if (!StringUtility.containsData(searchReq.getCountryOfRegistration())) {
                errors.add(new ErrorObject(BaseConstants.ERROR_TYPE_VALIDATION, ErrorProperties.CK003.code,
                        ErrorProperties.CK003.msg));
            }
            if (!StringUtility.containsData(searchReq.getRegistrationID())) {
                errors.add(new ErrorObject(BaseConstants.ERROR_TYPE_VALIDATION, ErrorProperties.CK002.code,
                        ErrorProperties.CK002.msg));
            }
            if (!StringUtility.containsData(searchReq.getSearchDepth())) {
                errors.add(new ErrorObject(BaseConstants.ERROR_TYPE_VALIDATION, ErrorProperties.CK004.code,
                        ErrorProperties.CK004.msg));
            }
            if (!StringUtility.containsData(searchReq.getApplicationReferenceNumber())) {
                errors.add(new ErrorObject(BaseConstants.ERROR_TYPE_VALIDATION, ErrorProperties.CK005.code,
                        ErrorProperties.CK005.msg));
            }
            if (!StringUtility.containsData(searchReq.getCountryOfAccountOpening())) {
                errors.add(new ErrorObject(BaseConstants.ERROR_TYPE_VALIDATION, ErrorProperties.CK006.code,
                        ErrorProperties.CK006.msg));
            }
            if (!errors.isEmpty() && errors.size() > 0) {
                ex = new ProcessException();
                ex.addAll(errors);
                throw ex;
            }
        } catch (ProcessException e) {
            Log.error("SearchCompanyService#validateRequestFields: ProcessException- " + e.getMessage(), e);
            throw e;
        } catch (Exception e) {
            Log.error("SearchCompanyService#validateRequestFields: Exception - " + e.getMessage(), e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL, BaseConstants.CLM_GENERIC_ERROR,
                    "INVALID DATA - INTERNAL EXCEPTION");
        }
    }

    private InitialResponse transformIntialResponse(ChkApiResponse apiResponse) {

        InitialResponse initialResponse = new InitialResponse();
        if (apiResponse.isSuccess()) {
            ChkSearchResponse chkSearchResponse = apiResponse.getResponse(ChkSearchResponse.class);
            EntityData entityData = new EntityData();
            ValidationStatus validationStatus = new ValidationStatus();
            Names names = new Names();
            External external = new External();
            Addresses addresses = new Addresses();

            entityData.setCountryOfEstablishment(chkSearchResponse.getContent().get(0).getJurisdiction());
            validationStatus.setStatusCode(chkSearchResponse.getContent().get(0).getStatus());
            names.setLegal(chkSearchResponse.getContent().get(0).getName());
            external.setRegistrationNumber(chkSearchResponse.getContent().get(0).getCode());
            addresses.setAddressL1(chkSearchResponse.getContent().get(0).getStreet_address());
            addresses.setCity(chkSearchResponse.getContent().get(0).getLocality());
            addresses.setPostalCode(chkSearchResponse.getContent().get(0).getZip());

            entityData.setNames(names);
            entityData.setExternal(external);
            entityData.setValidationStatus(validationStatus);
            entityData.setAddresses(addresses);
            initialResponse.setEntityData(entityData);
        } else {
            ErrorDetails errDetails = new ErrorDetails(apiResponse.getErrObj().getCode(),
                    apiResponse.getErrObj().getDescription().toString());
            initialResponse.setErrordetails(Arrays.asList(errDetails));
        }
        return initialResponse;
    }

    private ChekkRequestsEntity constructChekkRequestEnity(String requestId, Map<String, String> headers,
            SearchRequest searchReq, boolean isSuccess) {
        String status = isSuccess ? ProcessApiConstants.STATUS_UNWRAP_PENDING
                : ProcessApiConstants.STATUS_PUBLISH_FAILED;
        ChekkRequestsEntity chekkRequestsEntity = new ChekkRequestsEntity();
        chekkRequestsEntity.setCountryCode(headers.get(ProcessApiConstants.REQ_HDR_COUNTRY_CODE));
        chekkRequestsEntity.setRequestId(requestId);
        chekkRequestsEntity.setInstanceName(SystemUtility.getInstanceName());
        chekkRequestsEntity.setApplicationReference(searchReq.getApplicationReferenceNumber());
        chekkRequestsEntity.setEntityName(searchReq.getEntityName());
        chekkRequestsEntity.setRegistrationId(searchReq.getRegistrationID());
        chekkRequestsEntity.setClientEntityType(searchReq.getClientEntityType());
        chekkRequestsEntity.setSearchDepth(Integer.valueOf(searchReq.getSearchDepth()));
        chekkRequestsEntity.setCountryAccountOpen(searchReq.getCountryOfAccountOpening());
        chekkRequestsEntity.setCountryOfRegistration(searchReq.getCountryOfRegistration());
        chekkRequestsEntity.setCreatedOn(DateTimeUtility.getCurrentTime());
        chekkRequestsEntity.setUpdatedOn(DateTimeUtility.getCurrentTime());
        chekkRequestsEntity.setStatus(status);
        return chekkRequestsEntity;
    }

    private ChekkResponseDataEntity constructChekkResponseEnity(String requestId, String searchId,
            ChkApiResponse apiResponse) {
        String status = apiResponse.isSuccess() ? "S" : "F";

        ChekkResponseDataEntity chekkResponseDataEntity = new ChekkResponseDataEntity();
        chekkResponseDataEntity.setId(dbUtility.generateChkRespDataID());
        chekkResponseDataEntity.setSearchEntityId(searchId);
        chekkResponseDataEntity.setCreatedOn(DateTimeUtility.getCurrentTime());
        chekkResponseDataEntity.setRequestId(requestId);
        chekkResponseDataEntity.setResType("S");
        chekkResponseDataEntity.setStatus(status);
        chekkResponseDataEntity.setResData(apiResponse.getResponseData());
        return chekkResponseDataEntity;
    }

    private ChekkSearchEntityQEntity constructChekkSearchEnityQueueData(String requestId, SearchRequest searchReq,
            boolean isSuccess) {
        String status = isSuccess ? ProcessApiConstants.STATUS_CREATE_PENDING
                : ProcessApiConstants.STATUS_PUBLISH_FAILED;

        ChekkSearchEntityQEntity chekkSearchEntityQEntity = new ChekkSearchEntityQEntity();
        chekkSearchEntityQEntity.setSearchEntityId(dbUtility.generateChkSearchEntityId());
        chekkSearchEntityQEntity.setRequestId(requestId);
        chekkSearchEntityQEntity.setEntityName(searchReq.getEntityName());
        chekkSearchEntityQEntity.setLevel(0);
        chekkSearchEntityQEntity.setStatus(status);
        chekkSearchEntityQEntity.setRegistrationID(searchReq.getRegistrationID());
        chekkSearchEntityQEntity.setCountryOfRegistration(searchReq.getCountryOfRegistration());
        /**
         * chekkSearchEntityQEntity.setErrorCode("");
         */
        chekkSearchEntityQEntity.setCreatedOn(DateTimeUtility.getCurrentTime());
        chekkSearchEntityQEntity.setUpdatedOn(DateTimeUtility.getCurrentTime());

        return chekkSearchEntityQEntity;
    }

    private List<ErrorDetails> getErrorDetails(List<ErrorObject> errorObjects) {
        List<ErrorDetails> errorDetailsList = new ArrayList<>();
        for (ErrorObject errorObject : errorObjects) {
            ErrorDetails anError = new ErrorDetails(errorObject.getCode(), (String) errorObject.getDescription());

            errorDetailsList.add(anError);

        }
        return errorDetailsList;
    }
}
