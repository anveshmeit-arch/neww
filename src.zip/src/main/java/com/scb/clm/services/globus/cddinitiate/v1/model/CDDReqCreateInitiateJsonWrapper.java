package com.scb.clm.services.globus.cddinitiate.v1.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonInclude(JsonInclude.Include.NON_NULL)
public class CDDReqCreateInitiateJsonWrapper {

    @JsonProperty("country-code")
    private String countryCode;

    @JsonProperty("salutation-code")
    private String salutationCode;

    @JsonProperty("first-name")
    private String firstName;

    @JsonProperty("middle-name")
    private String middleName;

    @JsonProperty("last-name")
    private String lastName;

    @JsonProperty("birth-country")
    private String birthCountry;

    @JsonProperty("gender")
    private String gender;

    @JsonProperty("date-of-birth")
    private String dateOfBirth;

    @JsonProperty("profile-type")
    private String profileType;

    @JsonProperty("last-name-override-flag")
    private String lastNameOverrideFlag;

    @JsonProperty("account-opening-country")
    private String accountOpeningCountry;

    @JsonProperty("case-owner-psid")
    private String caseOwnerPsId;

    @JsonProperty("arm-code")
    private String armCode;

    @JsonProperty("segment-code")
    private String segmentCode;

    @JsonProperty("sub-segment-code")
    private String subSegmentCode;

    @JsonProperty("acquisition-channel")
    private String acquisitionChannel;

    @JsonProperty("home-branch")
    private String homeBranch;

    @JsonProperty("client-type")
    private String clienttype;

    @JsonProperty("sow-articulation")
    private String sowArticulation;

    @JsonProperty("position-title")
    private String positionTitle;

    @JsonProperty("pep-declaration-reason")
    private String pepDeclarationReason;

    public String getSowArticulation() {
        return sowArticulation;
    }

    public void setSowArticulation(String sowArticulation) {
        this.sowArticulation = sowArticulation;
    }

    @JsonProperty("applied-products")
    private List<CDDReqCreateInitiateAppliedProducts> appliedProducts;

    @JsonProperty("joint-applicants")
    private List<CDDCreateInitiateJointApplicants> jointApplicants;

    @JsonProperty("contact")
    private List<CDDReqCreateInitiateContacts> contact;

    @JsonProperty("documents")
    private List<CDDReqCreateInitiateDocuments> documents;

    @JsonProperty("source-of-wealth")
    private CDDCreateInitiateSourceOfWealth sourceOfWealth;

    @JsonProperty("employment")
    private CDDReqCreateInitiateEmployment employment;

    @JsonProperty("aliases")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private List<CDDCreateInitiateAliases> aliases;

    @JsonProperty("verification-status")
    private CDDReqCreateInitiateVerifyStatus verificationstatus;

    @JsonProperty("address")
    private List<CDDReqCreateInitiateAddress> address;

    @JsonProperty("adverse-flag")
    private String adverseFlag;

    @JsonProperty("sanction-flag")
    private String sanctionFlag;

    @JsonProperty("pep-flag")
    private String pepFlag;

    @JsonProperty("nationality")
    public List<String> nationality;

    @JsonProperty("onboarding-reference-key")
    private String onboardingReferenceKey;

    @JsonProperty("minor-flag")
    private String minorFlag;

    @JsonProperty("case-maker-psid")
    private String caseMakerPsid;

    @JsonProperty("preferred-name")
    private String preferredName;

    @JsonProperty("number-of-deposits")
    private String numberOfDeposits;

    @JsonProperty("value-of-deposits")
    private String valueOfDeposits;

    @JsonProperty("number-of-withdrawals")
    private String numberOfWithdrawals;

    @JsonProperty("value-of-withdrawals")
    private String valueOfWithdrawals;

    @JsonProperty("core-banking-reference-key")
    private String coreBankingReferenceKey;

    @JsonProperty("customer-master-reference-key")
    private String customerMasterReferenceKey;

    @JsonProperty("client-source-of-fund")
    private String clientSourceOfFund;

    @JsonProperty("client-source-of-fund-oth")
    private String clientSourceOfFundOth;


    @JsonProperty("purpose-offshore-relationship")
    private String purposeOffshoreRelationship;

    @JsonProperty("purpose-offshore-relationship-others")
    private String purposeOffshoreRelationshipOthers;

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getSalutationCode() {
        return salutationCode;
    }

    public void setSalutationCode(String salutationCode) {
        this.salutationCode = salutationCode;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getBirthCountry() {
        return birthCountry;
    }

    public void setBirthCountry(String birthCountry) {
        this.birthCountry = birthCountry;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getProfileType() {
        return profileType;
    }

    public void setProfileType(String profileType) {
        this.profileType = profileType;
    }

    public String getLastNameOverrideFlag() {
        return lastNameOverrideFlag;
    }

    public void setLastNameOverrideFlag(String lastNameOverrideFlag) {
        this.lastNameOverrideFlag = lastNameOverrideFlag;
    }

    public String getAccountOpeningCountry() {
        return accountOpeningCountry;
    }

    public void setAccountOpeningCountry(String accountOpeningCountry) {
        this.accountOpeningCountry = accountOpeningCountry;
    }

    public String getCaseOwnerPsId() {
        return caseOwnerPsId;
    }

    public void setCaseOwnerPsId(String caseOwnerPsId) {
        this.caseOwnerPsId = caseOwnerPsId;
    }

    public String getArmCode() {
        return armCode;
    }

    public void setArmCode(String armCode) {
        this.armCode = armCode;
    }

    public String getSegmentCode() {
        return segmentCode;
    }

    public void setSegmentCode(String segmentCode) {
        this.segmentCode = segmentCode;
    }

    public String getSubSegmentCode() {
        return subSegmentCode;
    }

    public void setSubSegmentCode(String subSegmentCode) {
        this.subSegmentCode = subSegmentCode;
    }

    public String getAcquisitionChannel() {
        return acquisitionChannel;
    }

    public void setAcquisitionChannel(String acquisitionChannel) {
        this.acquisitionChannel = acquisitionChannel;
    }

    public String getHomeBranch() {
        return homeBranch;
    }

    public void setHomeBranch(String homeBranch) {
        this.homeBranch = homeBranch;
    }

    public String getClienttype() {
        return clienttype;
    }

    public void setClienttype(String clienttype) {
        this.clienttype = clienttype;
    }

    public List<CDDReqCreateInitiateAppliedProducts> getAppliedProducts() {
        return appliedProducts;
    }

    public void setAppliedProducts(List<CDDReqCreateInitiateAppliedProducts> appliedProducts) {
        this.appliedProducts = appliedProducts;
    }

    public List<CDDCreateInitiateJointApplicants> getJointApplicants() {
        return jointApplicants;
    }

    public void setJointApplicants(List<CDDCreateInitiateJointApplicants> jointApplicants) {
        this.jointApplicants = jointApplicants;
    }

    public List<CDDReqCreateInitiateContacts> getContact() {
        return contact;
    }

    public void setContact(List<CDDReqCreateInitiateContacts> contact) {
        this.contact = contact;
    }

    public List<CDDReqCreateInitiateDocuments> getDocuments() {
        return documents;
    }

    public void setDocuments(List<CDDReqCreateInitiateDocuments> documents) {
        this.documents = documents;
    }

    public CDDCreateInitiateSourceOfWealth getSourceOfWealth() {
        return sourceOfWealth;
    }

    public void setSourceOfWealth(CDDCreateInitiateSourceOfWealth sourceOfWealth) {
        this.sourceOfWealth = sourceOfWealth;
    }

    public CDDReqCreateInitiateEmployment getEmployment() {
        return employment;
    }

    public void setEmployment(CDDReqCreateInitiateEmployment employment) {
        this.employment = employment;
    }

    public List<CDDCreateInitiateAliases> getAliases() {
        return aliases;
    }

    public void setAliases(List<CDDCreateInitiateAliases> aliases) {
        this.aliases = aliases;
    }

    public CDDReqCreateInitiateVerifyStatus getVerificationstatus() {
        return verificationstatus;
    }

    public void setVerificationstatus(CDDReqCreateInitiateVerifyStatus verificationstatus) {
        this.verificationstatus = verificationstatus;
    }

    public List<CDDReqCreateInitiateAddress> getAddress() {
        return address;
    }

    public void setAddress(List<CDDReqCreateInitiateAddress> address) {
        this.address = address;
    }

    public String getAdverseFlag() {
        return adverseFlag;
    }

    public void setAdverseFlag(String adverseFlag) {
        this.adverseFlag = adverseFlag;
    }

    public String getSanctionFlag() {
        return sanctionFlag;
    }

    public void setSanctionFlag(String sanctionFlag) {
        this.sanctionFlag = sanctionFlag;
    }

    public String getPepFlag() {
        return pepFlag;
    }

    public void setPepFlag(String pepFlag) {
        this.pepFlag = pepFlag;
    }

    public List<String> getNationality() {
        return nationality;
    }

    public void setNationality(List<String> nationality) {
        this.nationality = nationality;
    }

    public String getOnboardingReferenceKey() {
        return onboardingReferenceKey;
    }

    public void setOnboardingReferenceKey(String onboardingReferenceKey) {
        this.onboardingReferenceKey = onboardingReferenceKey;
    }

    public String getMinorFlag() {
        return minorFlag;
    }

    public void setMinorFlag(String minorFlag) {
        this.minorFlag = minorFlag;
    }

    public String getCaseMakerPsid() {
        return caseMakerPsid;
    }

    public void setCaseMakerPsid(String caseMakerPsid) {
        this.caseMakerPsid = caseMakerPsid;
    }

    public String getPreferredName() {
        return preferredName;
    }

    public void setPreferredName(String preferredName) {
        this.preferredName = preferredName;
    }

    public String getNumberOfDeposits() {
        return numberOfDeposits;
    }

    public void setNumberOfDeposits(String numberOfDeposits) {
        this.numberOfDeposits = numberOfDeposits;
    }

    public String getValueOfDeposits() {
        return valueOfDeposits;
    }

    public void setValueOfDeposits(String valueOfDeposits) {
        this.valueOfDeposits = valueOfDeposits;
    }

    public String getNumberOfWithdrawals() {
        return numberOfWithdrawals;
    }

    public void setNumberOfWithdrawals(String numberOfWithdrawals) {
        this.numberOfWithdrawals = numberOfWithdrawals;
    }

    public String getValueOfWithdrawals() {
        return valueOfWithdrawals;
    }

    public void setValueOfWithdrawals(String valueOfWithdrawals) {
        this.valueOfWithdrawals = valueOfWithdrawals;
    }

    public String getCoreBankingReferenceKey() {
        return coreBankingReferenceKey;
    }

    public void setCoreBankingReferenceKey(String coreBankingReferenceKey) {
        this.coreBankingReferenceKey = coreBankingReferenceKey;
    }

    public String getCustomerMasterReferenceKey() {
        return customerMasterReferenceKey;
    }

    public void setCustomerMasterReferenceKey(String customerMasterReferenceKey) {
        this.customerMasterReferenceKey = customerMasterReferenceKey;
    }

    public String getClientSourceOfFund() {
        return clientSourceOfFund;
    }

    public void setClientSourceOfFund(String clientSourceOfFund) {
        this.clientSourceOfFund = clientSourceOfFund;
    }

    public String getClientSourceOfFundOth() {
        return clientSourceOfFundOth;
    }

    public void setClientSourceOfFundOth(String clientSourceOfFundOth) {
        this.clientSourceOfFundOth = clientSourceOfFundOth;
    }

    public String getPepDeclarationReason() {
        return pepDeclarationReason;
    }

    public void setPepDeclarationReason(String pepDeclarationReason) {
        this.pepDeclarationReason = pepDeclarationReason;
    }

    public String getPurposeOffshoreRelationship() {
        return purposeOffshoreRelationship;
    }

    public void setPurposeOffshoreRelationship(String purposeOffshoreRelationship) {
        this.purposeOffshoreRelationship = purposeOffshoreRelationship;
    }

    public String getPurposeOffshoreRelationshipOthers() {
        return purposeOffshoreRelationshipOthers;
    }

    public void setPurposeOffshoreRelationshipOthers(String purposeOffshoreRelationshipOthers) {
        this.purposeOffshoreRelationshipOthers = purposeOffshoreRelationshipOthers;
    }

    public String getPositionTitle() {
        return positionTitle;
    }

    public void setPositionTitle(String positionTitle) {
        this.positionTitle = positionTitle;
    }
}
