package com.scb.clm.services.globus.cddcancel.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;


public class CddCancelRequestWrapper {

    @JsonProperty("data")
    private CddCancelRequest data;

    public CddCancelRequest getData() {
        return data;
    }

    public void setData(CddCancelRequest data) {
        this.data = data;
    }
}
