package com.scb.clm.services.globus.icm.v1.model;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ICMCustomerCreateKYC {

	@JsonProperty("id")
	private String guid;
	
	@JsonProperty("reference-id")
	private String profileId;
	
	@JsonProperty("birth-country")
	private String birthCountry;
	
	@JsonProperty("qualification-code")
	private String qualificationCode;
	
	@JsonProperty("marital-status")
	private String maritalStatus;
	
	@JsonProperty("no-of-dependent")
	private int noOfDependent;
	
	@JsonProperty("place-of-birth")
	private String placeOfBirth;

	@JsonProperty("ai-status")
	private String aiStatus;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	@JsonProperty("ai-expiry-date")
	private Date aiExpiryDate;
	
	@JsonProperty("ai-opt-in")
	private String aiOptIn;
	
	@JsonProperty("mother-maiden-name")
	private String motherMaidenName;
	
	@JsonProperty("sender-id")
	private String senderId;
	
	@JsonProperty("sender-branch")
	private String senderBranch;
	
	@JsonProperty("nationalitydetails")
    public List<ICMCustomerKYCNationality> nationality;
	
	public List<ICMCustomerKYCNationality> getNationality() {
		return nationality;
	}

	public void setNationality(List<ICMCustomerKYCNationality> nationality) {
		this.nationality = nationality;
	}

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	@JsonProperty("created-at")
	private Timestamp createdAt;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	@JsonProperty("updated-at")
	private Timestamp updatedAt;
	
	@JsonProperty("status")
	private String status;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	@JsonProperty("status-at")
	private Timestamp statusAt;
	
	@JsonIgnore
	private short recordStatus;
	
	@JsonProperty("country-id")
	private String companyId;

	public String getGuid() {
		return guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}

	public String getProfileId() {
		return profileId;
	}

	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}

	public String getBirthCountry() {
		return birthCountry;
	}

	public void setBirthCountry(String birthCountry) {
		this.birthCountry = birthCountry;
	}

	public String getQualificationCode() {
		return qualificationCode;
	}

	public void setQualificationCode(String qualificationCode) {
		this.qualificationCode = qualificationCode;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public int getNoOfDependent() {
		return noOfDependent;
	}

	public void setNoOfDependent(int noOfDependent) {
		this.noOfDependent = noOfDependent;
	}

	public String getPlaceOfBirth() {
		return placeOfBirth;
	}

	public void setPlaceOfBirth(String placeOfBirth) {
		this.placeOfBirth = placeOfBirth;
	}

	public String getAiStatus() {
		return aiStatus;
	}

	public void setAiStatus(String aiStatus) {
		this.aiStatus = aiStatus;
	}

	public Date getAiExpiryDate() {
		return aiExpiryDate;
	}

	public void setAiExpiryDate(Date aiExpiryDate) {
		this.aiExpiryDate = aiExpiryDate;
	}

	public String getAiOptIn() {
		return aiOptIn;
	}

	public void setAiOptIn(String aiOptIn) {
		this.aiOptIn = aiOptIn;
	}

	public String getMotherMaidenName() {
		return motherMaidenName;
	}

	public void setMotherMaidenName(String motherMaidenName) {
		this.motherMaidenName = motherMaidenName;
	}

	public String getSenderId() {
		return senderId;
	}

	public void setSenderId(String senderId) {
		this.senderId = senderId;
	}

	public String getSenderBranch() {
		return senderBranch;
	}

	public void setSenderBranch(String senderBranch) {
		this.senderBranch = senderBranch;
	}

	public Timestamp getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Timestamp createdAt) {
		this.createdAt = createdAt;
	}

	public Timestamp getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Timestamp updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getStatusAt() {
		return statusAt;
	}

	public void setStatusAt(Timestamp statusAt) {
		this.statusAt = statusAt;
	}

	public short getRecordStatus() {
		return recordStatus;
	}

	public void setRecordStatus(short recordStatus) {
		this.recordStatus = recordStatus;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
}
