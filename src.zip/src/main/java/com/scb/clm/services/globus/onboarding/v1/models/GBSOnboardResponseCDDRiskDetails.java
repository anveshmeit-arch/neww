package com.scb.clm.services.globus.onboarding.v1.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class GBSOnboardResponseCDDRiskDetails {
	
	public GBSOnboardResponseCDDRiskDetails() {
		
	}
	
	public GBSOnboardResponseCDDRiskDetails(String cddRiskRating, String cddStatus) {
		this.cddRiskRating = cddRiskRating;
		this.cddStatus = cddStatus;
	}

	@JsonProperty("cddRiskRating")
    private String cddRiskRating;

    @JsonProperty("cddStatus")
    private String cddStatus;

	public String getCddRiskRating() {
		return cddRiskRating;
	}

	public void setCddRiskRating(String cddRiskRating) {
		this.cddRiskRating = cddRiskRating;
	}

	public String getCddStatus() {
		return cddStatus;
	}

	public void setCddStatus(String cddStatus) {
		this.cddStatus = cddStatus;
	}
    
}
