package com.scb.clm.services.globus.onboarding.v1.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSOnboardVerificationStatusWrapper {

    @JsonProperty("applicantDetailsVerified")
    private String applicantDetailsVerified;

    @JsonProperty("verificationDateTime")
    private String verificationDateTime;

    @JsonProperty("modeOfVerification")
    private String modeOfVerification;

    @JsonProperty("verifiedBy")
    private String verifiedBy;

    @JsonProperty("nameOfVerification")
    private String nameOfVerification;

    @JsonProperty("dateOfBirthVerification")
    private String dateOfBirthVerification;

    @JsonProperty("residenceAddressVerification")
    private String residenceAddressVerification;

    @JsonProperty("idNumberVerification")
    private String idNumberVerification;

    @JsonProperty("nationalityVerification")
    private String nationalityVerification;

    @JsonProperty("countrySpecificOneCerification")
    private String countrySpecificOneCerification;

    @JsonProperty("countrySpecificTwoVerification")
    private String countrySpecificTwoVerification;

    @JsonProperty("isManualVerification")
    private Boolean isManualVerification;

    public String getApplicantDetailsVerified() {
        return applicantDetailsVerified;
    }

    public void setApplicantDetailsVerified(String applicantDetailsVerified) {
        this.applicantDetailsVerified = applicantDetailsVerified;
    }

    public String getVerificationDateTime() {
        return verificationDateTime;
    }

    public void setVerificationDateTime(String verificationDateTime) {
        this.verificationDateTime = verificationDateTime;
    }

    public String getModeOfVerification() {
        return modeOfVerification;
    }

    public void setModeOfVerification(String modeOfVerification) {
        this.modeOfVerification = modeOfVerification;
    }

    public String getVerifiedBy() {
        return verifiedBy;
    }

    public void setVerifiedBy(String verifiedBy) {
        this.verifiedBy = verifiedBy;
    }

    public String getNameOfVerification() {
        return nameOfVerification;
    }

    public void setNameOfVerification(String nameOfVerification) {
        this.nameOfVerification = nameOfVerification;
    }

    public String getDateOfBirthVerification() {
        return dateOfBirthVerification;
    }

    public void setDateOfBirthVerification(String dateOfBirthVerification) {
        this.dateOfBirthVerification = dateOfBirthVerification;
    }

    public String getResidenceAddressVerification() {
        return residenceAddressVerification;
    }

    public void setResidenceAddressVerification(String residenceAddressVerification) {
        this.residenceAddressVerification = residenceAddressVerification;
    }

    public String getIdNumberVerification() {
        return idNumberVerification;
    }

    public void setIdNumberVerification(String idNumberVerification) {
        this.idNumberVerification = idNumberVerification;
    }

    public String getNationalityVerification() {
        return nationalityVerification;
    }

    public void setNationalityVerification(String nationalityVerification) {
        this.nationalityVerification = nationalityVerification;
    }

    public String getCountrySpecificOneCerification() {
        return countrySpecificOneCerification;
    }

    public void setCountrySpecificOneCerification(String countrySpecificOneCerification) {
        this.countrySpecificOneCerification = countrySpecificOneCerification;
    }

    public String getCountrySpecificTwoVerification() {
        return countrySpecificTwoVerification;
    }

    public void setCountrySpecificTwoVerification(String countrySpecificTwoVerification) {
        this.countrySpecificTwoVerification = countrySpecificTwoVerification;
    }

    public Boolean getIsManualVerification() {
        return isManualVerification;
    }

    public void setIsManualVerification(Boolean isManualVerification) {
        this.isManualVerification = isManualVerification;
    }


}
