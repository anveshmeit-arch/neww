package com.scb.clm.services.globus.mule.v1.model;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class VerifyMuleRequest 
{
	@JsonProperty("firstName")
	private String firstName;

	@JsonProperty("middleName")
	private String middleName;

	@JsonProperty("lastName")
	private String lastName;

	@JsonProperty("fullName")
	private String fullName;

	@JsonProperty("profileID")
	private String profileID;

	@JsonProperty("relationshipNumber")
	private String relationshipNumber;

	@JsonProperty("muleSource")
	private String muleSource;

	@JsonProperty("gender")
	private String gender;

	@JsonProperty("nationalityCode")
	private String nationalityCode;

	@JsonProperty("dateOfBirth")
	private String dateOfBirth;

	@JsonProperty("contacts")
	ArrayList<VerifyMuleRequestContacts> contacts;

	@JsonProperty("address")
	ArrayList<VerifyMuleRequestAddress> address;

	@JsonProperty("documents")
	ArrayList<VerifyMuleRequestDocuments> documents;

	@JsonProperty("device")
	ArrayList<VerifyMuleRequestDevice> device;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getProfileID() {
		return profileID;
	}

	public void setProfileID(String profileID) {
		this.profileID = profileID;
	}

	public String getRelationshipNumber() {
		return relationshipNumber;
	}

	public void setRelationshipNumber(String relationshipNumber) {
		this.relationshipNumber = relationshipNumber;
	}

	public String getMuleSource() {
		return muleSource;
	}

	public void setMuleSource(String muleSource) {
		this.muleSource = muleSource;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getNationalityCode() {
		return nationalityCode;
	}

	public void setNationalityCode(String nationalityCode) {
		this.nationalityCode = nationalityCode;
	}

	public ArrayList<VerifyMuleRequestContacts> getContacts() {
		return contacts;
	}

	public void setContacts(ArrayList<VerifyMuleRequestContacts> contacts) {
		this.contacts = contacts;
	}

	public ArrayList<VerifyMuleRequestAddress> getAddress() {
		return address;
	}

	public void setAddress(ArrayList<VerifyMuleRequestAddress> address) {
		this.address = address;
	}

	public ArrayList<VerifyMuleRequestDocuments> getDocuments() {
		return documents;
	}

	public void setDocuments(ArrayList<VerifyMuleRequestDocuments> documents) {
		this.documents = documents;
	}

	public ArrayList<VerifyMuleRequestDevice> getDevice() {
		return device;
	}

	public void setDevice(ArrayList<VerifyMuleRequestDevice> device) {
		this.device = device;
	}

	public void addContacts(VerifyMuleRequestContacts contactEntity) {
		if (this.contacts == null) {
			this.contacts = new ArrayList<>();
		}
		this.contacts.add(contactEntity);
	}

	public void addAddress(VerifyMuleRequestAddress addressDetail) {
		if (this.address == null) {
			this.address = new ArrayList<>();
		}
		this.address.add(addressDetail);
	}

	public void addDocuments(VerifyMuleRequestDocuments documentsDetail) {
		if (this.documents == null) {
			this.documents = new ArrayList<>();
		}
		this.documents.add(documentsDetail);
	}

	public void addDevice(VerifyMuleRequestDevice deviceDetails) {
		if (this.device == null) {
			this.device = new ArrayList<>();
		}
		this.device.add(deviceDetails);
	}
}