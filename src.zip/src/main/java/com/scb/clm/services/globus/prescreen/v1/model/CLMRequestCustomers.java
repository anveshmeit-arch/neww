package com.scb.clm.services.globus.prescreen.v1.model;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;


public class CLMRequestCustomers 
{
    @JsonProperty("id") 
    String id;
    @JsonProperty("max-response-record") 
    int maxresponserecord;
    @JsonProperty("first-name") 
    String firstname;
    @JsonProperty("middle-name ") 
    String middlename ;
    @JsonProperty("last-name") 
    String lastname;
    @JsonProperty("full-name") 
    String fullname;
    @JsonProperty("date-of-birth") 
    String dateofbirth;
    @JsonProperty("bsbda-flag") 
    String bsbdaflag;
    @JsonProperty("last-name-override") 
    String lastnameoverride;
    @JsonProperty("contacts") 
    ArrayList<CLMRequestContacts> contacts;
    @JsonProperty("documents") 
    ArrayList<CLMRequestDocuments> documents;
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public int getMaxresponserecord() {
        return maxresponserecord;
    }
    public void setMaxresponserecord(int maxresponserecord) {
        this.maxresponserecord = maxresponserecord;
    }
    public String getFirstname() {
        return firstname;
    }
    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }
    public String getMiddlename() {
        return middlename;
    }
    public void setMiddlename(String middlename) {
        this.middlename = middlename;
    }
    public String getLastname() {
        return lastname;
    }
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }
    public String getFullname() {
        return fullname;
    }
    public void setFullname(String fullname) {
        this.fullname = fullname;
    }
    public String getDateofbirth() {
        return dateofbirth;
    }
    public void setDateofbirth(String dateofbirth) {
        this.dateofbirth = dateofbirth;
    }
    public String getBsbdaflag() {
        return bsbdaflag;
    }
    public void setBsbdaflag(String bsbdaflag) {
        this.bsbdaflag = bsbdaflag;
    }
    public String getLastnameoverride() {
        return lastnameoverride;
    }
    public void setLastnameoverride(String lastnameoverride) {
        this.lastnameoverride = lastnameoverride;
    }
    public ArrayList<CLMRequestContacts> getContacts() {
        return contacts;
    }
    public void setContacts(ArrayList<CLMRequestContacts> contacts) {
        this.contacts = contacts;
    }
    public ArrayList<CLMRequestDocuments> getDocuments() {
        return documents;
    }
    public void setDocuments(ArrayList<CLMRequestDocuments> documents) {
        this.documents = documents;
    }
    public void addContacts(CLMRequestContacts argContacts) {
        if(this.contacts == null) {
            this.contacts = new ArrayList<CLMRequestContacts>();     
        }
        this.contacts.add(argContacts);
    }
    public void addDocuments(CLMRequestDocuments argContacts) {
        if(this.documents == null) {
            this.documents= new ArrayList<CLMRequestDocuments>();     
        }
        this.documents.add(argContacts);
    }
}
