package com.scb.clm.services.companysearch.chekk.v1.support;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.scb.clm.common.config.ApplicationConfiguration;
import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.services.companysearch.chekk.v1.service.SearchCompanyAsyncProcessor;

@Configuration
public class ChkBeanConfig {
	private LoggerUtil log = LoggerUtil.getInstance("Company_Search", SearchCompanyAsyncProcessor.class.getName(), "execute", "APPLICATION");

	
	@Bean(name = "SearchCompanyQueue")
	public TaskExecutor searchCompanyExecutor() {
		String asyncCorePoolSize = "3";
		String asyncMaxPoolSize = "10";
		String asyncQueueCapacity = "100";
		ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();

		try {
			asyncCorePoolSize = ApplicationConfiguration.getPropertiesHash(BaseConstants.ASYNC_CORE_POOL_SIZE);
			asyncMaxPoolSize = ApplicationConfiguration.getPropertiesHash(BaseConstants.ASYNC_MAX_POOL_SIZE);
			asyncQueueCapacity = ApplicationConfiguration.getPropertiesHash(BaseConstants.ASYNC_QUEUE_CAPACITY);

			int corePoolSize = Integer.parseInt(
					(asyncCorePoolSize != null && asyncCorePoolSize.trim().length() > 0) ? asyncCorePoolSize.trim()
							: "3");
			int maxPoolSize = Integer.parseInt(
					(asyncMaxPoolSize != null && asyncMaxPoolSize.trim().length() > 0) ? asyncMaxPoolSize.trim()
							: "10");
			int queueCapacity = Integer.parseInt(
					(asyncQueueCapacity != null && asyncQueueCapacity.trim().length() > 0) ? asyncQueueCapacity.trim()
							: "100");

			log.println("\nSearchCompanyExecutor Initializing CorePoolSize #" + corePoolSize + "# MaxPoolSize #"
					+ maxPoolSize + "# QueueCapacity #" + queueCapacity + "#");

			threadPoolTaskExecutor.setThreadNamePrefix("CLM-SCQ-Async-");
			threadPoolTaskExecutor.setCorePoolSize(corePoolSize);
			threadPoolTaskExecutor.setMaxPoolSize(maxPoolSize);
			threadPoolTaskExecutor.setQueueCapacity(queueCapacity);
			threadPoolTaskExecutor.afterPropertiesSet();
			log.println("SearchCompanyExecutor Initialized CorePoolSize #" + corePoolSize + "# MaxPoolSize #"
					+ maxPoolSize + "# QueueCapacity #" + queueCapacity + "#");
		} catch (Exception e) {
			log.println("ServiceExecutor # Exception for # CLMApplication # " + e.getLocalizedMessage() + " / "
					+ e.getMessage());
		}
		return threadPoolTaskExecutor;
	}
}
