package com.scb.clm.services.globus.icm.v1.model;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ICMCustomerCreatePreference {

	@JsonProperty("id")
	private String guid;
	
	@JsonProperty("reference-id")
	private String profileId;
	
	@JsonProperty("pref-lang-for-comm")
	private String prefLangForComm;
	
	@JsonProperty("preferred-statement-language")
	private String prefStmtLang;
	
	@JsonProperty("preferred-atm-language")
	private String preferredATMLanguage;
	
	@JsonProperty("preferred-phone-language")
	private String preferredPhoneLanguage;
	
	@JsonProperty("ibanking-registered")
	private String ibankingRegistered;
	
	@JsonProperty("phone-banking-registered")
	private String phoneBankingRegistered;
	
	@JsonProperty("sms-banking-registered")
	private String smsBankingRegistered;
	
	@JsonProperty("sender-id")
	private String senderId;
	
	@JsonProperty("sender-branch")
	private String senderBranch;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	@JsonProperty("created-at")
	private Timestamp createdAt;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	@JsonProperty("updated-at")
	private Timestamp updatedAt;
	
	@JsonProperty("status")
	private String status;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	@JsonProperty("status-at")
	private Timestamp statusAt;
	
	@JsonProperty("country-id")
	private String companyId;

	public String getGuid() {
		return guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}

	public String getProfileId() {
		return profileId;
	}

	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}

	public String getPrefLangForComm() {
		return prefLangForComm;
	}

	public void setPrefLangForComm(String prefLangForComm) {
		this.prefLangForComm = prefLangForComm;
	}

	public String getPrefStmtLang() {
		return prefStmtLang;
	}

	public void setPrefStmtLang(String prefStmtLang) {
		this.prefStmtLang = prefStmtLang;
	}

	public String getPreferredATMLanguage() {
		return preferredATMLanguage;
	}

	public void setPreferredATMLanguage(String preferredATMLanguage) {
		this.preferredATMLanguage = preferredATMLanguage;
	}

	public String getPreferredPhoneLanguage() {
		return preferredPhoneLanguage;
	}

	public void setPreferredPhoneLanguage(String preferredPhoneLanguage) {
		this.preferredPhoneLanguage = preferredPhoneLanguage;
	}

	public String getIbankingRegistered() {
		return ibankingRegistered;
	}

	public void setIbankingRegistered(String ibankingRegistered) {
		this.ibankingRegistered = ibankingRegistered;
	}

	public String getPhoneBankingRegistered() {
		return phoneBankingRegistered;
	}

	public void setPhoneBankingRegistered(String phoneBankingRegistered) {
		this.phoneBankingRegistered = phoneBankingRegistered;
	}

	public String getSmsBankingRegistered() {
		return smsBankingRegistered;
	}

	public void setSmsBankingRegistered(String smsBankingRegistered) {
		this.smsBankingRegistered = smsBankingRegistered;
	}

	public String getSenderId() {
		return senderId;
	}

	public void setSenderId(String senderId) {
		this.senderId = senderId;
	}

	public String getSenderBranch() {
		return senderBranch;
	}

	public void setSenderBranch(String senderBranch) {
		this.senderBranch = senderBranch;
	}

	public Timestamp getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Timestamp createdAt) {
		this.createdAt = createdAt;
	}

	public Timestamp getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Timestamp updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getStatusAt() {
		return statusAt;
	}

	public void setStatusAt(Timestamp statusAt) {
		this.statusAt = statusAt;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
}
