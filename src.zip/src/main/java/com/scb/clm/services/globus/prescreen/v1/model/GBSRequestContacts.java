package com.scb.clm.services.globus.prescreen.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSRequestContacts 
{

    @JsonProperty("contactTypeCode")
    String contactTypeCode;

    @JsonProperty("contact")
    String contact;

    public String getContactTypeCode() {
        return contactTypeCode;
    }

    public void setContactTypeCode(String contactTypeCode) {
        this.contactTypeCode = contactTypeCode;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

}

