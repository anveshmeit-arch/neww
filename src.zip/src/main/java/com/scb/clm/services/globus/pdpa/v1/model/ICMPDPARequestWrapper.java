package com.scb.clm.services.globus.pdpa.v1.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ICMPDPARequestWrapper {

	@JsonProperty("data")
	private ICMPDPADatatWrapper data;

	public ICMPDPADatatWrapper getData() {
		return data;
	}

	public void setData(ICMPDPADatatWrapper data) {
		this.data = data;
	}
	
	
}
