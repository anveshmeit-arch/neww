package com.scb.clm.services.companysearch.chekk.v1.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "chk_countries")
@Getter
@Setter
public class ChekkCountriesEntity {

   @Id
   @Column(name="country_code")
   private String countryCode;

   @Column(name="country_code_3char")
   private String countryCode3Char;

   @Column(name="country_name")
   private String countryName;

}
