package com.scb.clm.services.companysearch.chekk.v1.support;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.clm.services.companysearch.chekk.v1.service.ChkTableReferences;
import com.solacesystems.jms.SolConnectionFactory;
import com.solacesystems.jms.SolJmsUtility;
import com.solacesystems.jms.SupportedProperty;

import jakarta.annotation.PostConstruct;
import jakarta.jms.Connection;
import jakarta.jms.DeliveryMode;
import jakarta.jms.JMSException;
import jakarta.jms.Message;
import jakarta.jms.MessageProducer;
import jakarta.jms.Session;
import jakarta.jms.TextMessage;
import jakarta.jms.Topic;

@Service
public class SolaceConnectionUtil {

    @Autowired
    private ChkConfigProperties configProps;
    @Autowired
    private ChkTableReferences refData;

    private String providerUrl;

    private String solaceTrustStore;

    private String solaceAuthKey;

    private String vpnName;

    private String solaceTrustPwd;

    private String solaceAuthKeyPwd;

    private static final String SOLACE_PROVIDER_URL = "SOLACE_PROVIDER_URL";
    private static final String SOLACE_VPN_NAME = "SOLACE_VPN_NAME";
    private static final String SOLACE_TRUSTSTORE_PATH = "SOLACE_TRUSTSTORE_PATH";
    private static final String SOLACE_TRUSTSTORE_PD = "SOLACE_TRUSTSTORE_PD";
    private static final String SOLACE_KEYSTORE_PATH = "SOLACE_KEYSTORE_PATH";
    private static final String SOLACE_KEYSTORE_PD = "SOLACE_KEYSTORE_PD";

    private Connection connection = null;

    @PostConstruct
    private void init() {
        providerUrl = configProps.getParamValue(SOLACE_PROVIDER_URL);
        solaceTrustStore = configProps.getParamValue(SOLACE_TRUSTSTORE_PATH);
        solaceAuthKey = configProps.getParamValue(SOLACE_KEYSTORE_PATH);
        vpnName = configProps.getParamValue(SOLACE_VPN_NAME);
        solaceTrustPwd = configProps.getParamValue(SOLACE_TRUSTSTORE_PD);
        solaceAuthKeyPwd = configProps.getParamValue(SOLACE_KEYSTORE_PD);

    }

    public boolean postMessagetoTopic(String jsonMsg, String countryCode, String interfaceId) {
        boolean isSend = false;
        String topicName = null;
        try {

            topicName = this.getTopicName(countryCode, interfaceId);
            Log.info(
                    "SolaceConnectionUtil#postMessagetoTopic: Started writing message to [countrycode,interface,topic] = ["
                            + topicName + "," + interfaceId + "," + topicName);
            connection = getConnection();
            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            Topic topic = session.createTopic(topicName);
            MessageProducer messageProducer = session.createProducer(topic);
            TextMessage message = session.createTextMessage(jsonMsg);
            messageProducer.send(topic, message, DeliveryMode.NON_PERSISTENT, Message.DEFAULT_PRIORITY,
                    Message.DEFAULT_TIME_TO_LIVE);
            session.close();
            isSend = true;
            Log.info("SolaceConnectionUtil#postMessagetoTopic: Message sent successfully");
        } catch (Exception ex) {
            isSend = false;
            Log.error(
                    "SolaceConnectionUtil#postMessagetoTopic: ########## Failed to post the message in topic ########## "
                            + ex.getMessage(),
                    ex);
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (JMSException e) {
                    Log.error(
                            "SolaceConnectionUtil#postMessagetoTopic: ########## Error in closing solace connection ########## "
                                    + e.getMessage(),
                            e);
                }
            }
        }
        return isSend;
    }

    public Connection getConnection() throws Exception {
        Log.info("SolaceConnectionUtil#getConnection: Inside getConnection , vpnName " + vpnName);

        SolConnectionFactory solConnectionFactory = SolJmsUtility.createConnectionFactory();
        solConnectionFactory.setHost(providerUrl);
        solConnectionFactory.setVPN(vpnName);
        solConnectionFactory.setAuthenticationScheme(SupportedProperty.AUTHENTICATION_SCHEME_CLIENT_CERTIFICATE);
        // Add ICM certificate jks
        solConnectionFactory.setSSLKeyStore(solaceAuthKey);
        solConnectionFactory.setSSLKeyStorePassword(solaceAuthKeyPwd);
        // add solace url ssl certificate in jks
        solConnectionFactory.setSSLTrustStore(solaceTrustStore);
        solConnectionFactory.setSSLTrustStorePassword(solaceTrustPwd);
        solConnectionFactory.setSSLProtocol(ProcessApiConstants.SSL_PROTOCOLS);

        solConnectionFactory.setSSLCipherSuites(ProcessApiConstants.SSL_CIPHER_SUITES_ARGS);
        solConnectionFactory.setReconnectRetryWaitInMillis(5000);
        solConnectionFactory.setConnectRetriesPerHost(2);
        solConnectionFactory.setReconnectRetries(50);
        solConnectionFactory.setConnectRetries(5);

        return solConnectionFactory.createConnection();
    }

    public String getTopicName(String cntryCode, String interfaceName) {
        String topicName = null;
        if (cntryCode != null && interfaceName != null) {
            topicName = refData.getSolaceTopicName(cntryCode, interfaceName);
        }
        return topicName;
    }
}
