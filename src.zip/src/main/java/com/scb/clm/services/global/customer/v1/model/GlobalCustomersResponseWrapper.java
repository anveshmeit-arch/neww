package com.scb.clm.services.global.customer.v1.model;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

public class GlobalCustomersResponseWrapper
{
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty("globalIdentifier")
    private String globalIdentifier;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty("errorDetails")
    private ArrayList<GlobalCustomersResponseErrorDetails> errorDetails;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty("applicationReferenceNumber")
    String applicationReferenceNumber;

    public String getGlobalIdentifier() {
        return globalIdentifier;
    }

    public void setGlobalIdentifier(String globalIdentifier) {
        this.globalIdentifier = globalIdentifier;
    }

    public ArrayList<GlobalCustomersResponseErrorDetails> getErrorDetails() 
    {
        return errorDetails;
    }

    public void setErrorDetails(ArrayList<GlobalCustomersResponseErrorDetails> errorDetails) 
    {
        this.errorDetails = errorDetails;
    }

    public String getApplicationReferenceNumber()
    {
        return applicationReferenceNumber;
    }

    public void setApplicationReferenceNumber(String applicationReferenceNumber)
    {
        this.applicationReferenceNumber = applicationReferenceNumber;
    }

    public void addErrors(GlobalCustomersResponseErrorDetails argErrors) 
    {
        if(this.errorDetails == null) 
        {
            this.errorDetails= new ArrayList<GlobalCustomersResponseErrorDetails>();     
        }
        this.errorDetails.add(argErrors);
    }
}