package com.scb.clm.services.globus.cddinitiate.v1.model;

import java.util.Arrays;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CDDCreateInitiateSourceOfWealth {

	@JsonProperty("primary-source")
	private String primary_source;

	@JsonProperty("occupation-code")
	private String occupation_code;

	@JsonProperty("employer-name")
	private String employer_name;

	@JsonProperty("employer-address")
	private String employer_address;

	@JsonProperty("employment-income")
	private String employment_income;

	@JsonProperty("employment-income-currency")
	private String employment_income_currency;

	@JsonProperty("business-type")
	private String business_type;

	@JsonProperty("business-name")
	private String business_name;

	@JsonProperty("business-address")
	private String business_address;

	@JsonProperty("business-income")
	private String business_income;

	@JsonProperty("business-income-currency")
	private String business_income_currency;

	@JsonProperty("investments")
	private String[] investments;


	@JsonProperty("savings-from")
	private String[] savings_from;

	@JsonProperty("previous-company-name")
	private String previous_company_name;

	@JsonProperty("relationship-with-funding-member")
	private String relationship_with_funding_member;

	@JsonProperty("funding-member-employee-name")
	private String funding_member_employee_name;


	@JsonProperty("relationship-with-benefactor")
	private String relationship_with_benefactor;

	@JsonProperty("benefactor-employee-name")
	private String benefactor_employee_name;


	public String getPrimary_source() {
		return primary_source;
	}

	public void setPrimary_source(String primary_source) {
		this.primary_source = primary_source;
	}

	public String getOccupation_code() {
		return occupation_code;
	}

	public void setOccupation_code(String occupation_code) {
		this.occupation_code = occupation_code;
	}

	public String getEmployer_name() {
		return employer_name;
	}

	public void setEmployer_name(String employer_name) {
		this.employer_name = employer_name;
	}

	public String getEmployer_address() {
		return employer_address;
	}

	public void setEmployer_address(String employer_address) {
		this.employer_address = employer_address;
	}

	public String getEmployment_income() {
		return employment_income;
	}

	public void setEmployment_income(String employment_income) {
		this.employment_income = employment_income;
	}

	public String getEmployment_income_currency() {
		return employment_income_currency;
	}

	public void setEmployment_income_currency(String employment_income_currency) {
		this.employment_income_currency = employment_income_currency;
	}

	public String getBusiness_type() {
		return business_type;
	}

	public void setBusiness_type(String business_type) {
		this.business_type = business_type;
	}

	public String getBusiness_name() {
		return business_name;
	}

	public void setBusiness_name(String business_name) {
		this.business_name = business_name;
	}

	public String getBusiness_address() {
		return business_address;
	}

	public void setBusiness_address(String business_address) {
		this.business_address = business_address;
	}

	public String getBusiness_income() {
		return business_income;
	}

	public void setBusiness_income(String business_income) {
		this.business_income = business_income;
	}

	public String getBusiness_income_currency() {
		return business_income_currency;
	}

	public void setBusiness_income_currency(String business_income_currency) {
		this.business_income_currency = business_income_currency;
	}

	public String[] getInvestments() {
		return investments;
	}

	public void setInvestments(String[] investments) {
		this.investments = investments;
	}

	public String[] getSavings_from() {
		return savings_from;
	}

	public void setSavings_from(String[] savings_from) {
		this.savings_from = savings_from;
	}

	public String getPrevious_company_name() {
		return previous_company_name;
	}

	public void setPrevious_company_name(String previous_company_name) {
		this.previous_company_name = previous_company_name;
	}

	public String getRelationship_with_funding_member() {
		return relationship_with_funding_member;
	}

	public void setRelationship_with_funding_member(String relationship_with_funding_member) {
		this.relationship_with_funding_member = relationship_with_funding_member;
	}

	public String getFunding_member_employee_name() {
		return funding_member_employee_name;
	}

	public void setFunding_member_employee_name(String funding_member_employee_name) {
		this.funding_member_employee_name = funding_member_employee_name;
	}

	public String getRelationship_with_benefactor() {
		return relationship_with_benefactor;
	}

	public void setRelationship_with_benefactor(String relationship_with_benefactor) {
		this.relationship_with_benefactor = relationship_with_benefactor;
	}

	public String getBenefactor_employee_name() {
		return benefactor_employee_name;
	}

	public void setBenefactor_employee_name(String benefactor_employee_name) {
		this.benefactor_employee_name = benefactor_employee_name;
	}

	@Override
	public String toString() {
		return "CDD_Create_Initiate_SourceOfWealth [primary_source=" + primary_source + ", occupation_code="
				+ occupation_code + ", employer_name=" + employer_name + ", employer_address=" + employer_address
				+ ", employment_income=" + employment_income + ", employment_income_currency="
				+ employment_income_currency + ", business_type=" + business_type + ", business_name=" + business_name
				+ ", business_address=" + business_address + ", business_income=" + business_income
				+ ", business_income_currency=" + business_income_currency + ", investments="
				+ Arrays.toString(investments) + ", savings_from=" + Arrays.toString(savings_from)
				+ ", previous_company_name=" + previous_company_name + ", relationship_with_funding_member="
				+ relationship_with_funding_member + ", funding_member_employee_name=" + funding_member_employee_name
				+ ", relationship_with_benefactor=" + relationship_with_benefactor + ", benefactor_employee_name="
				+ benefactor_employee_name + "]";
	}
}
