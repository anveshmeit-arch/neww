package com.scb.clm.services.globus.onboarding.v1.models;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.scb.clm.common.util.WrapperUtility;

public class GBSOnboardContactsWrapper {

	@JsonProperty("contact")
	private String contact;
	
	@JsonProperty("contactClassificationCode")
	private String contactClassificationCode;
	
	@JsonProperty("contactTypeCode")
	private String contactTypeCode;
	
	@JsonProperty("countryCode")
	private String countryCode;
	
	@JsonProperty("areaCode")
	private String areaCode;
	
	@JsonProperty("extensionDetail")
	private String extensionDetail;
	
	@JsonProperty("preferredContact")
	private String preferredContact;
	
	@JsonProperty("primaryContact")
	private String primaryContact;
	
	@JsonProperty("doNotDisturbRegistry")
	private String doNotDisturbRegistry;
	
	@JsonProperty("doNotDisturbExpiryDate")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date doNotDisturbExpiryDate;
	
	@JsonProperty("attentionParty")
	private String attentionParty;
	
	@JsonProperty("isdContactCountryCode")
	private String isdContactCountryCode;

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getContactClassificationCode() {
        return contactClassificationCode;
    }

    public void setContactClassificationCode(String contactClassificationCode) {
        this.contactClassificationCode = contactClassificationCode;
    }

    public String getContactTypeCode() {
        return contactTypeCode;
    }

    public void setContactTypeCode(String contactTypeCode) {
        this.contactTypeCode = contactTypeCode;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode;
    }

    public String getExtensionDetail() {
        return extensionDetail;
    }

    public void setExtensionDetail(String extensionDetail) {
        this.extensionDetail = extensionDetail;
    }

    public String getPreferredContact() {
        return preferredContact;
    }

    public void setPreferredContact(String preferredContact) {
        this.preferredContact = preferredContact;
    }

    public String getPrimaryContact() {
        return primaryContact;
    }

    public void setPrimaryContact(String primaryContact) {
        this.primaryContact = primaryContact;
    }

    public String getDoNotDisturbRegistry() {
        return doNotDisturbRegistry;
    }

    public void setDoNotDisturbRegistry(String doNotDisturbRegistry) {
        this.doNotDisturbRegistry = doNotDisturbRegistry;
    }

    public Date getDoNotDisturbExpiryDate() {
        return doNotDisturbExpiryDate;
    }

    public void setDoNotDisturbExpiryDate(Date doNotDisturbExpiryDate) {
        this.doNotDisturbExpiryDate = WrapperUtility.cloneData(doNotDisturbExpiryDate);
    }

    public String getAttentionParty() {
        return attentionParty;
    }

    public void setAttentionParty(String attentionParty) {
        this.attentionParty = attentionParty;
    }

    public String getIsdContactCountryCode() {
        return isdContactCountryCode;
    }

    public void setIsdContactCountryCode(String isdContactCountryCode) {
        this.isdContactCountryCode = isdContactCountryCode;
    }


}
