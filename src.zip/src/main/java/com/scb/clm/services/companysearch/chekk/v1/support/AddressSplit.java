package com.scb.clm.services.companysearch.chekk.v1.support;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AddressSplit {

    private AddressSplit() {

    }

    public static Map<String, String> addressSplit(String address) {
        List<String> addressLine;
        Map<String, String> addressLineMap;
        if (null == address) {
            address = ProcessApiConstants.EMPTY_STRING;
        }
        addressLine = splitAddress(address, 30);
        addressLineMap = constructAddressLineMap(addressLine);
        return addressLineMap;
    }

    public static List<String> splitAddress(String input, int maxLineLength) {
        List<String> res = new ArrayList<>();
        res = getAddressLineList(input, maxLineLength);
        return res;
    }

    public static List<String> getAddressLineList(String input, int maxLineLength) {
        List<String> resList = new ArrayList<>();

        String[] tokens = input
                .replaceAll(ProcessApiConstants.COMMA_SEPARATOR,
                        ProcessApiConstants.COMMA_SEPARATOR + ProcessApiConstants.BLANK_SPACE)
                .split(ProcessApiConstants.SPLIT_REGEXP1);
        StringBuilder output = new StringBuilder(input.length());
        int lineLen = 0;
        for (int i = 0; i < tokens.length; i++) {
            String word = tokens[i].trim();
            if (word.length() <= maxLineLength) {

                if (lineLen + (ProcessApiConstants.SPACE_SEPARATOR + word).length() > maxLineLength) {
                    if (i > 0) {
                        output.append(ProcessApiConstants.NEWLINE);
                    }
                    lineLen = 0;
                }
                if (i < tokens.length - 1 && (lineLen + (word + ProcessApiConstants.SPACE_SEPARATOR).length()
                        + tokens[i + 1].length() <= maxLineLength)) {
                    word += ProcessApiConstants.SPACE_SEPARATOR;
                }
                output.append(word);
                lineLen += word.length();
            } else {
                Log.error("Invalid Address String or NULL :: " + input);
                resList.add(ProcessApiConstants.EMPTY_STRING);
                resList.add(ProcessApiConstants.EMPTY_STRING);
                resList.add(ProcessApiConstants.EMPTY_STRING);
                resList.add(input);
                return resList;
            }
        }
        String[] lines = output.toString().split(ProcessApiConstants.SPLIT_REGEXP2);
        resList = Arrays.asList(lines);
        return resList;
    }

    public static Map<String, String> constructAddressLineMap(List<String> addressLine) {

        Map<String, String> addressLineMap = new HashMap<>();
        String tmpAddLine;
        addressLineMap.put(ProcessApiConstants.ADDRESS_LINE1, ProcessApiConstants.EMPTY_STRING);
        addressLineMap.put(ProcessApiConstants.ADDRESS_LINE2, ProcessApiConstants.EMPTY_STRING);
        addressLineMap.put(ProcessApiConstants.ADDRESS_LINE3, ProcessApiConstants.EMPTY_STRING);
        addressLineMap.put(ProcessApiConstants.ADDRESS_LINE4, ProcessApiConstants.EMPTY_STRING);

        for (int i = 0; i < addressLine.size(); i++) {
            if (i == 0) {
                addressLineMap.put(ProcessApiConstants.ADDRESS_LINE1, addressLine.get(i));
            } else if (i == 1) {
                addressLineMap.put(ProcessApiConstants.ADDRESS_LINE2, addressLine.get(i));
            } else if (i == 2) {
                addressLineMap.put(ProcessApiConstants.ADDRESS_LINE3, addressLine.get(i));
            } else if (i > 2) {
                tmpAddLine = addressLineMap.get(ProcessApiConstants.ADDRESS_LINE4) + ProcessApiConstants.SPACE_SEPARATOR
                        + addressLine.get(i);
                addressLineMap.put(ProcessApiConstants.ADDRESS_LINE4, tmpAddLine.trim());
            }
        }

        return addressLineMap;
    }
}
