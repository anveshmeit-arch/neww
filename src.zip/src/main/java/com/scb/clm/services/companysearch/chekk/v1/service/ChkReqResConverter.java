package com.scb.clm.services.companysearch.chekk.v1.service;

import java.util.List;

import com.scb.clm.services.companysearch.chekk.v1.exception.ApplicationException;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkPartyEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkSearchEntityQEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChkCreateRequest;
import com.scb.clm.services.companysearch.chekk.v1.model.ChkCreateResponse;
import com.scb.clm.services.companysearch.chekk.v1.model.ChkGetRequest;
import com.scb.clm.services.companysearch.chekk.v1.model.ChkGetResponse;
import com.scb.clm.services.companysearch.chekk.v1.model.ChkSearchRequest;
import com.scb.clm.services.companysearch.chekk.v1.model.ChkSearchResponse;
import com.scb.clm.services.companysearch.chekk.v1.model.Content;
import com.scb.clm.services.companysearch.chekk.v1.model.process.FinalResponse;

/**
 * <code> Construct request object from previous API's response object.</code>
 * 
 * <p>
 * To generate final response for a company search request from source system
 * (CSL / DCUBE), a sequence of API calls are executed in below order where
 * request of next API is constructed from response of previous one.
 * 
 * This utility class generates request object from response object to perform
 * API calls.
 * </p>
 * 
 * In addition, {@linkplain ChkGetResponse} object is converted to list of
 * {@linkplain ChekkPartyEntity} object to persist this data at DB or to
 * generate {@linkplain FinalResponse}.
 * 
 * <li>Generates {@linkplain ChkCreateRequest} from
 * {@linkplain ChkSearchResponse} object.</li>
 * <li>Generates {@linkplain ChkGetRequest} from {@linkplain ChkCreateResponse}
 * object.</li>
 * 
 * 
 */
public class ChkReqResConverter {

	private ChkReqResConverter() {

	}

	public static ChkCreateRequest toCreateRequest(ChkSearchResponse chkSearchResponse) {
		ChkCreateRequest chkCreateRequest = new ChkCreateRequest();
		List<Content> contentList = chkSearchResponse.getContent();
		if (contentList != null && contentList.size() == 1) {
			Content content = chkSearchResponse.getContent().get(0);
			chkCreateRequest.setJurisdiction(content.getJurisdiction());
			chkCreateRequest.setCode(content.getCode());
			chkCreateRequest.setName(content.getName());
			chkCreateRequest.setSourceConfiguration(content.getSourceConfiguration());
		} else {
			throw new ApplicationException();
		}
		return chkCreateRequest;
	}

	public static ChkGetRequest toGetRequest(ChkCreateResponse createRes) {
		ChkGetRequest chkGetRequest = new ChkGetRequest();
		if (createRes == null) {
			throw new ApplicationException();
		}
		chkGetRequest.setId(createRes.getId());
		return chkGetRequest;
	}

	public static ChkSearchRequest toSearchRequest(ChekkSearchEntityQEntity chkSearchEntity) {
		ChkSearchRequest chksrchReq = new ChkSearchRequest();
		chksrchReq.setJurisdiction(chkSearchEntity.getCountryOfRegistration());
		chksrchReq.setCode(chkSearchEntity.getRegistrationID());
		chksrchReq.setName(chkSearchEntity.getEntityName());
		return chksrchReq;
	}
}
