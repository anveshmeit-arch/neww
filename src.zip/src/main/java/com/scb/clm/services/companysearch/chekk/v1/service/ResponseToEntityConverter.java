package com.scb.clm.services.companysearch.chekk.v1.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.clm.common.util.DateTimeUtility;
import com.scb.clm.services.companysearch.chekk.v1.exception.ApplicationException;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekGetResponse;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkPartyEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkRequestsEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkResponseDataEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkSearchEntityQEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.NodeDataArray;
import com.scb.clm.services.companysearch.chekk.v1.model.ProcessApiRequestsEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.SearchRequest;
import com.scb.clm.services.companysearch.chekk.v1.model.process.FinalResponse;
import com.scb.clm.services.companysearch.chekk.v1.service.FinalResponseMapper.FinalResponseMapBuilder;
import com.scb.clm.services.companysearch.chekk.v1.support.DBUtility;
import com.scb.clm.services.companysearch.chekk.v1.support.JsonParserUtil;
import com.scb.clm.services.companysearch.chekk.v1.support.Log;
import com.scb.clm.services.companysearch.chekk.v1.support.ModelConverter;
import com.scb.clm.services.companysearch.chekk.v1.support.ProcessApiConstants;

@Service
public class ResponseToEntityConverter {

    @Autowired
    private ChkSchedulerDao scheudlerDao;

    @Autowired
    private ChkTableReferences refData;

    public ChekkResponseDataEntity constructChekkResponseEnity(String id, String requestId, String searchId,
            ChkApiResponse apiResponse) {
        if (apiResponse == null) {
            return null;
        }
        String status = apiResponse.isSuccess() ? ProcessApiConstants.SUCCESS_CODE : ProcessApiConstants.FAILURE_CODE;
        String responseType = apiResponse.getApiType().getResponseType();

        ChekkResponseDataEntity chekkResponseDataEntity = new ChekkResponseDataEntity();
        chekkResponseDataEntity.setId(id);
        chekkResponseDataEntity.setSearchEntityId(searchId);
        chekkResponseDataEntity.setCreatedOn(DateTimeUtility.getCurrentTime());
        chekkResponseDataEntity.setRequestId(requestId);
        chekkResponseDataEntity.setResType(responseType);
        chekkResponseDataEntity.setStatus(status);
        chekkResponseDataEntity.setResData(apiResponse.getResponseData());
        return chekkResponseDataEntity;
    }

    public ChekkSearchEntityQEntity constructChekkSearchEnityQueueData(String id, String requestId,
            SearchRequest searchReq, int level, boolean isSuccess) {
        String status = isSuccess ? ProcessApiConstants.STATUS_CREATE_PENDING
                : ProcessApiConstants.STATUS_PUBLISH_FAILED;

        ChekkSearchEntityQEntity chekkSearchEntityQEntity = new ChekkSearchEntityQEntity();
        chekkSearchEntityQEntity.setSearchEntityId(id);
        chekkSearchEntityQEntity.setRequestId(requestId);
        chekkSearchEntityQEntity.setEntityName(searchReq.getEntityName());
        chekkSearchEntityQEntity.setLevel(level);
        chekkSearchEntityQEntity.setStatus(status);
        chekkSearchEntityQEntity.setRegistrationID(searchReq.getRegistrationID());
        chekkSearchEntityQEntity.setCountryOfRegistration(searchReq.getCountryOfRegistration());
        /**
         * chekkSearchEntityQEntity.setErrorCode("");
         */
        chekkSearchEntityQEntity.setCreatedOn(DateTimeUtility.getCurrentTime());
        chekkSearchEntityQEntity.setUpdatedOn(DateTimeUtility.getCurrentTime());

        return chekkSearchEntityQEntity;
    }

    public Map<String, String> populateRequestHeader(ProcessApiRequestsEntity clmInboundRequest) {
        Map<String, String> requestHdrs = new HashMap<>();
        if (clmInboundRequest != null) {
            requestHdrs.put(ProcessApiConstants.REQ_HDR_COUNTRY_CODE, clmInboundRequest.getCountryCode());
            requestHdrs.put(ProcessApiConstants.PROCESS_API_HEADER_INTERFACE_ID, clmInboundRequest.getInterfaceId());
            requestHdrs.put(ProcessApiConstants.PROCESS_API_HEADER_TRANSACTION_ID, clmInboundRequest.getTrackingID());
        }
        return requestHdrs;
    }

    public Map<String, String> populateRequstBody(ChekkRequestsEntity checkRequestentity) {
        Map<String, String> requestBody = new HashMap<>();
        if (checkRequestentity != null) {
            requestBody.put(ProcessApiConstants.REQ_BODY_APPL_REF_NO, checkRequestentity.getApplicationReference());
            requestBody.put(ProcessApiConstants.REQ_BODY_CNTRY_ACCTOPEN, checkRequestentity.getCountryAccountOpen());
            requestBody.put(ProcessApiConstants.REQ_BODY_CNTRY_EST, checkRequestentity.getCountryOfRegistration());
        }
        return requestBody;

    }

    public List<ChekkPartyEntity> populateChkPartyData(ChekkSearchEntityQEntity searchEntityQ,
            ChekGetResponse chkGetResponse) {
        ChekkPartyEntity immdtParentEntity = null;
        int level = searchEntityQ.getLevel();

        if (level == 0 || searchEntityQ.getPartyId() == null) {
            immdtParentEntity = new ChekkPartyEntity();
            immdtParentEntity.setUniqueId(getMainEntityUniqueId(chkGetResponse));
            immdtParentEntity.setRequestId(searchEntityQ.getRequestId());
            immdtParentEntity.setSearchEntityId(searchEntityQ.getSearchEntityId());
            immdtParentEntity.setCreationDate(chkGetResponse.getCreationDate());
        } else {
            immdtParentEntity = scheudlerDao.findByPartyId(searchEntityQ.getPartyId());
        }

        ModelConverter convertModelToPartyEnt = new ModelConverter(refData, level, immdtParentEntity);

        List<ChekkPartyEntity> partyList = new ArrayList<>();
        ChekkPartyEntity aParty;
        try {
            for (NodeDataArray nodeData : chkGetResponse.getNodeDataArray()) {
                aParty = convertModelToPartyEnt.convertToPartyEntity(nodeData);
                if (aParty != null) {
                    aParty.setRequestId(searchEntityQ.getRequestId());
                    aParty.setSearchEntityId(searchEntityQ.getSearchEntityId());
                    aParty.setPartyId(scheudlerDao.generateChkPartyID());
                    aParty.setCreationDate(chkGetResponse.getCreationDate());
                    partyList.add(aParty);
                }
            }
        } catch (Exception e) {
            /**
             * TODO update response data table with get response and search entity q table
             * with appropriate error code and GF
             */
            Log.error("ResponseToEntityConverter#populateChkPartyData: " + e.getMessage(), e);
            throw new ApplicationException();
        }
        return partyList;
    }

    public String getMainEntityUniqueId(ChekGetResponse chkGetResponse) {
        String uniqueId = null;
        List<NodeDataArray> nodeDataList = chkGetResponse.getNodeDataArray();
        NodeDataArray aNode = nodeDataList.stream().filter(this::isMainEntity).findAny().orElse(null);
        if (aNode != null) {
            uniqueId = aNode.getUniqueid();
        }
        return uniqueId;
    }

    public boolean isMainEntity(NodeDataArray nodeData) {
        boolean retVal = false;
        if (nodeData != null && nodeData.getDistanceFromRoot() == 0 && nodeData.getKey() == 1) {
            retVal = true;
        }
        return retVal;
    }

    public Map<String, String> populateRequestHeader(Map<String, String> requestHeader) {
        Map<String, String> requestHdrs = new HashMap<>();
        if (requestHeader != null) {
            requestHdrs.put(ProcessApiConstants.REQ_HDR_COUNTRY_CODE,
                    requestHeader.get(ProcessApiConstants.REQ_HDR_COUNTRY_CODE));
            requestHdrs.put(ProcessApiConstants.PROCESS_API_HEADER_INTERFACE_ID,
                    requestHeader.get(ProcessApiConstants.PROCESS_API_HEADER_INTERFACE_ID));
            requestHdrs.put(ProcessApiConstants.PROCESS_API_HEADER_TRANSACTION_ID,
                    requestHeader.get(ProcessApiConstants.PROCESS_API_HEADER_TRANSACTION_ID));
        }
        return requestHdrs;
    }

}
