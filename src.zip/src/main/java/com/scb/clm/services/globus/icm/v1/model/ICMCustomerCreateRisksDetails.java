package com.scb.clm.services.globus.icm.v1.model;

import java.sql.Timestamp;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ICMCustomerCreateRisksDetails 
{

	@JsonProperty("country-id")
	private String companyId;

	@JsonProperty("reference-id")
	private String  profileId;

	@JsonProperty("risk-code")
	private String riskCode;

	@JsonProperty("risk-start-date")
	private String riskStartDate;

	@JsonProperty("risk-expiry-date")
	private String riskExpiryDate;

	@JsonProperty("risk-reason-remarks")
	private String riskReasonRemarks;

	@JsonProperty("risk-type")
	private String riskType;

	@JsonProperty("review-period")
	private short reviewPeriod;
  
	@JsonProperty("status")
	private String status;

	@JsonProperty("status-at")
	private Timestamp statusAt;

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getProfileId() {
		return profileId;
	}

	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}

	public String getRiskCode() {
		return riskCode;
	}

	public void setRiskCode(String riskCode) {
		this.riskCode = riskCode;
	}

	public String getRiskStartDate() {
		return riskStartDate;
	}

	public void setRiskStartDate(String riskStartDate) {
		this.riskStartDate = riskStartDate;
	}

	public String getRiskExpiryDate() {
		return riskExpiryDate;
	}

	public void setRiskExpiryDate(String riskExpiryDate) {
		this.riskExpiryDate = riskExpiryDate;
	}

	public String getRiskReasonRemarks() {
		return riskReasonRemarks;
	}

	public void setRiskReasonRemarks(String riskReasonRemarks) {
		this.riskReasonRemarks = riskReasonRemarks;
	}

	public String getRiskType() {
		return riskType;
	}

	public void setRiskType(String riskType) {
		this.riskType = riskType;
	}

	public short getReviewPeriod() {
		return reviewPeriod;
	}

	public void setReviewPeriod(short reviewPeriod) {
		this.reviewPeriod = reviewPeriod;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getStatusAt() {
		return statusAt;
	}

	public void setStatusAt(Timestamp statusAt) {
		this.statusAt = statusAt;
	}


}
