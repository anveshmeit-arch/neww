package com.scb.clm.services.companysearch.chekk.v1.model;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class CongnitoEmpty {

    public String getEmptyBody() throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		ObjectNode obj = mapper.createObjectNode();
	
		String s = mapper.writeValueAsString(obj);
	    return s;
    }

}
