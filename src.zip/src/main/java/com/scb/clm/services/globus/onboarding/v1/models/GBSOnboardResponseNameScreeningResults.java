package com.scb.clm.services.globus.onboarding.v1.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class GBSOnboardResponseNameScreeningResults {
	
	public GBSOnboardResponseNameScreeningResults() {
		
	}
	
	public GBSOnboardResponseNameScreeningResults(String nameScreeningHit, String nameScreeningAlertId) {
		this.nameScreeningHit = nameScreeningHit;
		this.nameScreeningAlertId = nameScreeningAlertId;
	}

	@JsonProperty("nameScreeningHit")
    private String nameScreeningHit;

    @JsonProperty("nameScreeningAlertId")
    private String nameScreeningAlertId;

	public String getNameScreeningHit() {
		return nameScreeningHit;
	}

	public void setNameScreeningHit(String nameScreeningHit) {
		this.nameScreeningHit = nameScreeningHit;
	}

	public String getNameScreeningAlertId() {
		return nameScreeningAlertId;
	}

	public void setNameScreeningAlertId(String nameScreeningAlertId) {
		this.nameScreeningAlertId = nameScreeningAlertId;
	}
}
