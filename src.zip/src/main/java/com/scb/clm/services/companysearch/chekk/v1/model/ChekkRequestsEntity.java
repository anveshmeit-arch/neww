package com.scb.clm.services.companysearch.chekk.v1.model;

import java.sql.Timestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/*
 * 
 *  @author      
 *  @version     1.0
 *  @since       
 *  @use         
 */

@Entity
@Table(name = "CHK_REQUESTS")
@Getter
@Setter
public class ChekkRequestsEntity {

    @Id
    @Column(name="REQUEST_ID")
    private String requestId;

    @Column(name="COUNTRY_CODE")
    private String countryCode;

    @Column(name="INSTANCE_NAME")
    private String instanceName;

    @Column(name="ENTITY_NAME")
    private String entityName;

    @Column(name="APPLICATION_REFERENCE")
    private String applicationReference;

    @Column(name="REGISTRATION_ID")
    private String registrationId;

    @Column(name="CLIENT_ENTITY_TYPE")
    private String clientEntityType;

    @Column(name="COUNTRY_OF_REGISTRATION")
    private String countryOfRegistration;
    
    @Column(name="SEARCH_DEPTH")
    private Integer searchDepth;

    @Column(name="COUNTRY_ACCOUNT_OPEN")
    private String countryAccountOpen;

    @Column(name="CREATED_ON")
    private Timestamp createdOn;   

    @Column(name="UPDATED_ON")
    private Timestamp updatedOn;

    @Column(name="STATUS")
    private String status;
}
