package com.scb.clm.services.companysearch.chekk.v1.support;

import org.springframework.util.StringUtils;

import com.scb.clm.services.companysearch.chekk.v1.service.ChkTableReferences;

public class PartyMapperUtil {

    public static String updateRoleDescription(String multiRoles, final ChkTableReferences refData) {
        String roleKey;
        String assnType;

        if (multiRoles == null || multiRoles.isEmpty()) {
            return multiRoles;
        }

        String[] roles = multiRoles.split(",");
        StringBuilder roleSB = new StringBuilder();
        int i = 0;
        for (String aRole : roles) {
            roleKey = "I" + "-" + aRole;
            assnType = refData.getRoleDescription(roleKey.toUpperCase());
            if (i > 0) {
                roleSB.append(",");
            }
            roleSB.append(StringUtils.hasText(assnType) ? assnType : aRole);
            i++;
        }
        return roleSB.toString();
    }
}
