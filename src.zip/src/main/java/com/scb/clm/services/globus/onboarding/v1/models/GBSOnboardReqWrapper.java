package com.scb.clm.services.globus.onboarding.v1.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonInclude(JsonInclude.Include.NON_NULL)  
public class GBSOnboardReqWrapper {

    @JsonProperty("application")
    private GBSOnboardApplnWrapper gbs_Onboard_ApplnWrapper;

    @JsonProperty("customers")
    private GBSOnboardCustomerWrapper gbs_Onboard_CustomerWrapper;

    public GBSOnboardApplnWrapper getGbs_Onboard_ApplnWrapper() {
        return gbs_Onboard_ApplnWrapper;
    }

    public void setGbs_Onboard_ApplnWrapper(GBSOnboardApplnWrapper gbs_Onboard_ApplnWrapper) {
        this.gbs_Onboard_ApplnWrapper = gbs_Onboard_ApplnWrapper;
    }

    public GBSOnboardCustomerWrapper getGbs_Onboard_CustomerWrapper() {
        return gbs_Onboard_CustomerWrapper;
    }

    public void setGbs_Onboard_CustomerWrapper(GBSOnboardCustomerWrapper gbs_Onboard_CustomerWrapper) {
        this.gbs_Onboard_CustomerWrapper = gbs_Onboard_CustomerWrapper;
    }

}
