package com.scb.clm.services.companysearch.chekk.v1.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ChkSearchResponse {

	@JsonProperty("code")
	private String code;

	@JsonProperty("content")
	private List<Content> content;

	@JsonProperty("message")
	private String message;

	@JsonProperty("status")
	private String status;

	@JsonProperty("error_code")
	private String errorCode;

	@JsonProperty("error")
	private String error;

}