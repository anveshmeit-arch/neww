package com.scb.clm.services.globus.cddinitiate.v1.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CDDReqCreateInitiateEmployment {


    @JsonProperty("industry-code")
    private String industrycode;

    @JsonProperty("occupation-code")
    private String occupationcode;

    @JsonProperty("work-type")
    private String work_type;

    @JsonProperty("employee-banking-employer-code")
    private String employee_banking_employer_code;

    @JsonProperty("staff-employee-id")
    private String staff_employee_id;

    @JsonProperty("annual-declared-income")
    private String annual_declared_income;

    @JsonProperty("annual-declared-income-currency")
    private String annual_declared_income_currency;


    public String getIndustrycode() {
        return industrycode;
    }

    public void setIndustrycode(String industrycode) {
        this.industrycode = industrycode;
    }

    public String getOccupationcode() {
        return occupationcode;
    }

    public void setOccupationcode(String occupationcode) {
        this.occupationcode = occupationcode;
    }

    public String getWork_type() {
        return work_type;
    }

    public void setWork_type(String work_type) {
        this.work_type = work_type;
    }

    @Override
    public String toString() {
        return "CDDReq_Create_Iniate_Employment [industrycode=" + industrycode + ", occupationcode=" + occupationcode
                + ", work_type=" + work_type + "]";
    }

    public String getEmployee_banking_employer_code() {
        return employee_banking_employer_code;
    }

    public void setEmployee_banking_employer_code(String employee_banking_employer_code) {
        this.employee_banking_employer_code = employee_banking_employer_code;
    }

    public String getStaff_employee_id() {
        return staff_employee_id;
    }

    public void setStaff_employee_id(String staff_employee_id) {
        this.staff_employee_id = staff_employee_id;
    }

    public String getAnnual_declared_income() {
        return annual_declared_income;
    }

    public void setAnnual_declared_income(String annual_declared_income) {
        this.annual_declared_income = annual_declared_income;
    }

    public String getAnnual_declared_income_currency() {
        return annual_declared_income_currency;
    }

    public void setAnnual_declared_income_currency(String annual_declared_income_currency) {
        this.annual_declared_income_currency = annual_declared_income_currency;
    }

}
