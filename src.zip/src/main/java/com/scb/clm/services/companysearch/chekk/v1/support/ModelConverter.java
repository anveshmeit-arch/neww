package com.scb.clm.services.companysearch.chekk.v1.support;

import com.scb.clm.services.companysearch.chekk.v1.model.ChekkPartyEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.NodeDataArray;
import com.scb.clm.services.companysearch.chekk.v1.service.ChkTableReferences;

public class ModelConverter {

    private ChkTableReferences refData;

    private ChekkPartyEntity immediateParentEntity;
    private int level;

    /**
     * For level 0 intermediate parties, pass MainEntity's UniqueId
     * at<code>immediateParentEntity</code> param for all others retrieve and pass
     * parent entity parties information.
     * 
     * @param level
     * @param immediateParentEntity
     */
    public ModelConverter(ChkTableReferences refData, int level, ChekkPartyEntity immediateParentEntity) {
        this.refData = refData;
        this.level = level;
        this.immediateParentEntity = immediateParentEntity;
    }

    /**
     * Converts {@link NodeDataArray} object received from Chekk GET API call to
     * {@link ChekkPartyEntity} to store in table.
     * 
     * In addition does party type based derivation.
     * 
     * @param source
     * @return
     */
    public ChekkPartyEntity convertToPartyEntity(NodeDataArray source) {
        if (source == null || (getPartyType(source) == ChkPartyType.NONE)) {
            return null;
        }
        ChekkPartyEntity destination = new ChekkPartyEntity();
        destination.setDistanceFromRoot(source.getDistanceFromRoot() + "");
        destination.setFiAccountCurrency(source.getFiAccountCurrency());
        destination.setFiCompanyCurrency(source.getFiCompanyCurrency());
        destination.setFiRevenue(source.getFiRevenue());
        destination.setIdAddressEffectiveDate(source.getIdAddressEffectiveDate());
        destination.setIdAddressIsValid(source.getIdAddressIsValid());
        destination.setIdCity(source.getIdCity());
        destination.setIdCommencementDate(source.getIdCommencementDate());
        destination.setIdCompanyName(source.getIdCompanyName());
        destination.setIdCompanyNumber(source.getIdCompanyNumber());
        destination.setIdCountry(source.getIdCountry());
        destination.setIdExpiryDate(source.getIdExpiryDate());
        destination.setIdFormernames(source.getIdFormernames());
        destination.setIdFullAddress(source.getIdFullAddress());
        destination.setIdFullOperatingAddress(source.getIdFullOperatingAddress());
        destination.setIdFullOperatingAddressCity(source.getIdFullOperatingAddressCity());
        destination.setIdFullOperatingAddressCountry(source.getIdFullOperatingAddressCountry());
        destination.setIdFullOperatingAddressState(source.getIdFullOperatingAddressState());
        destination.setIdFullOperatingAddressZip(source.getIdFullOperatingAddressZip());
        destination.setIdHomeCompanyName(source.getIdHomeCompanyName());
        destination.setIdNaceCode(source.getIdNaceCode());
        destination.setIdNaicsCode(source.getIdNaicsCode());
        destination.setIdNameEffectiveDate(source.getIdNameEffectiveDate());
        destination.setIdNatureOfBusiness(source.getIdNatureOfBusiness());
        destination.setIdPrimarySsicLabel(source.getIdPrimarySsicLabel());
        destination.setIdPrimarySsicCode(source.getIdPrimarySsicCode());
        destination.setIdPrimarySsicOtherDescription(source.getIdPrimarySsicOtherDescription());
        destination.setIdRenewalCutOffDate(source.getIdRenewalCutOffDate());
        destination.setIdSecondarySsicLabel(source.getIdSecondarySsicLabel());
        destination.setIdSecondarySsicCode(source.getIdSecondarySsicCode());
        destination.setIdSecondarySsicOtherDescription(source.getIdSecondarySsicOtherDescription());
        destination.setIdState(source.getIdState());
        destination.setIdStatus(source.getIdStatus());
        destination.setIdStatusEffectiveDate(source.getIdStatusEffectiveDate());
        destination.setIdZip(source.getIdZip());
        destination.setIndAdress(source.getIndAdress());
        destination.setIndAttorneyPowers(source.getIndAttorneyPowers());
        destination.setIndBiography(source.getIndBiography());
        destination.setIndControllingShareholder(source.getIndControllingShareholder());
        destination.setIndIndividualNumber(source.getIndIndividualNumber());
        destination.setIndIsUbo(source.getIndIsUbo());
        destination.setIndName(source.getIndName());
        destination.setIndRole(source.getIndRole());
        destination.setIndSharesAmount(source.getIndSharesAmount());
        destination.setIndSharesCurrency(source.getIndSharesCurrency());
        destination.setIndSharesType(source.getIndSharesType());
        destination.setIndSignatory(source.getIndSignatory());
        destination.setIndStatus(source.getIndStatus());
        destination.setIntermediateIdCity(source.getIntermediateIdCity());
        destination.setIntermediateIdCompanyName(source.getIntermediateIdCompanyName());
        destination.setIntermediateIdCompanyNumber(source.getIntermediateIdCompanyNumber());
        destination.setIntermediateIdCountry(source.getIntermediateIdCountry());
        destination.setIntermediateIdFullAddress(source.getIntermediateIdFullAddress());
        destination.setIntermediateIdInactive(source.getIntermediateIdInactive());
        destination.setIntermediateIdRole(source.getIntermediateIdRole());
        destination.setIntermediateIdState(source.getIntermediateIdState());
        destination.setIntermediateIdZip(source.getIntermediateIdZip());
        destination.setIntermediateShCurrency(source.getIntermediateShCurrency());
        destination.setIntermediateShSharesAmount(source.getIntermediateShSharesAmount());
        destination.setIntermediateShType(source.getIntermediateShType());
        destination.setKey(source.getKey() + "");
        destination.setLeNationalLegalForm(source.getLeNationalLegalForm());
        destination.setLeRegistrationDate(source.getLeRegistrationDate());
        destination.setOrshSharesNumberOther(source.getOrshSharesNumberOther());
        destination.setOrshSharesNumberUsad(source.getOrshSharesNumberUsad());
        destination.setOrshIssuedShareCapitalSgpd(source.getOrshIssuedShareCapitalSgpd());
        destination.setOrshIssuedShareCapitalOther(source.getOrshIssuedShareCapitalOther());
        destination.setOrshIssuedShareCapitalUsad(source.getOrshIssuedShareCapitalUsad());
        destination.setOrshPaidUpShareCapitalUsad(source.getOrshPaidUpShareCapitalUsad());
        destination.setOrshPaidUpShareCapitalSgpd(source.getOrshPaidUpShareCapitalSgpd());
        destination.setOrshPaidUpShareCapitalOther(source.getOrshPaidUpShareCapitalOther());
        destination.setOtshIssuedShareCapitalOther(source.getOtshIssuedShareCapitalOther());
        destination.setOtshIssuedShareCapitalSgpd(source.getOtshIssuedShareCapitalSgpd());
        destination.setOtshIssuedShareCapitalUsad(source.getOtshIssuedShareCapitalUsad());
        destination.setOtshPaidUpShareCapitalOther(source.getOtshPaidUpShareCapitalOther());
        destination.setOtshPaidUpShareCapitalSgpd(source.getOtshPaidUpShareCapitalSgpd());
        destination.setOtshPaidUpShareCapitalUsad(source.getOtshPaidUpShareCapitalUsad());
        destination.setOtshSharesNumberOther(source.getOtshSharesNumberOther());
        destination.setOtshSharesNumberSgdp(source.getOtshSharesNumberSgdp());
        destination.setOtshSharesNumberUsad(source.getOtshSharesNumberUsad());
        destination.setPersonalAddressCity(source.getPersonalAddressCity());
        destination.setPersonalAddressCountry(source.getPersonalAddressCountry());
        destination.setPersonalSgpId(source.getPersonalSgpId());
        destination.setPersonalSgpIdType(source.getPersonalSgpIdType());
        destination.setPersonalZipCode(source.getPersonalZipCode());
        destination.setPrshIssuedShareCapitalOther(source.getPrshIssuedShareCapitalOther());
        destination.setPrshIssuedShareCapitalSgpd(source.getPrshIssuedShareCapitalSgpd());
        destination.setPrshIssuedShareCapitalUsad(source.getPrshIssuedShareCapitalUsad());
        destination.setPrshPaidUpShareCapitalOther(source.getPrshPaidUpShareCapitalOther());
        destination.setPrshPaidUpShareCapitalSgpd(source.getPrshPaidUpShareCapitalSgpd());
        destination.setPrshPaidUpShareCapitalUsad(source.getPrshPaidUpShareCapitalUsad());
        destination.setPrshSharesNumberOther(source.getPrshSharesNumberOther());
        destination.setPrshSharesNumberSgdp(source.getPrshSharesNumberSgdp());
        destination.setPrshSharesNumberUsad(source.getPrshSharesNumberUsad());
        destination.setShTotalPercentage(source.getShTotalPercentage());
        destination.setTrshIssuedShareCapitalOther(source.getTrshIssuedShareCapitalOther());
        destination.setTrshIssuedShareCapitalSgpd(source.getTrshIssuedShareCapitalSgpd());
        destination.setTrshIssuedShareCapitalUsad(source.getTrshIssuedShareCapitalUsad());
        destination.setTrshPaidUpShareCapitalOther(source.getTrshPaidUpShareCapitalOther());
        destination.setTrshPaidUpShareCapitalSgpd(source.getTrshPaidUpShareCapitalSgpd());
        destination.setTrshPaidUpShareCapitalUsad(source.getTrshPaidUpShareCapitalUsad());
        destination.setTrshSharesNumberOther(source.getTrshSharesNumberOther());
        destination.setTrshSharesNumberSgdp(source.getTrshSharesNumberSgdp());
        destination.setTrshSharesNumberUsad(source.getTrshSharesNumberUsad());
        destination.setUniqueId(source.getUniqueid());
        /**
         * set derieved or calculated values here
         */

        destination.setIdCountry(refData.getCountryCodeIn2Char(source.getIdCountry()));
        destination.setIntermediateIdCountry(refData.getCountryCodeIn2Char(source.getIntermediateIdCountry()));
        destination.setPersonalAddressCountry(refData.getCountryCodeIn2Char(source.getPersonalAddressCountry()));
        destination.setIdFullOperatingAddressCountry(
                refData.getCountryCodeIn2Char(source.getIdFullOperatingAddressCountry()));
        destination.setPartyType(source.getType());

        destination.setParentPercentage(calculatePercentage(getParentPercentage(), source.getShTotalPercentage()));
        ChkPartyType partyType = getPartyType(source);

        if (partyType == ChkPartyType.MAIN_ENTITY) {
            destination.setIsMainEntity("Yes");
            destination.setAssociatedToId(source.getUniqueid());
        } else if (partyType == ChkPartyType.COMPANY) {
            destination.setAssociatedToId(immediateParentEntity.getUniqueId());
        } else if (partyType == ChkPartyType.INDIVIDUAL) {
            destination.setAssociatedToId(immediateParentEntity.getUniqueId());
        }

        return destination;
    }

    private String getParentPercentage() {
        String percentage = "0";
        if (immediateParentEntity != null) {
            String parentPecentage = immediateParentEntity.getParentPercentage();
            percentage = (parentPecentage == null || parentPecentage.isEmpty()) ? "0" : parentPecentage;
        }
        return percentage;
    }

    private String calculatePercentage(String parentPercentage, String shareHoldingPercentage) {
        Float calculatedPercentage = convertToNumber(shareHoldingPercentage);
        if (level > 0) {
            Float parentPercentValue = convertToNumber(parentPercentage);
            Float shareHoldPercentageFlt = (shareHoldingPercentage == null || shareHoldingPercentage.isEmpty())
                    ? Float.valueOf(0)
                    : Float.valueOf(shareHoldingPercentage);
            try {
                calculatedPercentage = (shareHoldPercentageFlt * parentPercentValue) / 100;
            } catch (Exception e) {
                Log.error("ModelConverter#calculatePercentage: " + e.getMessage(), e);
            }
        }
        return calculatedPercentage + "";
    }

    private Float convertToNumber(String percentage) {
        Float retValue = 0f;
        if (percentage != null) {
            try {
                retValue = Float.valueOf(percentage);
            } catch (Exception e) {
                Log.error("ModelConverter#convertToNumber: Exception" + e.getMessage(), e);
            }
        }
        return retValue;
    }

    public ChkPartyType getPartyType(NodeDataArray nodeData) {
        ChkPartyType partyType = null;
        if (nodeData != null) {
            if (nodeData.getDistanceFromRoot() == 0 && nodeData.getKey() == 1 && level == 0) {
                partyType = ChkPartyType.MAIN_ENTITY;
            } else if (nodeData.getDistanceFromRoot().intValue() == 1 && nodeData.getKey().intValue() > 1
                    && "Company".equalsIgnoreCase(nodeData.getType())) {
                partyType = ChkPartyType.COMPANY;
            } else if (nodeData.getDistanceFromRoot() == 1 && nodeData.getKey() > 1
                    && "Individual".equalsIgnoreCase(nodeData.getType())) {
                partyType = ChkPartyType.INDIVIDUAL;
            } else {
                partyType = ChkPartyType.NONE;
            }
        }

        return partyType;
    }

}
