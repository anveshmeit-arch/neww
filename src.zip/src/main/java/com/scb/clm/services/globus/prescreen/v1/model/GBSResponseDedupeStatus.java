package com.scb.clm.services.globus.prescreen.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSResponseDedupeStatus {

    @JsonProperty("dedupStatus")
    private String dedupeStatus;

    @JsonProperty("remarks")
    private String remarks;

    public String getDedupeStatus() {
        return dedupeStatus;
    }

    public void setDedupeStatus(String dedupeStatus) {
        this.dedupeStatus = dedupeStatus;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

}
