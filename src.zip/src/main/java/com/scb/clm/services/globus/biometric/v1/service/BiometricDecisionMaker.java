package com.scb.clm.services.globus.biometric.v1.service;

import java.util.List;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.codesetup.NodesEntity;
import com.scb.clm.common.model.transactions.NodeStatus;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.core.service.DecisionMakerInterface;
import com.scb.clm.services.globus.biometric.v1.support.BiometricConstants;

public class BiometricDecisionMaker implements DecisionMakerInterface {


	@Override
	public void isGoodToProceed(TravellingObject travelObj, NodesEntity nodesEntity, List<NodeServicesEntity> service,
			NodeStatus nodeStatus) {
		// TODO Auto-generated method stub
		LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "method_name", LogType.APPLICATION.name());
		try
		{
			log.println("BIOMETRIC SERVICE");
			for(NodeServicesEntity services :  service) 
			{
				ServiceStatus stat = travelObj.getServiceStatus(services.getId());
				if(!stat.getStatus().equals(BaseConstants.SERVICE_SUCCESS)) 
				{
					log.println("Biometric Decision Maker Service Failed For "+stat.printKey());
					nodeStatus.setProcessToNextNode(false);
				}
			}
			log.println("Biometric Decision Maker - Service Success Status ["+((nodeStatus.isProcessToNextNode())?"Success":"Failure")+"]");
		}
		catch(Exception e)
		{
			log.printErrorMessage(e);
		}
		finally
		{
			//N.A
		}
	}
	@Override
	public void buildResponse(TravellingObject travelObj, NodesEntity nodesEntity, List<NodeServicesEntity> service,
			boolean isSuccess) throws ProcessException {
		// TODO Auto-generated method stub
		LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "buildResponse", LogType.APPLICATION.name());
		try
		{
			log.println("Building Response Data ["+isSuccess+"]");
			if(travelObj.getFlowIdentifier().equalsIgnoreCase(BiometricConstants.ONBOARD_FLOW)) 
			{
				ServiceStatus serviceStatus = travelObj.getServiceStatus().get(BaseConstants.ONBOARD_CREATEICM_SRV);
				if(serviceStatus != null && serviceStatus.getResponsePayload() != null) 
				{
					travelObj.setResponseData(serviceStatus.getResponsePayload());
				}
			}
			else
			{
				log.println("Building Response Data");
			}
		}
		catch(Exception e)
		{
			log.printErrorMessage(e);
		}
		finally
		{
			//N.A
		}
	}
}
