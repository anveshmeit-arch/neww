package com.scb.clm.services.globus.pdpa.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ICMErrorDetails {

	@JsonProperty("error-code")
	private String errorCode;
	
	@JsonProperty("error-description")
	private String errorDescription;
	
	public ICMErrorDetails () {	    
	}

	public ICMErrorDetails(String errorCode,String errorDescription) {
	    this.errorCode           = errorCode;
        this.errorDescription    = errorDescription;
	}
	
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorDescription() {
		return errorDescription;
	}
	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}
}
