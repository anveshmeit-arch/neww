package com.scb.clm.services.companysearch.chekk.v1.support;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import com.scb.clm.common.config.CountryConfig;
import com.scb.clm.common.db.support.CryptoDecrypter;

import jakarta.annotation.PostConstruct;
import lombok.Getter;
import lombok.Setter;

@ConfigurationProperties(prefix = "chk")
@Configuration
//@PropertySource("classpath:application.properties")
@Getter
@Setter

public class ChkConfigProperties {

	@Autowired
	private CountryConfig countryConfig;

	private String loginUrl;
	private String loginUsername;
	private String loginPassword;
	private String searchCompanyUrl;
	private String createCustomerfileUrl;
	private String getCustomerfileUrl;
	private Integer retryCount;
	private Integer retryDelay;
	private String accountToken;
	private String baseUrl;
	private String cognitoTokenUrl;
	private String proxyHost;
	private int proxyPort;
	private String enableProxy;
	private String saveFinalResponse;
	private String saveLevel1Response;
	private int intervalBetweenApiCallsInSecs;
	private String maxThresholdPercentage;
	private String tokenRefreshScheduler;
	private int tokenRefreshIntervalInMts;
	private String scheduler1CronExpression;
	private String scheduler2CronExpression;
	private String scheduler3CronExpression;

	private String[] paramCodes = { URL_LOGIN, LOGIN_USERNAME, LOGIN_PD, URL_SEARCH_COMPANY, URL_CREATE_CUSTOMER_FILE,
			URL_GET_CUSTOMER_FILE, RETRY_COUNT, RETRY_DELAY, ACCOUNT_TOKEN, BASE_URL, URL_COGNITO_TOKEN, PROXY_HOST,
			PROXY_PORT, ENABLE_PROXY, SAVE_FINAL_RESPONSE, SAVE_LEVEL1_RESPONSE, INTERVAL_BETWEEN_API_CALLS_IN_SECS,
			MAX_THRESHOLD_PERCENTAGE, TOKEN_REFRESH_SCHEDULER, TOKEN_REFRESH_INTERVAL_IN_MTS,
			SCHEDULER1_CRON_EXPRESSION, SCHEDULER2_CRON_EXPRESSION, SCHEDULER3_CRON_EXPRESSION };

	private static final String URL_LOGIN = "URL_LOGIN";
	private static final String LOGIN_USERNAME = "LOGIN_USERNAME";
	private static final String LOGIN_PD = "LOGIN_PD";
	private static final String URL_SEARCH_COMPANY = "URL_SEARCH_COMPANY";
	private static final String URL_CREATE_CUSTOMER_FILE = "URL_CREATE_CUSTOMER_FILE";
	private static final String URL_GET_CUSTOMER_FILE = "URL_GET_CUSTOMER_FILE";
	private static final String RETRY_COUNT = "RETRY_COUNT";
	private static final String RETRY_DELAY = "RETRY_DELAY";
	private static final String ACCOUNT_TOKEN = "ACCOUNT_TOKEN";
	private static final String BASE_URL = "BASE_URL";
	private static final String URL_COGNITO_TOKEN = "URL_COGNITO_TOKEN";
	private static final String PROXY_HOST = "PROXY_HOST";
	private static final String PROXY_PORT = "PROXY_PORT";
	private static final String ENABLE_PROXY = "ENABLE_PROXY";
	private static final String SAVE_FINAL_RESPONSE = "SAVE_FINAL_RESPONSE";
	private static final String SAVE_LEVEL1_RESPONSE = "SAVE_LEVEL1_RESPONSE";
	private static final String INTERVAL_BETWEEN_API_CALLS_IN_SECS = "INTERVAL_BETWEEN_API_CALLS_IN_SECS";
	private static final String MAX_THRESHOLD_PERCENTAGE = "MAX_THRESHOLD_PERCENTAGE";
	private static final String TOKEN_REFRESH_SCHEDULER = "TOKEN_REFRESH_SCHEDULER";
	private static final String TOKEN_REFRESH_INTERVAL_IN_MTS = "TOKEN_REFRESH_INTERVAL_IN_MTS";
	private static final String SCHEDULER1_CRON_EXPRESSION = "SCHEDULER1_CRON_EXPRESSION";
	private static final String SCHEDULER2_CRON_EXPRESSION = "SCHEDULER2_CRON_EXPRESSION";
	private static final String SCHEDULER3_CRON_EXPRESSION = "SCHEDULER3_CRON_EXPRESSION";
	private static final String APPID_LOGIN_API = "APPID_LOGIN_API";
	private static final String APPID_COGNITO_API = "APPID_COGNITO_API";
	private static final String COMPANYID_CHEKK = "COMPANYID_CHEKK";
	

	@PostConstruct
	private void iniitialise() {
		for (String code : paramCodes) {
			setParamValue(code);
		}
		initApiCredentials();
	}

	private void initApiCredentials() {
		String companyId = getParamValue(COMPANYID_CHEKK);
		String loginAppId = getParamValue(APPID_LOGIN_API);
		String cognitoAppId = getParamValue(APPID_COGNITO_API);

		String loginPd = getDecryptedPassword(loginAppId, companyId);
		String cognitoPd = getDecryptedPassword(cognitoAppId, companyId);
		setLoginPassword(loginPd);
		setAccountToken(cognitoPd);
	}

	private String getDecryptedPassword(String appId, String companyId) {
		String decryptPassword = "";
		try {
			decryptPassword = CryptoDecrypter.getInstance().decryptDBPwd(appId, companyId);
			setLoginPassword(decryptPassword);
		} catch (Exception e) {
			Log.error("Error in generating password for [appId,companyId] = ["+appId+","+companyId+"]", e);
		}
		return decryptPassword;
	}

	public String getParamValue(String paramCode) {
		return CountryConfig.getCountryParam("SG", "COMPANY_SEARCH", paramCode, paramCode, false);
	}

	
	
	private void setParamValue(String paramCode) {
		if (!replacePropValueWithDB(paramCode)) {
			return;
		}

		String paramValue = getParamValue(paramCode);

		switch (paramCode) {
		case URL_LOGIN:
			setLoginUrl(paramValue);
			break;
		case LOGIN_USERNAME:
			setLoginUsername(paramValue);
			break;
		case LOGIN_PD:
			setLoginPassword(paramValue);
			break;
		case URL_SEARCH_COMPANY:
			setSearchCompanyUrl(paramValue);
			break;
		case URL_CREATE_CUSTOMER_FILE:
			setCreateCustomerfileUrl(paramValue);
			break;
		case URL_GET_CUSTOMER_FILE:
			setGetCustomerfileUrl(paramValue);
			break;
		case RETRY_COUNT:
			setRetryCount(DataUtility.getAsNumber(paramValue));
			break;
		case RETRY_DELAY:
			setRetryDelay(DataUtility.getAsNumber(paramValue));
			break;
		case ACCOUNT_TOKEN:
			setAccountToken(paramValue);
			break;
		case BASE_URL:
			setBaseUrl(paramValue);
			break;
		case URL_COGNITO_TOKEN:
			setCognitoTokenUrl(paramValue);
			break;
		case PROXY_HOST:
			setProxyHost(paramValue);
			break;
        case PROXY_PORT:
            setProxyPort(DataUtility.getAsNumber(paramValue));
            break;

		case ENABLE_PROXY:
			setEnableProxy(paramValue);
			break;
		case SAVE_FINAL_RESPONSE:
			setSaveFinalResponse(paramValue);
			break;
		case SAVE_LEVEL1_RESPONSE:
			setSaveLevel1Response(paramValue);
			break;
		case INTERVAL_BETWEEN_API_CALLS_IN_SECS:
			setIntervalBetweenApiCallsInSecs(DataUtility.getAsNumber(paramValue));
			break;
		case MAX_THRESHOLD_PERCENTAGE:
			setMaxThresholdPercentage(paramValue);
			break;
		case TOKEN_REFRESH_SCHEDULER:
		    setTokenRefreshScheduler(paramValue);
			break;
		case TOKEN_REFRESH_INTERVAL_IN_MTS:
			setTokenRefreshIntervalInMts(DataUtility.getAsNumber(paramValue));
			break;
		case SCHEDULER1_CRON_EXPRESSION:
			setScheduler1CronExpression(paramValue);
			break;
		case SCHEDULER2_CRON_EXPRESSION:
			setScheduler2CronExpression(paramValue);
			break;
		case SCHEDULER3_CRON_EXPRESSION:
			setScheduler3CronExpression(paramValue);
			break;
		default:
			break;
		}
	}

	private boolean replacePropValueWithDB(String paramCode) {
		boolean retValue = true;
		if (!DataUtility.isDevProfile())
			return retValue;

		String propValue = getApplicationPropertiesValue(paramCode);

		if (propValue != null && !propValue.isEmpty()) {
			retValue = false;
		}
		return retValue;
	}

	private String getApplicationPropertiesValue(String paramCode) {
		String propValue = "";
		switch (paramCode) {
		case URL_LOGIN:
			propValue = getLoginUrl();
			break;
		case LOGIN_USERNAME:
			propValue = getLoginUsername();
			break;
		case LOGIN_PD:
			propValue = getLoginPassword();
			break;
		case URL_SEARCH_COMPANY:
			propValue = getSearchCompanyUrl();
			break;
		case URL_CREATE_CUSTOMER_FILE:
			propValue = getCreateCustomerfileUrl();
			break;
		case URL_GET_CUSTOMER_FILE:
			propValue = getGetCustomerfileUrl();
			break;
		case RETRY_COUNT:
			propValue = getRetryCount() + "";
			break;
		case RETRY_DELAY:
			propValue = getRetryDelay() + "";
			break;
		case ACCOUNT_TOKEN:
			propValue = getAccountToken();
			break;
		case BASE_URL:
			propValue = getBaseUrl();
			break;
		case URL_COGNITO_TOKEN:
			propValue = getCognitoTokenUrl();
			break;
		case PROXY_HOST:
			propValue = getProxyHost();
			break;
        case PROXY_PORT:
            propValue = getProxyPort()+"";
            break;
		case ENABLE_PROXY:
			propValue = getEnableProxy();
			break;
		case SAVE_FINAL_RESPONSE:
			propValue = getSaveFinalResponse();
			break;
		case SAVE_LEVEL1_RESPONSE:
			propValue = getSaveLevel1Response();
			break;
		case INTERVAL_BETWEEN_API_CALLS_IN_SECS:
			propValue = getIntervalBetweenApiCallsInSecs() + "";
			break;
		case MAX_THRESHOLD_PERCENTAGE:
			propValue = getMaxThresholdPercentage();
			break;
		case TOKEN_REFRESH_SCHEDULER:
			propValue = getTokenRefreshScheduler();
			break;
		case TOKEN_REFRESH_INTERVAL_IN_MTS:
			propValue = getTokenRefreshIntervalInMts() + "";
			break;
		case SCHEDULER1_CRON_EXPRESSION:
			propValue = getScheduler1CronExpression();
			break;
		case SCHEDULER2_CRON_EXPRESSION:
			propValue = getScheduler2CronExpression();
			break;
		case SCHEDULER3_CRON_EXPRESSION:
			propValue = getScheduler3CronExpression();
			break;
		default:
			break;
		}
		return propValue;
	}
}
