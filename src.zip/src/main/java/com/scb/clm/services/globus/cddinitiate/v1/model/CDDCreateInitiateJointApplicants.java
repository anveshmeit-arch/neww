package com.scb.clm.services.globus.cddinitiate.v1.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)  
public class CDDCreateInitiateJointApplicants 
{

    @JsonProperty("related-applicant-reference-key")
    private String related_applicant_reference_key;

    @JsonProperty("profile-role")
    private String profile_role;

    public String getRelated_applicant_reference_key() {
        return related_applicant_reference_key;
    }

    public void setRelated_applicant_reference_key(String related_applicant_reference_key) {
        this.related_applicant_reference_key = related_applicant_reference_key;
    }

    public String getProfile_role() {
        return profile_role;
    }

    public void setProfile_role(String profile_role) {
        this.profile_role = profile_role;
    }
}
