package com.scb.clm.services.companysearch.chekk.v1.service;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.scb.clm.common.util.DateTimeUtility;
import com.scb.clm.common.util.StringUtility;
import com.scb.clm.services.companysearch.chekk.v1.exception.ApplicationException;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkPartyEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkRequestsEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkResponseDataEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkSearchEntityQEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ProcessApiRequestsEntity;
import com.scb.clm.services.companysearch.chekk.v1.repository.ChekkPartyRepository;
import com.scb.clm.services.companysearch.chekk.v1.repository.ChekkRequestsRepository;
import com.scb.clm.services.companysearch.chekk.v1.repository.ChekkResponseDataRepository;
import com.scb.clm.services.companysearch.chekk.v1.repository.ChekkSearchEntityQueueRepository;
import com.scb.clm.services.companysearch.chekk.v1.repository.ProcessApiRequestsRepository;
import com.scb.clm.services.companysearch.chekk.v1.support.DBUtility;
import com.scb.clm.services.companysearch.chekk.v1.support.Log;
import com.scb.clm.services.companysearch.chekk.v1.support.ProcessApiConstants;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;

/**
 * Defines all repository objects used at Scheduler services
 */
@Service
public class ChkSchedulerDao {
	@Autowired
	private ChekkRequestsRepository chekkRequestsRepository;

	@Autowired
	private ChekkResponseDataRepository chekkResponseDataRepository;

	@Autowired
	private ChekkSearchEntityQueueRepository chekkSearchEntityRepository;

	@Autowired
	private ChekkPartyRepository chekkPartyRepository;

	@Autowired
	ProcessApiRequestsRepository processApiRequestsRepository;

	@Autowired
	private EntityManager entityManager;

	/**
	 * Used to store Search and Create API call results when
	 * {@linkplain ChekkSearchEntityQEntity} object is not available
	 * 
	 * @param srchEntQUpdateStatus
	 * @param searchEntityQ
	 * @param responseData
	 * @return
	 */
	@Transactional
	public void saveApiResults(String requestId, String searchId, String searchQStatus,
			ChekkResponseDataEntity responseData) {
		try {
			chekkSearchEntityRepository.updateStatusByIds(searchQStatus, searchId, requestId);
			if (responseData != null) {
				saveChkResData(responseData);
			}
		} catch (Exception e) {
		    Log.error("ChkSchedulerDao#saveApiResults: Exceptiion in saving "+e.getMessage(), e);
			throw new ApplicationException("DB Error", "CS-DBTXN-ERR", "Error in saving api results to db");
		}
	}

	/**
	 * Used to store Search and Create API call results
	 * 
	 * @param srchEntQUpdateStatus
	 * @param searchEntityQ
	 * @param responseData
	 * @return
	 */
	@Transactional
	public int saveApiResults(String srchEntQUpdateStatus, ChekkSearchEntityQEntity searchEntityQ,
			ChekkResponseDataEntity responseData) {
		try {
			chekkSearchEntityRepository.updateStatusByIds(srchEntQUpdateStatus, searchEntityQ.getSearchEntityId(),
					searchEntityQ.getRequestId());
			if (responseData != null) {
				saveChkResData(responseData);
			}
		} catch (Exception e) {
			throw new ApplicationException("DB Error", "CS-DBTXN-ERR", "Error in saving api results to db");
		}
		return 1;
	}

	/**
	 * Used to store GET API call results
	 * 
	 * @param srchEntQUpdateStatus
	 * @param searchEntityQ
	 * @param responseData
	 * @param partyList
	 * @return
	 */
	@Transactional
	public int saveApiResults(String srchEntQUpdateStatus, ChekkSearchEntityQEntity searchEntityQ,
			ChekkResponseDataEntity responseData, List<ChekkPartyEntity> partyList) {

		/**
		 * TODO update error code for failure scenarios
		 */
		try {
			chekkSearchEntityRepository.updateStatusByIds(srchEntQUpdateStatus, searchEntityQ.getSearchEntityId(),
					searchEntityQ.getRequestId());
			if (responseData != null) {
				chekkResponseDataRepository.save(responseData);
			}
			if (partyList != null && !partyList.isEmpty()) {
				chekkPartyRepository.saveAll(partyList);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new ApplicationException("DB Error", "CS-DBTXN-ERR", "Error in saving api results to db");
		}
		return 1;
	}

	public List<ChekkSearchEntityQEntity> readPendingSearchCreateRequests(String instanceName) {
		return chekkSearchEntityRepository.getPendingGetCreateRequests(instanceName);
	}

	public List<ChekkSearchEntityQEntity> readPendingGetRequests(String instanceName) {
		return chekkSearchEntityRepository.getSearchEntityQueue(instanceName, ProcessApiConstants.STATUS_GET_PENDING);
	}

	public List<ChekkSearchEntityQEntity> readUnwrapPendingRequests(String instanceName){
		return chekkSearchEntityRepository
		.getSearchEntityQueueDetails(instanceName, ProcessApiConstants.STATUS_UNWRAP_PENDING);
	}
	
	public ChekkResponseDataEntity getSearchApiResponse(String requestId, String searchId) {
		return chekkResponseDataRepository.findByRequestIdAndSearchEntityIdAndResTypeAndStatus(requestId, searchId, "S",
				"S");
	}

	public ChekkResponseDataEntity getGetApiResponse(String requestId, String searchId) {
		return chekkResponseDataRepository.findByRequestIdAndSearchEntityIdAndResTypeAndStatus(requestId, searchId, "C",
				"S");
	}

	public ChekkPartyEntity findByPartyId(String partyId) {
		return chekkPartyRepository.findByPartyId(partyId);
	}

	public void saveChkResData(ChekkResponseDataEntity chekkResponseDataEntity) {
		try {
			chekkResponseDataEntity.setCreatedOn(DateTimeUtility.getCurrentTime());
			chekkResponseDataRepository.save(chekkResponseDataEntity);
		} catch (Exception e) {
			Log.error("ChkSchedulerDao#saveChkResData: Exception occured while saving data:"+e.getMessage(),e);
		}
	}

	public int savePartyList(List<ChekkPartyEntity> partyList) {
		if (partyList != null && !partyList.isEmpty()) {
			chekkPartyRepository.saveAll(partyList);
		}
		return 1;
	}

	public List<ChekkSearchEntityQEntity> getFailedSearchEntityQRecords(String requestId) {
		List<String> failedStatus = Arrays.asList(ProcessApiConstants.STATUS_SEARCH_FAILED,
				ProcessApiConstants.STATUS_CREATE_FAILED, ProcessApiConstants.STATUS_GET_FAILED,
				ProcessApiConstants.STATUS_UNWRAP_FAILED, ProcessApiConstants.STATUS_PUBLISH_FAILED);
		List<ChekkSearchEntityQEntity> searchQErrorLst = chekkSearchEntityRepository
				.findByRequestIdAndStatusIn(requestId, failedStatus);
		return searchQErrorLst;
	}

	public List<ChekkRequestsEntity> readUCRequests(String instanceName) {
		return chekkRequestsRepository.findByStatusAndInstanceName(ProcessApiConstants.STATUS_UNWRAPPING_COMPLETED,
				instanceName);

	}

	public List<ChekkPartyEntity> getAllParties(String requestId) {
		return chekkPartyRepository.findByRequestId(requestId);
	}

	public ProcessApiRequestsEntity getRequestHeaders(String requestId) {
		return processApiRequestsRepository.findByRequestId(requestId);
	}

	public ChekkRequestsEntity getChkRequest(String requestId) {
		List<ChekkRequestsEntity> chkRequestEntities = chekkRequestsRepository.findByRequestId(requestId);
		if (chkRequestEntities != null && !chkRequestEntities.isEmpty()) {
			return chkRequestEntities.get(0);
		}
		return null;
	}

	public BigDecimal sumOfIndividualPercentage(String requestId) {
		Float calculatedPercentage = chekkPartyRepository.caliculateSumOfIndPercentage(requestId, "Individual");

		return (calculatedPercentage == null) ? new BigDecimal("0.0000")
				: new BigDecimal(Float.toString(calculatedPercentage), new MathContext(4, RoundingMode.HALF_EVEN));
	}


	@Transactional
	public void updateRequestAsCompleted(String requestId, List<ChekkSearchEntityQEntity> searchEntQForProcesing) {
		for (ChekkSearchEntityQEntity searchEntityQ : searchEntQForProcesing) {
			chekkSearchEntityRepository.updateStatusByIds(ProcessApiConstants.STATUS_PUBLISH_COMPLETED,
					searchEntityQ.getSearchEntityId(), searchEntityQ.getRequestId());
		}
		chekkRequestsRepository.updateStatusByIds(ProcessApiConstants.STATUS_UNWRAPPING_COMPLETED, requestId);
	}

	@Transactional
	public void updateRequestAsFailed(String requestId, List<ChekkSearchEntityQEntity> searchEntQForProcesing) {
		for (ChekkSearchEntityQEntity searchEntityQ : searchEntQForProcesing) {
			chekkSearchEntityRepository.updateStatusByIds(ProcessApiConstants.STATUS_UNWRAP_FAILED,
					searchEntityQ.getSearchEntityId(), searchEntityQ.getRequestId());
		}
		chekkRequestsRepository.updateStatusByIds(ProcessApiConstants.STATUS_UNWRAP_FAILED, requestId);
	}

	public void updateSearchEntityQStatus(String status, String searchId, String requestId) {
		chekkSearchEntityRepository.updateStatusByIds(ProcessApiConstants.STATUS_PUBLISH_COMPLETED, searchId,
				requestId);
	}

	public void updateChkRequestSatus(String requestId, String status) {
		chekkRequestsRepository.updateStatusByIds(status, requestId);

	}

	public List<ChekkPartyEntity> readEntityParties(String requestId, String searchId) {
		return chekkPartyRepository.findBySearchEntityIdAndRequestIdAndPartyType(searchId, requestId,
				ProcessApiConstants.COMPANY);

	}

	public String generateChkRespDataID() {
		return getSequenceId("chk_response_data_seq");
	}

	public String generateChkSearchEntityId() {
		return getSequenceId("CHK_SEARCH_ENTITY_QUEUE_SEQ");
	}

	public String generateChkPartyID() {
		return getSequenceId("CHK_PARTY_SEQ");
	}

	public String getSequenceId(String tableName) {
		StringBuilder query = new StringBuilder();
		query.append("SELECT NEXTVAL('");
		query.append(tableName);
		query.append("')");
		Query qry = null;
		qry = entityManager.createNativeQuery(query.toString());
		String sequenceId = StringUtility.padLeft(String.valueOf(qry.getResultList().get(0)), 8, "0");
		return sequenceId;
	}

	@Transactional
	public void addNextLevelParyAndUpdateParentEntity(List<ChekkSearchEntityQEntity> chekkSearchEntityQueue,String requestId,String parentSearchEntityId) {
		try {
			if(chekkSearchEntityQueue!=null && !chekkSearchEntityQueue.isEmpty()) {
				chekkSearchEntityRepository.saveAll(chekkSearchEntityQueue);
				chekkSearchEntityRepository.updateStatusByIds(ProcessApiConstants.STATUS_UNWRAPPING_COMPLETED,parentSearchEntityId,requestId);
			}
			
		} catch (Exception ex) {
			Log.error("ChkSchedulerDao#addNextLevelParyAndUpdateParentEntity: "+ex.getMessage());
		}
	}

}
