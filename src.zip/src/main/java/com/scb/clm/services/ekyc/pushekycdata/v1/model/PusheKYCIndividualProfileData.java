package com.scb.clm.services.ekyc.pushekycdata.v1.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PusheKYCIndividualProfileData {
	
	@JsonProperty("id")
	private String id;
	
	@JsonProperty("identityType")
	private String identityType;
	
	@JsonProperty("dateOfExpiry")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	private Date dateOfExpiry;
	
	@JsonProperty("dateOfIssuance")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	private Date dateOfIssuance;
	
	@JsonProperty("fullName")
	private String fullName;
	
	@JsonProperty("fatherOrSpouseName")
	private String fatherOrSpouseName;
	
	@JsonProperty("motherMaidenName")
	private String motherMaidenName;
	
	@JsonProperty("dateOfBirth")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	private Date dateOfBirth;
	
	@JsonProperty("placeOfBirth")
	private String placeOfBirth;
	
	@JsonProperty("profile")
	private String profile;
	
	@JsonProperty("nationality")
	private String nationality;
	
	@JsonProperty("mobileNumber")
	private String mobileNumber;
	
	@JsonProperty("addressCurrent")
	private String addressCurrent;
	
	@JsonProperty("cityOfResidence")
	private String cityOfResidence;
	
	@JsonProperty("countryOfResidence")
	private String countryOfResidence;
	
	@JsonProperty("occupation")
	private String occupation;
	
	@JsonProperty("nameOfEmployer")
	private String nameOfEmployer;
	
	@JsonProperty("sourceOfIncome")
	private String sourceOfIncome;
	
	@JsonProperty("expectedAnnualIncomeRange")
	private String expectedAnnualIncomeRange;
	

	@JsonProperty("purposeOfAccount")
	private String purposeOfAccount;
	
	@JsonProperty("fatca")
	private String fatca;
	
	@JsonProperty("PEPIdentifed")
	private String pEPIdentifed;

	@JsonProperty("nextOfKin")
	private String nextOfKin;
	
	@JsonProperty("IBAN")
	private String iBan;
	
	@JsonProperty("CRSDeclaration")
	private String cRSDeclaration;
	
	@JsonProperty("isDeceased")
	private String isDeceased;
	
	@JsonProperty("accountTitle")
	private String accountTitle;
	
	@JsonProperty("accountType")
	private String accountType;
	
	
	
	@JsonProperty("mandateHolder")
	private PusheKYCCustomerMandateHolder objMinorCustomerMandateHolder;



	public String getId() {
		return id;
	}



	public void setId(String id) {
		this.id = id;
	}



	public String getIdentityType() {
		return identityType;
	}



	public void setIdentityType(String identityType) {
		this.identityType = identityType;
	}



	public Date getDateOfExpiry() {
		return dateOfExpiry;
	}



	public void setDateOfExpiry(Date dateOfExpiry) {
		this.dateOfExpiry = dateOfExpiry;
	}



	public Date getDateOfIssuance() {
		return dateOfIssuance;
	}



	public void setDateOfIssuance(Date dateOfIssuance) {
		this.dateOfIssuance = dateOfIssuance;
	}



	public String getFullName() {
		return fullName;
	}



	public void setFullName(String fullName) {
		this.fullName = fullName;
	}



	public String getFatherOrSpouseName() {
		return fatherOrSpouseName;
	}



	public void setFatherOrSpouseName(String fatherOrSpouseName) {
		this.fatherOrSpouseName = fatherOrSpouseName;
	}



	public String getMotherMaidenName() {
		return motherMaidenName;
	}



	public void setMotherMaidenName(String motherMaidenName) {
		this.motherMaidenName = motherMaidenName;
	}



	public Date getDateOfBirth() {
		return dateOfBirth;
	}



	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}



	public String getPlaceOfBirth() {
		return placeOfBirth;
	}



	public void setPlaceOfBirth(String placeOfBirth) {
		this.placeOfBirth = placeOfBirth;
	}



	public String getProfile() {
		return profile;
	}



	public void setProfile(String profile) {
		this.profile = profile;
	}



	public String getNationality() {
		return nationality;
	}



	public void setNationality(String nationality) {
		this.nationality = nationality;
	}



	public String getMobileNumber() {
		return mobileNumber;
	}



	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}



	public String getAddressCurrent() {
		return addressCurrent;
	}



	public void setAddressCurrent(String addressCurrent) {
		this.addressCurrent = addressCurrent;
	}



	public String getCityOfResidence() {
		return cityOfResidence;
	}



	public void setCityOfResidence(String cityOfResidence) {
		this.cityOfResidence = cityOfResidence;
	}



	public String getCountryOfResidence() {
		return countryOfResidence;
	}



	public void setCountryOfResidence(String countryOfResidence) {
		this.countryOfResidence = countryOfResidence;
	}



	public String getOccupation() {
		return occupation;
	}



	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}



	public String getNameOfEmployer() {
		return nameOfEmployer;
	}



	public void setNameOfEmployer(String nameOfEmployer) {
		this.nameOfEmployer = nameOfEmployer;
	}



	public String getSourceOfIncome() {
		return sourceOfIncome;
	}



	public void setSourceOfIncome(String sourceOfIncome) {
		this.sourceOfIncome = sourceOfIncome;
	}



	public String getExpectedAnnualIncomeRange() {
		return expectedAnnualIncomeRange;
	}



	public void setExpectedAnnualIncomeRange(String expectedAnnualIncomeRange) {
		this.expectedAnnualIncomeRange = expectedAnnualIncomeRange;
	}



	public String getPurposeOfAccount() {
		return purposeOfAccount;
	}



	public void setPurposeOfAccount(String purposeOfAccount) {
		this.purposeOfAccount = purposeOfAccount;
	}



	public String getFatca() {
		return fatca;
	}



	public void setFatca(String fatca) {
		this.fatca = fatca;
	}



	public String getpEPIdentifed() {
		return pEPIdentifed;
	}



	public void setpEPIdentifed(String pEPIdentifed) {
		this.pEPIdentifed = pEPIdentifed;
	}



	public String getNextOfKin() {
		return nextOfKin;
	}



	public void setNextOfKin(String nextOfKin) {
		this.nextOfKin = nextOfKin;
	}



	public String getiBan() {
		return iBan;
	}



	public void setiBan(String iBan) {
		this.iBan = iBan;
	}



	public String getcRSDeclaration() {
		return cRSDeclaration;
	}



	public void setcRSDeclaration(String cRSDeclaration) {
		this.cRSDeclaration = cRSDeclaration;
	}



	public String getIsDeceased() {
		return isDeceased;
	}



	public void setIsDeceased(String isDeceased) {
		this.isDeceased = isDeceased;
	}



	public String getAccountTitle() {
		return accountTitle;
	}



	public void setAccountTitle(String accountTitle) {
		this.accountTitle = accountTitle;
	}



	public String getAccountType() {
		return accountType;
	}



	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}



	public PusheKYCCustomerMandateHolder getObjMinorCustomerMandateHolder() {
		return objMinorCustomerMandateHolder;
	}



	public void setObjMinorCustomerMandateHolder(PusheKYCCustomerMandateHolder objMinorCustomerMandateHolder) {
		this.objMinorCustomerMandateHolder = objMinorCustomerMandateHolder;
	}

}
