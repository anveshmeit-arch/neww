package com.scb.clm.services.companysearch.chekk.v1.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.relational.core.mapping.Table;
import org.springframework.stereotype.Repository;

import com.scb.clm.services.companysearch.chekk.v1.model.ChekSolaceConfigEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChkSolaceConfigEntityKey;
@Table
@Repository
public interface ChekSolaceConfigRepository extends JpaRepository<ChekSolaceConfigEntity, ChkSolaceConfigEntityKey>{

	public List<ChekSolaceConfigEntity> findAll();
}