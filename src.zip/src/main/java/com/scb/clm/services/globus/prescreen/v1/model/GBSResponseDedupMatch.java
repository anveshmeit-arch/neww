package com.scb.clm.services.globus.prescreen.v1.model;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSResponseDedupMatch
{

    @JsonProperty("profileId")
    String profileId;

    @JsonProperty("relationshipNumber")
    String relationshipNumber;

    @JsonProperty("firstName")
    String firstName;

    @JsonProperty("middleName")
    String middleName;

    @JsonProperty("lastName")
    String lastName;

    @JsonProperty("fullName")
    String fullName;

    @JsonProperty("matchCategory")
    String matchCategory;

    @JsonProperty("dateOfBirth")
    String dateOfBirth;

    @JsonIgnore
    String matchCategoryText;
  
    @JsonProperty("profileType")
    String profileType;
    
    @JsonProperty("profileStatus")
    String profileStatus;
    
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty("isDeepeningAllowed")
    String isDeepeningAllowed;

    @JsonProperty("digitalIdentity")
    ArrayList<GBSResponseDigitalIdentity> digitalidentity;

    @JsonProperty("contacts")
    ArrayList<GBSResponseContacts> contacts;
    
    @JsonProperty("documents")
    ArrayList<GBSResponseDocuments> documents;
    
    

	@JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty("cddReferenceKey")
    String cddReferenceKey;
  
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty("allowedForOnboarding")
    String allowedForOnboarding;
 
    public String getAllowedForOnboarding() {
        return allowedForOnboarding;
    }

    public void setAllowedForOnboarding(String allowedForOnboarding) {
        this.allowedForOnboarding = allowedForOnboarding;
    }

    public String getCddReferenceKey() {
        return cddReferenceKey;
    }

    public void setCddReferenceKey(String cddReferenceKey) {
        this.cddReferenceKey = cddReferenceKey;
    }

	public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getRelationshipNumber() {
        return relationshipNumber;
    }

    public void setRelationshipNumber(String relationshipNumber) {
        this.relationshipNumber = relationshipNumber;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getMatchCategory() {
        return matchCategory;
    }

    public void setMatchCategory(String matchCategory) {
        this.matchCategory = matchCategory;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }
    
    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getMatchCategoryText() {
        return matchCategoryText;
    }

    public void setMatchCategoryText(String matchCategoryText) {
        this.matchCategoryText = matchCategoryText;
    }

	public String getProfileType() {
        return profileType;
    }

    public void setProfileType(String profileType) {
        this.profileType = profileType;
    }

    public String getProfileStatus() {
        return profileStatus;
    }

    public void setProfileStatus(String profileStatus) {
        this.profileStatus = profileStatus;
    }

    public String getIsDeepeningAllowed() {
        return isDeepeningAllowed;
    }

    public void setIsDeepeningAllowed(String isDeepeningAllowed) {
        this.isDeepeningAllowed = isDeepeningAllowed;
    }

    public ArrayList<GBSResponseDigitalIdentity> getDigitalidentity() {
        return digitalidentity;
    }

    public void setDigitalidentity(ArrayList<GBSResponseDigitalIdentity> digitalidentity) {
        this.digitalidentity = digitalidentity;
    }

	public ArrayList<GBSResponseContacts> getContacts() {
		return contacts;
	}

	public void setContacts(ArrayList<GBSResponseContacts> contacts) {
		this.contacts = contacts;
	}

	public ArrayList<GBSResponseDocuments> getDocuments() {
		return documents;
	}

	public void setDocuments(ArrayList<GBSResponseDocuments> documents) {
		this.documents = documents;
	}

 }
