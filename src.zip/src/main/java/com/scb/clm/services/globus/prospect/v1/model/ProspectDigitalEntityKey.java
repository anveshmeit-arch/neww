package com.scb.clm.services.globus.prospect.v1.model;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

/*
 * 
 * @author       1378958
 * @version      1.0
 * @since           
 * @use          
 */
@Embeddable
public class ProspectDigitalEntityKey implements Serializable,Cloneable
{
    private static final long serialVersionUID = 1103847698360379355L;

    @Column(name = "COUNTRY_CODE", nullable = false ,insertable=false, updatable=false)
    private String countryCode;

    @Column(name = "PROSPECT_ID", nullable = false ,insertable=false, updatable=false)
    private String prospectID;

    @Column(name = "DEVICE_TYPE", nullable = false ,insertable=false, updatable=false)
    private String deviceType;


    public ProspectDigitalEntityKey() {

    }

    public ProspectDigitalEntityKey (String countryCode,String prospectID,String deviceType) {
        this.countryCode                = countryCode;
        this.prospectID = prospectID;
        this.deviceType                 = deviceType;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getProspectID() {
        return prospectID;
    }

    public void setProspectID(String prospectID) {
        this.prospectID = prospectID;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    @Override
    public int hashCode() {
        StringBuilder finalHashCode = new StringBuilder();
        if (this.countryCode != null && this.prospectID != null && this.deviceType!=null) 
        {
            finalHashCode.append(countryCode);
            finalHashCode.append(prospectID);
            finalHashCode.append(deviceType);
        }
        return finalHashCode.toString().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
        {
            return true;
        }
        if ((obj == null) || (obj.getClass() != this.getClass())) 
        {
            return false;
        }
        ProspectDigitalEntityKey other = (ProspectDigitalEntityKey) obj;
        return   Objects.equals(this.countryCode, other.countryCode) 
                && Objects.equals(this.prospectID, other.prospectID)
                && Objects.equals(this.deviceType, other.deviceType);
    }

    @Override
    public Object clone() {
        try {
            return (ProspectDigitalEntityKey) super.clone();
        } catch (CloneNotSupportedException e) {
            return new ProspectDigitalEntityKey(this.getCountryCode(),this.getProspectID(),this.getDeviceType());
        }
    }    
}
