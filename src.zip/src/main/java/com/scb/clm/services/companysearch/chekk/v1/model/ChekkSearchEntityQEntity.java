package com.scb.clm.services.companysearch.chekk.v1.model;

import java.sql.Timestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "CHK_SEARCH_ENTITY_QUEUE")
@Getter
@Setter
public class ChekkSearchEntityQEntity {

    @Id
    @Column(name="SEARCH_ENTITY_ID")
    private String searchEntityId;

    @Column(name="REQUEST_ID")
    private String requestId;

    @Column(name="PARTY_ID")
    private String partyId;

    @Column(name="ENTITY_NAME")
    private String entityName;

    @Column(name="LEVEL")
    private Integer level;

    @Column(name="STATUS")
    private String status; 

    @Column(name="REGISTRATION_ID")
    private String registrationID;       

    @Column(name="COUNTRY_OF_REGISTRATION")
    private String countryOfRegistration;    
    
    
    @Column(name="ERROR_CODE")
    private String errorCode;
    
    @Column(name="CREATED_ON")
    private Timestamp createdOn;  
    
    
    @Column(name="UPDATED_ON")
    private Timestamp updatedOn; 
}

