package com.scb.clm.services.companysearch.chekk.v1.support;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.services.companysearch.chekk.v1.exception.ApplicationException;

public class Log {
    private static final String COMPONENT_NAME = "Chekk_CompanySearch";
    private static final String KEY_CLASS_NAME = "className";
    private static final String KEY_METHOD_NAME = "methodName";
    private static final String KEY_LINE_NO = "lineNumber";

    private static ConcurrentHashMap<String, LoggerUtil> logMap = new ConcurrentHashMap<>();

    private Log() {

    }

    public static void info(String message) {
        String className = null;
        String methodName = null;

        Map<String, String> threadDetails = getThreadDetails();

        if (threadDetails != null && !threadDetails.isEmpty()) {
            className = threadDetails.get(KEY_CLASS_NAME);
            methodName = threadDetails.get(KEY_METHOD_NAME);
        }

        if ("com.scb.clm.services.processapi.chekk.v1.support.Log".equalsIgnoreCase(className)) {
            throw new ApplicationException();
        }

        LoggerUtil logger = getLogger(className, methodName);
        logger.println(message);
    }

    public static void debug(String message) {
        String className = null;
        String methodName = null;
        int lineNo = 0;
        Map<String, String> threadDetails = getThreadDetails();

        if (!threadDetails.isEmpty()) {
            className = threadDetails.get(KEY_CLASS_NAME);
            methodName = threadDetails.get(KEY_METHOD_NAME);
        }

        LoggerUtil logger = getLogger(className, methodName);
        logger.println(message);
    }

    public static void error(String message) {
        error(message, null);
    }

    public static void error(String message, Throwable error) {
        String className = null;
        String methodName = null;
        int lineNo = 0;

        Map<String, String> threadDetails = getThreadDetails();

        if (!threadDetails.isEmpty()) {
            className = threadDetails.get(KEY_CLASS_NAME);
            methodName = threadDetails.get(KEY_METHOD_NAME);
        }

        LoggerUtil logger = getLogger(className, methodName);
        logger.printError(message);
        if (error != null) {
            logger.printErrorMessage(error);
        }
    }

    private static LoggerUtil getLogger(String className, String methodName) {
        String key = className + "-" + methodName;
        LoggerUtil logger = logMap.get(key);
        synchronized (Log.class) {
            if (logger == null) {
                logger = LoggerUtil.getInstance(COMPONENT_NAME, className, methodName, LogType.APPLICATION.name());
                logMap.put(key, logger);
            }
        }
        return logger;
    }

    private static Map<String, String> getThreadDetails() {
        Map<String, String> threadDetails = new HashMap<>();

        StackTraceElement[] trace = Thread.currentThread().getStackTrace();
        if (trace.length > 3) {
            threadDetails.put(KEY_CLASS_NAME, trace[3].getClassName());
            threadDetails.put(KEY_METHOD_NAME, trace[3].getMethodName());
            threadDetails.put(KEY_LINE_NO, trace[3].getLineNumber() + "");
        }
        return threadDetails;
    }

}
