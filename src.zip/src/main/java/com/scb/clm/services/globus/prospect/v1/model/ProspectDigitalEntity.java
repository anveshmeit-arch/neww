package com.scb.clm.services.globus.prospect.v1.model;

import java.util.Objects;

import com.scb.clm.common.util.StringUtility;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/*
 * 
 *  @author      1378958
 *  @version     1.0
 *  @since       
 *  @use         
 */
@Entity
@Table(name = "GBS_PROSPECT_DIGITAL_IDS")
public class ProspectDigitalEntity implements Cloneable
{
    @EmbeddedId
    private ProspectDigitalEntityKey id;

    @Column(name="DEVICE_VALUE")
    private String deviceValue;

    @ManyToOne
    @JoinColumns({
        @JoinColumn(name="COUNTRY_CODE", referencedColumnName="COUNTRY_CODE", insertable= false, updatable= false),
        @JoinColumn(name="PROSPECT_ID", referencedColumnName="PROSPECT_ID",insertable= false, updatable=false)
    })
    private ProspectEntity digitalMapper;

    public ProspectDigitalEntity(ProspectDigitalEntityKey id) {
        this.id = (ProspectDigitalEntityKey) id.clone();
    }
    public ProspectDigitalEntity() {
    }
    public ProspectDigitalEntityKey getId() {
        return (ProspectDigitalEntityKey) id.clone();
    }
    public void setId(ProspectDigitalEntityKey id) {
        this.id = (ProspectDigitalEntityKey) id.clone();
    }
    public String getDeviceValue() {
        return deviceValue;
    }
    public void setDeviceValue(String deviceValue) {
        this.deviceValue = deviceValue;
    }

    @Override
    public int hashCode() {
        return this.getId().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof ProspectDigitalEntity)) {
            return false;
        }
        return Objects.equals(this.getId(), ((ProspectDigitalEntity) obj).getId());
    }

    public void synchronizeThisWith( ProspectDigitalEntity argProspectDigitalEntity) 
    {
        this.setDeviceValue(argProspectDigitalEntity.getDeviceValue());
    }
    
    @Override
    public Object clone() throws CloneNotSupportedException {
        ProspectDigitalEntity prospectDigitalEntity=(ProspectDigitalEntity) super.clone();
        prospectDigitalEntity.setId((ProspectDigitalEntityKey) this.getId().clone());
        return prospectDigitalEntity;
    }
}
