package com.scb.clm.services.globus.mule.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSMuleResponseErrorDetails 
{
    @JsonProperty("errorCode") 
    private String errorcode;

    @JsonProperty("errorDescription") 
    private String errordescription;

    public GBSMuleResponseErrorDetails(String errorCode,String errorDescription) {
        this.errorcode = errorCode;
        this.errordescription = errorDescription;
    }

    public String getErrorcode() {
        return errorcode;
    }

    public void setErrorcode(String errorcode) {
        this.errorcode = errorcode;
    }

    public String getErrordescription() {
        return errordescription;
    }

    public void setErrordescription(String errordescription) {
        this.errordescription = errordescription;
    }

}