package com.scb.clm.services.companysearch.chekk.v1.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekSolaceConfigEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkCountriesEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkSSICCodeMappingEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChkEntityTypeRefEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChkRoleRefEntity;
import com.scb.clm.services.companysearch.chekk.v1.repository.ChekSolaceConfigRepository;
import com.scb.clm.services.companysearch.chekk.v1.repository.ChekkCountriesRepository;
import com.scb.clm.services.companysearch.chekk.v1.repository.ChekkSSICCodeMappingRepository;
import com.scb.clm.services.companysearch.chekk.v1.repository.ChkEntityTypeRefRepository;
import com.scb.clm.services.companysearch.chekk.v1.repository.ChkRoleRefRepository;
import com.scb.clm.services.companysearch.chekk.v1.support.Log;

import jakarta.annotation.PostConstruct;

@Component
public class ChkTableReferences {
    @Autowired
    private ChekkCountriesRepository chekkCountriesRepository;

    @Autowired
    private ChekSolaceConfigRepository chekSolaceConfigRepository;

    @Autowired
    private ChekkSSICCodeMappingRepository chekkSSICCodeMappingRepository;

    @Autowired
    private ChkRoleRefRepository chkRoleRefRepository;

    @Autowired
    private ChkEntityTypeRefRepository chkEntityTypeRefRepository;

    private Map<String, String> country3CodeMap = new HashMap<>();
    private Map<String, String> countryDescMap = new HashMap<>();
    private Map<String, String> countryTopicNamesMap = new HashMap<>();
    private Map<String, String> ssicCodeMap = new HashMap<>();
    private Map<String, String> rolecodeMap = new HashMap<>();
    private static HashMap<String, String> entityTypeMap = new HashMap<>();
    private static HashMap<String, String> entitySubTypeMap = new HashMap<>();

    @PostConstruct
    public void loadReferenceTables() {
        loadChekkCountryConfig();
        loadChekkCountrySolaceTopicNames();
        loadSSICCodeMapping();
        loadRoleMapping();
        loadEntityTypeMapping();
    }

    private void loadChekkCountryConfig() {
        Log.info("ChkTableReferences#loadChekkCountryConfig: Loading chekkCountryConfig table data");

        try {
            List<ChekkCountriesEntity> chekkCountries = chekkCountriesRepository.findAll();
            for (ChekkCountriesEntity chekkCountriesEntity : chekkCountries) {
                country3CodeMap.put(chekkCountriesEntity.getCountryCode3Char().toUpperCase(),
                        chekkCountriesEntity.getCountryCode());
                countryDescMap.put(chekkCountriesEntity.getCountryName().toUpperCase(),
                        chekkCountriesEntity.getCountryCode());
            }
            Log.info("ChkTableReferences#loadChekkCountryConfig: Chekk Countries Loaded :" + chekkCountries.size());
        } catch (Exception e) {
            Log.error("ChkTableReferences#loadChekkCountryConfig: Exception in loading country config from chk table "
                    + e.getMessage(), e);
        }
    }

    private void loadChekkCountrySolaceTopicNames() {
        Log.info("ChkTableReferences#loadChekkCountrySolaceTopicNames: Loading chk solace topic names");

        try {
            List<ChekSolaceConfigEntity> chekkCntryTopics = chekSolaceConfigRepository.findAll();
            String key;
            for (ChekSolaceConfigEntity chekCountriesTopicNamesEntity : chekkCntryTopics) {
                key = chekCountriesTopicNamesEntity.getId().getCountryCode()
                        + chekCountriesTopicNamesEntity.getId().getInterfaceId();
                countryTopicNamesMap.put(key.toUpperCase(), chekCountriesTopicNamesEntity.getTopicName());
            }
            Log.info("ChkTableReferences#loadChekkCountrySolaceTopicNames: Completed loading solace topics ");

        } catch (Exception e) {
            Log.error("ChkTableReferences#loadChekkCountrySolaceTopicNames: Exception in loading solace topic names "
                    + e.getMessage(), e);
        }
    }

    private void loadSSICCodeMapping() {
        try {
            List<ChekkSSICCodeMappingEntity> chekkssiccodemappings = chekkSSICCodeMappingRepository.findAll();
            for (ChekkSSICCodeMappingEntity chekkSSICCodeMappingEntity : chekkssiccodemappings) {
                ssicCodeMap.put(chekkSSICCodeMappingEntity.getSsic(), chekkSSICCodeMappingEntity.getScbEnhancedIsic());
            }
            Log.info("ChkTableReferences#loadSSICCodeMapping: Completed loading SSICCode Mapping" + ssicCodeMap.size());

        } catch (Exception e) {
            Log.error("ChkTableReferences#loadSSICCodeMapping: Exception in loading SSICCode Mapping" + e.getMessage(),
                    e);
        }
    }

    private void loadRoleMapping() {
        try {
            List<ChkRoleRefEntity> roleRefmappings = chkRoleRefRepository.findAll();
            String key;
            for (ChkRoleRefEntity chkRoleRefEntity : roleRefmappings) {
                key = chkRoleRefEntity.getId().getPartyType() + "-" + chkRoleRefEntity.getId().getRoleCode();
                rolecodeMap.put(key.toUpperCase(), chkRoleRefEntity.getRoleDescr());
            }
            Log.info("ChkTableReferences#loadRoleMapping: role codes mapping loaded successfully. "
                    + ssicCodeMap.size());
        } catch (Exception e) {
            Log.error("ChkTableReferences#loadRoleMapping: Exception in loading role mapping " + e.getMessage(), e);
        }
    }

    public void loadEntityTypeMapping() {
        List<String> entityList = null;
        try {
            List<ChkEntityTypeRefEntity> chkEntityTypemappings = chkEntityTypeRefRepository.findAll();
            for (ChkEntityTypeRefEntity chkEntityTypeRefEntity : chkEntityTypemappings) {
                entityTypeMap.put(chkEntityTypeRefEntity.getLeNationalLegalForm().toUpperCase(),
                        chkEntityTypeRefEntity.getClientEntityType());
                entitySubTypeMap.put(chkEntityTypeRefEntity.getLeNationalLegalForm().toUpperCase(),
                        chkEntityTypeRefEntity.getClientEntitySubType());
            }
            Log.info("ChkTableReferences#loadEntityTypeMapping: entity type mapping Loaded successfully. Total size = "
                    + ssicCodeMap.size());
        } catch (Exception e) {
            Log.error("ChkTableReferences#loadEntityTypeMapping: Exception in loading Entity type mapping "
                    + e.getMessage(), e);
        }
    }

    /**
     * roleCode is converted to uppercase while searching in the table to avoid case
     * sensitive issue in map
     * 
     * @param roleCode
     * @return
     */
    public String getRoleDescription(String roleCode) {
        return rolecodeMap.get(roleCode.toUpperCase());
    }

    public String getCountryDescription(String countryCodeIn2Char) {
        String retCntryDescr = countryCodeIn2Char;
        if (retCntryDescr != null) {
            retCntryDescr = countryDescMap.get(countryCodeIn2Char.toUpperCase());
        }
        return retCntryDescr;
    }

    public String getCountryCodeIn2Char(String countryCodeIn3Char) {
        String retCntryCodeIn2Char = countryCodeIn3Char;
        if (countryCodeIn3Char != null) {
            retCntryCodeIn2Char = country3CodeMap.get(countryCodeIn3Char.toUpperCase());
        }
        return retCntryCodeIn2Char;
    }

    public String getIsicFromSsicCode(String ssicCode) {
        return ssicCodeMap.get(ssicCode);
    }

    public String getSolaceTopicName(String countryCode, String interfaceId) {
        String key = countryCode + interfaceId;
        return countryTopicNamesMap.get(key.toUpperCase());
    }

    public String getEntityType(String leNationalLegalForm) {
        return (leNationalLegalForm == null) ? null : entityTypeMap.get(leNationalLegalForm.toUpperCase());
    }

    public String getEntitySubType(String leNationalLegalForm) {
        return (leNationalLegalForm == null) ? null : entitySubTypeMap.get(leNationalLegalForm.toUpperCase());
    }

}
