package com.scb.clm.services.companysearch.chekk.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Content {

	@JsonProperty("name")
    private String name;

    @JsonProperty("code")
    private String code;

	@JsonProperty("status")
    private String status;

    @JsonProperty("jurisdiction")
    private String jurisdiction;

    @JsonProperty("locality")
    private String locality;

    @JsonProperty("zip")
    private String zip;

    @JsonProperty("national_ids")
    private String national_ids;

    @JsonProperty("street_address")
    private String street_address;

    @JsonProperty("source_configuration")
    private String sourceConfiguration;
}
