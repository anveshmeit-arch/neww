package com.scb.clm.services.globus.deepening.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;

public class GBSDeepeningResponseDocuments {
    @JsonProperty("documentType")
    private String documentType;

    @JsonProperty("documentCode")
    private String documentCode;

    @JsonProperty("documentNumber")
    private String documentNumber;

    @JsonProperty("sequenceNumber")
    private short sequenceNumber;

    @JsonProperty("documentReceiveDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date documentReceiveDate;

    @JsonProperty("documentSignatoryDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date documentSignatoryDate;

    @JsonProperty("documentExpiryDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date documentExpiryDate;

    @JsonProperty("taxResidenceCountry")
    private String taxResidenceCountry;

    @JsonProperty("w8nSupportDocumentIndicator")
    private String w8nSupportDocumentIndicator;

    @JsonProperty("countryTreaty")
    private String countryTreaty;

    @JsonProperty("documentEvidenceLink")
    private String documentEvidenceLink;

    @JsonProperty("docRemarks")
    private String docRemarks;

    @JsonProperty("docReasonCode")
    private String docReasonCode;

    @JsonProperty("expiryCheckOverride")
    private String expiryCheckOverride;

    @JsonProperty("poiDocument")
    private String poiDocument;

    public GBSDeepeningResponseDocuments() {
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public String getDocumentCode() {
        return documentCode;
    }

    public void setDocumentCode(String documentCode) {
        this.documentCode = documentCode;
    }

    public String getDocumentNumber() {
        return documentNumber;
    }

    public void setDocumentNumber(String documentNumber) {
        this.documentNumber = documentNumber;
    }

    public short getSequenceNumber() {
        return sequenceNumber;
    }

    public void setSequenceNumber(short sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public Date getDocumentReceiveDate() {
        return documentReceiveDate;
    }

    public void setDocumentReceiveDate(Date documentReceiveDate) {
        this.documentReceiveDate = documentReceiveDate;
    }

    public Date getDocumentSignatoryDate() {
        return documentSignatoryDate;
    }

    public void setDocumentSignatoryDate(Date documentSignatoryDate) {
        this.documentSignatoryDate = documentSignatoryDate;
    }

    public Date getDocumentExpiryDate() {
        return documentExpiryDate;
    }

    public void setDocumentExpiryDate(Date documentExpiryDate) {
        this.documentExpiryDate = documentExpiryDate;
    }

    public String getTaxResidenceCountry() {
        return taxResidenceCountry;
    }

    public void setTaxResidenceCountry(String taxResidenceCountry) {
        this.taxResidenceCountry = taxResidenceCountry;
    }

    public String getW8nSupportDocumentIndicator() {
        return w8nSupportDocumentIndicator;
    }

    public void setW8nSupportDocumentIndicator(String w8nSupportDocumentIndicator) {
        this.w8nSupportDocumentIndicator = w8nSupportDocumentIndicator;
    }

    public String getCountryTreaty() {
        return countryTreaty;
    }

    public void setCountryTreaty(String countryTreaty) {
        this.countryTreaty = countryTreaty;
    }

    public String getDocumentEvidenceLink() {
        return documentEvidenceLink;
    }

    public void setDocumentEvidenceLink(String documentEvidenceLink) {
        this.documentEvidenceLink = documentEvidenceLink;
    }

    public String getDocRemarks() {
        return docRemarks;
    }

    public void setDocRemarks(String docRemarks) {
        this.docRemarks = docRemarks;
    }

    public String getDocReasonCode() {
        return docReasonCode;
    }

    public void setDocReasonCode(String docReasonCode) {
        this.docReasonCode = docReasonCode;
    }

    public String getExpiryCheckOverride() {
        return expiryCheckOverride;
    }

    public void setExpiryCheckOverride(String expiryCheckOverride) {
        this.expiryCheckOverride = expiryCheckOverride;
    }

    public String getPoiDocument() {
        return poiDocument;
    }

    public void setPoiDocument(String poiDocument) {
        this.poiDocument = poiDocument;
    }
}
