package com.scb.clm.services.companysearch.chekk.v1.service;

import com.scb.clm.services.companysearch.chekk.v1.model.ChekkPartyEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.process.Address;
import com.scb.clm.services.companysearch.chekk.v1.model.process.Association;
import com.scb.clm.services.companysearch.chekk.v1.model.process.Document;
import com.scb.clm.services.companysearch.chekk.v1.model.process.FinalResponse;

/**
 * Defines all common mapper methods used by Individual and Entity parties to
 * convert {@link ChekkPartyEntity} to {@link FinalResponse}
 */
public interface PartyMapperInterface {
	public final String RESIDENTIAL_ADDRESS = "RA";
	public final String ADDRESS_TYPE_RES = "RES";
	public final String ADDRESS_TYPE_OA = "OA";

	public Address createAddress();

	public Association createAssociation();

	public String getDuplicateKeyId();

	public Document createDocument();

}
