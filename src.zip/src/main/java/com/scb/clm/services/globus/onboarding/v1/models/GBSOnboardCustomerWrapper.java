package com.scb.clm.services.globus.onboarding.v1.models;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.scb.clm.common.util.WrapperUtility;


@JsonInclude(JsonInclude.Include.NON_NULL)  
public class GBSOnboardCustomerWrapper {

    @JsonProperty("salutationCode")
    private String salutationCode;

    @JsonProperty("firstName")
    private String firstName;

    @JsonProperty("middleName")
    private String middleName;

    @JsonProperty("lastName")
    private String lastName;

    @JsonProperty("fullName")
    private String fullName;

    @JsonProperty("gender")
    private String gender;

    @JsonProperty("dateOfBirth")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date dateOfBirth;

    @JsonProperty("residentCountry")
    private String residentCountry;   

    @JsonProperty("birthCountry")
    private String birthCountry;

    @JsonProperty("accountOpeningCountry")
    private String accountOpeningCountry;
    

    @JsonProperty("bankInternalInfo")
    private GBSOnboardBankInternalInfoWrapper objBankInternalInfo;

    @JsonProperty("suspiciousFlags")
    private GBSOnboardSuspiciousFlagsWrapper objSuspiciousFlags;

    @JsonProperty("cddCompliance")
    private GBSOnboardCDDComplianceWrapper objCddCompliance;

    @JsonProperty("pdpa")
    private List<GBSOnboardPdpaWrapper> objOnboard_PdpaWrapper;

    @JsonProperty("customerMultilingual")
    private GBSOnboardCustomerMultiLingualWrapper objOnboard_CustomerMultiLingualWrapper;

    @JsonProperty("digitalIdentity")
    private List<GBSOnboardDigitalIdentityWrapper> objOnboard_DigitalIdentityWrapper; 

    @JsonProperty("misc")
    private List<GBSOnboardMiscWrapper> objOnboard_MiscWrapper;

    @JsonProperty("auxiliary")
    private List<GBSOnboardAuxiliaryWrapper> objOnboard_AuxiliaryWrapper;

    @JsonProperty("addresses")
    private List<GBSOnboardAddressesWrapper> objOnboard_AddressesWrapper;

    @JsonProperty("contacts")
    private List<GBSOnboardContactsWrapper> objOnboard_ContactsWrapper;

    @JsonProperty("aliases")
    private List<GBSOnboardAliasesWrapper> objOnboard_AliasesWrapper;

    @JsonProperty("cdd")
    private List<GBSOnboardCDDWrapper> objOnboard_CDDWrapper;

    @JsonProperty("kyc")
    private GBSOnboardKYCWrapper objOnboard_KYCWrapper;

   

    

    @JsonProperty("employments")
    private GBSOnboardEmploymentsMandatoryWrapper objOnboard_EmploymentsMandatoryWrapper;

    @JsonProperty("sourceOfWealth")
    private GBSOnboardSourceOfWealthWrapper objOnboard_SourceOfWealthWrapper;

    @JsonProperty("documents")
    private List<GBSOnboardDocumentsWrapper> objOnboard_DocumentsWrapper;

    @JsonProperty("tars")
    private GBSOnboardTarsCondnMandatoryWrapper objOnboard_TarsCondnMandatoryWrapper;

    @JsonProperty("preferences")
    private GBSOnboardPreferencesWrapper objOnboard_PreferencesWrapper;

    @JsonProperty("appliedProducts")
    private List<GBSOnboardAppliedProductsWrapper> objOnboard_AppliedProductsWrapper;

    @JsonProperty("jointApplicants")
    private List<GBSOnboardJointApplicantsWrapper> objOnboard_JointApplicantsWrapper;

    @JsonProperty("verificationStatus")
    private List<GBSOnboardVerificationStatusWrapper> objOnboard_VerificationStatusWrapper;

    public String getSalutationCode() {
        return salutationCode;
    }

    public void setSalutationCode(String salutation_code) {
        this.salutationCode = salutation_code;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String first_name) {
        this.firstName = first_name;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middle_name) {
        this.middleName = middle_name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String last_name) {
        this.lastName = last_name;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String full_name) {
        this.fullName = full_name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date date_of_birth) {
        this.dateOfBirth = WrapperUtility.cloneData(date_of_birth);
    }

    public String getResidentCountry() {
        return residentCountry;
    }

    public void setResidentCountry(String resident_country) {
        this.residentCountry = resident_country;
    }

    



    public String getBirthCountry() {
        return birthCountry;
    }

    public void setBirthCountry(String birth_country) {
        this.birthCountry = birth_country;
    }

    public String getAccountOpeningCountry() {
        return accountOpeningCountry;
    }

    public void setAccountOpeningCountry(String account_opening_country) {
        this.accountOpeningCountry = account_opening_country;
    }

    public List<GBSOnboardPdpaWrapper> getObjOnboard_PdpaWrapper() {
        return objOnboard_PdpaWrapper;
    }

    public void setObjOnboard_PdpaWrapper(List<GBSOnboardPdpaWrapper> objOnboard_PdpaWrapper) {
        this.objOnboard_PdpaWrapper = objOnboard_PdpaWrapper;
    }


    public GBSOnboardCustomerMultiLingualWrapper getObjOnboard_CustomerMultiLingualWrapper() {
        return objOnboard_CustomerMultiLingualWrapper;
    }

    public void setObjOnboard_CustomerMultiLingualWrapper(
            GBSOnboardCustomerMultiLingualWrapper objOnboard_CustomerMultiLingualWrapper) {
        this.objOnboard_CustomerMultiLingualWrapper = objOnboard_CustomerMultiLingualWrapper;
    }

    public List<GBSOnboardDigitalIdentityWrapper> getObjOnboard_DigitalIdentityWrapper() {
        return objOnboard_DigitalIdentityWrapper;
    }

    public void setObjOnboard_DigitalIdentityWrapper(
            List<GBSOnboardDigitalIdentityWrapper> objOnboard_DigitalIdentityWrapper) {
        this.objOnboard_DigitalIdentityWrapper = objOnboard_DigitalIdentityWrapper;
    }

    public List<GBSOnboardMiscWrapper> getObjOnboard_MiscWrapper() {
        return objOnboard_MiscWrapper;
    }

    public void setObjOnboard_MiscWrapper(List<GBSOnboardMiscWrapper> objOnboard_MiscWrapper) {
        this.objOnboard_MiscWrapper = objOnboard_MiscWrapper;
    }

    public List<GBSOnboardAuxiliaryWrapper> getObjOnboard_AuxiliaryWrapper() {
        return objOnboard_AuxiliaryWrapper;
    }

    public void setObjOnboard_AuxiliaryWrapper(List<GBSOnboardAuxiliaryWrapper> objOnboard_AuxiliaryWrapper) {
        this.objOnboard_AuxiliaryWrapper = objOnboard_AuxiliaryWrapper;
    }

    public List<GBSOnboardAddressesWrapper> getObjOnboard_AddressesWrapper() {
        return objOnboard_AddressesWrapper;
    }

    public void setObjOnboard_AddressesWrapper(List<GBSOnboardAddressesWrapper> objOnboard_AddressesWrapper) {
        this.objOnboard_AddressesWrapper = objOnboard_AddressesWrapper;
    }

    public List<GBSOnboardContactsWrapper> getObjOnboard_ContactsWrapper() {
        return objOnboard_ContactsWrapper;
    }

    public void setObjOnboard_ContactsWrapper(List<GBSOnboardContactsWrapper> objOnboard_ContactsWrapper) {
        this.objOnboard_ContactsWrapper = objOnboard_ContactsWrapper;
    }

    public List<GBSOnboardAliasesWrapper> getObjOnboard_AliasesWrapper() {
        return objOnboard_AliasesWrapper;
    }

    public void setObjOnboard_AliasesWrapper(List<GBSOnboardAliasesWrapper> objOnboard_AliasesWrapper) {
        this.objOnboard_AliasesWrapper = objOnboard_AliasesWrapper;
    }

    public List<GBSOnboardCDDWrapper> getObjOnboard_CDDWrapper() {
        return objOnboard_CDDWrapper;
    }

    public void setObjOnboard_CDDWrapper(List<GBSOnboardCDDWrapper> objOnboard_CDDWrapper) {
        this.objOnboard_CDDWrapper = objOnboard_CDDWrapper;
    }

    public GBSOnboardKYCWrapper getObjOnboard_KYCWrapper() {
        return objOnboard_KYCWrapper;
    }

    public void setObjOnboard_KYCWrapper(GBSOnboardKYCWrapper objOnboard_KYCWrapper) {
        this.objOnboard_KYCWrapper = objOnboard_KYCWrapper;
    }



    

    public GBSOnboardEmploymentsMandatoryWrapper getObjOnboard_EmploymentsMandatoryWrapper() {
        return objOnboard_EmploymentsMandatoryWrapper;
    }

    public void setObjOnboard_EmploymentsMandatoryWrapper(
            GBSOnboardEmploymentsMandatoryWrapper objOnboard_EmploymentsMandatoryWrapper) {
        this.objOnboard_EmploymentsMandatoryWrapper = objOnboard_EmploymentsMandatoryWrapper;
    }

    public GBSOnboardSourceOfWealthWrapper getObjOnboard_SourceOfWealthWrapper() {
        return objOnboard_SourceOfWealthWrapper;
    }

    public void setObjOnboard_SourceOfWealthWrapper(GBSOnboardSourceOfWealthWrapper objOnboard_SourceOfWealthWrapper) {
        this.objOnboard_SourceOfWealthWrapper = objOnboard_SourceOfWealthWrapper;
    }

    public List<GBSOnboardDocumentsWrapper> getObjOnboard_DocumentsWrapper() {
        return objOnboard_DocumentsWrapper;
    }

    public void setObjOnboard_DocumentsWrapper(List<GBSOnboardDocumentsWrapper> objOnboard_DocumentsWrapper) {
        this.objOnboard_DocumentsWrapper = objOnboard_DocumentsWrapper;
    }

    public GBSOnboardTarsCondnMandatoryWrapper getObjOnboard_TarsCondnMandatoryWrapper() {
        return objOnboard_TarsCondnMandatoryWrapper;
    }

    public void setObjOnboard_TarsCondnMandatoryWrapper(
            GBSOnboardTarsCondnMandatoryWrapper objOnboard_TarsCondnMandatoryWrapper) {
        this.objOnboard_TarsCondnMandatoryWrapper = objOnboard_TarsCondnMandatoryWrapper;
    }

    public GBSOnboardPreferencesWrapper getObjOnboard_PreferencesWrapper() {
        return objOnboard_PreferencesWrapper;
    }

    public void setObjOnboard_PreferencesWrapper(GBSOnboardPreferencesWrapper objOnboard_PreferencesWrapper) {
        this.objOnboard_PreferencesWrapper = objOnboard_PreferencesWrapper;
    }

    public List<GBSOnboardAppliedProductsWrapper> getObjOnboard_AppliedProductsWrapper() {
        return objOnboard_AppliedProductsWrapper;
    }

    public void setObjOnboard_AppliedProductsWrapper(
            List<GBSOnboardAppliedProductsWrapper> objOnboard_AppliedProductsWrapper) {
        this.objOnboard_AppliedProductsWrapper = objOnboard_AppliedProductsWrapper;
    }

    public List<GBSOnboardJointApplicantsWrapper> getObjOnboard_JointApplicantsWrapper() {
        return objOnboard_JointApplicantsWrapper;
    }

    public void setObjOnboard_JointApplicantsWrapper(
            List<GBSOnboardJointApplicantsWrapper> objOnboard_JointApplicantsWrapper) {
        this.objOnboard_JointApplicantsWrapper = objOnboard_JointApplicantsWrapper;
    }

    public List<GBSOnboardVerificationStatusWrapper> getObjOnboard_VerificationStatusWrapper() {
        return objOnboard_VerificationStatusWrapper;
    }

    public void setObjOnboard_VerificationStatusWrapper(
            List<GBSOnboardVerificationStatusWrapper> objOnboard_VerificationStatusWrapper) {
        this.objOnboard_VerificationStatusWrapper = objOnboard_VerificationStatusWrapper;
    }    

    public GBSOnboardBankInternalInfoWrapper getObjBankInternalInfo() {
        return objBankInternalInfo;
    }

    public void setObjBankInternalInfo(GBSOnboardBankInternalInfoWrapper objBankInternalInfo) {
        this.objBankInternalInfo = objBankInternalInfo;
    }

    public GBSOnboardSuspiciousFlagsWrapper getObjSuspiciousFlags() {
        return objSuspiciousFlags;
    }

    public void setObjSuspiciousFlags(GBSOnboardSuspiciousFlagsWrapper objSuspiciousFlags) {
        this.objSuspiciousFlags = objSuspiciousFlags;
    }

    public GBSOnboardCDDComplianceWrapper getObjCddCompliance() {
        return objCddCompliance;
    }

    public void setObjCddCompliance(GBSOnboardCDDComplianceWrapper objCddCompliance) {
        this.objCddCompliance = objCddCompliance;
    }

}
