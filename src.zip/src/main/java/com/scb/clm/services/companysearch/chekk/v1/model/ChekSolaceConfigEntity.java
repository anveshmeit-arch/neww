package com.scb.clm.services.companysearch.chekk.v1.model;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "chk_solace_config")
@Getter
@Setter
public class ChekSolaceConfigEntity {

	@EmbeddedId
	private ChkSolaceConfigEntityKey id;

	@Column(name = "topic_name")
	private String topicName;

	public ChekSolaceConfigEntity clone() throws CloneNotSupportedException {
		return (ChekSolaceConfigEntity) super.clone();
	}
}
