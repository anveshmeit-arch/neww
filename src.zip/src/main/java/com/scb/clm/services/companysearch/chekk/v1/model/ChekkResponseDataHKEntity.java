package com.scb.clm.services.companysearch.chekk.v1.model;

import java.sql.Timestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/*
 * 
 *  @author      
 *  @version     1.0
 *  @since       
 *  @use         
 */

@Entity
@Table(name = "CHK_RESPONSE_DATA")
@Getter
@Setter
public class ChekkResponseDataHKEntity {

    @Id
    @Column(name="ID")
    private String id;

    @Column(name="REQUEST_ID")
    private String requestId;

    @Column(name="RES_DATA")
    private String resData;

    @Column(name="RES_TYPE")
    private String resType;

    @Column(name="STATUS")
    private String status; 

    @Column(name="CREATED_ON")
    private Timestamp createdOn;   
    
    @Column(name="SEARCH_ENTITY_ID")
    private String searchEntityId;
    
    @ManyToOne
    @JoinColumns({
        @JoinColumn(name="REQUEST_ID", referencedColumnName="REQUEST_ID", insertable= false, updatable= false)
    })
    private ChekkRequestsHKEntity chekkResponseDataEntityMapper;
}
