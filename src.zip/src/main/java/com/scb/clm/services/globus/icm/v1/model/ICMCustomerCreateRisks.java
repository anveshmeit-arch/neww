package com.scb.clm.services.globus.icm.v1.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ICMCustomerCreateRisks
{
	
    @JsonProperty("riskdetails")
	private List<ICMCustomerCreateRisksDetails> riskDetails = new ArrayList<ICMCustomerCreateRisksDetails>();

    public List<ICMCustomerCreateRisksDetails> getRiskDetails() {
		return riskDetails;
	}

	public void setRiskDetails(List<ICMCustomerCreateRisksDetails> riskDetails) {
		this.riskDetails = riskDetails;
	}

	public void addRisks(ICMCustomerCreateRisksDetails riskDetails)
    {
    	if(riskDetails == null) {
    		 return;
    	}
    	if(this.riskDetails==null || this.riskDetails.size()==0) {
    		this.riskDetails = new ArrayList<ICMCustomerCreateRisksDetails>();
    	}
    	this.riskDetails.add(riskDetails);   	
    }
}
