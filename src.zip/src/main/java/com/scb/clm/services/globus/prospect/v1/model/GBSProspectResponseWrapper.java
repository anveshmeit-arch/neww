package com.scb.clm.services.globus.prospect.v1.model;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSProspectResponseWrapper
{

    @JsonProperty("prospectId")
    private String prospectID;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty("errorDetails")
    private ArrayList<GBSProspectResponseErrorDetails> errorDetails;

    public String getProspectID() {
        return prospectID;
    }

    public void setProspectID(String prospectID) {
        this.prospectID = prospectID;
    }

    public ArrayList<GBSProspectResponseErrorDetails> getErrorDetails() {
        return errorDetails;
    }

    public void setErrorDetails(ArrayList<GBSProspectResponseErrorDetails> errorDetails) {
        this.errorDetails = errorDetails;
    }

    public void addErrors(GBSProspectResponseErrorDetails argErrors) {
        if(this.errorDetails == null) {
            this.errorDetails= new ArrayList<GBSProspectResponseErrorDetails>();     
        }
        this.errorDetails.add(argErrors);
    }
}