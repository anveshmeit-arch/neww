package com.scb.clm.services.ekyc.pushekycdata.v1.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PusheKYCMinorCustomerProfileData {

	@JsonProperty("guardianIdentityType")
	private String guardianIdentityType;
	
	@JsonProperty("minorIdentityType")
	private String minorIdentityType;
	
	@JsonProperty("guardianId")
	private String guardianId;
	
	@JsonProperty("minorId")
	private String minorId;
	
	@JsonProperty("guardianDateOfExpiry")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	private Date guardianDateOfExpiry;
	
	@JsonProperty("minorDateOfExpiry")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	private Date minorDateOfExpiry;
	
	@JsonProperty("guardianDateOfIssuance")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	private Date guardianDateOfIssuance;
	
	@JsonProperty("minorDateOfIssuance")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	private Date minorDateOfIssuance;
	
	@JsonProperty("guardianFullName")
	private String guardianFullName;
	
	@JsonProperty("minorFullName")
	private String minorFullName;
	
	@JsonProperty("guardianFatherOrSpouseName")
	private String guardianFatherOrSpouseName;
	
	@JsonProperty("minorFatherOrSpouseName")
	private String minorFatherOrSpouseName;
	
	@JsonProperty("guardianMotherMaidenName")
	private String guardianMotherMaidenName;
	
	@JsonProperty("minorMotherMaidenName")
	private String minorMotherMaidenName;
	
	@JsonProperty("guardianDateOfBirth")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	private Date guardianDateOfBirth;
	
	@JsonProperty("minorDateOfBirth")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	private Date minorDateOfBirth;
	
	@JsonProperty("guardianPlaceOfBirth")
	private String guardianPlaceOfBirth;
	
	@JsonProperty("minorPlaceOfBirth")
	private String minorPlaceOfBirth;
	
	@JsonProperty("guardianNationality")
	private String guardianNationality;
	
	@JsonProperty("minorNationality")
	private String minorNationality;
	
	@JsonProperty("guardianMobileNumber")
	private String guardianMobileNumber;
	
	@JsonProperty("minorMobileNumber")
	private String minorMobileNumber;
	
	@JsonProperty("guardianAddressCurrent")
	private String guardianAddressCurrent;
	
	@JsonProperty("minorAddressCurrent")
	private String minorAddressCurrent;
	
	@JsonProperty("guardianCityOfResidence")
	private String guardianCityOfResidence;
	
	@JsonProperty("minorCityOfResidence")
	private String minorCityOfResidence;
	
	@JsonProperty("guardianCountryOfResidence")
	private String guardianCountryOfResidence;
	
	@JsonProperty("minorCountryOfResidence")
	private String minorCountryOfResidence;
	
	@JsonProperty("guardianOccupation")
	private String guardianOccupation;
	
	@JsonProperty("minorOccupation")
	private String minorOccupation;
	
	@JsonProperty("guardianNameOfEmployer")
	private String guardianNameOfEmployer;
	
	@JsonProperty("guardianSourceOfIncome")
	private String guardianSourceOfIncome;
	
	@JsonProperty("guardianExpectedAnnualIncomeRange")
	private String guardianExpectedAnnualIncomeRange;
	
	@JsonProperty("purposeOfAccount")
	private String purposeOfAccount;
	
	@JsonProperty("minorFatca")
	private String minorFatca;
	
	@JsonProperty("guardianFatca")
	private String guardianFatca;
	
	@JsonProperty("guardianPEPIdentifed")
	private String guardianPEPIdentifed;
	
	@JsonProperty("minorPEPIdentifed")
	private String minorPEPIdentifed;
	
	@JsonProperty("nextOfKin")
	private String nextOfKin;
	
	@JsonProperty("IBAN")
	private String iBan;
	
	@JsonProperty("guardianCRSDeclaration")
	private String guardianCRSDeclaration;
	
	@JsonProperty("minorCRSDeclaration")
	private String minorCRSDeclaration;
	
	@JsonProperty("accountTitle")
	private String accountTitle;
	
	@JsonProperty("accountType")
	private String accountType;
	
	@JsonProperty("isGuardianDeceased")
	private String isGuardianDeceased;
	
	@JsonProperty("isMinorDeceased")
	private String isMinorDeceased;
	
	@JsonProperty("mandateHolder")
	private PusheKYCCustomerMandateHolder objMinorCustomerMandateHolder;

	public String getGuardianIdentityType() {
		return guardianIdentityType;
	}

	public void setGuardianIdentityType(String guardianIdentityType) {
		this.guardianIdentityType = guardianIdentityType;
	}

	public String getMinorIdentityType() {
		return minorIdentityType;
	}

	public void setMinorIdentityType(String minorIdentityType) {
		this.minorIdentityType = minorIdentityType;
	}

	public String getGuardianId() {
		return guardianId;
	}

	public void setGuardianId(String guardianId) {
		this.guardianId = guardianId;
	}

	public String getMinorId() {
		return minorId;
	}

	public void setMinorId(String minorId) {
		this.minorId = minorId;
	}

	public Date getGuardianDateOfExpiry() {
		return guardianDateOfExpiry;
	}

	public void setGuardianDateOfExpiry(Date guardianDateOfExpiry) {
		this.guardianDateOfExpiry = guardianDateOfExpiry;
	}

	public Date getMinorDateOfExpiry() {
		return minorDateOfExpiry;
	}

	public void setMinorDateOfExpiry(Date minorDateOfExpiry) {
		this.minorDateOfExpiry = minorDateOfExpiry;
	}

	public Date getGuardianDateOfIssuance() {
		return guardianDateOfIssuance;
	}

	public void setGuardianDateOfIssuance(Date guardianDateOfIssuance) {
		this.guardianDateOfIssuance = guardianDateOfIssuance;
	}

	public Date getMinorDateOfIssuance() {
		return minorDateOfIssuance;
	}

	public void setMinorDateOfIssuance(Date minorDateOfIssuance) {
		this.minorDateOfIssuance = minorDateOfIssuance;
	}

	public String getGuardianFullName() {
		return guardianFullName;
	}

	public void setGuardianFullName(String guardianFullName) {
		this.guardianFullName = guardianFullName;
	}

	public String getMinorFullName() {
		return minorFullName;
	}

	public void setMinorFullName(String minorFullName) {
		this.minorFullName = minorFullName;
	}

	public String getGuardianFatherOrSpouseName() {
		return guardianFatherOrSpouseName;
	}

	public void setGuardianFatherOrSpouseName(String guardianFatherOrSpouseName) {
		this.guardianFatherOrSpouseName = guardianFatherOrSpouseName;
	}

	public String getMinorFatherOrSpouseName() {
		return minorFatherOrSpouseName;
	}

	public void setMinorFatherOrSpouseName(String minorFatherOrSpouseName) {
		this.minorFatherOrSpouseName = minorFatherOrSpouseName;
	}

	public String getGuardianMotherMaidenName() {
		return guardianMotherMaidenName;
	}

	public void setGuardianMotherMaidenName(String guardianMotherMaidenName) {
		this.guardianMotherMaidenName = guardianMotherMaidenName;
	}

	public Date getGuardianDateOfBirth() {
		return guardianDateOfBirth;
	}

	public void setGuardianDateOfBirth(Date guardianDateOfBirth) {
		this.guardianDateOfBirth = guardianDateOfBirth;
	}

	public Date getMinorDateOfBirth() {
		return minorDateOfBirth;
	}

	public void setMinorDateOfBirth(Date minorDateOfBirth) {
		this.minorDateOfBirth = minorDateOfBirth;
	}

	public String getGuardianPlaceOfBirth() {
		return guardianPlaceOfBirth;
	}

	public void setGuardianPlaceOfBirth(String guardianPlaceOfBirth) {
		this.guardianPlaceOfBirth = guardianPlaceOfBirth;
	}

	public String getMinorPlaceOfBirth() {
		return minorPlaceOfBirth;
	}

	public void setMinorPlaceOfBirth(String minorPlaceOfBirth) {
		this.minorPlaceOfBirth = minorPlaceOfBirth;
	}

	public String getGuardianNationality() {
		return guardianNationality;
	}

	public void setGuardianNationality(String guardianNationality) {
		this.guardianNationality = guardianNationality;
	}

	public String getMinorNationality() {
		return minorNationality;
	}

	public void setMinorNationality(String minorNationality) {
		this.minorNationality = minorNationality;
	}

	public String getGuardianMobileNumber() {
		return guardianMobileNumber;
	}

	public void setGuardianMobileNumber(String guardianMobileNumber) {
		this.guardianMobileNumber = guardianMobileNumber;
	}

	public String getMinorMobileNumber() {
		return minorMobileNumber;
	}

	public void setMinorMobileNumber(String minorMobileNumber) {
		this.minorMobileNumber = minorMobileNumber;
	}

	public String getGuardianAddressCurrent() {
		return guardianAddressCurrent;
	}

	public void setGuardianAddressCurrent(String guardianAddressCurrent) {
		this.guardianAddressCurrent = guardianAddressCurrent;
	}

	public String getMinorAddressCurrent() {
		return minorAddressCurrent;
	}

	public void setMinorAddressCurrent(String minorAddressCurrent) {
		this.minorAddressCurrent = minorAddressCurrent;
	}

	public String getGuardianCityOfResidence() {
		return guardianCityOfResidence;
	}

	public void setGuardianCityOfResidence(String guardianCityOfResidence) {
		this.guardianCityOfResidence = guardianCityOfResidence;
	}

	public String getMinorCityOfResidence() {
		return minorCityOfResidence;
	}

	public void setMinorCityOfResidence(String minorCityOfResidence) {
		this.minorCityOfResidence = minorCityOfResidence;
	}

	public String getGuardianCountryOfResidence() {
		return guardianCountryOfResidence;
	}

	public void setGuardianCountryOfResidence(String guardianCountryOfResidence) {
		this.guardianCountryOfResidence = guardianCountryOfResidence;
	}

	public String getMinorCountryOfResidence() {
		return minorCountryOfResidence;
	}

	public void setMinorCountryOfResidence(String minorCountryOfResidence) {
		this.minorCountryOfResidence = minorCountryOfResidence;
	}

	public String getGuardianOccupation() {
		return guardianOccupation;
	}

	public void setGuardianOccupation(String guardianOccupation) {
		this.guardianOccupation = guardianOccupation;
	}

	public String getMinorOccupation() {
		return minorOccupation;
	}

	public void setMinorOccupation(String minorOccupation) {
		this.minorOccupation = minorOccupation;
	}

	public String getGuardianNameOfEmployer() {
		return guardianNameOfEmployer;
	}

	public void setGuardianNameOfEmployer(String guardianNameOfEmployer) {
		this.guardianNameOfEmployer = guardianNameOfEmployer;
	}

	public String getGuardianSourceOfIncome() {
		return guardianSourceOfIncome;
	}

	public void setGuardianSourceOfIncome(String guardianSourceOfIncome) {
		this.guardianSourceOfIncome = guardianSourceOfIncome;
	}

	public String getGuardianExpectedAnnualIncomeRange() {
		return guardianExpectedAnnualIncomeRange;
	}

	public void setGuardianExpectedAnnualIncomeRange(String guardianExpectedAnnualIncomeRange) {
		this.guardianExpectedAnnualIncomeRange = guardianExpectedAnnualIncomeRange;
	}

	public String getPurposeOfAccount() {
		return purposeOfAccount;
	}

	public void setPurposeOfAccount(String purposeOfAccount) {
		this.purposeOfAccount = purposeOfAccount;
	}

	public String isMinorFatca() {
		return minorFatca;
	}

	public void setMinorFatca(String minorFatca) {
		this.minorFatca = minorFatca;
	}

	public String isGuardianFatca() {
		return guardianFatca;
	}

	public void setGuardianFatca(String guardianFatca) {
		this.guardianFatca = guardianFatca;
	}

	public String getGuardianPEPIdentifed() {
		return guardianPEPIdentifed;
	}

	public void setGuardianPEPIdentifed(String guardianPEPIdentifed) {
		this.guardianPEPIdentifed = guardianPEPIdentifed;
	}

	public String getMinorPEPIdentifed() {
		return minorPEPIdentifed;
	}

	public void setMinorPEPIdentifed(String minorPEPIdentifed) {
		this.minorPEPIdentifed = minorPEPIdentifed;
	}

	public String getNextOfKin() {
		return nextOfKin;
	}

	public void setNextOfKin(String nextOfKin) {
		this.nextOfKin = nextOfKin;
	}



	public String getGuardianCRSDeclaration() {
		return guardianCRSDeclaration;
	}

	public void setGuardianCRSDeclaration(String guardianCRSDeclaration) {
		this.guardianCRSDeclaration = guardianCRSDeclaration;
	}

	public String getMinorCRSDeclaration() {
		return minorCRSDeclaration;
	}

	public void setMinorCRSDeclaration(String minorCRSDeclaration) {
		this.minorCRSDeclaration = minorCRSDeclaration;
	}

	public String getAccountTitle() {
		return accountTitle;
	}

	public void setAccountTitle(String accountTitle) {
		this.accountTitle = accountTitle;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}



	public PusheKYCCustomerMandateHolder getObjMinorCustomerMandateHolder() {
		return objMinorCustomerMandateHolder;
	}

	public void setObjMinorCustomerMandateHolder(PusheKYCCustomerMandateHolder objMinorCustomerMandateHolder) {
		this.objMinorCustomerMandateHolder = objMinorCustomerMandateHolder;
	}

	public String getMinorMotherMaidenName() {
		return minorMotherMaidenName;
	}

	public void setMinorMotherMaidenName(String minorMotherMaidenName) {
		this.minorMotherMaidenName = minorMotherMaidenName;
	}

	public String getiBan() {
		return iBan;
	}

	public void setiBan(String iBan) {
		this.iBan = iBan;
	}

	public String getIsGuardianDeceased() {
		return isGuardianDeceased;
	}

	public void setIsGuardianDeceased(String isGuardianDeceased) {
		this.isGuardianDeceased = isGuardianDeceased;
	}

	public String getIsMinorDeceased() {
		return isMinorDeceased;
	}

	public void setIsMinorDeceased(String isMinorDeceased) {
		this.isMinorDeceased = isMinorDeceased;
	}
}
