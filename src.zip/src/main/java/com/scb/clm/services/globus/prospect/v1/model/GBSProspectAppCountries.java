package com.scb.clm.services.globus.prospect.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;
public class GBSProspectAppCountries {

	@JsonProperty("countryCode")
	String countryCode;

	public GBSProspectAppCountries()
	{

	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

}
