package com.scb.clm.services.globus.deepening.service;

import com.scb.clm.common.config.ApplicationConfiguration;
import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.config.ContactServerInfo;
import com.scb.clm.common.exception.ErrorObject;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.repository.InterfaceRequestTypeRepository;
import com.scb.clm.common.util.JSONUtility;
import com.scb.clm.common.util.StringUtility;
import com.scb.clm.core.service.ServiceAbstract;
import com.scb.clm.core.service.ServiceInterface;
import com.scb.clm.services.globus.deepening.model.*;
import com.scb.clm.services.globus.deepening.support.DeepeningConstants;
import com.scb.clm.services.globus.icm.v1.model.*;
import com.scb.clm.services.globus.prescreen.v1.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Service
public class DeepeningService extends ServiceAbstract implements ServiceInterface{

    @Autowired
    InterfaceRequestTypeRepository interfaceRequestTypeRepository;

    @Autowired
    RestTemplate restTemplate;

    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object readRequestObject(TravellingObject travellingObject, NodeServicesEntity srvEntity) throws ProcessException
    {
        try
        {
            return JSONUtility.jsonTODomainWrapper(travellingObject.getRequestData(), GBSRequestWrapper.class);
        }
        catch(Exception e)
        {
            ProcessException gbxEx = new ProcessException();
            gbxEx.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, BaseConstants.VALIDATION_ERROR,"INVALID REQUEST MESSAGE FORMAT FOR DEEPENING SERVICE"));
            throw gbxEx;
        }
        finally
        {
            // N.A
        }
    }

    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public void validateData(TravellingObject travellingObject,NodeServicesEntity srvEntity,Object requestPayload) throws ProcessException
    {
        // validate the data you get from Experience layer
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateData", LogType.APPLICATION.name());
        List<ErrorObject> errorObjectList = new ArrayList<ErrorObject>();

        try
        {
            log.println("[Validating] [Deepening] [Thread "+Thread.currentThread()+"]");

            GBSDeepeningRequestWrapper requestWrapper    =   (GBSDeepeningRequestWrapper) requestPayload;
            GBSDeepeningRequestCustomers customers       =   null;
            GBSDeepeningRequestApplication application   =   null;

            if(requestWrapper == null)
            {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, DeepeningConstants.INVALID_JSON_FORMAT,"INVALID REQUEST"));
                throw new Exception();
            }

            /***Application Validation **/
            if(requestWrapper != null && requestWrapper.getApplication() != null){
                application = requestWrapper.getApplication();
            }
            if(application==null){
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, DeepeningConstants.INVALID_JSON_FORMAT,"INVALID APPLICATION DATA BLOCK"));
            }
            else{
                if(!StringUtility.minMaxlength(application.getApplicationReferenceNumber(),"0","50")) {
                    errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, DeepeningConstants.INVALID_APPLICATION_REFERENCE_NUMBER,"INVALID APPLICATION REFERENCE NUMBER"));
                }
                else
                {
                    travellingObject.setApplicationReferenceNumber(requestWrapper.getApplication().getApplicationReferenceNumber());
                }

            }

            /*** Customer Data Validation **/
            if(requestWrapper != null && requestWrapper.getCustomers() != null) {
                customers = requestWrapper.getCustomers();
            }

            if(customers==null) {
                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, DeepeningConstants.INVALID_JSON_FORMAT,"INVALID CUSTOMER DATA BLOCK"));
            }
            else {
                if(customers.getBankInternalInfo()==null){
                    errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, DeepeningConstants.INVALID_JSON_FORMAT,"INVALID BANK INTERNAL INFO DATA BLOCK"));
                }
                else if(!StringUtility.minMaxlength(customers.getBankInternalInfo().getCoreBankingReferenceKey(),"0","20")){
                    errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, DeepeningConstants.INVALID_CORE_BANKING_REFERENCE_KEY ,"INVALID CORE BANKING REFERENCE KEY ["+customers.getBankInternalInfo().getCoreBankingReferenceKey()+"]"));
                }
            }

        }
        catch (ProcessException e)
        {
            log.println(" Error ["+e.getAllErrors()+"]");
            throw e;
        }
        catch (Exception e)
        {
            log.printErrorMessage(e);
            errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_TECHNICAL, DeepeningConstants.INTERNAL_ERROR,"INTERNAL ERROR"));
            ProcessException gbxEx = new ProcessException();
            gbxEx.addAll(errorObjectList);
            throw gbxEx;
        }
    }

    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object constructOutboundObject(TravellingObject travellingObject,NodeServicesEntity srvEntity,Object requestPayload) throws ProcessException
    //in this we will send data to ICM from globus
    //hence from here create the request wrapper for ICM from the data you get from Experience layer
    //we will create the request wrapper for ICM using GBS request wrapper
    {

        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "constructServiceResponse", LogType.APPLICATION.name());
        ICMCustomerCreateRequestWrapper icmRequestWrapper=null;
        ICMCustomerCreateRequestData icmRequestData = null;
        ICMCustomerCreateRequestAttributes icmRequestAttributes =  null;
        ICMCustomerCreateCustomer icmRequestCustomer =  null;
        GBSDeepeningRequestWrapper requestWrapper  = null;
        try
        {
            requestWrapper  = (GBSDeepeningRequestWrapper) requestPayload;
            if(requestWrapper == null || requestWrapper.getCustomers() == null)
            {
                throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, BaseConstants.VALIDATION_ERROR,"BASIC INFORMATION ('customers') TAG IS NULL");
            }
            else if(requestWrapper.getCustomers().getBankInternalInfo() == null){
                throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, BaseConstants.VALIDATION_ERROR,"BASIC INFORMATION ('bankInternalInfo') TAG IS NULL");
            }
            else{
                icmRequestWrapper = new ICMCustomerCreateRequestWrapper();
                icmRequestData = new ICMCustomerCreateRequestData();
                icmRequestAttributes = new ICMCustomerCreateRequestAttributes();
                icmRequestCustomer = new ICMCustomerCreateCustomer();
                icmRequestCustomer.setRelationshipNo(requestWrapper.getCustomers().getBankInternalInfo().getCoreBankingReferenceKey());
                icmRequestAttributes.setCustomers(icmRequestCustomer);
                icmRequestData.setAttributes(icmRequestAttributes);
                icmRequestWrapper.setData(icmRequestData);
            }
        }
        catch (Exception e)
        {
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL, DeepeningConstants.REQUEST_INCOMPATABLE_WITH_DEEPENING_SERVICE,"DEEPENING REQUEST MESSAGE IS INCOMPATABLE");
        }
        finally
        {

        }
        return  icmRequestWrapper;
    }

    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object process(TravellingObject travellingObject, NodeServicesEntity srvEntity, ServiceStatus serviceStatus, Object outBoundRequestObject) throws ProcessException
    {
        //here we will connect to ICM service
        //outBoundRequestObject == ICMCustomerCreateRequestWrapper
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "process", LogType.APPLICATION.name());
        ICMCustomerCreateResponseWrapper icmResponseWrapper=null;
        ICMCustomerCreateRequestWrapper requestWrapper = null;
        ICMCustomerCreateRequestData icmRequestData = null;
        ICMCustomerCreateRequestAttributes icmRequestAttributes =  null;
        ICMCustomerCreateCustomer icmRequestCustomer =  null;

        try{
            requestWrapper = (ICMCustomerCreateRequestWrapper) outBoundRequestObject;
            icmRequestData = requestWrapper.getData();
            icmRequestAttributes = icmRequestData.getAttributes();
            icmRequestCustomer = icmRequestAttributes.getCustomers();
            String jsonString = (String)JSONUtility.domainWrapperToJSON( requestWrapper, ICMCustomerCreateRequestWrapper.class);
            log.println("Request Orchestrated to ICM : "+ jsonString);
            String hostServiceURL = "https://hklvadapp5636.hk.standardchartered.com:8543/Retail-Customer-Services/profile/v1/customers?filter[previous-core-banking-id]="+icmRequestCustomer.getRelationshipNo()+"&include=cdd,risks,documents,kyc,contacts,addresses,risks,tars";
            log.println("ICM inquiry URL # "+ hostServiceURL);
            ContactServerInfo contactServerInfo = new ContactServerInfo(travellingObject.getCountryCode(),hostServiceURL, BaseConstants.ICM_SCOPE, travellingObject.getTransactionID(), travellingObject.getInterfaceId(), jsonString, BaseConstants.POST_PROTOCOL, srvEntity);
            contactServerInfo = ApplicationConfiguration.getInstance().contactServer(contactServerInfo,travellingObject);
            log.println("[ICM enquiry Raw Response] \n "+contactServerInfo.getResponseMessage());
            icmResponseWrapper = (ICMCustomerCreateResponseWrapper) JSONUtility.jsonTODomainWrapper(contactServerInfo.getResponseMessage(), ICMCustomerCreateResponseWrapper.class);
            log.println("[ICM enquiry Response] \n "+JSONUtility.domainWrapperToJSON(icmResponseWrapper ));
        }
        catch(Exception e)
        {
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, DeepeningConstants.CLM_REQUEST_ERROR," INTERNAL ERROR WHILE SERVICE PROCESSING WITH CLM");
        }

        return icmResponseWrapper;
    }


    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object constructServiceResponse(TravellingObject travellingObject,NodeServicesEntity srvEntity, Object processedData,ServiceStatus serviceStatus) throws ProcessException
    //in this we will send final response to exp layer-> return type GBSResponse
    //and we will use ICMCreate Response to create GBS response
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "constructServiceResponse", LogType.APPLICATION.name());
        GBSDeepeningResponseWrapper responseWrapper = new GBSDeepeningResponseWrapper();
        GBSDeepeningResponseCustomers gbsCustomer = responseWrapper.getCustomers();
        try{
            ICMCustomerCreateResponseWrapper processedWrapper = (ICMCustomerCreateResponseWrapper)processedData;
            if(serviceStatus!=null && serviceStatus.getErrorObject()!=null && serviceStatus.getErrorObject().size() >0)
            {
                for(ErrorObject errorObject : serviceStatus.getErrorObject())
                {
                    responseWrapper.addErrors(new GBSDeepeningResponseErrorDetails((String)errorObject.getCode(),(String)errorObject.getDescription()));
                }
            }
            else{
                ICMCustomerCreateResponseData data = processedWrapper.getData();
                ICMCustomerCreateResponseAttributes attributes = data.getAttributes();
                ICMCustomerCreateCustomer icmCustomer = attributes.getCustomers();
                gbsCustomer.setFirstName(icmCustomer.getFirstName());
                gbsCustomer.setMiddleName(icmCustomer.getMiddleName());
                gbsCustomer.setLastName(icmCustomer.getLastName());
                gbsCustomer.setFullName(icmCustomer.getFullName());
                gbsCustomer.setProfileType(icmCustomer.getProfileType());
                gbsCustomer.setProfileStatus(icmCustomer.getStatus());
                gbsCustomer.setGender(icmCustomer.getGender());
                gbsCustomer.setResidentCountry(icmCustomer.getResidentCountry());
                gbsCustomer.setDateOfBirth(icmCustomer.getDateOfBirth());
                gbsCustomer.setCustomerNationalityCode(icmCustomer.getCustomerNationalityCode());
                gbsCustomer.setDeepeningResponseAddresses(setAddresses(icmCustomer.getAddresses()));
                gbsCustomer.setBankInternalInfo(setBankInternalInfo(icmCustomer));
                gbsCustomer.setDocuments(setDocuments(icmCustomer.getDocuments()));
                gbsCustomer.setDeepeningResponseCDD(setCDD(icmCustomer.getCdd()));
                gbsCustomer.setDeepeningResponseContacts(setContacts(icmCustomer.getContacts()));
                gbsCustomer.setDeepeningResponseTars(setTars(icmCustomer.getTars()));
                gbsCustomer.setDeepeningResponseRiskCodes(setRisks(icmCustomer.getRisks()));
                gbsCustomer.setDeepeningResponseKYC(setKyc(icmCustomer.getKyc()));

                String isDeepening= isDeepeningAllowed(icmCustomer.getCdd(),icmCustomer.getRisks(),icmCustomer)==true?"Y":"N";
                gbsCustomer.setIsDeepeningAllowed(isDeepening);

                responseWrapper.setCustomers(gbsCustomer);
            }

        }
        catch(Exception e)
        {
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, DeepeningConstants.RESPONSE_CONSTRUCTION_ERROR," INTERNAL ERROR WHILE RESPONSE CONSTRUCTION");
        }
        return responseWrapper;}


    private List<GBSDeepeningResponseAddresses> setAddresses(List<ICMCustomerCreateAddress> icmListAddresses){
        List<GBSDeepeningResponseAddresses> listAddresses = new ArrayList<>();
        for(ICMCustomerCreateAddress objAddress: icmListAddresses){
            GBSDeepeningResponseAddresses add = new GBSDeepeningResponseAddresses();
            add.setAddressType(objAddress.getAddressType());
            add.setAddressLine1(objAddress.getAddress1());
            add.setAddressLine2(objAddress.getAddress2());
            add.setAddressLine3(objAddress.getAddress3());
            add.setCityName(objAddress.getCityName());
            add.setState(objAddress.getState());
            add.setCountryCode(objAddress.getCountryCode());
            add.setPostalCode(objAddress.getPostalCode());
            add.setNearestLandMark(objAddress.getNearestLandMark());
            add.setIsMailingAddress(objAddress.getMailAddrInd());
            add.setPostBoxNo(objAddress.getPostBoxNo());
            add.setPoaDocument(objAddress.getPoaDocument());
            add.setStateCode(objAddress.getStateCode());
            add.setLangId(objAddress.getLangID());
            add.setAddressClassificationCode(objAddress.getAddressClassification());
            add.setLocalGovernmentAreaCode(objAddress.getLocalGovernmentAreaCode());
            listAddresses.add(add);
        }
        return listAddresses;
    }

    private GBSDeepeningResponseBankInternalInfo setBankInternalInfo(ICMCustomerCreateCustomer icmCustomer){
        GBSDeepeningResponseBankInternalInfo bankInternalInfo = new GBSDeepeningResponseBankInternalInfo();
        bankInternalInfo.setCoreBankingReferenceKey(icmCustomer.getRelationshipNo());
        bankInternalInfo.setCustomerMasterReferenceKey(icmCustomer.getProfileId());
        return bankInternalInfo;
    }
    private  List<GBSDeepeningResponseDocuments> setDocuments(List<ICMCustomerCreateDocuments> icmListDocuments){
        List<GBSDeepeningResponseDocuments> listDocuments = new ArrayList<>();
        for(ICMCustomerCreateDocuments objDocument: icmListDocuments){
            GBSDeepeningResponseDocuments doc = new GBSDeepeningResponseDocuments();
            doc.setDocumentType(objDocument.getDocumentType());
            doc.setDocumentCode(objDocument.getDocumentCode());
            doc.setDocumentNumber(objDocument.getDocumentNumber());
            doc.setSequenceNumber(objDocument.getSeqNo());
            doc.setDocumentReceiveDate(objDocument.getDocumentReceiveDt());
            doc.setDocumentSignatoryDate(objDocument.getDocumentSignatoryDt());
            doc.setDocumentExpiryDate(objDocument.getDocumentExpDt());
            doc.setTaxResidenceCountry(objDocument.getTaxResidenceCountry());
            doc.setW8nSupportDocumentIndicator(objDocument.getW8nSupportDocumentIndicator());
            doc.setCountryTreaty(objDocument.getCountryTreaty());
            doc.setDocumentEvidenceLink(objDocument.getDocumentEvidenceLink());
            doc.setDocRemarks(objDocument.getDocRemarks());
            doc.setDocReasonCode(objDocument.getDocReasonCode());
            doc.setExpiryCheckOverride(objDocument.getExpiryCheckOverride());
            doc.setPoiDocument(objDocument.getPoiDocument());
            listDocuments.add(doc);
        }
        return listDocuments;
    }

    private GBSDeepeningResponseCDD setCDD(ICMCustomerCreateCDD  icmCDD){
        GBSDeepeningResponseCDD cdd = new GBSDeepeningResponseCDD();
        cdd.setCddRiskRating(icmCDD.getCddRiskCode());
        cdd.setCddLastReviewDate(icmCDD.getCddLastReviewDt());
        cdd.setCddNextReviewDate(icmCDD.getCddNextReviewDt());
        cdd.setCddReviewStatus(icmCDD.getCddReviewStatus());
        cdd.setCddReason(icmCDD.getCddReason());
        cdd.setSddEligibleDate(icmCDD.getSddEligibleDate());
        cdd.setSddEligibleStatus(icmCDD.getSddEligibleStatus());
        cdd.setCddRiskRatingDate(icmCDD.getCddRiskRatingDate());
        cdd.setCountryLastReviewDate(icmCDD.getCountryLRD());
        cdd.setCountryNextReviewDate(icmCDD.getCountryNRD());
        cdd.setCountryReviewStatus(icmCDD.getCountryReviewStatus());
        cdd.setCddReviewedFlag(icmCDD.getCddReviewedFlag());
        cdd.setCddLastReviewedBy(icmCDD.getCddLastReviewedBy());
        cdd.setSenderId(icmCDD.getSenderId());
        cdd.setSenderBranch(icmCDD.getSenderBranch());
        cdd.setIcddReference(icmCDD.getIcddReferenceNumber());
        cdd.setCupidReference(icmCDD.getCupidReferenceNumber());
        cdd.setCrsReference(icmCDD.getCrsReference());
        cdd.setCrsStatus(icmCDD.getCrsStatus());
        cdd.setCrsRemarks(icmCDD.getCrsRemarks());
        cdd.setCrsCreatedTimeStamp(icmCDD.getCrsCreatedTimeStamp());
        cdd.setCrsUpdatedTimeStamp(icmCDD.getCrsUpdatedTimeStamp());
        return cdd;
    }
    private List<GBSDeepeningResponseContacts> setContacts(List<ICMCustomerCreateContacts> icmContacts){
        List<GBSDeepeningResponseContacts> listContacts = new ArrayList<>();
        for(ICMCustomerCreateContacts objContacts: icmContacts) {
            GBSDeepeningResponseContacts contacts = new GBSDeepeningResponseContacts();
            contacts.setContact(objContacts.getContact());
            contacts.setContactClassificationCode(objContacts.getContactClassificationCode());
            contacts.setContactTypeCode(objContacts.getContactTypeCode());
            contacts.setAreaCode(objContacts.getAreaCode());
            contacts.setExtensionDetail(objContacts.getExtensionDet());
            contacts.setPreferredContact(objContacts.getPreferredContact());
            contacts.setDoNotDisturbRegistry(objContacts.getDndRegistry());
            contacts.setDoNotDisturbExpiryDate(objContacts.getDndExpiryDt());
            contacts.setPreferredContact(objContacts.getPreferredContact());
            contacts.setPrimaryContact(objContacts.getPrimaryContact());
            contacts.setAttentionParty(objContacts.getAttentionParty());
            contacts.setIsdContactCountryCode(objContacts.getIsdCountryCode());
            listContacts.add(contacts);
        }
        return listContacts;
    }

    private GBSDeepeningResponseTars setTars(ICMCustomerCreateTAR icmTars){
        GBSDeepeningResponseTars tars = new GBSDeepeningResponseTars();
        tars.setUsCitizen(icmTars.getUsCitizen());
        tars.setUsResident(icmTars.getUsResident());
        tars.setUsGreenCardHolder(icmTars.getUsGreenCardHolder());
        tars.setOnBoardWithDis(icmTars.getOnBoardWithDis());
        tars.setUsaIndiciaInd(icmTars.getUsaIndiciaInd());
        tars.setUsaPersonInd(icmTars.getUsaPersonInd());
        tars.setReportToIrsInd(icmTars.getReportToIRSInd());
        tars.setJointAcInd(icmTars.getJointAcInd());
        tars.setRecalcitrantInd(icmTars.getRecalcitrantInd());
        tars.setRecalcitrantIndAssignDate(icmTars.getRecalcitrantIndAssignDt());
        tars.setRecalcitrantIndClearedDate(icmTars.getRecalcitrantIndClearedDt());
        tars.setWithholdInd(icmTars.getWithholdInd());
        tars.setEnhancedReviewInd(icmTars.getEnhancedReviewInd());
        tars.setEnhancedReviewStartDate(icmTars.getEnhancedReviewStartDt());
        tars.setEnhancedReviewEndDate(icmTars.getEnhancedReviewEndDt());
        tars.setDocumentSubmittedIndicator(icmTars.getDocumentSubmittedIndicator());
        tars.setDocumentDueDate(icmTars.getDocumentDueDt());
        tars.setGstResidentStatus(icmTars.getGstResidentStatus());
        tars.setTaxResidentStatus(icmTars.getTaxResidentStatus());
        tars.setUsIndiciaDate(icmTars.getLastChangeDateForUSIndicia());
        tars.setUsPersonFlagChangedDate(icmTars.getLastChangeDateForUSPerson());
        return tars;
    }

    private GBSDeepeningResponseRiskCodes setRisks(ICMCustomerCreateRisks icmRisks){
        GBSDeepeningResponseRiskCodes risk = new GBSDeepeningResponseRiskCodes();
        List<GBSDeepeningResponseRiskDetails> riskDetailsList = new ArrayList<>();
        List<ICMCustomerCreateRisksDetails> icmRiskDetailsList = new ArrayList<>();
        for(ICMCustomerCreateRisksDetails objRiskDetails : icmRiskDetailsList){
            GBSDeepeningResponseRiskDetails riskDetails = new GBSDeepeningResponseRiskDetails();
            riskDetails.setRiskCode(objRiskDetails.getRiskCode());
            riskDetails.setRiskRemarks(objRiskDetails.getRiskReasonRemarks());
            riskDetails.setRiskStartDate(objRiskDetails.getRiskStartDate());
            riskDetails.setRiskExpiryDate(objRiskDetails.getRiskExpiryDate());
            riskDetailsList.add(riskDetails);
        }
        risk.setRiskDetails(riskDetailsList);
        return risk;
    }

    private GBSDeepeningResponseKYC setKyc(ICMCustomerCreateKYC icmKyc){
        GBSDeepeningResponseKYC kyc = new GBSDeepeningResponseKYC();
        kyc.setBirthCountry(icmKyc.getBirthCountry());
        List<GBSDeepeningResponseNationalilty> nationalityList = new ArrayList<>();
        List<ICMCustomerKYCNationality> icmCustomerKYCNationalityList = icmKyc.getNationality();
        for(ICMCustomerKYCNationality objNationality :icmCustomerKYCNationalityList){
            GBSDeepeningResponseNationalilty nationality = new GBSDeepeningResponseNationalilty();
            nationality.setNationalityCode(objNationality.getNationalityCode());
            nationalityList.add(nationality);
        }
        kyc.setNationality(nationalityList);
        return kyc;

    }

    boolean isDeepeningAllowed(ICMCustomerCreateCDD icmCDD, ICMCustomerCreateRisks risks, ICMCustomerCreateCustomer icmCustomer){
        /* Risk Codes to be considered for HK to derive the Is Deepening Allowed flag:
        HXT, HHP, HHA, HHC, PRA, CJT, CDD, FDX, UDX, EXT, CJX, B04, B03, BKC, DER, PVB
        */
        // get country from header
        // get value of risk code dynamically from DB
        String country = icmCustomer.getCustomerNationalityCode();
        // are values for risk codes stored anywhere against a particlur country or what country to consider
        String cddStatus = icmCDD.getCddReviewStatus();
        //if cddStatus==A or C return true (also check about risk code for particular country

        //else return false
        return false;
    }

}





