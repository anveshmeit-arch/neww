package com.scb.clm.services.globus.prospect.v1.model;

import java.util.Date;
import java.util.Objects;

import com.scb.clm.common.util.StringUtility;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/*
 * 
 *  @author      1378958
 *  @version     1.0
 *  @since       
 *  @use         
 */
@Entity
@Table(name = "GBS_PROSPECT_CONTACTS")
public class ProspectContactEntity implements Cloneable
{
    @EmbeddedId
    private ProspectContactEntityKey id;

    @Column(name="CONTACT")
    private String contact;

    @Column(name="CONTACT_CLASSIFICATION_CODE")
    private String contactClassificationCode;
    
    @Column(name="CONTACT_COUNTRY_CODE")
    private String countryCode;
    
    @Column(name="CONTACT_AREA_CODE")
    private String areaCode;
    
    @Column(name="CONTACT_EXTENSION")
    private String extensionDetail;
    
    @Column(name="PREFERRED_CONTACT")
    private String preferredContact;
    
    @Column(name="PRIMARY_CONTACT")
    private String primaryContact;
    
    @Column(name="DND_REGISTRY")
    private String doNotDisturbRegistry;
    
    @Column(name="DND_EXPIRY_DATE")
    private Date doNotDisturbExpiryDate;
    
    @Column(name="ATTENTION_PARTY")
    private String attentionParty;
    
    @Column(name="ISD_COUNTRY_CODE")
    private String isdContactCountryCode;
    
    @ManyToOne
    @JoinColumns({
        @JoinColumn(name="COUNTRY_CODE", referencedColumnName="COUNTRY_CODE", insertable= false, updatable= false),
        @JoinColumn(name="PROSPECT_ID", referencedColumnName="PROSPECT_ID",insertable= false, updatable=false)
    })
    private ProspectEntity contactMapper;

    public ProspectContactEntity() {
    }

    public ProspectContactEntity(ProspectContactEntityKey id) {
        this.id = (ProspectContactEntityKey) id.clone();
    }
    public ProspectContactEntityKey getId() {
        return (ProspectContactEntityKey) id.clone();
    }
    public void setId(ProspectContactEntityKey id) {
        this.id = (ProspectContactEntityKey) id.clone();
    }


    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = StringUtility.toUpperCase(contact);
    }

    public String getContactClassificationCode() {
        return contactClassificationCode;
    }

    public void setContactClassificationCode(String contactClassificationCode) {
        this.contactClassificationCode = StringUtility.toUpperCase(contactClassificationCode);
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = StringUtility.toUpperCase(countryCode);
    }

    public String getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(String areaCode) {
        this.areaCode = StringUtility.toUpperCase(areaCode);
    }

    public String getExtensionDetail() {
        return extensionDetail;
    }

    public void setExtensionDetail(String extensionDetail) {
        this.extensionDetail = StringUtility.toUpperCase(extensionDetail);
    }

    public String getPreferredContact() {
        return preferredContact;
    }

    public void setPreferredContact(String preferredContact) {
        this.preferredContact = StringUtility.toUpperCase(preferredContact);
    }

    public String getPrimaryContact() {
        return primaryContact;
    }

    public void setPrimaryContact(String primaryContact) {
        this.primaryContact = StringUtility.toUpperCase(primaryContact);
    }

    public String getDoNotDisturbRegistry() {
        return doNotDisturbRegistry;
    }

    public void setDoNotDisturbRegistry(String doNotDisturbRegistry) {
        this.doNotDisturbRegistry = doNotDisturbRegistry;
    }

    public Date getDoNotDisturbExpiryDate() {
        return doNotDisturbExpiryDate;
    }

    public void setDoNotDisturbExpiryDate(Date doNotDisturbExpiryDate) {
        this.doNotDisturbExpiryDate = doNotDisturbExpiryDate;
    }

    public String getAttentionParty() {
        return attentionParty;
    }

    public void setAttentionParty(String attentionParty) {
        this.attentionParty = StringUtility.toUpperCase(attentionParty);
    }

    public String getIsdContactCountryCode() {
        return isdContactCountryCode;
    }

    public void setIsdContactCountryCode(String isdContactCountryCode) {
        this.isdContactCountryCode = StringUtility.toUpperCase(isdContactCountryCode);
    }

    @Override
    public int hashCode() {
        return this.getId().hashCode();
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        ProspectContactEntity prospectContactEntity=(ProspectContactEntity) super.clone();
        prospectContactEntity.setId((ProspectContactEntityKey) this.getId().clone());
        return prospectContactEntity;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof ProspectContactEntity)) {
            return false;
        }
        return Objects.equals(this.getId(), ((ProspectContactEntity) obj).getId());
    }

    public void synchronizeThisWith( ProspectContactEntity argProspectContactEntity) 
    {       
        this.setContact(argProspectContactEntity.getContact());
        this.setContactClassificationCode(argProspectContactEntity.getContactClassificationCode());
        this.setCountryCode(argProspectContactEntity.getCountryCode());
        this.setAreaCode(argProspectContactEntity.getAreaCode());
        this.setExtensionDetail(argProspectContactEntity.getExtensionDetail());
        this.setPreferredContact(argProspectContactEntity.getPreferredContact());
        this.setPrimaryContact(argProspectContactEntity.getPrimaryContact());
        this.setDoNotDisturbRegistry(argProspectContactEntity.getDoNotDisturbRegistry());
        this.setDoNotDisturbExpiryDate(argProspectContactEntity.getDoNotDisturbExpiryDate());
        this.setAttentionParty(argProspectContactEntity.getAttentionParty());
        this.setIsdContactCountryCode(argProspectContactEntity.getIsdContactCountryCode());
    }
}
