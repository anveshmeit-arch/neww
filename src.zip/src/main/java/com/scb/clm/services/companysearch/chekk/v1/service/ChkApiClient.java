package com.scb.clm.services.companysearch.chekk.v1.service;

import java.net.http.HttpResponse;
import java.util.Arrays;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.clm.services.companysearch.chekk.v1.exception.RetryException;
import com.scb.clm.services.companysearch.chekk.v1.model.ChkCreateRequest;
import com.scb.clm.services.companysearch.chekk.v1.model.ChkGetRequest;
import com.scb.clm.services.companysearch.chekk.v1.model.ChkSearchRequest;
import com.scb.clm.services.companysearch.chekk.v1.support.ChkApiType;
import com.scb.clm.services.companysearch.chekk.v1.support.ChkConfigProperties;
import com.scb.clm.services.companysearch.chekk.v1.support.JsonParserUtil;
import com.scb.clm.services.companysearch.chekk.v1.support.ProcessApiConstants;
import com.scb.clm.services.companysearch.chekk.v1.support.Retrier;

@Service
public class ChkApiClient {
    @Autowired
    private ChkConfigProperties configProps;

    @Autowired
    private ChkTokenManager tknManager;

    @Autowired
    private RestApiClient client;

    @Autowired
    private ChkResponseValidator responseValidator;

    public ChkApiResponse invokeSearchApi(ChkSearchRequest searchRequest) {
        String requestJson = JsonParserUtil.toJson(searchRequest);
        ChkApiResponse responseJson = invokeApiWithRetrier(ChkApiType.SEARCH, configProps.getSearchCompanyUrl(),
                requestJson);
        return responseJson;
    }

    public ChkApiResponse invokeCreateApi(ChkCreateRequest createRequest) {
        String requestJson = JsonParserUtil.toJson(createRequest);
        ChkApiResponse responseJson = invokeApiWithRetrier(ChkApiType.CREATE, configProps.getCreateCustomerfileUrl(),
                requestJson);
        return responseJson;
    }

    public ChkApiResponse invokeGetApi(ChkGetRequest getRequest) {
        String requestJson = JsonParserUtil.toJson(getRequest);
        ChkApiResponse responseJson = invokeApiWithRetrier(ChkApiType.GET, configProps.getGetCustomerfileUrl(),
                requestJson);
        return responseJson;
    }

    private Map<String, String> getApiHeaders() {
        Map<String, String> tknHeaders = tknManager.getChkTokenHeaders();
        tknHeaders.put(ProcessApiConstants.CONTENT_TYPE, ProcessApiConstants.APPLICATION_JSON);
        return tknHeaders;
    }

    private ChkApiResponse invokeApiWithRetrier(ChkApiType apiType, String url, String requestJson) {
        HttpResponse<String> httpResponse = new Retrier<String, HttpResponse<String>>("input", input -> {
            HttpResponse<String> tmpResponse = client.callApi(url, getApiHeaders(), requestJson);
            responseValidator.isRetryRequired(tmpResponse.statusCode(), tmpResponse.body(), apiType);
            return tmpResponse;
        }, configProps.getRetryCount(), configProps.getRetryDelay()).execute(Arrays.asList(RetryException.class));
        String responseJson = client.getResponseBody(httpResponse);
        return new ChkApiResponse(apiType, httpResponse.statusCode(), responseJson);
    }

    private void printMap(Map<String, String> header) {
        for (Map.Entry<String, String> entry : header.entrySet()) {
            String key = entry.getKey();
            String val = entry.getValue();
        }
    }

}
