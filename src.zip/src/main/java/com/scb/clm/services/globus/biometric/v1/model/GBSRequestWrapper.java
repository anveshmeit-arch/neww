package com.scb.clm.services.globus.biometric.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSRequestWrapper implements Cloneable
{
	@JsonProperty("application")
	private GBSRequestApplication application;

	public GBSRequestApplication getApplication() {
		return application;
	}

	public void setApplication(GBSRequestApplication application) {
		this.application = application;
	}
	
	@Override
	protected Object clone() {
		try {
			return super.clone();
		} catch (CloneNotSupportedException e) {
			return new GBSRequestWrapper();
		}
	}

}