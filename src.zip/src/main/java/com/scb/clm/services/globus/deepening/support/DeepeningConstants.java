package com.scb.clm.services.globus.deepening.support;

public class DeepeningConstants {
    public static final String INVALID_JSON_FORMAT                    = "DP000001";
    public static final String INVALID_APPLICATION_REFERENCE_NUMBER   = "DP000002";
    public static final String INVALID_CORE_BANKING_REFERENCE_KEY     = "DP000003";
    public static final String INTERNAL_ERROR                         = "DP000004";
    public static final String REQUEST_INCOMPATABLE_WITH_DEEPENING_SERVICE = "DP000005";
    public static final String DEEPENING_FLOW                         = "FDPNING";
    public static final String DEEPENING_INTERFACE_ID         = "ICM";
    public static final String SERVICE_DEEPENING			  = "SDEEPN";
    public static final String CLM_REQUEST_ERROR                      = "OB000001";
    public static final String RESPONSE_CONSTRUCTION_ERROR = "DP000006";

}
