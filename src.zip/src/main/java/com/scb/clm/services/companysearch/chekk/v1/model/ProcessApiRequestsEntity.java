package com.scb.clm.services.companysearch.chekk.v1.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "CLM_INBOUND_REQUESTS")
@Getter
@Setter
public class ProcessApiRequestsEntity {

	@Id
    @Column(name="REQUEST_ID")
    private String requestId;

    @Column(name="COUNTRY_CODE")
    private String countryCode;

    @Column(name="INTERFACE_ID")
    private String interfaceId;
    
    @Column(name="TRACKING_ID")
    private String trackingID;

}

