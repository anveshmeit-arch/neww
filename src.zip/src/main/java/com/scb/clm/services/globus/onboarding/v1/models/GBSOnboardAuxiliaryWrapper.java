package com.scb.clm.services.globus.onboarding.v1.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSOnboardAuxiliaryWrapper {

	@JsonProperty("code")
	private String auxiliary_code;
	
	@JsonProperty("value")
	private String auxiliary_value;

	public String getAuxiliary_code() {
		return auxiliary_code;
	}

	public void setAuxiliary_code(String auxiliary_code) {
		this.auxiliary_code = auxiliary_code;
	}

	public String getAuxiliary_value() {
		return auxiliary_value;
	}

	public void setAuxiliary_value(String auxiliary_value) {
		this.auxiliary_value = auxiliary_value;
	}
}
