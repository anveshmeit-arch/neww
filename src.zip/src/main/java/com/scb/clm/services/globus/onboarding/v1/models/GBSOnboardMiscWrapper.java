package com.scb.clm.services.globus.onboarding.v1.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSOnboardMiscWrapper {

    @JsonProperty("code")
    private String misc_code;

    @JsonProperty("value")
    private String misc_value;

    public String getMisc_code() {
        return misc_code;
    }

    public void setMisc_code(String misc_code) {
        this.misc_code = misc_code;
    }

    public String getMisc_value() {
        return misc_value;
    }

    public void setMisc_value(String misc_value) {
        this.misc_value = misc_value;
    }
}
