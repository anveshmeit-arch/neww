package com.scb.clm.services.global.customer.v1.model;

import java.sql.Timestamp;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/*
 * 
 *  @author      1378958
 *  @version     1.0
 *  @since       
 *  @use         
 */
@Entity
@Table(name = "GLOBAL_CUSTOMER_LINKAGE")
public class GlobalCustomersEntity implements Cloneable
{
    @Id
    @Column(name = "SEQ_NO")
    private String sequenceNumber;

    @Column(name="GLOBAL_ID")
    private String globalIdentifier;
    
    @Column(name="BASE_COUNTRY")
    private String baseCountry;

    @Column(name="RELATIONSHIP_COUNTRY")
    private String relationshipCountry;

    @Column(name="PROFILE_ID")
    private String profileId;

    @Column(name="RELATIONSHIP_ID")
    private String relationshipId;

    @Column(name="VALIDATED_BY")
    private String validatedBy;

    @Column(name="STATUS_FLAG")
    private String statusFlag;

    @Column(name="CREATED_DATE")
    private Timestamp createdDate;

    @Column(name="CREATED_BY")
    private String createdBy;
    
    @Column(name="UPDATED_DATE")
    private Timestamp updatedDate;

    @Column(name = "APPLICATION_REFERENCE")
    private String applicationReferenceNumber;

    public GlobalCustomersEntity() {
    } 

    public GlobalCustomersEntity(String sequenceNumber) 
    {
        super();
        this.sequenceNumber = sequenceNumber;
    } 

    public String getSequenceNumber() {
        return sequenceNumber;
    }

    public void setSequenceNumber(String sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public String getGlobalIdentifier() {
        return globalIdentifier;
    }

    public void setGlobalIdentifier(String globalIdentifier) {
        this.globalIdentifier = globalIdentifier;
    }

    public String getBaseCountry() {
        return baseCountry;
    }

    public void setBaseCountry(String baseCountry) {
        this.baseCountry = baseCountry;
    }

    public String getRelationshipCountry() {
        return relationshipCountry;
    }

    public void setRelationshipCountry(String relationshipCountry) {
        this.relationshipCountry = relationshipCountry;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getRelationshipId() {
        return relationshipId;
    }

    public void setRelationshipId(String relationshipId) {
        this.relationshipId = relationshipId;
    }

    public String getValidatedBy() {
        return validatedBy;
    }

    public void setValidatedBy(String validatedBy) {
        this.validatedBy = validatedBy;
    }

    public String getStatusFlag() {
        return statusFlag;
    }

    public void setStatusFlag(String statusFlag) {
        this.statusFlag = statusFlag;
    }

    public Timestamp getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Timestamp createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getApplicationReferenceNumber()
    {
        return applicationReferenceNumber;
    }

    public void setApplicationReferenceNumber(String applicationReferenceNumber)
    {
        this.applicationReferenceNumber = applicationReferenceNumber;
    }

    public void synchronizeThisWith(GlobalCustomersEntity argGlobalCustomersEntity)
    {
        if(argGlobalCustomersEntity!=null)
        {
            this.setGlobalIdentifier(argGlobalCustomersEntity.getGlobalIdentifier());
            this.setBaseCountry(argGlobalCustomersEntity.getBaseCountry());
            this.setRelationshipCountry(argGlobalCustomersEntity.getRelationshipCountry());
            this.setProfileId(argGlobalCustomersEntity.getProfileId());
            this.setRelationshipId(argGlobalCustomersEntity.getRelationshipId());
            this.setValidatedBy(argGlobalCustomersEntity.getValidatedBy());
            this.setStatusFlag(argGlobalCustomersEntity.getStatusFlag());
            this.setCreatedDate(argGlobalCustomersEntity.getCreatedDate());
            this.setCreatedBy(argGlobalCustomersEntity.getCreatedBy());
            this.setUpdatedDate(argGlobalCustomersEntity.getUpdatedDate());
            this.setApplicationReferenceNumber(argGlobalCustomersEntity.getApplicationReferenceNumber());
        }
    }

    @Override
    public boolean equals(Object obj) 
    {
        if (this == obj) { return true; }  
        if (obj == null || getClass() != obj.getClass()) {return false;}  
        GlobalCustomersEntity that = (GlobalCustomersEntity) obj;
        
        return Objects.equals(sequenceNumber, that.sequenceNumber);  
    }

    @Override
    public int hashCode() 
    {
        return Objects.hash(sequenceNumber);  
    }

    @Override
    public GlobalCustomersEntity clone() 
    {
        try 
        {
            return (GlobalCustomersEntity) super.clone();  
        } 
        catch (CloneNotSupportedException e) 
        {
            throw new AssertionError("Cloning not supported", e);  
        }
    }

    @Override
    public String toString() 
    {
        return "GlobalCustomersEntity{" +
                "sequenceNumber='" + sequenceNumber + '\'' +
                '}';
    }
}
