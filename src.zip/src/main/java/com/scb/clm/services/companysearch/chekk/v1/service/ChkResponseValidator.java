package com.scb.clm.services.companysearch.chekk.v1.service;

import org.springframework.stereotype.Service;

import com.scb.clm.common.exception.ErrorObject;
import com.scb.clm.services.companysearch.chekk.v1.exception.RetryException;
import com.scb.clm.services.companysearch.chekk.v1.support.ChkApiType;
import com.scb.clm.services.companysearch.chekk.v1.support.JsonParserUtil;
import com.scb.clm.services.companysearch.chekk.v1.support.Log;

@Service
public class ChkResponseValidator {
	private static final String JSON_KEY_MESSAGE = "message";
	private static final String JSON_KEY_ERROR = "error";
	private static final String JSON_KEY_ERROR_CODE = "error_code";
	
	public static final String ERRCODE_UNAUTHORIZED_TOKENEXPIRED = "Ck007";
	public static final String ERRCODE_INVALID_PATH = "Ck008";
	public static final String ERRCODE_INTERNAL_ERROR = "Ck009";
	public static final String CONNECTION_FAILURE = "Connectivity Issue";
	public static final String ERRCODE_INVALID_DATA = "Ck010";
	public static final String ERRCODE_INVALID_CLIENT = "Ck011";
	public static final String ERROR_TYPE_VALIDATION = "VAL";
	public static final String ERROR_TYPE_TECHNICAL = "TEC";

	public void isRetryRequired(int resCode) {
		if (resCode == 401 || resCode == 500 || resCode == 404) {
			throw new RetryException("Retry");
		}
	}

	public void isRetryRequired(int resCode,String response,ChkApiType apiType) {
		if (resCode == 401 || resCode == 500 ) {
			throw new RetryException("Retry");
		}
		
		//errorCode = FER_51_12 and error=API call is still pending then retry 
		if(resCode==200 && ChkApiType.GET==apiType && isApiCallPending(response)) {
			Log.info("ChkResponseValidator#isRetryRequired: API call is still pending. Retry after some time");
			throw new RetryException("API call is still pending. Retry after some time");
		}
	}
	
	private boolean isApiCallPending(String response) {
	    Log.info("ChkResponseValidator#isApiCallPending:  Inside API call is pending....");
		String errorCode = JsonParserUtil.getNodeValue(response, JSON_KEY_ERROR_CODE);
		String error = JsonParserUtil.getNodeValue(response, JSON_KEY_ERROR);
		return (errorCode.equals("FER_51_12") || error.equalsIgnoreCase("API call is still pending"));
	}
	
	public ErrorObject validateResponseCode(int resCode, String resData) {
		ErrorObject errObj = null;
		String errorMsg = getErrorMessage(resData);
		if (!errorMsg.isEmpty()) {
			String errorType = "";
			String errorCode = "";
			if (resCode == 400) {
				errorType = ERROR_TYPE_VALIDATION;
				errorCode = "";
			} else if (resCode == 401) {
				errorType = ERROR_TYPE_VALIDATION;
				errorCode = ERRCODE_UNAUTHORIZED_TOKENEXPIRED;

			} else if (resCode == 403) {
				errorType = ERROR_TYPE_VALIDATION;
				errorCode = ERRCODE_INVALID_PATH;
			} else if (resCode == 500) {
				errorType = ERROR_TYPE_TECHNICAL;
				errorCode = ERRCODE_INTERNAL_ERROR;
			}
			errObj = new ErrorObject(errorType, errorCode, errorMsg);
		}
		return errObj;
	}

	private String getErrorMessage(String errorBody) {
		StringBuilder errorMessage = new StringBuilder();
		String message = JsonParserUtil.getNodeValue(errorBody, JSON_KEY_MESSAGE);
		if(!message.isEmpty() && !"OK".equalsIgnoreCase(message)) {
			errorMessage.append(message);
		}
		String error = JsonParserUtil.getNodeValue(errorBody, JSON_KEY_ERROR);
		//for success message field will have "OK", so need to ignore it. 
		if (!error.isEmpty()) {
			errorMessage.append(errorMessage.isEmpty() ? " " + error : error);
		}
		return errorMessage.toString();
	}

}
