package com.scb.clm.services.globus.icm.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;


public class ICMCustomerCreateRequestData {

    @JsonProperty("type") 
    String type;

    @JsonProperty("attributes") 
    private ICMCustomerCreateRequestAttributes attributes;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public ICMCustomerCreateRequestAttributes getAttributes() {
        return attributes;
    }

    public void setAttributes(ICMCustomerCreateRequestAttributes attributes) {
        this.attributes = attributes;
    }
}
