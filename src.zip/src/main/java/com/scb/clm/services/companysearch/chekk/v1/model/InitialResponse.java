package com.scb.clm.services.companysearch.chekk.v1.model;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InitialResponse {

	@JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty("errorDetails")
    private List<ErrorDetails> errordetails;
    
	@JsonInclude(JsonInclude.Include.NON_NULL)
	@JsonProperty("entityData")
    private EntityData entityData;
    

	public List<ErrorDetails> getErrordetails() {
        return (errordetails == null)?null:(errordetails.stream().collect(Collectors.toList()));
    }

    public void setErrordetails(List<ErrorDetails> errordetails) {
        this.errordetails = errordetails;
    }
    
    public void addErrors(ErrorDetails argErrors) {
        if(this.errordetails == null) {
            this.errordetails= new ArrayList<ErrorDetails>();     
        }
        this.errordetails.add(argErrors);
    }

}
