package com.scb.clm.services.companysearch.chekk.v1.model;

import java.io.Serializable;
import java.util.Objects;

import com.scb.clm.common.model.codesetup.CountryParametersEntityKey;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.EmbeddedId;

@Embeddable
public class ChkSolaceConfigEntityKey implements Serializable, Cloneable {

	@Column(name = "country_code", nullable = false, insertable = false, updatable = false)
	private String countryCode;

	@Column(name = "interface_id", nullable = false, insertable = false, updatable = false)
	private String interfaceId;

	public ChkSolaceConfigEntityKey() {
		
	}
	
	public ChkSolaceConfigEntityKey(String countryCode, String interfaceId) {
		this.countryCode = countryCode;
		this.interfaceId = interfaceId;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getInterfaceId() {
		return interfaceId;
	}

	public void setInterfaceId(String interfaceId) {
		this.interfaceId = interfaceId;
	}

	@Override
	public int hashCode() {
		StringBuilder finalHashCode = new StringBuilder();
		if (this.countryCode != null && this.interfaceId != null) {
			finalHashCode.append(countryCode);
			finalHashCode.append(interfaceId);
		}
		return finalHashCode.toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if ((obj == null) || (obj.getClass() != this.getClass())) {
			return false;
		}
		ChkSolaceConfigEntityKey other = (ChkSolaceConfigEntityKey) obj;
		return Objects.equals(this.countryCode, other.countryCode)
				&& Objects.equals(this.interfaceId, other.interfaceId);
	}

	@Override
	public Object clone() {
		try {
			return (ChkSolaceConfigEntityKey) super.clone();
		} catch (CloneNotSupportedException e) {
			return new ChkSolaceConfigEntityKey(this.getCountryCode(), this.getInterfaceId());
		}
	}
}
