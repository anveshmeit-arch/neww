package com.scb.clm.services.globus.onboarding.v1.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSOnboardCDDComplianceWrapper {

	@JsonProperty("numberOfDeposits")
	private String numberOfDeposits;
	
	@JsonProperty("valueOfDeposits")
	private String valueOfDeposits;
	
	@JsonProperty("numberOfWithdrawals")
	private String numberOfWithdrawals;
	
	@JsonProperty("valueOfWithdrawals")
	private String valueOfWithdrawals;
	
	@JsonProperty("clientSourceOfFund")
	private String clientSourceOfFund;
	
	@JsonProperty("clientSourceOfFundOth")
	private String clientSourceOfFundOth;	
	
	@JsonProperty("purposeOfAccountOpeningOffshore")
	private String purposeOfAccountOpeningOffshore;
	
	@JsonProperty("purposeOfAccountOpeningOffshoreOthers")
	private String purposeOfAccountOpeningOffshoreOthers;

    public String getNumberOfDeposits() {
        return numberOfDeposits;
    }

    public void setNumberOfDeposits(String numberOfDeposits) {
        this.numberOfDeposits = numberOfDeposits;
    }

    public String getValueOfDeposits() {
        return valueOfDeposits;
    }

    public void setValueOfDeposits(String valueOfDeposits) {
        this.valueOfDeposits = valueOfDeposits;
    }

    public String getNumberOfWithdrawals() {
        return numberOfWithdrawals;
    }

    public void setNumberOfWithdrawals(String numberOfWithdrawals) {
        this.numberOfWithdrawals = numberOfWithdrawals;
    }

    public String getValueOfWithdrawals() {
        return valueOfWithdrawals;
    }

    public void setValueOfWithdrawals(String valueOfWithdrawals) {
        this.valueOfWithdrawals = valueOfWithdrawals;
    }

    public String getClientSourceOfFund() {
        return clientSourceOfFund;
    }

    public void setClientSourceOfFund(String clientSourceOfFund) {
        this.clientSourceOfFund = clientSourceOfFund;
    }

    public String getClientSourceOfFundOth() {
        return clientSourceOfFundOth;
    }

    public void setClientSourceOfFundOth(String clientSourceOfFundOth) {
        this.clientSourceOfFundOth = clientSourceOfFundOth;
    }

    public String getPurposeOfAccountOpeningOffshore() {
        return purposeOfAccountOpeningOffshore;
    }

    public void setPurposeOfAccountOpeningOffshore(String purposeOfAccountOpeningOffshore) {
        this.purposeOfAccountOpeningOffshore = purposeOfAccountOpeningOffshore;
    }

    public String getPurposeOfAccountOpeningOffshoreOthers() {
        return purposeOfAccountOpeningOffshoreOthers;
    }

    public void setPurposeOfAccountOpeningOffshoreOthers(String purposeOfAccountOpeningOffshoreOthers) {
        this.purposeOfAccountOpeningOffshoreOthers = purposeOfAccountOpeningOffshoreOthers;
    }


}
