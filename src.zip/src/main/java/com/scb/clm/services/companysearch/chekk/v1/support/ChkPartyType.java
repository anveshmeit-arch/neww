package com.scb.clm.services.companysearch.chekk.v1.support;

public enum ChkPartyType {
	MAIN_ENTITY, COMPANY, INDIVIDUAL,NONE;
}
