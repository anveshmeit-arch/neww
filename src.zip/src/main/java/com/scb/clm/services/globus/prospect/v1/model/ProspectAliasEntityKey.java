package com.scb.clm.services.globus.prospect.v1.model;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

/*
 * 
 * @author       1378958
 * @version      1.0
 * @since           
 * @use          
 */
@Embeddable
public class ProspectAliasEntityKey implements Serializable,Cloneable
{
    private static final long serialVersionUID = 1103847698360379355L;

    @Column(name = "COUNTRY_CODE", nullable = false ,insertable=false, updatable=false)
    private String countryCode;

    @Column(name = "PROSPECT_ID", nullable = false ,insertable=false, updatable=false)
    private String prospectID;

    @Column(name = "ALIAS_TYPE", nullable = false ,insertable=false, updatable=false)
    private String aliasType;
    
    @Column(name = "SEQUENCE_NUMBER", nullable = false ,insertable=false, updatable=false)
    private String sequenceNumber;

    public ProspectAliasEntityKey() {

    }

    public ProspectAliasEntityKey (String countryCode,String prospectID,String aliasType, String sequenceNumber) {
        this.countryCode    = countryCode;
        this.prospectID     = prospectID;
        this.aliasType      = aliasType;
        this.sequenceNumber = sequenceNumber;
    }


    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getProspectID() {
        return prospectID;
    }

    public void setProspectID(String prospectID) {
        this.prospectID = prospectID;
    }

    public String getAliasType() {
        return aliasType;
    }

    public void setAliasType(String aliasType) {
        this.aliasType = aliasType;
    }

    public String getSequenceNumber() {
        return sequenceNumber;
    }

    public void setSequenceNumber(String sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    @Override
    public int hashCode() {
        StringBuilder finalHashCode = new StringBuilder();
        if (this.countryCode != null && this.prospectID != null && this.aliasType !=null && this.sequenceNumber!=null) 
        {
            finalHashCode.append(countryCode);
            finalHashCode.append(prospectID);
            finalHashCode.append(aliasType);
            finalHashCode.append(sequenceNumber);            
        }
        return finalHashCode.toString().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
        {
            return true;
        }
        if ((obj == null) || (obj.getClass() != this.getClass())) 
        {
            return false;
        }
        ProspectAliasEntityKey other = (ProspectAliasEntityKey) obj;
        return   Objects.equals(this.countryCode, other.countryCode) 
                && Objects.equals(this.prospectID, other.prospectID)
                && Objects.equals(this.aliasType, other.aliasType)
                && Objects.equals(this.sequenceNumber, other.sequenceNumber);
    }

    @Override
    public Object clone() {
        try {
            return (ProspectAliasEntityKey) super.clone();
        } catch (CloneNotSupportedException e) {
            return new ProspectAliasEntityKey(this.getCountryCode(),this.getProspectID(),this.getAliasType(), this.getSequenceNumber());
        }
    }    
}
