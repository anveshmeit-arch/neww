package com.scb.clm.services.ekyc.pushekycdata.v1.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PusheKYCJointCustomerStakeHolders {
	
	@JsonProperty("stakeholders")
	private List<PusheKYCJointCustomerStakeHoldersList> listStakeholders;

	public List<PusheKYCJointCustomerStakeHoldersList> getListStakeholders() {
		return listStakeholders;
	}

	public void setListStakeholders(List<PusheKYCJointCustomerStakeHoldersList> listStakeholders) {
		this.listStakeholders = listStakeholders;
	}


}
