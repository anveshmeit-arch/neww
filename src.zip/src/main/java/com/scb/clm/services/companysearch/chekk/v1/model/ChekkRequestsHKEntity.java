package com.scb.clm.services.companysearch.chekk.v1.model;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

import com.scb.clm.common.model.transactions.AbstractPersistableEntity;
import com.scb.clm.common.model.transactions.LoggerInterface;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/*
 * 
 *  @author      
 *  @version     1.0
 *  @since       
 *  @use         
 */
@Entity
@Table(name = "CHK_REQUESTS")
@Getter
@Setter
public class ChekkRequestsHKEntity extends AbstractPersistableEntity<String> implements Cloneable,LoggerInterface {

    @Id
    @Column(name="REQUEST_ID")
    private String requestId;

    @Column(name="COUNTRY_CODE")
    private String countryCode;

    @Column(name="INSTANCE_NAME")
    private String instanceName;

    @Column(name="ENTITY_NAME")
    private String entityName;

    @Column(name="APPLICATION_REFERENCE")
    private String applicationReference;

    @Column(name="REGISTRATION_ID")
    private String registrationId;

    @Column(name="CLIENT_ENTITY_TYPE")
    private String clientEntityType;

    @Column(name="COUNTRY_OF_REGISTRATION")
    private String countryOfRegistration;
    
    @Column(name="SEARCH_DEPTH")
    private Integer searchDepth;

    @Column(name="COUNTRY_ACCOUNT_OPEN")
    private String countryAccountOpen;

    @Column(name="CREATED_ON")
    private Timestamp createdOn;   

    @Column(name="UPDATED_ON")
    private Timestamp updatedOn;

    @Column(name="STATUS")
    private String status;

    @OneToMany(fetch=FetchType.LAZY,mappedBy="chekkSearchEntityQEntityMapper")
    @Cascade({CascadeType.ALL})
    private Set<ChekkSearchEntityQHKEntity> chekkSearchEntityQEntitySet = new HashSet<>();

    @OneToMany(fetch=FetchType.LAZY,mappedBy="chekkResponseDataEntityMapper")
    @Cascade({CascadeType.ALL})
    private Set<ChekkResponseDataHKEntity> chekkResponseDataEntitySet;    

    @OneToMany(fetch=FetchType.LAZY,mappedBy="chekkPartyEntityMapper")
    @Cascade({CascadeType.ALL})
    private Set<ChekkPartyHKEntity> chekkPartyEntitySet;
    
    public ChekkRequestsHKEntity() {

    }

    public ChekkRequestsHKEntity(String requestId) {
        this.requestId = requestId;
    }
    
    @Override
    public String getId() 
    {
        return this.requestId;
    }

    @Override
    public int hashCode() {
        StringBuilder finalHashCode = new StringBuilder();
        if (this.requestId != null) 
        {
            finalHashCode.append(requestId);
        }
        return finalHashCode.toString().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
        {
            return true;
        }
        if ((obj == null) || (obj.getClass() != this.getClass())) 
        {
            return false;
        }
        ChekkRequestsHKEntity other = (ChekkRequestsHKEntity) obj;
        return Objects.equals(this.requestId, other.requestId);
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return (ChekkRequestsHKEntity) super.clone();
    }   

}
