package com.scb.clm.services.globus.icm.v1.model;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ICMCustomerCreateCDD {


    @JsonProperty("cdd-risk-rating")
    private String cddRiskCode;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @JsonProperty("cdd-last-review-date")
    private Date cddLastReviewDt;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @JsonProperty("cdd-next-review-date")
    private Date cddNextReviewDt;

    @JsonProperty("cdd-review-status")
    private String cddReviewStatus;

    @JsonProperty("cdd-reason")
    private String cddReason;

    @JsonProperty("sdd-eligible-status")
    private String sddEligibleStatus;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @JsonProperty("sdd-eligible-date")
    private Date sddEligibleDate;

    @JsonProperty("country-id")
    private String companyId;

    @JsonProperty("icdd-reference")
    private String icddReferenceNumber;

    @JsonProperty("cupid-reference")
    private String cupidReferenceNumber;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @JsonProperty("cdd-risk-rating-date")
    private Date cddRiskRatingDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @JsonProperty("country-last-review-date")
    private Date countryLRD;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @JsonProperty("country-next-review-date")
    private Date countryNRD;

    @JsonProperty("country-review-status")
    private String countryReviewStatus;

    @JsonProperty("cdd-reviewed-flag")
    private String cddReviewedFlag;

    @JsonProperty("cdd-last-reviewed-by")
    private String cddLastReviewedBy;

    @JsonProperty("sender-id")
    private String senderId;

    @JsonProperty("sender-branch")
    private String senderBranch;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    @JsonProperty("created-at")
    private Timestamp createdAt;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    @JsonProperty("updated-at")
    private Timestamp updatedAt;

    @JsonProperty("status")
    private String status;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    @JsonProperty("status-at")
    private Timestamp statusAt;

    @JsonProperty("id")
    private String guid;

    @JsonProperty("reference-id")
    private String profileId;

    @JsonProperty("crs-reference")
    private String crsReference;

    @JsonProperty("crs-remarks")
    private String crsRemarks;

    @JsonProperty("crs-status")
    private String crsStatus;

    @JsonProperty("crs-created-time-tamp")
    private String crsCreatedTimeStamp;

    @JsonProperty("crs-updated-time-stamp")
    private String crsUpdatedTimeStamp;

    private List<ErrorDetails> errordetails;

    public String getCddRiskCode() {
        return cddRiskCode;
    }

    public void setCddRiskCode(String cddRiskCode) {
        this.cddRiskCode = cddRiskCode;
    }

    public Date getCddLastReviewDt() {
        return cddLastReviewDt;
    }

    public void setCddLastReviewDt(Date cddLastReviewDt) {
        this.cddLastReviewDt = cddLastReviewDt;
    }

    public Date getCddNextReviewDt() {
        return cddNextReviewDt;
    }

    public void setCddNextReviewDt(Date cddNextReviewDt) {
        this.cddNextReviewDt = cddNextReviewDt;
    }

    public String getCddReviewStatus() {
        return cddReviewStatus;
    }

    public void setCddReviewStatus(String cddReviewStatus) {
        this.cddReviewStatus = cddReviewStatus;
    }

    public String getCddReason() {
        return cddReason;
    }

    public void setCddReason(String cddReason) {
        this.cddReason = cddReason;
    }

    public String getSddEligibleStatus() {
        return sddEligibleStatus;
    }

    public void setSddEligibleStatus(String sddEligibleStatus) {
        this.sddEligibleStatus = sddEligibleStatus;
    }

    public Date getSddEligibleDate() {
        return sddEligibleDate;
    }

    public void setSddEligibleDate(Date sddEligibleDate) {
        this.sddEligibleDate = sddEligibleDate;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getIcddReferenceNumber() {
        return icddReferenceNumber;
    }

    public void setIcddReferenceNumber(String icddReferenceNumber) {
        this.icddReferenceNumber = icddReferenceNumber;
    }

    public String getCupidReferenceNumber() {
        return cupidReferenceNumber;
    }

    public void setCupidReferenceNumber(String cupidReferenceNumber) {
        this.cupidReferenceNumber = cupidReferenceNumber;
    }

    public Date getCddRiskRatingDate() {
        return cddRiskRatingDate;
    }

    public void setCddRiskRatingDate(Date cddRiskRatingDate) {
        this.cddRiskRatingDate = cddRiskRatingDate;
    }

    public Date getCountryLRD() {
        return countryLRD;
    }

    public void setCountryLRD(Date countryLRD) {
        this.countryLRD = countryLRD;
    }

    public Date getCountryNRD() {
        return countryNRD;
    }

    public void setCountryNRD(Date countryNRD) {
        this.countryNRD = countryNRD;
    }

    public String getCountryReviewStatus() {
        return countryReviewStatus;
    }

    public void setCountryReviewStatus(String countryReviewStatus) {
        this.countryReviewStatus = countryReviewStatus;
    }

    public String getCddReviewedFlag() {
        return cddReviewedFlag;
    }

    public void setCddReviewedFlag(String cddReviewedFlag) {
        this.cddReviewedFlag = cddReviewedFlag;
    }

    public String getCddLastReviewedBy() {
        return cddLastReviewedBy;
    }

    public void setCddLastReviewedBy(String cddLastReviewedBy) {
        this.cddLastReviewedBy = cddLastReviewedBy;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public String getSenderBranch() {
        return senderBranch;
    }

    public void setSenderBranch(String senderBranch) {
        this.senderBranch = senderBranch;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getStatusAt() {
        return statusAt;
    }

    public void setStatusAt(Timestamp statusAt) {
        this.statusAt = statusAt;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getCrsReference() {
        return crsReference;
    }

    public void setCrsReference(String crsReference) {
        this.crsReference = crsReference;
    }

    public String getCrsRemarks() {
        return crsRemarks;
    }

    public void setCrsRemarks(String crsRemarks) {
        this.crsRemarks = crsRemarks;
    }

    public String getCrsStatus() {
        return crsStatus;
    }

    public void setCrsStatus(String crsStatus) {
        this.crsStatus = crsStatus;
    }

    public String getCrsCreatedTimeStamp() {
        return crsCreatedTimeStamp;
    }

    public void setCrsCreatedTimeStamp(String crsCreatedTimeStamp) {
        this.crsCreatedTimeStamp = crsCreatedTimeStamp;
    }

    public String getCrsUpdatedTimeStamp() {
        return crsUpdatedTimeStamp;
    }

    public void setCrsUpdatedTimeStamp(String crsUpdatedTimeStamp) {
        this.crsUpdatedTimeStamp = crsUpdatedTimeStamp;
    }

    public List<ErrorDetails> getErrordetails() {
        return errordetails;
    }

    public void setErrordetails(List<ErrorDetails> errordetails) {
        this.errordetails = errordetails;
    }

}
