package com.scb.clm.services.global.customer.v1.service;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.stereotype.Service;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ErrorObject;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.repository.CountryCodeRepository;
import com.scb.clm.common.util.JSONUtility;
import com.scb.clm.common.util.StringUtility;
import com.scb.clm.core.service.ServiceAbstract;
import com.scb.clm.core.service.ServiceInterface;
import com.scb.clm.services.global.customer.v1.model.GlobalCustomersEnquiryContent;
import com.scb.clm.services.global.customer.v1.model.GlobalCustomersEnquiryErrorDetails;
import com.scb.clm.services.global.customer.v1.model.GlobalCustomersEnquiryResponseWrapper;
import com.scb.clm.services.global.customer.v1.model.GlobalCustomersEntity;
import com.scb.clm.services.global.customer.v1.repository.GlobalCustomersRepository;
import com.scb.clm.services.global.customer.v1.support.GlobalCustomersConstants;


@Service
@Configurable
public class GlobalCustomersEnquiryService extends ServiceAbstract implements ServiceInterface
{

    @Autowired
    CountryCodeRepository countryCodeRepository;

    @Autowired
    GlobalCustomersRepository globalCustomersRepository;

    static final Map<String, String> allowedFilterKeys = new HashMap<String, String>() {{
        put("applicationReferenceNumber", "isAlphaNumericSpecialChar");
        put("baseCountry", "isAlphaNumericSpecialChar");
        put("globalIdentifier", "isAlphaNumericSpecialChar");
        put("relationshipNumber", "isAlphaNumericSpecialChar");
        put("profileId", "isAlphaNumericSpecialChar");
    }};
    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object readRequestObject(TravellingObject travellingObject, NodeServicesEntity srvEntity) throws ProcessException 
    {
        return null;    
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public void validateData(TravellingObject travellingObject,NodeServicesEntity srvEntity,Object requestPayload)  throws ProcessException 
    {
        List<ErrorObject> errorObjectList = new ArrayList<ErrorObject>();
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateData", LogType.APPLICATION.name());

        try 
        {
            log.println("Global Customer - Filter Conditions : "+JSONUtility.domainWrapperToJSON(travellingObject.getFilterMap()));

            if(travellingObject.getFilterMap()!=null && travellingObject.getFilterMap().size() >0)
            {
                for (Entry<String, List<String>> entry : travellingObject.getFilterMap().entrySet()) 
                {
                    log.println("Filter Key : ["+entry.getKey()+"] - Value : ["+allowedFilterKeys.get(entry.getKey())+"]");
                    if(allowedFilterKeys.get(entry.getKey()) == null) 
                    {
                        errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.INVALID_FILTER_CONDITION,"INVALID FILTER KEY INPUT ["+entry.getKey()+"] "));
                        continue;
                    }  

                    if(!StringUtility.isAlphaNumeric(entry.getKey()))
                    {
                        errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.INVALID_FILTER_CONDITION,"INVALID FILTER KEY ["+entry.getKey()+"] "));
                        continue;
                    }

                    if (allowedFilterKeys.get(entry.getKey()).trim().length()!=0)
                    {
                        log.println("Validating Key : ["+entry.getKey()+"] - Value : ["+allowedFilterKeys.get(entry.getKey())+"]");
                        Method m = StringUtility.class.getDeclaredMethod(allowedFilterKeys.get(entry.getKey()), String.class);

                        for(String data : entry.getValue()) 
                        {
                            if(! (Boolean) (m.invoke(null, data))) 
                            {
                                errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.INVALID_FILTER_CONDITION,"INVALID FILTER KEY VALUE ["+data+"] "));							
                            }
                        }
                    }
                    log.println("Parameter List Key ["+entry.getKey()+"] Value ["+entry.getValue()+"]");
                }
            }

            if(errorObjectList.size()> 0)
            {
                ProcessException gbxEx = new ProcessException();
                gbxEx.addAll(errorObjectList);
                throw gbxEx;
            }

        }
        catch(ProcessException e)
        {
            log.println(" Error ["+e.getAllErrors()+"]");
            throw e;
        }
        catch(Exception e)
        {
            log.printErrorMessage(e);
            errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_TECHNICAL, GlobalCustomersConstants.INTERNAL_PROCESSING_ERROR,"Internal Error"));
            ProcessException gbxEx = new ProcessException();
            gbxEx.addAll(errorObjectList);
            throw gbxEx; 
        }
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object constructOutboundObject(TravellingObject travellingObject,NodeServicesEntity srvEntity,Object requestPayload) throws ProcessException
    {
        return null;
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    public Object process(TravellingObject travellingObject,NodeServicesEntity srvEntity,ServiceStatus serviceStatus,Object processPayload) throws ProcessException
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "process", LogType.APPLICATION.name());

        List<GlobalCustomersEnquiryContent> enquiryResults = new ArrayList<GlobalCustomersEnquiryContent>();
        log.println("Global Customer Enquiry Service");
        try
        {
            if(!getHttpMethod(travellingObject).equalsIgnoreCase(BaseConstants.HTTP_GET))
            {
                throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL, GlobalCustomersConstants.INVALID_HTTP_STATUS,"INVALID HTTP STATUS");
            }
            enquiryResults =  doEnquiry(travellingObject);
            serviceStatus.setHttpStatus(String.valueOf(BaseConstants.HTTP_200));
            serviceStatus.setInterfaceId(travellingObject.getInterfaceId());
            log.println("Global Customer JSON "+JSONUtility.domainWrapperToJSON(processPayload));
        }
        catch (ProcessException e)
        {
            log.printErrorMessage(e);
            throw e;
        }
        catch (Exception e)
        {
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL, GlobalCustomersConstants.INTERNAL_PROCESSING_ERROR,"INTERNAL ERROR WHILE SERVICE PROCESSING");
        }
        return enquiryResults;
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @SuppressWarnings("unchecked")
    @Override
    public Object constructServiceResponse(TravellingObject travellingObject,NodeServicesEntity srvEntity,Object processedData,ServiceStatus serviceStatus) throws ProcessException 
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "constructServiceResponse", LogType.APPLICATION.name());
        GlobalCustomersEnquiryResponseWrapper responseWrapper = new GlobalCustomersEnquiryResponseWrapper();

        try
        {
            List<GlobalCustomersEnquiryContent> enquiryResults = (List<GlobalCustomersEnquiryContent>) processedData;
            responseWrapper.setCustomers(enquiryResults);

            if(serviceStatus!=null && serviceStatus.getErrorObject()!=null && serviceStatus.getErrorObject().size() >0)
            { 
                for(ErrorObject errorObject : serviceStatus.getErrorObject())
                {
                    responseWrapper.addErrors(new GlobalCustomersEnquiryErrorDetails((String)errorObject.getCode(),(String)errorObject.getDescription()));
                }
            } 
        }
        catch(Exception e)
        {
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.RESPONSE_CONSTRUCTION_ERROR,"INTERNAL ERROR WHILE RESPONSE CONSTRUCTION");
        }
        finally
        {
            //N.A
        }
        return responseWrapper;
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    private String getHttpMethod(TravellingObject trObj) {
        String httpMethod = trObj.getServiceContext().getHttpMethod();
        if(httpMethod == null || httpMethod.equalsIgnoreCase(BaseConstants.HTTP_GET)) {
            return BaseConstants.HTTP_GET;
        } else if(httpMethod.equalsIgnoreCase(BaseConstants.HTTP_POST)) {
            return BaseConstants.HTTP_POST;
        } else if(httpMethod.equalsIgnoreCase(BaseConstants.HTTP_PUT)) {
            return BaseConstants.HTTP_PUT;
        } else if(httpMethod.equalsIgnoreCase(BaseConstants.HTTP_DELETE)) {
            return BaseConstants.HTTP_DELETE;
        }
        return "";
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @throws ProcessException 
     * @exception
     * @see
     * @since
     */
    private List<GlobalCustomersEnquiryContent> doEnquiry(TravellingObject trObj) throws ProcessException
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "getDataWithParam", LogType.APPLICATION.name());
        log.println("Inside getDataWithParam using JPA");
        List<GlobalCustomersEnquiryContent> enquiryResults = new ArrayList<GlobalCustomersEnquiryContent>();

        try
        {
            List<String> baseCountryList 			    = new ArrayList<>();
            List<String> applicationRefList 			= new ArrayList<>();
            List<String> globalIDRefList 				= new ArrayList<>();
            List<String> profileIDRefList 				= new ArrayList<>();
            List<String> relationshipRefList 			= new ArrayList<>();
            List<GlobalCustomersEntity> id                 = new ArrayList<GlobalCustomersEntity>();

            log.println("[Global Customer Enquiry] ParameterList : "+trObj.getFilterMap());

            for (Entry<String, List<String>> parameter1 : trObj.getFilterMap().entrySet())
            {
                String key              = parameter1.getKey();
                List<String> valueList  = parameter1.getValue();
                String[] splitValues    = valueList.get(0).split(",");
                switch (key) 
                {
                case "baseCountry":
                    baseCountryList = List.of(splitValues);
                    break;
                    case "applicationReferenceNumber":
                        applicationRefList = List.of(splitValues);
                        break;
                case "globalIdentifier":
                    globalIDRefList = List.of(splitValues);
                    break;
                case "relationshipNumber":
                    relationshipRefList = List.of(splitValues);
                    break;
                case "profileId":
                    profileIDRefList = List.of(splitValues);
                    break;
                default:
                    break;
                }
            }

            validateFilterDataPoints(new List[]{applicationRefList, globalIDRefList, relationshipRefList, profileIDRefList});

            if(baseCountryList==null || baseCountryList.size()==0) {
                throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.COUNTRY_CODE_MANDATORY_ENQUIRY,"COUNTRY CODE IS MANDATORY IN REQUEST FILTERS");
            }
            if(baseCountryList!=null && baseCountryList.size()>1) {
                throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.INVALID_COUNTRY_CODE_SIZE_ENQUIRY,"NOT MORE THAN ONE COUNTRY CODE ALLOWED IN REQUEST FILTERS");
            }

            if(applicationRefList.size()>0 || globalIDRefList.size()>0 || relationshipRefList.size()>0 || profileIDRefList.size()>0)
            {
                id = globalCustomersRepository.findByFilters(applicationRefList, globalIDRefList,  relationshipRefList, profileIDRefList, baseCountryList.get(0), 0, 50);
            }
            else 
            {
                throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.RESPONSE_CONSTRUCTION_ERROR,"INTERNAL ERROR WHILE RESPONSE CONSTRUCTION");
            }

            log.println("Result Data  : "+JSONUtility.domainWrapperToJSON(id));

            for(GlobalCustomersEntity dat : id) 
            {
                GlobalCustomersEnquiryContent obj = new GlobalCustomersEnquiryContent();
                obj.setApplicationReferenceNumber(dat.getApplicationReferenceNumber());
                obj.setGlobalIdentifier(dat.getGlobalIdentifier());
                obj.setBaseCountry(dat.getBaseCountry());
                obj.setRelationshipCountry(dat.getRelationshipCountry());
                obj.setProfileId(dat.getProfileId());
                obj.setRelationshipId(dat.getRelationshipId());
                obj.setValidatedBy(dat.getValidatedBy());
                obj.setStatusFlag(dat.getStatusFlag());
                obj.setCreatedDate(dat.getCreatedDate());
                obj.setCreatedBy(dat.getCreatedBy());
                obj.setUpdatedDate(dat.getUpdatedDate());
                enquiryResults.add(obj);   
            }
        }
        catch (ProcessException e)
        {
            throw e;
        }
        catch (Exception e) 
        {
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, GlobalCustomersConstants.ENQUIRY_EXTRACTION_ERROR,"ENQUIRY EXTRACTION ERROR");
        }
        return enquiryResults;
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @throws ProcessException 
     * @exception
     * @see
     * @since
     */
    private void validateFilterDataPoints(List<? extends String>[] filterLists) throws ProcessException {
        for (List<? extends String> filterList : filterLists) {
            if (filterList.size() > GlobalCustomersConstants.MAX_FILTER_DATA_POINTS) {
                throw new ProcessException(
                        BaseConstants.ERROR_TYPE_BUSINESS,
                        GlobalCustomersConstants.COUNTRY_CODE_MANDATORY_ENQUIRY,
                        "MAXIMUM FILTER CONDITIONS CANNOT EXCEED [" + GlobalCustomersConstants.MAX_FILTER_DATA_POINTS + "]"
                        );
            }
        }
    }
}
