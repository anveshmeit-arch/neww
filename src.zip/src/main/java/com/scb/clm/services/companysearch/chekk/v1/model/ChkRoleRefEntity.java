package com.scb.clm.services.companysearch.chekk.v1.model;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "CHK_ROLE_REF")
@Getter
@Setter
public class ChkRoleRefEntity {

	@EmbeddedId
	private ChkRoleRefEntityKey id;
	
	@Column(name="role_code")
	private String roleCode;

	@Column(name="role_descr")
	private String roleDescr;

}
