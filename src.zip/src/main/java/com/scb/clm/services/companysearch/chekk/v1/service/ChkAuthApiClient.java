package com.scb.clm.services.companysearch.chekk.v1.service;

import java.net.http.HttpResponse;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.clm.services.companysearch.chekk.v1.model.ChkCognitoTokenResponse;
import com.scb.clm.services.companysearch.chekk.v1.model.ChkLoginRequest;
import com.scb.clm.services.companysearch.chekk.v1.model.ChkLoginResponse;
import com.scb.clm.services.companysearch.chekk.v1.support.ChkConfigProperties;
import com.scb.clm.services.companysearch.chekk.v1.support.JsonParserUtil;
import com.scb.clm.services.companysearch.chekk.v1.support.ProcessApiConstants;

@Service
public class ChkAuthApiClient {

    @Autowired
    private ChkConfigProperties configProps;

    @Autowired
    private RestApiClient client;

    private Map<String, String> getCognitoHeaders() {

        Map<String, String> headers = new HashMap<>();
        headers.put(ProcessApiConstants.AUTHORIZATION, configProps.getAccountToken());
        headers.put(ProcessApiConstants.CONTENT_TYPE, ProcessApiConstants.APPLICATION_FORM_URLENCODED);
        return headers;
    }

    private Map<String, String> getLoginHeaders(String cognitoToken) {
        Map<String, String> headers = new HashMap<>();
        headers.put(ProcessApiConstants.XAUTHORIZATION,
                ProcessApiConstants.BEARER + ProcessApiConstants.SINGLE_SPACE + cognitoToken);
        headers.put(ProcessApiConstants.CONTENT_TYPE, ProcessApiConstants.APPLICATION_JSON);
        return headers;
    }

    /**
     * throw exception if any issue in retrieving token Retry is not required for
     * cognito url as it do not have any token authentication. All values are passed
     * from configuration. Throw custom runtime exception in case of any errors
     * 
     * @return
     */
    public ChkCognitoTokenResponse invokeCognitoApi() {
        HttpResponse<String> httpResponse = client.callApi(configProps.getCognitoTokenUrl(), getCognitoHeaders());
        String cognitoResPayload = client.getResponseBody(httpResponse);
        ChkCognitoTokenResponse cognitoResponse = JsonParserUtil.toObject(cognitoResPayload,
                ChkCognitoTokenResponse.class);
        return cognitoResponse;
    }

    public ChkLoginResponse invokeLoginApi(String cognitoToken) {
        ChkLoginRequest chekkLoginRequest = new ChkLoginRequest(configProps.getLoginUsername(),
                configProps.getLoginPassword());
        String requestLoginData = JsonParserUtil.toJson(chekkLoginRequest);
        HttpResponse<String> httpResponse = client.callApi(configProps.getLoginUrl(), getLoginHeaders(cognitoToken),
                requestLoginData);
        String loginResPayload = client.getResponseBody(httpResponse);
        ChkLoginResponse loginResponse = JsonParserUtil.toObject(loginResPayload, ChkLoginResponse.class);
        return loginResponse;
    }

}
