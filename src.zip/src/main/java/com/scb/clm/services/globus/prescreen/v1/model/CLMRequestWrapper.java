package com.scb.clm.services.globus.prescreen.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CLMRequestWrapper
{
    @JsonProperty("data") 
    CLMRequestData data;

    public CLMRequestData getData() {
        return data;
    }
    public void setData(CLMRequestData data) {
        this.data = data;
    }
}