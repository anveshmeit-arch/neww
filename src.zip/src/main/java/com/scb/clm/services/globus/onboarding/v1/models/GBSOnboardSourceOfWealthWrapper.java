package com.scb.clm.services.globus.onboarding.v1.models;

import java.util.Arrays;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonInclude(JsonInclude.Include.NON_NULL)  
public class GBSOnboardSourceOfWealthWrapper {

    @JsonProperty("primarySource")
    private String primarySource;

    @JsonProperty("occupationCode")
    private String occupationCode;

    @JsonProperty("employerName")
    private String employerName;

    @JsonProperty("employerAddress")
    private String employerAddress;

    @JsonProperty("employmentIncome")
    private String employmentIncome;

    @JsonProperty("employmentIncomeCurrency")
    private String employmentIncomeCurrency;

    @JsonProperty("businessType")
    private String businessType;

    @JsonProperty("businessName")
    private String businessName;

    @JsonProperty("businessAddress")
    private String businessAddress;

    @JsonProperty("businessIncome")
    private String businessIncome;

    @JsonProperty("businessIncomeCurrency")
    private String businessIncomeCurrency;

    @JsonProperty("investments")
    private String[] investments;


    @JsonProperty("savingsFrom")
    private String[] savingsFrom;

    @JsonProperty("previousCompanyName")
    private String previousCompanyName;

    @JsonProperty("relationshipWithFundingMember")
    private String relationshipWithFundingMember;

    @JsonProperty("fundingMemberEmployeeName")
    private String fundingMemberEmployeeName;


    @JsonProperty("relationshipWithBenefactor")
    private String relationshipWithBenefactor;

    @JsonProperty("benefactorEmployeeName")
    private String benefactorEmployeeName;

    @JsonProperty("sowArticulation")
    private String sowArticulation;


    public String getPrimarySource() {
        return primarySource;
    }


    public void setPrimarySource(String primarySource) {
        this.primarySource = primarySource;
    }


    public String getOccupationCode() {
        return occupationCode;
    }


    public void setOccupationCode(String occupationCode) {
        this.occupationCode = occupationCode;
    }


    public String getEmployerName() {
        return employerName;
    }


    public void setEmployerName(String employerName) {
        this.employerName = employerName;
    }


    public String getEmployerAddress() {
        return employerAddress;
    }


    public void setEmployerAddress(String employerAddress) {
        this.employerAddress = employerAddress;
    }


    public String getEmploymentIncome() {
        return employmentIncome;
    }


    public void setEmploymentIncome(String employmentIncome) {
        this.employmentIncome = employmentIncome;
    }


    public String getEmploymentIncomeCurrency() {
        return employmentIncomeCurrency;
    }


    public void setEmploymentIncomeCurrency(String employmentIncomeCurrency) {
        this.employmentIncomeCurrency = employmentIncomeCurrency;
    }


    public String getBusinessType() {
        return businessType;
    }


    public void setBusinessType(String businessType) {
        this.businessType = businessType;
    }


    public String getBusinessName() {
        return businessName;
    }


    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }


    public String getBusinessAddress() {
        return businessAddress;
    }


    public void setBusinessAddress(String businessAddress) {
        this.businessAddress = businessAddress;
    }


    public String getBusinessIncome() {
        return businessIncome;
    }


    public void setBusinessIncome(String businessIncome) {
        this.businessIncome = businessIncome;
    }


    public String getBusinessIncomeCurrency() {
        return businessIncomeCurrency;
    }


    public void setBusinessIncomeCurrency(String businessIncomeCurrency) {
        this.businessIncomeCurrency = businessIncomeCurrency;
    }


    public String[] getInvestments() {
        return investments;
    }


    public void setInvestments(String[] investments) {
        this.investments = investments;
    }


    public String[] getSavingsFrom() {
        return savingsFrom;
    }


    public void setSavingsFrom(String[] savingsFrom) {
        this.savingsFrom = savingsFrom;
    }


    public String getPreviousCompanyName() {
        return previousCompanyName;
    }


    public void setPreviousCompanyName(String previousCompanyName) {
        this.previousCompanyName = previousCompanyName;
    }


    public String getRelationshipWithFundingMember() {
        return relationshipWithFundingMember;
    }


    public void setRelationshipWithFundingMember(String relationshipWithFundingMember) {
        this.relationshipWithFundingMember = relationshipWithFundingMember;
    }


    public String getFundingMemberEmployeeName() {
        return fundingMemberEmployeeName;
    }


    public void setFundingMemberEmployeeName(String fundingMemberEmployeeName) {
        this.fundingMemberEmployeeName = fundingMemberEmployeeName;
    }


    public String getRelationshipWithBenefactor() {
        return relationshipWithBenefactor;
    }


    public void setRelationshipWithBenefactor(String relationshipWithBenefactor) {
        this.relationshipWithBenefactor = relationshipWithBenefactor;
    }


    public String getBenefactorEmployeeName() {
        return benefactorEmployeeName;
    }


    public void setBenefactorEmployeeName(String benefactorEmployeeName) {
        this.benefactorEmployeeName = benefactorEmployeeName;
    }

    public String getSowArticulation() {
        return sowArticulation;
    }

    public void setSowArticulation(String sowArticulation) {
        this.sowArticulation = sowArticulation;
    }

    @Override
    public String toString() {
        return "GBSOnboardSourceOfWealthWrapper [primary_source=" + primarySource + ", occupation_code="
                + occupationCode + ", employer_name=" + employerName + ", employer_address=" + employerAddress
                + ", employment_income=" + employmentIncome + ", employment_income_currency="
                + employmentIncomeCurrency + ", business_type=" + businessType + ", business_name=" + businessName
                + ", business_address=" + businessAddress + ", business_income=" + businessIncome
                + ", business_income_currency=" + businessIncomeCurrency + ", investments="
                + Arrays.toString(investments) + ", savings_from=" + Arrays.toString(savingsFrom)
                + ", previous_company_name=" + previousCompanyName + ", relationship_with_funding_member="
                + relationshipWithFundingMember + ", funding_member_employee_name=" + fundingMemberEmployeeName
                + ", relationship_with_benefactor=" + relationshipWithBenefactor + ", benefactor_employee_name="
                + benefactorEmployeeName + ", getPrimary_source()=" + getPrimarySource() + ", getOccupation_code()="
                + getOccupationCode() + ", getEmployer_name()=" + getEmployerName() + ", getEmployer_address()="
                + getEmployerAddress() + ", getEmployment_income()=" + getEmploymentIncome()
                + ", getEmployment_income_currency()=" + getEmploymentIncomeCurrency() + ", getBusiness_type()="
                + getBusinessType() + ", getBusiness_name()=" + getBusinessName() + ", getBusiness_address()="
                + getBusinessAddress() + ", getBusiness_income()=" + getBusinessIncome()
                + ", getBusiness_income_currency()=" + getBusinessIncomeCurrency() + ", getInvestments()="
                + Arrays.toString(getInvestments()) + ", getSavings_from()=" + Arrays.toString(getSavingsFrom())
                + ", getPrevious_company_name()=" + getPreviousCompanyName()
                + ", getRelationship_with_funding_member()=" + getRelationshipWithFundingMember()
                + ", getFunding_member_employee_name()=" + getFundingMemberEmployeeName()
                + ", getRelationship_with_benefactor()=" + getRelationshipWithBenefactor()
                + ", getBenefactor_employee_name()=" + getBenefactorEmployeeName() + ", getClass()=" + getClass()
                + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
    }

}
