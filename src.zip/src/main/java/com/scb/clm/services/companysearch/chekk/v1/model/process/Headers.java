package com.scb.clm.services.companysearch.chekk.v1.model.process;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Headers {

	@JsonProperty("transactionID")
	public String transactionID;
	
	@JsonProperty("interfaceId")
	public String interfaceId;
	
	@JsonProperty("countryCode")
	public String countryCode;
}
