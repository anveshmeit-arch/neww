package com.scb.clm.services.globus.icm.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Error {
	
	@JsonProperty("status")
	public String status;
	
	@JsonProperty("title")
    public String title;
	
	@JsonProperty("detail")
    public String detail;
    
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}

}
