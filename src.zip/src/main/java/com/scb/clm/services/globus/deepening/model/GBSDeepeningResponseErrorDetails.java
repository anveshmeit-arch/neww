package com.scb.clm.services.globus.deepening.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSDeepeningResponseErrorDetails {
    @JsonProperty("errorCode")
    String errorcode;

    @JsonProperty("errorDescription")
    String errordescription;

    public GBSDeepeningResponseErrorDetails(String errorcode, String errordescription) {
        this.errorcode = errorcode;
        this.errordescription = errordescription;
    }

    public String getErrorcode() {
        return errorcode;
    }

    public void setErrorcode(String errorcode) {
        this.errorcode = errorcode;
    }

    public String getErrordescription() {
        return errordescription;
    }

    public void setErrordescription(String errordescription) {
        this.errordescription = errordescription;
    }
}
