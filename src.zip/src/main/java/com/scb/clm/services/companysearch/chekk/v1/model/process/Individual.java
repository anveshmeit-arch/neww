package com.scb.clm.services.companysearch.chekk.v1.model.process;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Individual {

	@JsonProperty("individualID")
	public String individualID;
	@JsonProperty("firstName")
	public String firstName;
	@JsonProperty("countryOfResidence")
	public String countryOfResidence;
	@JsonProperty("nationality")
	public List<String> nationality;
	@JsonProperty("percentageOfOwnershipAgainstParent")
	public String percentageOfOwnershipAgainstParent;

}