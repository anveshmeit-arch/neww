package com.scb.clm.services.globus.prescreen.v1.service;

import java.util.List;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.codesetup.NodeServicesEntityKey;
import com.scb.clm.common.model.codesetup.NodesEntity;
import com.scb.clm.common.model.transactions.NodeStatus;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.util.JSONUtility;
import com.scb.clm.core.service.DecisionMakerInterface;

public class PreScreenDecisionMaker implements DecisionMakerInterface
{

	private static final String DEDUPE_SERVICE_ID = "SDEDUP";
	private static final String DEDUPE_NODE="NDEDUP";

	@Override
	public void isGoodToProceed(TravellingObject travelObj,NodesEntity nodesEntity,List<NodeServicesEntity> service,NodeStatus nodeStatus)
	{
		try
		{
			for(NodeServicesEntity services :  service) {
				ServiceStatus stat = travelObj.getServiceStatus(services.getId());
				if(!stat.getStatus().equals(BaseConstants.SERVICE_SUCCESS)) {
					System.out.println("Service Failed For "+stat.printKey());
					nodeStatus.setProcessToNextNode(false);
				}
			}
			System.out.println("Pre-Screen Decision Maker - Service Success Status ["+((nodeStatus.isProcessToNextNode())?"Success":"Failure")+"]");

		}
		catch(Exception e)
		{
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "isGoodToProceed", LogType.APPLICATION.name());
			log.printErrorMessage(e);

		}
		finally
		{
			//N.A
		} 
	}

	@Override
	public void buildResponse(TravellingObject travelObj,NodesEntity nodesEntity,List<NodeServicesEntity> service,boolean isSuccess) throws ProcessException
	{
		try
		{
			System.out.println("Building Response Data ["+isSuccess+"]");
			if(isSuccess) {
				travelObj.setResponseData(buildSuccessResponse(travelObj,nodesEntity,service));
			} else {
				travelObj.setResponseData(buildFailureResponse(travelObj,nodesEntity,service));
			}
		}
		catch(Exception e)
		{
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "buildResponse", LogType.APPLICATION.name());
			log.printErrorMessage(e);

			throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,BaseConstants.CLM_REQUEST_ERROR,"DECISION MAKER - INTERNAL ERROR");
		}
		finally
		{

		}
	}

	private Object buildSuccessResponse(TravellingObject travelObj,NodesEntity nodesEntity,List<NodeServicesEntity> service) throws ProcessException
	{
		try
		{
			System.out.println("Success - "+JSONUtility.domainWrapperToJSON(travelObj));

			return (travelObj.getServiceStatus(new NodeServicesEntityKey(
					nodesEntity.getId().getCountryCode(), 
					nodesEntity.getId().getFlowIdentifier(), 
					DEDUPE_NODE, 
					DEDUPE_SERVICE_ID))).getResponsePayload();
		}
		catch(Exception e)
		{
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "buildSuccessResponse", LogType.APPLICATION.name());
			log.printErrorMessage(e);

			throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,BaseConstants.CLM_REQUEST_ERROR,"DECISION MAKER - INTERNAL ERROR");
		}
		finally
		{

		}
	}

	private Object buildFailureResponse(TravellingObject travelObj,NodesEntity nodesEntity,List<NodeServicesEntity> service)
	{
		try
		{
			System.out.println("Fail -"+JSONUtility.domainWrapperToJSON(travelObj));
			return (travelObj.getServiceStatus(new NodeServicesEntityKey(
					nodesEntity.getId().getCountryCode(), 
					nodesEntity.getId().getFlowIdentifier(), 
					DEDUPE_NODE,
					DEDUPE_SERVICE_ID))).getResponsePayload();
		}
		catch(Exception e)
		{
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "buildFailureResponse", LogType.APPLICATION.name());
			log.printErrorMessage(e);

		}
		finally
		{

		}
		return null;
	}
}
