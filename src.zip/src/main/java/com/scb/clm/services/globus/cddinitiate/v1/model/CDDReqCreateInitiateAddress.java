package com.scb.clm.services.globus.cddinitiate.v1.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
@JsonInclude(JsonInclude.Include.NON_NULL)  
public class CDDReqCreateInitiateAddress {

    @JsonProperty("address-type")
    private String address_type;

    @JsonProperty("address-line1")
    private String address_line1;

    @JsonProperty("address-line2")
    private String address_line2;

    @JsonProperty("address-line3")
    private String address_line3;

    @JsonProperty("city-name")
    private String city_name;

    @JsonProperty("country-code")
    private String country_code;

    @JsonProperty("state")
    private String state;

    @JsonProperty("postal-code")
    private String postal_code;

    @JsonProperty("nearest-landmark")
    private String nearest_landmark;

    @JsonProperty("po-box")
    private String po_box;




    public String getAddress_type() {
        return address_type;
    }

    public void setAddress_type(String address_type) {
        this.address_type = address_type;
    }

    public String getAddress_line1() {
        return address_line1;
    }

    public void setAddress_line1(String address_line1) {
        this.address_line1 = address_line1;
    }

    public String getAddress_line2() {
        return address_line2;
    }

    public void setAddress_line2(String address_line2) {
        this.address_line2 = address_line2;
    }

    public String getCity_name() {
        return city_name;
    }

    public void setCity_name(String city_name) {
        this.city_name = city_name;
    }

    public String getCountry_code() {
        return country_code;
    }

    public void setCountry_code(String country_code) {
        this.country_code = country_code;
    }

    @Override
    public String toString() {
        return "CDDReq_Create_Iniate_Address [address_type=" + address_type + ", address_line1=" + address_line1
                + ", address_line2=" + address_line2 + ", city_name=" + city_name + ", country_code=" + country_code
                + "]";
    }

    public String getAddress_line3() {
        return address_line3;
    }

    public void setAddress_line3(String address_line3) {
        this.address_line3 = address_line3;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getPostal_code() {
        return postal_code;
    }

    public void setPostal_code(String postal_code) {
        this.postal_code = postal_code;
    }

    public String getNearest_landmark() {
        return nearest_landmark;
    }

    public void setNearest_landmark(String nearest_landmark) {
        this.nearest_landmark = nearest_landmark;
    }

    public String getPo_box() {
        return po_box;
    }

    public void setPo_box(String po_box) {
        this.po_box = po_box;
    }
}
