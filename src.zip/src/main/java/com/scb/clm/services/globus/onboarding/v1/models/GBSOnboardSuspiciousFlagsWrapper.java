package com.scb.clm.services.globus.onboarding.v1.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSOnboardSuspiciousFlagsWrapper {

    @JsonProperty("adverseFlag")
    private String adverseFlag;

    @JsonProperty("pepFlag")
    private String pepFlag;

    @JsonProperty("pepDetails")
    private String pepDetails;

    @JsonProperty("sanctionFlag")
    private String sanctionFlag;

    public String getAdverseFlag() {
        return adverseFlag;
    }

    public void setAdverseFlag(String adverseFlag) {
        this.adverseFlag = adverseFlag;
    }

    public String getPepFlag() {
        return pepFlag;
    }

    public void setPepFlag(String pepFlag) {
        this.pepFlag = pepFlag;
    }

    public String getPepDetails() {
        return pepDetails;
    }

    public void setPepDetails(String pepDetails) {
        this.pepDetails = pepDetails;
    }

    public String getSanctionFlag() {
        return sanctionFlag;
    }

    public void setSanctionFlag(String sanctionFlag) {
        this.sanctionFlag = sanctionFlag;
    }
}
