package com.scb.clm.services.companysearch.chekk.v1.model;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Getter;
import lombok.Setter;

@Embeddable
@Getter
@Setter
public class ChkRoleRefEntityKey implements Serializable, Cloneable {

	@Column(name = "PARTY_TYPE", nullable = false, insertable = false, updatable = false)
	private String partyType;

	@Column(name = "ROLE_CODE", nullable = false, insertable = false, updatable = false)
	private String roleCode;

	public ChkRoleRefEntityKey() {

	}

	public ChkRoleRefEntityKey(String partyType, String roleCode) {
		this.partyType = partyType;
		this.roleCode = roleCode;
	}

	@Override
	public int hashCode() {
		StringBuilder finalHashCode = new StringBuilder();
		if (this.partyType != null && this.roleCode != null) {
			finalHashCode.append(partyType);
			finalHashCode.append(roleCode);
		}
		return finalHashCode.toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if ((obj == null) || (obj.getClass() != this.getClass())) {
			return false;
		}
		ChkRoleRefEntityKey other = (ChkRoleRefEntityKey) obj;
		return Objects.equals(this.partyType, other.partyType) && Objects.equals(this.roleCode, other.roleCode);
	}

	@Override
	public Object clone() {
		try {
			return super.clone();
		} catch (CloneNotSupportedException e) {
			return new ChkRoleRefEntityKey(this.partyType, this.roleCode);
		}
	}
}
