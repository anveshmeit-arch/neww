package com.scb.clm.services.globus.prospect.v1.model;

import java.util.Objects;

import com.scb.clm.common.util.StringUtility;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/*
 * 
 *  @author      1378958
 *  @version     1.0
 *  @since       
 *  @use         
 */
@Entity
@Table(name = "GBS_PROSPECT_ALIAS")
public class ProspectAliasEntity implements Cloneable
{
    @EmbeddedId
    private ProspectAliasEntityKey id;

    @Column(name="ALIAS_NAME")
    private String aliasName;

    
    @ManyToOne
    @JoinColumns({
        @JoinColumn(name="COUNTRY_CODE", referencedColumnName="COUNTRY_CODE", insertable= false, updatable= false),
        @JoinColumn(name="PROSPECT_ID", referencedColumnName="PROSPECT_ID",insertable= false, updatable=false)
    })
    private ProspectEntity aliasMapper;

    public ProspectAliasEntity() {
    }

    public ProspectAliasEntity(ProspectAliasEntityKey id) {
        this.id = (ProspectAliasEntityKey) id.clone();
    }
    public ProspectAliasEntityKey getId() {
        return (ProspectAliasEntityKey) id.clone();
    }
    public void setId(ProspectAliasEntityKey id) {
        this.id = (ProspectAliasEntityKey) id.clone();
    }

    public String getAliasName() {
        return aliasName;
    }

    public void setAliasName(String aliasName) {
        this.aliasName = StringUtility.toUpperCase(aliasName);
    }

    @Override
    public int hashCode() {
        return this.getId().hashCode();
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        ProspectAliasEntity prospectAliasEntity=(ProspectAliasEntity) super.clone();
        prospectAliasEntity.setId((ProspectAliasEntityKey) this.getId().clone());
        return prospectAliasEntity;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof ProspectAliasEntity)) {
            return false;
        }
        return Objects.equals(this.getId(), ((ProspectAliasEntity) obj).getId());
    }

    public void synchronizeThisWith( ProspectAliasEntity argProspectAliasEntity) 
    {
        this.setAliasName(argProspectAliasEntity.getAliasName());
       
    }
}
