package com.scb.clm.services.companysearch.chekk.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Names {

    @JsonProperty("legal")
	private String legal;

}
