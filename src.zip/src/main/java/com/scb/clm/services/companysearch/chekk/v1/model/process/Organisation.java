package com.scb.clm.services.companysearch.chekk.v1.model.process;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Organisation {

	@JsonProperty("legal")
	public String legal;
	@JsonProperty("organisationID")
	public String organisationID;
	@JsonProperty("registrationNumber")
	public String registrationNumber;
	@JsonProperty("countryOfEstablishment")
	public String countryOfEstablishment;
	@JsonProperty("percentageOfOwnershipAgainstParent")
	public String percentageOfOwnershipAgainstParent;

}