package com.scb.clm.services.companysearch.chekk.v1.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.scb.clm.services.companysearch.chekk.v1.model.ChkRoleRefEntity;

public interface ChkRoleRefRepository extends JpaRepository<ChkRoleRefEntity, String>{

	@Override
	public List<ChkRoleRefEntity> findAll();

}
