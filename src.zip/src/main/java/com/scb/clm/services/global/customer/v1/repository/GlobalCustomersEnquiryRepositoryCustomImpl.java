package com.scb.clm.services.global.customer.v1.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.scb.clm.services.global.customer.v1.model.GlobalCustomersEntity;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;

@Repository
public class GlobalCustomersEnquiryRepositoryCustomImpl implements GlobalCustomersEnquiryRepositoryCustom 
{
 
    @PersistenceContext
    private EntityManager em;
 
    @Override
    public List<GlobalCustomersEntity> findByFilters(List<String> applicationRefList,List<String> globalIDRefList,List<String> relationshipRefList,List<String> profileIDRefList,String countryCode,int offset,int limit)
    {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<GlobalCustomersEntity> query = cb.createQuery(GlobalCustomersEntity.class);
        Root<GlobalCustomersEntity> root = query.from(GlobalCustomersEntity.class);
 
        List<Predicate> predicates = new ArrayList<>();

        if (isNotNullAndNotEmpty(applicationRefList))
        {
            predicates.add(root.get("applicationReferenceNumber").in(applicationRefList));
        }
 
        if (isNotNullAndNotEmpty(globalIDRefList)) 
        {
            predicates.add(root.get("globalIdentifier").in(globalIDRefList));
        }
 
        if (isNotNullAndNotEmpty(relationshipRefList)) 
        {
            predicates.add(root.get("relationshipId").in(relationshipRefList));
        }
 
        if (isNotNullAndNotEmpty(profileIDRefList)) 
        {
            predicates.add(root.get("profileId").in(profileIDRefList));
        }
 
        if (countryCode != null && !countryCode.isEmpty()) 
        {
            predicates.add(cb.equal(root.get("baseCountry"), countryCode));
        }
 
        query.select(root).where(cb.and(predicates.toArray(new Predicate[0])));
 
        TypedQuery<GlobalCustomersEntity> typedQuery = em.createQuery(query);
        typedQuery.setFirstResult(offset); // e.g. 0 for first page
        typedQuery.setMaxResults(limit);   // e.g. 50 for page size
 
        return typedQuery.getResultList();
    }

    private boolean isNotNullAndNotEmpty(List<?> list) {
        return list != null && !list.isEmpty();
    }
}
