package com.scb.clm.services.companysearch.chekk.v1.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.scb.clm.services.companysearch.chekk.v1.model.ChkEntityTypeRefEntity;

public interface ChkEntityTypeRefRepository extends JpaRepository<ChkEntityTypeRefEntity, String>{

}
