package com.scb.clm.services.globus.biometric.v1.service;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.scb.clm.common.config.ApplicationConfiguration;
import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ErrorObject;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.repository.InterfaceRequestTypeRepository;
import com.scb.clm.common.util.JSONUtility;
import com.scb.clm.common.util.StringUtility;
import com.scb.clm.core.service.ServiceAbstract;
import com.scb.clm.core.service.ServiceInterface;
import com.scb.clm.services.globus.biometric.v1.model.GBSRequestIdApplication;
import com.scb.clm.services.globus.biometric.v1.model.GBSRequestIdCustomers;
import com.scb.clm.services.globus.biometric.v1.model.GBSRequestIdWrapper;
import com.scb.clm.services.globus.biometric.v1.model.GBSRequestWrapper;
import com.scb.clm.services.globus.biometric.v1.support.BiometricConstants;
import com.scb.clm.services.globus.onboarding.v1.models.GBSOnboardResponseWrapper;
@Service
public class BiometricService extends ServiceAbstract implements ServiceInterface {
	@Autowired
	InterfaceRequestTypeRepository interfaceRequestTypeRepository;

	@Autowired
	ApplicationConfiguration applicationConfiguration;

	@Autowired
	RestTemplate restTemplate;

	@Override
	public Object readRequestObject(TravellingObject travellingObject, NodeServicesEntity srvEntity)
			throws ProcessException {
		// TODO Auto-generated method stub

		try {
			return JSONUtility.jsonTODomainWrapper(travellingObject.getRequestData(), GBSRequestWrapper.class);
		} catch (Exception e) {
			ProcessException gbxEx = new ProcessException();
			gbxEx.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, BaseConstants.VALIDATION_ERROR,
					"INVALID REQUEST MESSAGE FORMAT FOR BIOMETRIC SERVICE"));
			throw gbxEx;
		} finally {
			// N.A
		}
	}

	@Override
	public void validateData(TravellingObject travellingObject, NodeServicesEntity srvEntity, Object requestPayload)
			throws ProcessException {
		// TODO Auto-generated method stub

		LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateData",
				LogType.APPLICATION.name());

		List<ErrorObject> errorObjectList = new ArrayList<ErrorObject>();

		try 
		{
			log.println("[Validating] [Biometric] [Thread " + Thread.currentThread() + "]");

			GBSRequestWrapper requestWrapper = (GBSRequestWrapper) requestPayload; 

			if(requestWrapper == null)
			{
				errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_TECHNICAL, BiometricConstants.INVALID_JSON_FORMAT,"INVALID REQUEST"));
			} 
			else if( (requestWrapper.getApplication()== null || !StringUtility.containsData(requestWrapper.getApplication().getApplicationReferenceNumber()))) 
			{
				errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, BiometricConstants.INVALID_APPLICATION_REFERENCE_NUMBER,"INVALID APPLICATION REFERENCE NUMBER"));
			} 
			else {
				travellingObject.setApplicationReferenceNumber(requestWrapper.getApplication().getApplicationReferenceNumber());
			}
			if(errorObjectList.size()> 0) 
			{
				ProcessException gbxEx = new ProcessException();
				gbxEx.addAll(errorObjectList);
				throw gbxEx;
			}
		}
		catch(ProcessException e)
		{
			log.println(" Error ["+e.getAllErrors()+"]");
			throw e;
		}
		catch(Exception e)
		{
			log.printErrorMessage(e);
			errorObjectList.add(new ErrorObject(BaseConstants.ERROR_TYPE_TECHNICAL, BiometricConstants.INTERNAL_PROCESSING_ERROR,"Internal Error"));
			ProcessException gbxEx = new ProcessException();
			gbxEx.addAll(errorObjectList);
			throw gbxEx; 
		}
	}

	@Override
	public Object constructOutboundObject(TravellingObject travellingObject, NodeServicesEntity srvEntity,
			Object requestPayload) throws ProcessException {
		GBSRequestIdWrapper requestIdWrapper  = null;

		if(travellingObject.getFlowIdentifier().equalsIgnoreCase("FONBRD"))
		{
			if(travellingObject.getServiceProcessParameter(BaseConstants.ONBOARD_CREATEICM_SRV, "ONBOARDINGSTATUS").equalsIgnoreCase("COMPLETED"))
			{
				GBSRequestWrapper requestWrapper = (GBSRequestWrapper) requestPayload;
				requestIdWrapper = new GBSRequestIdWrapper();
				GBSRequestIdApplication app = new GBSRequestIdApplication();
				GBSRequestIdCustomers cust = new GBSRequestIdCustomers();
				app.setApplicationReferenceNumber(requestWrapper.getApplication().getApplicationReferenceNumber());
				requestIdWrapper.setApplication(app);
				ServiceStatus status = travellingObject.getServiceStatus().get(BaseConstants.ONBOARD_CREATEICM_SRV);
				GBSOnboardResponseWrapper responseWrapper = (GBSOnboardResponseWrapper)status.getResponsePayload();
				cust.setProfileId(responseWrapper.getCustomerMasterReferenceKey());
				cust.setRelationshipNumber(responseWrapper.getCoreBankingReferenceKey());
				requestIdWrapper.setCustomers(cust);
			}
		}
		return requestIdWrapper;
	}

	@Override
	public Object process(TravellingObject travellingObject, NodeServicesEntity srvEntity, ServiceStatus serviceStatus,
			Object processPayload) throws ProcessException {
		// TODO Auto-generated method stub

		LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "process", LogType.APPLICATION.name());

		String idSafeResponse  = null;
		try
		{ 
			if(travellingObject.getServiceProcessParameter(BaseConstants.ONBOARD_CREATEICM_SRV, "ONBOARDINGSTATUS").equalsIgnoreCase("COMPLETED"))
			{
				GBSRequestIdWrapper requestWrapper = (GBSRequestIdWrapper) processPayload;
				log.println("Out Bound Data -- : "+ requestWrapper);
				String jsonString = (String)JSONUtility.domainWrapperToJSON(requestWrapper, GBSRequestIdWrapper.class);
				log.println("Request from GLOBUS to IDV"+jsonString);
				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_JSON);
				headers.set("countryCode", travellingObject.getCountryCode());
				headers.set("interfaceId", travellingObject.getInterfaceId());
				headers.set("transactionId", travellingObject.getTransactionID());
				headers.set("X-JWT-Assertion","NO_JWT_VALIDATE");
				String hostServiceURL = interfaceRequestTypeRepository.getInterfaceURL(travellingObject.getCountryCode(), travellingObject.getInterfaceId(), BiometricConstants.REQUEST_TYPE,"IB" , "1");
				HttpEntity<String> entity = new HttpEntity<>(jsonString,headers);
				log.println(hostServiceURL);
				ResponseEntity<String> response= restTemplate.exchange(hostServiceURL,HttpMethod.POST,entity,String.class);
				idSafeResponse = response.getBody();	
				serviceStatus.setHttpStatus(String.valueOf(response.getStatusCodeValue()));
			}
			else
			{
				log.println("Since the Onboarding is Rejected we cannot proceed to idsafe");
			}
		}
		catch(HttpStatusCodeException ex)
		{  
			ex.printStackTrace();
			log.printErrorMessage(ex);
			log.println("Raw Code ["+ex.getRawStatusCode()+"] Status Code ["+ex.getStatusCode().toString()+"]");
			serviceStatus.setHttpStatus(ex.getRawStatusCode()+"");
			log.println(ex.getResponseBodyAsString());
			travellingObject.setResponseData(idSafeResponse);
		}
		catch(Exception e)
		{
			log.printErrorMessage(e);
		}
		return idSafeResponse;
	}

	@Override
	public Object constructServiceResponse(TravellingObject travellingObject, NodeServicesEntity srvEntity, Object obj,
			ServiceStatus serviceStatus) throws ProcessException {
		return obj;
	}
}

