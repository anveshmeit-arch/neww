package com.scb.clm.services.globus.cddinitiate.v1.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
@JsonInclude(JsonInclude.Include.NON_NULL)  
public class CDDReqCreateInitiateVerifyStatus {

    @JsonProperty("applicant-details-verified")
    private String applicant_details_verified;

    @JsonProperty("verification-date-time")
    private String verification_date_time;

    @JsonProperty("mode-of-verification")
    private String mode_of_verification;

    @JsonProperty("verified-by")
    private String verified_by;

    @JsonProperty("name-of-verification")
    private String name_of_verification;

    @JsonProperty("date-of-birth-verification")
    private String date_of_birth_verification;

    @JsonProperty("residence-address-verification")
    private String residence_address_verification;

    @JsonProperty("id-number-verification")
    private String id_number_verification;

    @JsonProperty("nationality-verification")
    private String nationality_verification;

    @JsonProperty("country-specific-1-verification")
    private String country_specific_1_verification;

    @JsonProperty("country-specific-2-verification")
    private String country_specific_2_verification;

    @JsonProperty("is-manual-verification")
    private Boolean is_manual_verification;

    public String getApplicant_details_verified() {
        return applicant_details_verified;
    }

    public void setApplicant_details_verified(String applicant_details_verified) {
        this.applicant_details_verified = applicant_details_verified;
    }

    public String getVerification_date_time() {
        return verification_date_time;
    }

    public void setVerification_date_time(String verification_date_time) {
        this.verification_date_time = verification_date_time;
    }

    public String getMode_of_verification() {
        return mode_of_verification;
    }

    public void setMode_of_verification(String mode_of_verification) {
        this.mode_of_verification = mode_of_verification;
    }

    public String getVerified_by() {
        return verified_by;
    }

    public void setVerified_by(String verified_by) {
        this.verified_by = verified_by;
    }

    public String getName_of_verification() {
        return name_of_verification;
    }

    public void setName_of_verification(String name_of_verification) {
        this.name_of_verification = name_of_verification;
    }

    public String getDate_of_birth_verification() {
        return date_of_birth_verification;
    }

    public void setDate_of_birth_verification(String date_of_birth_verification) {
        this.date_of_birth_verification = date_of_birth_verification;
    }

    public String getResidence_address_verification() {
        return residence_address_verification;
    }

    public void setResidence_address_verification(String residence_address_verification) {
        this.residence_address_verification = residence_address_verification;
    }

    public String getId_number_verification() {
        return id_number_verification;
    }

    public void setId_number_verification(String id_number_verification) {
        this.id_number_verification = id_number_verification;
    }

    public String getNationality_verification() {
        return nationality_verification;
    }

    public void setNationality_verification(String nationality_verification) {
        this.nationality_verification = nationality_verification;
    }

    public String getCountry_specific_1_verification() {
        return country_specific_1_verification;
    }

    public void setCountry_specific_1_verification(String country_specific_1_verification) {
        this.country_specific_1_verification = country_specific_1_verification;
    }

    public String getCountry_specific_2_verification() {
        return country_specific_2_verification;
    }

    public void setCountry_specific_2_verification(String country_specific_2_verification) {
        this.country_specific_2_verification = country_specific_2_verification;
    }

    public Boolean getIs_manual_verification() {
        return is_manual_verification;
    }

    public void setIs_manual_verification(Boolean is_manual_verification) {
        this.is_manual_verification = is_manual_verification;
    }


}
