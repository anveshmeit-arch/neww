package com.scb.clm.services.globus.prospect.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSProspectRequestWrapper
{
    @JsonProperty("prospectId")
    private String prospectID;

    @JsonProperty("application")
    private GBSProspectRequestApplication application;

    @JsonProperty("customers")
    private GBSProspectRequestCustomers customers;

    public GBSProspectRequestWrapper() {        
    }

    public String getProspectID() {
        return prospectID;
    }

    public void setProspectID(String prospectID) {
        this.prospectID = prospectID;
    }

    public GBSProspectRequestApplication getApplication() {
        return application;
    }

    public void setApplication(GBSProspectRequestApplication application) {
        this.application = application;
    }

    public GBSProspectRequestCustomers getCustomers() {
        return customers;
    }

    public void setCustomers(GBSProspectRequestCustomers customers) {
        this.customers = customers;
    }

}