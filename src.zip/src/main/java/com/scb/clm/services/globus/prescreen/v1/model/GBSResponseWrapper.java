package com.scb.clm.services.globus.prescreen.v1.model;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GBSResponseWrapper
{
    @JsonProperty("dedupeStatus")
    private GBSResponseDedupeStatus dedupeStatus;

    @JsonProperty("exactMatch")
    private ArrayList<GBSResponseDedupMatch> exactmatch = new ArrayList<GBSResponseDedupMatch>();

    @JsonProperty("likelyMatch")
    private ArrayList<GBSResponseDedupMatch> likelyMatch = new ArrayList<GBSResponseDedupMatch>();

    public GBSResponseDedupeStatus getDedupeStatus() {
        return dedupeStatus;
    }

    public void setDedupeStatus(GBSResponseDedupeStatus dedupeStatus) {
        this.dedupeStatus = dedupeStatus;
    }

    public ArrayList<GBSResponseDedupMatch> getExactmatch() {
        return exactmatch;
    }

    public void setExactmatch(ArrayList<GBSResponseDedupMatch> exactmatch) {
        this.exactmatch = exactmatch;
    }

    public ArrayList<GBSResponseDedupMatch> getLikelyMatch() {
        return likelyMatch;
    }

    public void setLikelyMatch(ArrayList<GBSResponseDedupMatch> likelyMatch) {
        this.likelyMatch = likelyMatch;
    }


}