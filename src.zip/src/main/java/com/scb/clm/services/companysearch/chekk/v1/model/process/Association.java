package com.scb.clm.services.companysearch.chekk.v1.model.process;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class Association {

	@JsonProperty("associatedID")
	public String associatedID;
	@JsonProperty("associatedToIDs")
	public String associatedToIDs;
	@JsonProperty("associationType")
	public String associationType;

	@JsonProperty("partyRole")
	public String partyRole;
	
	@JsonProperty("ownershipPercentage")
	public String ownershipPercentage;
	@JsonProperty("sharesAmount")
	public String sharesAmount;
	@JsonProperty("shareType")
	public String shareType;
	@JsonProperty("shareCurrency")
	public String shareCurrency;
	@JsonProperty("percentageOfParent")
	public String percentageOfParent;

}