package com.scb.clm.services.companysearch.chekk.v1.support;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.scb.clm.common.util.DateTimeUtility;
import com.scb.clm.common.util.StringUtility;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkPartyEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkRequestsEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkResponseDataEntity;
import com.scb.clm.services.companysearch.chekk.v1.model.ChekkSearchEntityQEntity;
import com.scb.clm.services.companysearch.chekk.v1.repository.ChekkPartyRepository;
import com.scb.clm.services.companysearch.chekk.v1.repository.ChekkRequestsRepository;
import com.scb.clm.services.companysearch.chekk.v1.repository.ChekkResponseDataRepository;
import com.scb.clm.services.companysearch.chekk.v1.repository.ChekkSearchEntityQueueRepository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;

@Component
public class DBUtility {

    @Autowired
    private EntityManager entityManager;

    @Autowired
    private ChekkResponseDataRepository chekkResponseDataRepository;

    @Autowired
    private ChekkRequestsRepository chekkRequestsRepository;

    @Autowired
    ChekkSearchEntityQueueRepository chekkSearchEntityQueueRepository;

    @Autowired
    ChekkPartyRepository chekkPartyRepository;

    @Autowired
    ChekkSearchEntityQueueRepository chekkSearchEntityRepository;

    public void saveChkResData(ChekkResponseDataEntity chekkResponseDataEntity) {
        try {
            chekkResponseDataEntity.setCreatedOn(DateTimeUtility.getCurrentTime());
            chekkResponseDataRepository.save(chekkResponseDataEntity);
        } catch (Exception e) {
            Log.error("DBUtility#saveChkResData: Exception in saving responseDataEntity " + e.getMessage(), e);
        }
    }

    public void saveChkPartyDataLst(List<ChekkPartyEntity> chekkPartyEntityLst) {
        try {
            chekkPartyRepository.saveAll(chekkPartyEntityLst);
        } catch (Exception e) {
            Log.error("DBUtility#saveChkPartyDataLst: Exception in saving partyData list " + e.getMessage(), e);
        }
    }

    public void updateStatusByIds(String status, ChekkResponseDataEntity chekkResponseDataEnty) {
        try {
            chekkSearchEntityRepository.updateStatusByIds(status, chekkResponseDataEnty.getSearchEntityId(),
                    chekkResponseDataEnty.getRequestId());
        } catch (Exception e) {
            Log.error("DBUtility#updateStatusByIds: Exception in updating status id at ChkSearchEntityQ table "
                    + e.getMessage(), e);
        }
    }

    public void saveChkReqData(ChekkRequestsEntity chekkRequestsEntity) {
        try {

            chekkRequestsRepository.save(chekkRequestsEntity);
        } catch (Exception e) {
            Log.error("DBUtility#saveChkReqData: Exception in saving chekk request data " + e.getMessage(), e);
        }
    }

    public String generateChkRespDataID() {
        return getSequenceId("chk_response_data_seq");
    }

    public void saveChkSearchEntityQueueData(ChekkSearchEntityQEntity chekkSearchEntityQEntity) {
        try {

            chekkSearchEntityQueueRepository.save(chekkSearchEntityQEntity);
        } catch (Exception e) {
            Log.error("DBUtility#saveChkSearchEntityQueueData: Exception in saving chksearchEntityQ table "
                    + e.getMessage(), e);
        }
    }

    public void saveChkSearchEntityQueueLst(List<ChekkSearchEntityQEntity> checkSearchEntityQueue) {
        try {
            chekkSearchEntityQueueRepository.saveAll(checkSearchEntityQueue);
        } catch (Exception ex) {
            Log.error("DBUtility#saveChkSearchEntityQueueLst: Exception in saving chksearchEntityQ table as list "
                    + ex.getMessage(), ex);
        }
    }

    public String generateChkSearchEntityId() {
        return getSequenceId("CHK_SEARCH_ENTITY_QUEUE_SEQ");
    }

    public String generateChkPartyID() throws Exception {
        return getSequenceId("CHK_PARTY_SEQ");
    }

    public String getSequenceId(String tableName) {
        StringBuilder query = new StringBuilder();
        query.append("SELECT NEXTVAL('");
        query.append(tableName);
        query.append("')");
        Query qry = null;
        qry = entityManager.createNativeQuery(query.toString());
        String sequenceId = StringUtility.padLeft(String.valueOf(qry.getResultList().get(0)), 8, "0");
        return sequenceId;
    }
}
