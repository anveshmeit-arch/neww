package com.scb.clm.services.globus.deepening.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.scb.clm.services.globus.prospect.v1.model.GBSProspectRequestApplication;
import com.scb.clm.services.globus.prospect.v1.model.GBSProspectRequestCustomers;

public class GBSDeepeningRequestWrapper {
    @JsonProperty("application")
    private GBSDeepeningRequestApplication application;

    @JsonProperty("customers")
    private GBSDeepeningRequestCustomers customers;

    public GBSDeepeningRequestApplication getApplication() {
        return application;
    }
    public GBSDeepeningRequestWrapper() {
    }

    public void setApplication(GBSDeepeningRequestApplication application) {
        this.application = application;
    }

    public GBSDeepeningRequestCustomers getCustomers() {
        return customers;
    }

    public void setCustomers(GBSDeepeningRequestCustomers customers) {
        this.customers = customers;
    }
}
