package com.scb.clm.services.globus.mule.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class VerifyMuleRequestContacts 
{

    @JsonProperty("contactTypeCode")
    private String contactTypeCode;

    @JsonProperty("contact")
    private String contact;

    public VerifyMuleRequestContacts() {
        
    }
    
    public String getContactTypeCode() {
        return contactTypeCode;
    }

    public void setContactTypeCode(String contactTypeCode) {
        this.contactTypeCode = contactTypeCode;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

}

