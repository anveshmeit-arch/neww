package com.scb.clm.services.companysearch.chekk.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Addresses {

    @JsonProperty("city")
    private String city;

    @JsonProperty("postalCode")
    private String postalCode;

    @JsonProperty("addressL1")
    private String addressL1;

    @JsonProperty("addressL2")
    private String addressL2;

    @JsonProperty("addressL3")
    private String addressL3;

    @JsonProperty("country")
    private String country;

    @JsonProperty("landmark")
    private String landmark;

    @JsonProperty("zipcode")
    private String zipcode;

}
