package com.scb.clm.services.globus.prescreen.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CLMResponseRisks
{

	@JsonProperty("risk-code") 
    String riskCode;

	@JsonProperty("risk-expiry-date")
	String riskExpiryDate;

	public String getRiskCode() {
		return riskCode;
	}

	public void setRiskCode(String riskCode) {
		this.riskCode = riskCode;
	}

	public String getRiskExpiryDate() {
		return riskExpiryDate;
	}

	public void setRiskExpiryDate(String riskExpiryDate) {
		this.riskExpiryDate = riskExpiryDate;
	}
	

}