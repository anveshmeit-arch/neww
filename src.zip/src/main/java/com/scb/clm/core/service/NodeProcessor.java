package com.scb.clm.core.service;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.codesetup.NodesEntity;
import com.scb.clm.common.model.transactions.NodeStatus;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.util.JSONUtility;
import com.scb.clm.common.util.StringUtility;

@Service
public class NodeProcessor
{
    @Autowired
    ServiceProcessor serviceProcessor;

    public NodeStatus processAllServicesUnderNode(TravellingObject travelObj,NodesEntity nodesEntity,List<NodeServicesEntity> service,boolean isFinalNode) throws ProcessException
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "processAllServicesUnderNode", LogType.APPLICATION.name());

        NodeStatus nodeStatus = new NodeStatus();

        try
        {
            if(nodesEntity.getAsyncProcess()!=null && nodesEntity.getAsyncProcess().equalsIgnoreCase("Y") && service.size()>1) {
                throw new ProcessException(BaseConstants.ERROR_TYPE_PROCESSING,BaseConstants.CLM_REQUEST_ERROR,"INVALID NODE SETUP [ASYC NODE CANNOT HAVE MORE THAN ONE SERVICE CONFIGURED]");
            }

            if(service.size()==1)
            {
                log.println("*** Single Thread Execution ***");
                log.println("Processing Services Under Node ["+nodesEntity.getId().getCountryCode()+"/"+nodesEntity.getId().getFlowIdentifier()+"/"+nodesEntity.getId().getNodeIdentifier()+"] in Single Thread");
                ServiceStatus serviceStatus = serviceProcessor.executeService(travelObj,nodesEntity,service.get(0));
                log.println("Service Status : "+JSONUtility.domainWrapperToJSON(serviceStatus));

                log.println("[Adding Service Status to Travel Object] & [Assigning Errors If Any]");
                travelObj.addServiceStatus(serviceStatus);
            }
            else
            {
                log.println("*** Multi Thread Execution ***");
                log.println("Processing Services Under Node ["+nodesEntity.getId().getCountryCode()+"/"+nodesEntity.getId().getFlowIdentifier()+"/"+nodesEntity.getId().getNodeIdentifier()+"] in Multi Thread");

                List<CompletableFuture<ServiceStatus>> services = new ArrayList<CompletableFuture<ServiceStatus>>();

                for(NodeServicesEntity nodeServices : service)
                {
                    CompletableFuture<ServiceStatus> future = CompletableFuture.supplyAsync(() -> { return serviceProcessor.executeService(travelObj,nodesEntity,nodeServices); });
                    services.add(future);
                }
                CompletableFuture<Void> combinedFuture = CompletableFuture.allOf(services.toArray(new CompletableFuture[services.size()]));
                combinedFuture.get();
                CompletableFuture<List<ServiceStatus>> allFutureResults = combinedFuture.thenApply(t -> services.stream().map(CompletableFuture::join).collect(Collectors.toList()));
                List<ServiceStatus> stats = allFutureResults.get();

                for(ServiceStatus stat : stats) 
                {
                    travelObj.addServiceStatus(stat);
                }
            }
        }        
        catch(Exception e)
        {
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_VALIDATION,BaseConstants.CLM_REQUEST_ERROR,"NODE PROCESSOR - INTERNAL ERROR");
        }
        finally
        {
            //N.A
        }

        log.println("Preparing to Make Decision for Next Node Current Node Status ["+nodeStatus.isProcessToNextNode()+"]");

        isGoodToProceed(travelObj,nodesEntity,service,nodeStatus);

        log.println("Decision to Proceed Good ? ["+(nodeStatus.isProcessToNextNode()?"Yes, Proceed to Next Node":"No, Break The Flow Here")+"] - Is Final Node ? ["+(isFinalNode?"Yes":"No")+"] Skip Node ["+nodeStatus.getSkipToNode()+"]");

        if(isFinalNode || !nodeStatus.isProcessToNextNode())
        {
            if(StringUtility.containsData(nodesEntity.getNodeProgram()) && nodesEntity.getNodeProgram().equals("-")) {
                throw new ProcessException(BaseConstants.ERROR_TYPE_VALIDATION,BaseConstants.CLM_REQUEST_ERROR,"DECISION MAKER - NOT CONFIGURED");
            }

            log.println("Building Response ["+nodeStatus.isProcessToNextNode()+"]");
            buildResponse(travelObj,nodesEntity,service,nodeStatus.isProcessToNextNode());
        }

        return nodeStatus;
    }

    // Decision Maker Component
    private void isGoodToProceed(TravellingObject travelObj,NodesEntity nodesEntity,List<NodeServicesEntity> service,NodeStatus nodeStatus) throws ProcessException
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "isGoodToProceed", LogType.APPLICATION.name());
        try
        {
            if(nodesEntity.getAsyncProcess().equalsIgnoreCase("Y")) {
                log.println("[Decision Maker Program Not Invoked] [Async Mode is Y] [Returning True By Default]");
                nodeStatus.setProcessToNextNode(true);
            }

            if(!StringUtility.containsData(nodesEntity.getNodeProgram())) {
                throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,BaseConstants.CLM_REQUEST_ERROR,"[DECISION MAKER NOT CONFIGURED] - INTERNAL ERROR");
            }

            log.println("Invoking Decision Maker Program : "+nodesEntity.getNodeProgram());
            Class<?> cls = Class.forName(nodesEntity.getNodeProgram());
            Method method = cls.getMethod("isGoodToProceed",TravellingObject.class,NodesEntity.class,List.class,NodeStatus.class);
            method.invoke(cls.newInstance(),travelObj,nodesEntity,service,nodeStatus);             
        }
        catch(ProcessException e) 
        {
            throw e;
        }
        catch(Exception e) 
        {
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_VALIDATION,BaseConstants.CLM_REQUEST_ERROR,"NODE PROCESSOR [DECISION MAKER] - INTERNAL ERROR");
        }
        finally
        {
            //N.A
        }
    }

    private void buildResponse(TravellingObject travelObj,NodesEntity nodesEntity,List<NodeServicesEntity> service,boolean isSuccess) throws ProcessException
    {
        try
        {
            Class<?> cls = Class.forName(nodesEntity.getNodeProgram());
            Method method = cls.getMethod("buildResponse",TravellingObject.class,NodesEntity.class,List.class,boolean.class);
            method.invoke(cls.newInstance(),travelObj,nodesEntity,service,isSuccess);
        }
        catch(Exception e)
        {
            LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "buildResponse", LogType.APPLICATION.name());
            log.printErrorMessage(e);

            throw new ProcessException(BaseConstants.ERROR_TYPE_VALIDATION,BaseConstants.CLM_REQUEST_ERROR,"NODE PROCESSOR [DECISION MAKER] - INTERNAL ERROR");
        }
        finally
        {
            //N.A
        }
    }
}
