package com.scb.clm.core.service;

import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.codesetup.NodesEntity;
import com.scb.clm.common.model.transactions.ServiceMetadata;
import com.scb.clm.common.model.transactions.TravellingObject;

public abstract class ServiceThreadAdvisorAbstract 
{

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    public String getServiceName()
    {
        return this.getClass().getName();
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    public ServiceMetadata[] execute(TravellingObject travelObj,NodesEntity nodesEntity, NodeServicesEntity nodeServicesEntity) throws ProcessException
    {
        LoggerUtil log      = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "ServiceStatus - execute ", LogType.APPLICATION.name());

        ServiceMetadata[] serviceMetadata =  seekAdvice(travelObj, nodesEntity, nodeServicesEntity);
        if(serviceMetadata==null || serviceMetadata.length==0) 
        {
            log.println("ServiceMetadata Returned Null / Empty ");

            return null;
        }
        return serviceMetadata;
    }

    public abstract ServiceMetadata[] seekAdvice(TravellingObject travelObj,NodesEntity nodesEntity, NodeServicesEntity nodeServicesEntity) throws ProcessException;
    
}