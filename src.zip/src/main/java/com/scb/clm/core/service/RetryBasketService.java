package com.scb.clm.core.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.codesetup.NodesEntity;
import com.scb.clm.common.model.transactions.RetryBasketEntity;
import com.scb.clm.common.model.transactions.RetryBasketEntityKey;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.repository.NodesServicesRepository;
import com.scb.clm.common.repository.RetryBasketRepository;
import com.scb.clm.common.util.DateTimeUtility;
import com.scb.clm.common.util.JSONUtility;

@Service
public class RetryBasketService extends ServiceAbstract implements ServiceInterface
{
    @Autowired
    NodesServicesRepository nodesServicesRepository; 

    @Autowired
    RetryBasketRepository retryBasketRepository;
 
    private static final String PENDING = "P";
    
    public RetryBasketService() {
    }

    @Override
    public Object readRequestObject(TravellingObject travellingObject, NodeServicesEntity srvEntity) throws ProcessException 
    {
        return null;
    }

    @Override
    public void validateData(TravellingObject travellingObject, NodeServicesEntity srvEntity, Object requestPayload) throws ProcessException 
    {
    }

    @Override
    public Object constructOutboundObject(TravellingObject travellingObject, NodeServicesEntity srvEntity,Object requestPayload) throws ProcessException 
    {
        return null;
    }

    @Override
    public Object process(TravellingObject travellingObject, NodeServicesEntity srvEntity, ServiceStatus serviceStatus,Object obj) throws ProcessException 
    {
        return null;
    }

    @Override
    public Object constructServiceResponse(TravellingObject travellingObject, NodeServicesEntity srvEntity, Object obj,ServiceStatus serviceStatus) throws ProcessException 
    {
        return null;
    }
    
    /**
     *  
     * 
     * <p>
     *
     * @param         N.A
     * @return        
     * @exception     
     * @see
     * @since         
     */
    @Transactional
    public void addToRetryBasket(TravellingObject travelObj,NodesEntity nodesEntity,NodeServicesEntity nodeServicesEntity,ServiceStatus serviceStatus)
    {
        long startTime = System.currentTimeMillis();
        try
        {
            System.out.println("Retry Execution Starts - Country Code ["+travelObj.getCountryCode()+"] "+ " Path ID ["+travelObj.getPathIdentifier()+"] "+ " API Version ["+travelObj.getApiVersion()+"] "+ " App Ref No["+travelObj.getApplicationReferenceNumber()+"] "+ " Transaction ID ["+travelObj.getTransactionID()+"]");

            RetryBasketEntity retryEntity = new RetryBasketEntity(new RetryBasketEntityKey(travelObj.getCountryCode(),travelObj.getInBoundLogSequenceNumber()));
            retryEntity.setProcessDate(DateTimeUtility.getDateByCountryCode(travelObj.getCountryCode()));
            retryEntity.setMessage(JSONUtility.domainWrapperToJSON(travelObj).toString().getBytes());
            retryEntity.setStatus(PENDING);
            retryEntity.setLatestProcessTime(DateTimeUtility.getTimeByCountryCode(travelObj.getCountryCode()));
            retryEntity.setRetryCount("0");
            retryEntity.setJobID(nodeServicesEntity.getRetryJobId());

            retryBasketRepository.insertToBasket(retryEntity);
        }
        catch (Exception e)
        {
        }
        System.out.println("Total Time Taken for Retry Basket "+(System.currentTimeMillis()-startTime));
    }
}
