package com.scb.clm.core.service;

import java.util.ArrayList;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ErrorObject;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.util.DateTimeUtility;

public abstract class ServiceAbstract
{

    public String getServiceName() {
        return this.getClass().getName();
    }

    public ServiceStatus execute(TravellingObject travellingObject,NodeServicesEntity srvEntity)
    {
        ServiceStatus serviceStatus = new ServiceStatus(
                srvEntity.getId().getFlowIdentifier(),
                srvEntity.getId().getNodeIdentifier(),
                srvEntity.getId().getServiceIdentifier());

        Object processData  = null;
        LoggerUtil log      = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "ServiceStatus - execute ", LogType.APPLICATION.name());

        try
        {
            serviceStatus.setRequestTime(DateTimeUtility.getTimeByCountryCode(travellingObject.getCountryCode())); 
            serviceStatus.setInterfaceId(travellingObject.getInterfaceId()); 

            Object requestPayload = readRequestObject(travellingObject,srvEntity);
            serviceStatus.setRequestPayload(requestPayload);

            /***************   VALIDATING REQUEST DATA ****************** */
            log.println("Executing Service Request");
            validateData(travellingObject,srvEntity,requestPayload);

            /***************   OUTBOUND REQUESTS MAPPING   ****************** */
            log.println("Executing Outbound Request");
            Object processPayload =  constructOutboundObject(travellingObject,srvEntity,requestPayload);

            /*********************   PROCESSING LOGIC ************************ */
            serviceStatus.setRequestTime(DateTimeUtility.getTimeByCountryCode(travellingObject.getCountryCode())); /* OVER WRITE THE SERVICE REQUEST TIME IN CASE OF SUCCESSFUL VALIDATIONS */
            log.println("Executing Process Method");
            processData = process(travellingObject,srvEntity,serviceStatus,processPayload);
            serviceStatus.setStatus(BaseConstants.SERVICE_SUCCESS);
        }
        catch(ProcessException e) {
            log.println("Service Errors "+e.getAllErrors());
            serviceStatus.addErrorObject(e.getErrorList());
        }
        catch(Exception e)
        {
            serviceStatus.addErrorObject(generateDefaultErrorObjectList(serviceStatus));
            log.printErrorMessage(e);
        }

        try 
        {
            serviceStatus.setResponseTime(DateTimeUtility.getTimeByCountryCode(travellingObject.getCountryCode()));
        } 
        catch(Exception e) 
        {
            log.printErrorMessage(e);
        }

        try 
        {
            /*********************   INBOUND RESPONSE LOGIC ************************ */
            log.println("[Constructing Inbound Request] "+serviceStatus);
            Object inboundData = constructServiceResponse(travellingObject,srvEntity,processData,serviceStatus);
            serviceStatus.setResponsePayload(inboundData);
        }
        catch(Exception e)
        {
            serviceStatus.addErrorObject(generateDefaultErrorObjectList(serviceStatus));
            log.printErrorMessage(e);
        }

        return serviceStatus;
    }

    public abstract Object readRequestObject(TravellingObject travellingObject,NodeServicesEntity srvEntity) throws ProcessException;
    /* 
     * Method to Validate Request Data
     */
    public abstract void validateData(TravellingObject travellingObject,NodeServicesEntity srvEntity,Object requestPayload) throws ProcessException;

    /* 
     * Method to Construct Outbound Objects -  CLM Object to Interface Object
     */
    public abstract Object constructOutboundObject(TravellingObject travellingObject,NodeServicesEntity srvEntity,Object requestPayload) throws ProcessException;

    /* 
     * Method to execute the service logic
     */
    public abstract Object process(TravellingObject travellingObject,NodeServicesEntity srvEntity,ServiceStatus serviceStatus,Object obj) throws ProcessException;

    /* 
     * Method to Construct Inbound Objects - Interface Object to CLM Object
     */
    public abstract Object constructServiceResponse(TravellingObject travellingObject,NodeServicesEntity srvEntity,Object obj,ServiceStatus serviceStatus) throws ProcessException;

    private ArrayList<ErrorObject> generateDefaultErrorObjectList(ServiceStatus serviceStatus) 
    {
        ArrayList<ErrorObject> errObj = new ArrayList<ErrorObject>();
        try 
        {
            ErrorObject err = new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, BaseConstants.VALIDATION_ERROR,"SERVICE FAILURE - Flow ["+serviceStatus.getFlowIdentifier()+"] Node ["+serviceStatus.getNodeIdentifier()+"] Service ["+serviceStatus.getServiceIdentifier()+"]");
            errObj.add(err);
        } 
        catch (Exception e)
        {
            LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "generateDefaultErrorObjectList", LogType.APPLICATION.name());
            log.printErrorMessage(e);

        }
        return errObj;
    }
}