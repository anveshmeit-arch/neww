package com.scb.clm.core.service;

import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.codesetup.NodesEntity;
import com.scb.clm.common.model.transactions.ServiceMetadata;
import com.scb.clm.common.model.transactions.TravellingObject;

public interface ServiceThreadAdvisorInterface 
{
    public String getServiceName();
    
    ServiceMetadata[] execute(TravellingObject travelObj,NodesEntity nodesEntity, NodeServicesEntity nodeServicesEntity)  throws ProcessException;
}
