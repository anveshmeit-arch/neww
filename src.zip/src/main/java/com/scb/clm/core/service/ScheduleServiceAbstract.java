package com.scb.clm.core.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ErrorObject;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.JobScheduleEntity;
import com.scb.clm.common.model.transactions.ServiceStatus;

public abstract class ScheduleServiceAbstract
{

    public String getServiceName() {
        return this.getClass().getName();
    }

    public List<ErrorObject> executeRetry(JobScheduleEntity jobScheduleEntity) throws ProcessException
    { 
        List<ErrorObject> errObject = new ArrayList<ErrorObject>();
        try
        {
            ResponseEntity<Object> obj = executeService(jobScheduleEntity,constructRequestMandatoryData(jobScheduleEntity));
            if(obj.getStatusCodeValue() != BaseConstants.HTTP_200) {
                errObject.add(new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, BaseConstants.INTERNAL_PROCESSING_ERROR,"PROCESSING ERROR"));
            }
        }
        catch(Exception e)
        {
        	LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "executeRetry", LogType.APPLICATION.name());
        	log.printErrorMessage(e);

            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, BaseConstants.INTERNAL_PROCESSING_ERROR,"PROCESSING ERROR");
        }
        finally
        {
            //N.A
        }
        return errObject;
    }

    protected abstract ResponseEntity<Object> executeService(JobScheduleEntity jobScheduleEntity,Map<String, String> map);

    public Map<String, String> constructRequestMandatoryData(JobScheduleEntity jobScheduleEntity) throws ProcessException
    { 
        Map<String,String> requestHeaders = new HashMap<String,String>();
        try
        {
            System.out.println("CountryCode >>> "+jobScheduleEntity.getId().getCountryCode());
            requestHeaders.put(BaseConstants.SERVICE_API_HEADER_COUNTRY_CODE,jobScheduleEntity.getId().getCountryCode());
            requestHeaders.put(BaseConstants.SERVICE_API_HEADER_INTERFACE_ID,BaseConstants.APPLICATION_NAME);
            requestHeaders.put(BaseConstants.SERVICE_API_HEADER_TRANSACTION_ID,jobScheduleEntity.getJobSequenceId());
        }
        catch(Exception e)
        {
        	LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "constructRequestMandatoryData", LogType.APPLICATION.name());
        	log.printErrorMessage(e);

        }
        finally
        {
            //N.A
        }
        return requestHeaders;
    }

    /* 
     * Method to Validate Request Data
     */
    private ArrayList<ErrorObject> generateDefaultErrorObjectList(ServiceStatus serviceStatus) 
    {
        ArrayList<ErrorObject> errObj = new ArrayList<ErrorObject>();
        try 
        {
            ErrorObject err = new ErrorObject(BaseConstants.ERROR_TYPE_BUSINESS, BaseConstants.VALIDATION_ERROR,"SERVICE FAILURE - Flow ["+serviceStatus.getFlowIdentifier()+"] Node ["+serviceStatus.getNodeIdentifier()+"] Service ["+serviceStatus.getServiceIdentifier()+"]");
            errObj.add(err);
        } 
        catch (Exception e)
        {
        	LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "generateDefaultErrorObjectList", LogType.APPLICATION.name());
        	log.printErrorMessage(e);

        }
        return errObj;
    }



}