package com.scb.clm.core.service;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.clm.common.config.ApplicationConfiguration;
import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.log.DatabaseLogger;
import com.scb.clm.common.model.codesetup.FlowsEntity;
import com.scb.clm.common.model.codesetup.InterfaceRequestTypeEntity;
import com.scb.clm.common.model.codesetup.InterfaceRequestTypeEntityKey;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.codesetup.NodesEntity;
import com.scb.clm.common.model.codesetup.PathFlowsEntity;
import com.scb.clm.common.model.codesetup.PathIdentifierEntity;
import com.scb.clm.common.model.codesetup.ServicesEntity;
import com.scb.clm.common.model.transactions.InboundRequestsEntity;
import com.scb.clm.common.model.transactions.NodeStatus;
import com.scb.clm.common.model.transactions.ServiceMetadata;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.repository.FlowsRepository;
import com.scb.clm.common.repository.InboundRequestsRepository;
import com.scb.clm.common.repository.InterfaceRequestTypeRepository;
import com.scb.clm.common.repository.NodesRepository;
import com.scb.clm.common.repository.NodesServicesRepository;
import com.scb.clm.common.repository.PathIdentifierRepository;
import com.scb.clm.common.repository.ServicesRepository;
import com.scb.clm.common.util.DateTimeUtility;
import com.scb.clm.common.util.JSONUtility;
import com.scb.clm.common.util.StringUtility;

import jakarta.persistence.EntityNotFoundException;

@Service
public class OrchestrationService 
{

    @Autowired
    InboundRequestsRepository inboundRequestsRepository;

    @Autowired
    InterfaceRequestTypeRepository interfaceRequestTypeRepository;

    @Autowired
    FlowsRepository flowsRepository;

    @Autowired
    NodesRepository nodesRepository;

    @Autowired
    NodesServicesRepository nodesServicesRepository;

    @Autowired
    ServicesRepository servicesRepository;

    @Autowired
    DatabaseLogger databaseLogger;

    @Autowired
    NodeProcessor nodeProcessor;

    @Autowired
    ServiceThreadAdvisor serviceThreadAdvisor;

    @Autowired
    PathIdentifierRepository pathIdentifierRepository;

    public OrchestrationService() {

    }

    /**
     *  
     * 
     * <p>
     *
     * @param         N.A
     * @return        
     * @exception     
     * @see
     * @since         March 2024
     */
    public void executeProcessFlow(TravellingObject travelObj) throws ProcessException
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "executeProcessFlow", LogType.APPLICATION.name());

    	InboundRequestsEntity inboundRequestsEntity = generateInBoundObject(travelObj);
    	String logDatabase = "";

        try
        {

        	log.println("Execution Starts - Country Code ["+travelObj.getCountryCode()+"] "+ " Path ID ["+travelObj.getPathIdentifier()+"] "+ " API Version ["+travelObj.getApiVersion()+"] "+ " App Ref No["+travelObj.getApplicationReferenceNumber()+"] "+ " Transaction ID ["+travelObj.getTransactionID()+"]");

            validateHeaderDetails(travelObj);

            validateInterfaceSetup(travelObj);

            /* FETCHING THE FLOW */
            String flowID = revisedFlowIdentifier(travelObj);
            log.println("Revised Flow Identifier ["+flowID+"]");

            FlowsEntity flowsEntity = null ;
            if(flowID !=null) {
                flowsEntity = flowsRepository.findByIdCountryCodeAndIdFlowIdentifierAndStatusFlag(travelObj.getCountryCode(),flowID,BaseConstants.CODE_SETUP_ACTIVE);  
            }
            else {
                flowsEntity = flowsRepository.findByIdCountryCodeAndPathIdentifierAndStatusFlag(travelObj.getCountryCode(),travelObj.getPathIdentifier(),BaseConstants.CODE_SETUP_ACTIVE);
            }

            if( flowsEntity == null) {
                throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,BaseConstants.CLM_GENERIC_ERROR,"PATH IDENTIFIER NOT FOUND / MULTIPLE PATH CONFIGURED FOR Country Code : ["+travelObj.getCountryCode()+"] Path Identifier : ["+travelObj.getPathIdentifier()+"] OR [FLOW IS NOT ACTIVE]");
            }


            logDatabase = flowsEntity.getLogTime();
            travelObj.setFlowIdentifier(flowsEntity.getId().getFlowIdentifier());
            travelObj.getServiceContext().setServiceType(flowsEntity.getId().getFlowIdentifier());
            log.println("Processing Starts For Country Code : ["+flowsEntity.getId().getCountryCode()+"] Flow ID : ["+flowsEntity.getId().getFlowIdentifier()+"]");

            readRequestData(flowsEntity,travelObj);

            Long maxNode = nodesRepository.getMaxNodeLevel(flowsEntity.getId().getCountryCode(),flowsEntity.getId().getFlowIdentifier(),BaseConstants.CODE_SETUP_ACTIVE);
            log.println("Max Node Sequence ["+maxNode+"]");

            if(maxNode==0) {
                throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,BaseConstants.CLM_GENERIC_ERROR,"INVALID NODE CONFIGURATION ["+maxNode+"] ");
            }

            NodeStatus nodeStatus = new NodeStatus();
            
            for(int currentNode=1;currentNode<=maxNode;currentNode++)
            {
                List<NodesEntity> nodeList = nodesRepository.findByIdCountryCodeAndIdFlowIdentifierAndSequenceIdAndStatusFlag(flowsEntity.getId().getCountryCode(),flowsEntity.getId().getFlowIdentifier(), String.valueOf(currentNode),BaseConstants.CODE_SETUP_ACTIVE);

                log.println("Nodes Configured Under Flow ["+flowsEntity.getId().getFlowIdentifier()+"] With Sequence Number ["+currentNode+"] - Max Size ["+(nodeList==null?null:nodeList.size())+"]");

                if(nodeList==null || nodeList.size()==0) 
                {
                    log.println("No Nodes Configured");
                    continue;
                }

                for(NodesEntity nodesEntity : nodeList)
                {
                    log.println("Configured Service [Country Code :"+nodesEntity.getId().getCountryCode()+"] [Flow Id :"+nodesEntity.getId().getFlowIdentifier()+"] [Node :"+nodesEntity.getId().getNodeIdentifier()+"]");
                    log.println("Skip ? [Country Code :"+nodesEntity.getId().getCountryCode()+"] [Flow Id :"+nodesEntity.getId().getFlowIdentifier()+"] [Node :"+nodesEntity.getId().getNodeIdentifier()+"] Skip Node["+nodeStatus.getSkipToNode()+"]");
                    
                	if(nodeStatus!=null && nodeStatus.getSkipToNode()!=null && !nodeStatus.getSkipToNode().equalsIgnoreCase(nodesEntity.getId().getNodeIdentifier())) {
                		log.println("Rerouting Node to ["+nodesEntity.getId().getNodeIdentifier()+"]");
                		continue;
                	}
                    
                    List<NodeServicesEntity> serviceList        =   nodesServicesRepository.findByIdCountryCodeAndIdFlowIdentifierAndIdNodeIdentifierAndStatusFlag(nodesEntity.getId().getCountryCode(),nodesEntity.getId().getFlowIdentifier(),nodesEntity.getId().getNodeIdentifier(),BaseConstants.CODE_SETUP_ACTIVE);
                    List<NodeServicesEntity> servicesToProcess  =   new ArrayList<NodeServicesEntity>();

                    for(NodeServicesEntity nodeServicesEntity : serviceList)
                    {
                        log.println("Fetching Code Setup for Service ID ["+nodeServicesEntity.getId().getCountryCode()+"] Service ID ["+nodeServicesEntity.getId().getServiceIdentifier()+"]");
                        ServicesEntity servicesEntity = servicesRepository.findByIdCountryCodeAndIdServiceID(nodeServicesEntity.getId().getCountryCode(),nodeServicesEntity.getId().getServiceIdentifier());
                        
                        try
                        {
                            if(servicesEntity==null || servicesEntity.getStatusFlag()==null || !servicesEntity.getStatusFlag().equalsIgnoreCase(BaseConstants.CODE_SETUP_ACTIVE))
                            {
                                throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,BaseConstants.CLM_REQUEST_ERROR,"SERVICE ID ["+nodeServicesEntity.getId().getCountryCode()+"-"+nodeServicesEntity.getId().getServiceIdentifier()+"] NOT CONFIGURED");
                            }
                        } catch (EntityNotFoundException | NullPointerException eX) {
                            throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,BaseConstants.CLM_REQUEST_ERROR,"SERVICE ID ["+nodeServicesEntity.getId().getCountryCode()+"-"+nodeServicesEntity.getId().getServiceIdentifier()+"] NOT CONFIGURED");
                        }

                        nodeServicesEntity.setServicesEntity(servicesEntity);
                        log.printDebug("Contacting Thread Advisor ");
                        contactThreadAdvisor(nodeServicesEntity, servicesToProcess, travelObj, nodesEntity);
                        
                    }

                    nodeStatus = new NodeStatus();
                    if( servicesToProcess.size() > 0 )
                    {
                    	nodeStatus = nodeProcessor.processAllServicesUnderNode(travelObj, nodesEntity, servicesToProcess,(currentNode==maxNode)?true:false);
                    	log.println("Node Status "+nodeStatus.getSkipToNode());
                    }
                    else 
                    {
                        log.println("No Services Configured Under Node [Country Code :"+nodesEntity.getId().getCountryCode()+"] [Flow Id :"+nodesEntity.getId().getFlowIdentifier()+"] [Node :"+nodesEntity.getId().getNodeIdentifier()+"]");
                    }

                    log.println("Node Decision Proceed Or Break "+nodeStatus.isProcessToNextNode());
                    if(!nodeStatus.isProcessToNextNode() && nodeStatus.getSkipToNode()==null)
                    {
                        break;
                    }
                }

                if(!nodeStatus.isProcessToNextNode()) 
                {
                    break;
                }
            }
        }
        catch (ProcessException e)
        {
            log.println(""+JSONUtility.domainWrapperToJSON(e.getAllErrors()));
            travelObj.addErrors(e.getErrorList());
            throw e;
        }
        catch (Exception e)
        {
        	log.printErrorMessage(e);

            throw new ProcessException(BaseConstants.ERROR_TYPE_VALIDATION,BaseConstants.CLM_REQUEST_ERROR,"INVALID DATA - INTERNAL ERROR");
        }
        finally
        {
            try
            {
                //LOGIC SHOULD BE AT STARTING AS WE CANT TRACK RECORDS IN PROGRESS
                if(StringUtility.containsData(logDatabase) && logDatabase.equalsIgnoreCase("Y")) {
                    databaseLogger.constructInBoundLog(travelObj,inboundRequestsEntity);
                } else {
                    log.println("DataBase Log Disabled for the Flow");
                }
            }
            catch(Exception e)
            {
            	log.printErrorMessage(e);
            }
            finally
            {
                //N.A
            }
        }

    }
    /**
     *  
     * 
     * <p>
     *
     * @param         N.A
     * @return        
     * @exception     
     * @see
     * @since         June 2025
     */
    private void contactThreadAdvisor(NodeServicesEntity nodeServicesEntity, List<NodeServicesEntity> servicesToProcess,TravellingObject travelObj, NodesEntity nodesEntity) throws ProcessException
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "contactThreadAdvisor", LogType.APPLICATION.name());
        try 
        {
            if (StringUtility.isEmpty(nodeServicesEntity.getThreadAdvisor())) 
            {
                log.println("[Thread Advisor Not Configured] - Processing Service Directly "+JSONUtility.domainWrapperToJSON(nodeServicesEntity));
                servicesToProcess.add(nodeServicesEntity);
                return;
            }
          
            ServiceMetadata[] serviceMetadata = serviceThreadAdvisor.seekAdvice(travelObj, nodesEntity, nodeServicesEntity);
            if(serviceMetadata==null) 
            {
                servicesToProcess.add(nodeServicesEntity);
                return;
            }

            for (ServiceMetadata metaData : serviceMetadata) 
            {
                NodeServicesEntity nodeServicesEnt = nodeServicesEntity.clone();
                nodeServicesEnt.setServiceMetadata(metaData); 
                servicesToProcess.add(nodeServicesEnt);
                log.println("Service Thread Advisor [" + nodeServicesEntity.getThreadAdvisor() + "] - Service Metadata Added for Country Code [" + metaData.getServiceCountryCode() + "]");
            }

        }
        catch(ProcessException e)
        {
            throw e;
        }
        catch(Exception e)
        {
            log.printErrorMessage(e);
            throw new ProcessException(BaseConstants.ERROR_TYPE_VALIDATION,BaseConstants.SERVICE_THREAD_ADVISOR_ERROR,"SERVICE THREAD ADVISOR ERROR");
        }
        finally
        {
            //N.A
        }
    }

    /**
     *  
     * 
     * <p>
     *
     * @param         N.A
     * @return        
     * @exception     
     * @see
     * @since         March 2024
     */
    private void validateHeaderDetails(TravellingObject travellingObj) throws ProcessException
    {
        try
        {
            if(travellingObj == null) {
                throw new ProcessException(BaseConstants.ERROR_TYPE_VALIDATION,BaseConstants.CLM_REQUEST_ERROR,"INVALID DATA - INTERNAL ERROR");
            }

            if(!StringUtility.containsData(travellingObj.getCountryCode()))
            {
                throw new ProcessException(BaseConstants.ERROR_TYPE_VALIDATION,BaseConstants.INVALID_HEADER_COUNTRY_CODE,"INVALID HEADER DATA - MISSING COUNTRY CODE");
            }

            if(!StringUtility.containsData(travellingObj.getInterfaceId()))
            {
                throw new ProcessException(BaseConstants.ERROR_TYPE_VALIDATION,BaseConstants.INVALID_HEADER_INTERFACE_ID,"INVALID HEADER DATA - MISSING INTERFACE ID");
            }

            if(!StringUtility.containsData(travellingObj.getApiVersion()))
            {
                throw new ProcessException(BaseConstants.ERROR_TYPE_VALIDATION,BaseConstants.INVALID_API_VERSION,"INVALID HEADER DATA - MISSING API VERSION");
            }

            if(!StringUtility.containsData(travellingObj.getTransactionID()))
            {
                throw new ProcessException(BaseConstants.ERROR_TYPE_VALIDATION,BaseConstants.INVALID_HEADER_TRANSACTION_ID,"INVALID HEADER DATA - MISSING TRANSACTION ID");
            }

        }
        catch(ProcessException e)
        {
            throw e;
        }
        catch(Exception e)
        {
            throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,BaseConstants.CLM_GENERIC_ERROR,"INVALID DATA - INTERNAL EXCEPTION");
        }
        finally
        {
            //N.A
        }
    }

    /**
     *  
     * 
     * <p>
     *
     * @param         N.A
     * @return        
     * @exception     
     * @see
     * @since         March 2024
     */
    private void validateInterfaceSetup(TravellingObject travellingObj) throws ProcessException
    {
    	LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "validateInterfaceSetup", LogType.APPLICATION.name());

        try
        {
            log.println("Validating Country Code ["+travellingObj.getCountryCode()+"] Interface ID ["+travellingObj.getInterfaceId()+"] Path Identifier ["+travellingObj.getPathIdentifier()+"]");
            InterfaceRequestTypeEntity interfaceRequestType = interfaceRequestTypeRepository.getOne(new InterfaceRequestTypeEntityKey(travellingObj.getCountryCode(),travellingObj.getInterfaceId(),travellingObj.getPathIdentifier()));
            //interfaceRequestType.toString();
            if(interfaceRequestType == null || interfaceRequestType.getId()==null)
            {
                throw new ProcessException(BaseConstants.ERROR_TYPE_VALIDATION,BaseConstants.INVALID_INTERFACE_REQUEST_TYPE,"INVALID INTERFACE ID ["+travellingObj.getInterfaceId()+"] REQUEST_TYPE ["+travellingObj.getPathIdentifier()+"] COMBINATION");
            }
        }
        catch(EntityNotFoundException e)
        {
            throw new ProcessException(BaseConstants.ERROR_TYPE_VALIDATION,BaseConstants.INVALID_INTERFACE_REQUEST_TYPE,"INVALID INTERFACE ID ["+travellingObj.getInterfaceId()+"] REQUEST_TYPE ["+travellingObj.getPathIdentifier()+"] COMBINATION");
        }
        catch(ProcessException e)
        {
            throw e;
        }
        catch(Exception e)
        {
        	log.printErrorMessage(e);

            throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,BaseConstants.CLM_GENERIC_ERROR,"INVALID DATA - INTERNAL EXCEPTION");
        }
        finally
        {
            //N.A
        }
    }

    /**
     *  
     * 
     * <p>
     *
     * @param         N.A
     * @return        
     * @exception     
     * @see
     * @since         March 2024
     */
    @SuppressWarnings("unchecked")
    private void readRequestData(FlowsEntity flowsEntity,TravellingObject travellingObject) throws ProcessException
    {
    	LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "readRequestData", LogType.APPLICATION.name());
        try
        {
            if(!StringUtility.containsData(flowsEntity.getModelClass()) || flowsEntity.getModelClass().equalsIgnoreCase("-")) {
                log.println("Model Class Not Defined - Request Data Will Remain as String");
                return; 
            }

            Class<?> modelClass = Class.forName(flowsEntity.getModelClass());
            Object obj = JSONUtility.jsonTODomainWrapper(travellingObject.getRequestData(), modelClass);
            travellingObject.setRequestData(obj);

            if(travellingObject.getRequestData()==null) {
                throw new Exception();
            }
        }
        catch(Exception e) 
        {
            throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,BaseConstants.INVALID_REQUEST_FORMAT,"REQUEST DATA - NOT COMPATABLE");
        }
    }

    /**
     *  
     * 
     * <p>
     *
     * @param         N.A
     * @return        
     * @exception     
     * @see
     * @since         March 2024
     */
    private InboundRequestsEntity generateInBoundObject(TravellingObject trObj) throws ProcessException
    {
        try 
        {
            InboundRequestsEntity inboundRequestsEntity = new InboundRequestsEntity();

            String sequenceNumber = null;
            //String dataBaseType   = CountryConfig.getCountryParam(trObj.getCountryCode(),BaseConstants.DATABASE_GROUP_CNTRY_PARAM,BaseConstants.DATABASE_TYPE);
            String dataBaseType   = ApplicationConfiguration.getInstance().getHashicorpValutedProperties(BaseConstants.DATABASE_TYPE);
            if(dataBaseType != null && dataBaseType.equalsIgnoreCase(BaseConstants.ORACLE)) 
            {
                sequenceNumber = inboundRequestsRepository.getOracleInboundSequenceNumber().toString();
            }
            else 
            {
                sequenceNumber = inboundRequestsRepository.getPostgresInboundSequenceNumber().toString();
            }
           
            
            sequenceNumber        = DateTimeUtility.formatDate(DateTimeUtility.getCurrentDateForLogging(),"yyMMddHHmmss")+""+String.format("%08d", Integer.parseInt(sequenceNumber));

            inboundRequestsEntity =  new InboundRequestsEntity(sequenceNumber);
            inboundRequestsEntity.setRequestTime(DateTimeUtility.getTimeByCountryCode(trObj.getCountryCode()));


            trObj.setInBoundLogSequenceNumber(inboundRequestsEntity.getId());

            return inboundRequestsEntity;
        } 
        catch (Exception e) 
        {
        	LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "generateInBoundObject", LogType.APPLICATION.name());
        	log.printErrorMessage(e);

            throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,BaseConstants.CLM_DB_LOGGING_ERROR,"INBOUND LOG ERROR");
        }

    }

    /**
     *  
     * 
     * <p>
     *
     * @param         
     * @return        
     * @exception     
     * @see
     * @since         
     */
    public String revisedFlowIdentifier(TravellingObject trObj) throws Exception
    {
        String newFlowID = null;

        try
        {
            PathIdentifierEntity pathIdentifierEntity = pathIdentifierRepository.findByIdCountryCodeAndIdPathIdentifierAndStatusFlag(trObj.getCountryCode(),trObj.getPathIdentifier().toUpperCase(),BaseConstants.CODE_SETUP_ACTIVE);
            if(pathIdentifierEntity == null)
            {
                   return null;
            }
            Set<PathFlowsEntity> pathFlows = pathIdentifierEntity.getPathFlows();

            if(pathFlows==null || pathFlows.size()==0) {
                throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,BaseConstants.CLM_NO_FLOW_CONFIGURED,"FLOW ID(S) NOT CONFIGURED FOR Country Code ["+trObj.getCountryCode()+"] Path Identifier ["+trObj.getPathIdentifier().toUpperCase()+"]");
            }

            Class<?> cls = Class.forName(pathIdentifierEntity.getFlowDeciderProgram());
            Method method = cls.getMethod("extractFlowIdentifier",TravellingObject.class);
            newFlowID = (String)method.invoke(cls.newInstance(),trObj);

            if(newFlowID==null || newFlowID.trim().length()==0) {
                return null;
            }

            for(PathFlowsEntity obj : pathFlows) {
                if(newFlowID.equalsIgnoreCase(obj.getId().getFlowId()))
                {
                    return obj.getId().getFlowId();
                }
            }

            throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,BaseConstants.INVALID_FLOW_IDENTIFIER,"FLOW IDENTIFIER ["+newFlowID+"] IS INVALID FOR COUNTRY CODE ["+trObj.getCountryCode()+"] Path Identifier ["+trObj.getPathIdentifier()+"] ");
        }
        catch (InvocationTargetException  e) {
            throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,BaseConstants.ERROR_IN_PATH_IDENTIFIER_SPECIAL_PROGRAM,"EXCEPTION IN FLOWS CONFIGURATION / PROGRAM CONFIGURED FOR COUNTRY CODE ["+trObj.getCountryCode()+"] Path Identifier ["+trObj.getPathIdentifier()+"] ");
        }
        catch (ProcessException e) {
            throw e;        
        }
        catch (Exception e) {
            throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,BaseConstants.GENERAL_EXCEPTION_PATH_IDENTIFIER,"EXCEPTION IN FLOWS CONFIGURATION FOR Country Code ["+trObj.getCountryCode()+"] Path Identifier ["+trObj.getPathIdentifier()+"] ");
        }
        finally {
            // N.A
        }
    }
}
