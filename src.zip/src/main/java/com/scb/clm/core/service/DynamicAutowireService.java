package com.scb.clm.core.service;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;

@Service
public class DynamicAutowireService {
    private final Map<String, ServiceInterface> servicesByName;

    @Autowired
    public DynamicAutowireService(List<ServiceInterface> getServiceName) {
        servicesByName = getServiceName.stream()
                .collect(Collectors.toMap(ServiceInterface::getServiceName, Function.identity()));
    }

    public ServiceStatus execute(TravellingObject travellingObject,NodeServicesEntity srvEntity) throws ProcessException
    {
        try {
            ServiceInterface service = servicesByName.get(srvEntity.getServicesEntity().getServiceProgram());
            return service.execute(travellingObject,srvEntity);
        } catch (Exception e ) {
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, BaseConstants.INTERNAL_PROCESSING_ERROR,"Configuration Error - Check the Process Setup ["+srvEntity.getServicesEntity().getServiceProgram()+"]");
        }
    }
}
