package com.scb.clm.core.controller;

import java.sql.Timestamp;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.scb.clm.common.config.ApplicationConfiguration;
import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.repository.InboundRequestsRepository;
import com.scb.clm.common.util.JSONUtility;
import com.scb.clm.common.util.ModuleContextManager;
import com.scb.clm.common.util.ResponseBuilder;
import com.scb.clm.common.util.ServiceContextCache;
import com.scb.clm.core.service.OrchestrationService;

@RestController
public class BaseController extends ResponseBuilder 
{

    @Autowired 
    OrchestrationService orchestrationService;

    @Autowired
    InboundRequestsRepository inboundRequestsRepository;

    LoggerUtil log    = null;
    LoggerUtil reqLog = null;
    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */

   
    @PostMapping("/profile/{apiVersion}/{pathIdentifier}")
    @ResponseBody
    public ResponseEntity<Object> processInboundRequest(@RequestBody String requestData,@RequestHeader Map<String,String> requestHeaders,
            @PathVariable("apiVersion") String apiVersion,
            @PathVariable("pathIdentifier") String pathIdentifier)
    {
        return processRequest(requestData,requestHeaders,apiVersion,pathIdentifier,BaseConstants.HTTP_POST);
    }
	
	@PatchMapping("/profile/{apiVersion}/{pathIdentifier}")
    @ResponseBody
    public ResponseEntity<Object> processInboundPatchRequest(@RequestBody String requestData,@RequestHeader Map<String,String> requestHeaders,
            @PathVariable("apiVersion") String apiVersion,
            @PathVariable("pathIdentifier") String pathIdentifier)
    {
        return processRequest(requestData,requestHeaders,apiVersion,pathIdentifier,BaseConstants.HTTP_PATCH);
    }

	@PutMapping("/profile/{apiVersion}/{pathIdentifier}")
    @ResponseBody
    public ResponseEntity<Object> processInboundPutRequest(@RequestBody String requestData,@RequestHeader Map<String,String> requestHeaders,
            @PathVariable("apiVersion") String apiVersion,
            @PathVariable("pathIdentifier") String pathIdentifier)
    {
        return processRequest(requestData,requestHeaders,apiVersion,pathIdentifier,BaseConstants.HTTP_PUT);
    }   

    @DeleteMapping("/profile/{apiVersion}/{pathIdentifier}")
    @ResponseBody
    public ResponseEntity<Object> processInboundDeleteRequest(@RequestBody String requestData,@RequestHeader Map<String,String> requestHeaders,
            @PathVariable("apiVersion") String apiVersion,
            @PathVariable("pathIdentifier") String pathIdentifier)
    {
        return processRequest(requestData,requestHeaders,apiVersion,pathIdentifier,BaseConstants.HTTP_DELETE);
    }   

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    public ResponseEntity<Object> processRequest(String requestData,Map<String,String> requestHeaders,String apiVersion,String pathIdentifier,String httpMethodType)
    {
        long startTime                    =  System.currentTimeMillis();

        TravellingObject travellingObject =  new TravellingObject();
        System.out.println("[Post] [ProcessRequest] Request Data # "+(cleanStringData(requestData)));
        System.out.println("[Post] [ProcessRequest] Request Header # "+(cleanMapData(requestHeaders)));

        try
        {
            /* SETTING TRAVELLING OBJECT */
            travellingObject.setApiVersion(apiVersion);
            travellingObject.setPathIdentifier(pathIdentifier);
            travellingObject.setRequestType(pathIdentifier);
            travellingObject.setRequestData(requestData);
            travellingObject.getServiceContext().setHttpMethod(httpMethodType);

            travellingObject.setRequestHeaders(requestHeaders);
            setHeaderValues(travellingObject,requestHeaders);
            
            ServiceContextCache.getInstance().createProviderContext(travellingObject.getServiceContext());
            log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "processRequest", LogType.APPLICATION.name());
            reqLog = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "processRequest", "RequestResponse");
            reqLog.printReqResLog(startTime, 0);
            
            ApplicationConfiguration.getInstance().isPasswordRoated("GBL");
            /* PASS DATA TO ORCHESTRATON LAYER */
            orchestrationService.executeProcessFlow(travellingObject);

            log.println("[BaseController] # Response_Time # Country Code "+travellingObject.getCountryCode()+" # Path "+travellingObject.getPathIdentifier()+" # "+ (System.currentTimeMillis()-startTime) +" ms / "+ (System.currentTimeMillis()-startTime)/1000 +" seconds");

            printResponse(travellingObject);

            return returnSuccessData(travellingObject);
        }
        catch (ProcessException e)
        {
        	log.println("Exception for # BaseController # processRequest  # "+e.getLocalizedMessage()+" / "+e.getMessage());
        	log.printErrorMessage(e);
        	return returnFailure(e,travellingObject);
        }
        catch (Exception e)
        {
            System.out.println("Exception for # BaseController # processRequest  # "+e.getLocalizedMessage()+" / "+e.getMessage());
            log.printErrorMessage(e);
            return returnFailure("Unable to Read the Request");
        }
        finally
        {
            printServiceTimings(travellingObject);
            reqLog.printReqResLog(startTime, System.currentTimeMillis());
            ModuleContextManager.getModuleContext().removeModuleCache();
        }
    }

    public void printResponse(TravellingObject travellingObject) 
    {
    	try 
    	{
            LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "processRequest", LogType.APPLICATION.name());
    		log.println("\n Response Data ["+travellingObject.getTransactionID()+"] Response "+JSONUtility.domainWrapperToJSON(travellingObject.getResponseData()));
    	}
    	catch(Exception e) 
    	{
    		e.printStackTrace();
    	}
    }

    public void printServiceTimings(TravellingObject travellingObject)
    {
        try
        {
            LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "processRequest", LogType.APPLICATION.name());
            for (Map.Entry<String,ServiceStatus> entry : travellingObject.getServiceStatus().entrySet())
            {
                log.println("Service ID - " + entry.getKey() +
                        ", Timings - Request Time - " + new Timestamp(entry.getValue().getRequestTime().getTime())+" / Response Time - "+new Timestamp(entry.getValue().getResponseTime().getTime())+" "
                        + " Time Taken "+(entry.getValue().getResponseTime().getTime()-entry.getValue().getRequestTime().getTime())
                        + " ms /  "+((entry.getValue().getResponseTime().getTime()-entry.getValue().getRequestTime().getTime()))/1000+" Seconds" );
            }
        }
        catch(Exception e)
        {

        }
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    private void setHeaderValues(TravellingObject travellingObject,Map<String,String> requestHeaders) throws ProcessException
    {
        try
        {
            if(requestHeaders==null)
            {
                System.out.println("BaseController # No HeaderValues # ");
                return;
            }

            travellingObject.setCountryCode(requestHeaders.get(BaseConstants.SERVICE_API_HEADER_COUNTRY_CODE));
            travellingObject.setInterfaceId(requestHeaders.get(BaseConstants.SERVICE_API_HEADER_INTERFACE_ID));
            travellingObject.setOriginalTransactionIDforRetryRequest(requestHeaders.get(BaseConstants.SERVICE_API_HEADER_ORIGINAL_TRANSACTION_ID));
            travellingObject.setTransactionID(requestHeaders.get(BaseConstants.SERVICE_API_HEADER_TRANSACTION_ID));
            travellingObject.setDuplicateFlag(requestHeaders.get(BaseConstants.SERVICE_API_HEADER_DUPLICATE_FLAG));

        }
        catch(Exception e)
        {
            System.out.println("Exception for # BaseController # setHeaderValues  # "+e.getLocalizedMessage()+" / "+e.getMessage());
            e.printStackTrace();
            throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,BaseConstants.CLM_GENERIC_ERROR,"INVALID HEADER DATA");
        }
        finally
        {
            //N.A
        }
    }
}
