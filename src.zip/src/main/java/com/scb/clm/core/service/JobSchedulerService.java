package com.scb.clm.core.service;

import java.security.SecureRandom;
import java.util.List;
import java.util.concurrent.ScheduledFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.scb.clm.common.config.ApplicationConfiguration;
import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ErrorObject;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.JobScheduleEntity;
import com.scb.clm.common.model.transactions.JobStatusEntity;
import com.scb.clm.common.repository.JobScheduleRepository;
import com.scb.clm.common.repository.JobStatusRepository;
import com.scb.clm.common.util.DateTimeUtility;
import com.scb.clm.common.util.StringUtility;
import com.scb.clm.common.util.SystemUtility;

import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;


@Service
public class JobSchedulerService {

    @Autowired 
    private JobScheduleRepository jobScheduleRepository;

    @Autowired
    JobStatusRepository jobStatusRepository;
    
    @Autowired 
    private TaskScheduler taskScheduler;

    @Autowired
    RestTemplate restTemplate;
    
    @Autowired 
    private EntityManager entityManager;
    
    @Autowired
    ScheduleDynamicAutowireService retryDynamicAutowireService;

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @PostConstruct
    public void scheduleJobs()
    {
        List<JobScheduleEntity> jobs = jobScheduleRepository.findAll();
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "scheduleJobs", LogType.APPLICATION.name());
        
        log.println("***********************************************************************************");
        log.println("*************** A U T O M A T E D     J O B     S C H E D U L E S   ***************");
        log.println("***********************************************************************************");

        for(JobScheduleEntity jobScheduleEntity : jobs)
        {
           if(StringUtility.containsData( jobScheduleEntity.getCronExpression())) {
               scheduleJob(jobScheduleEntity);
           } else {
            log.println("Cron Expresssion is Empty for Job ID ["+jobScheduleEntity.getId().getCountryCode()+" / "+jobScheduleEntity.getId().getJobId()+"]");
           }
        }
        log.println("***********************************************************************************");
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    public void scheduleJob(JobScheduleEntity jobScheduleEntity)
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "scheduleJob", LogType.APPLICATION.name());
        Runnable task = ()-> executeJob(jobScheduleEntity.getId().getCountryCode(),jobScheduleEntity.getId().getJobId(),jobScheduleEntity.getId().getJobSequence());
        log.println("SCHEDULING JOB ["+jobScheduleEntity.getId().getJobId()+"] FOR COUNTRY ["+jobScheduleEntity.getId().getCountryCode()+"] WITH CRON ["+jobScheduleEntity.getCronExpression()+"]");
        ScheduledFuture<?> ss = taskScheduler.schedule(task, new CronTrigger(jobScheduleEntity.getCronExpression()));
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Transactional
    public void executeJob(String countryCode,String jobId,String jobSequence)
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "scheduleJob", LogType.APPLICATION.name());
        JobStatusEntity jobStatusEntity = new JobStatusEntity(countryCode,jobId);
        try
        {
            log.println("[Started Executing Job] [Country Code - "+countryCode+"] [Job ID - "+jobId+"] ["+DateTimeUtility.getTimeByCountryCode(countryCode)+"]");

            jobStatusEntity = generateJobStatusID(jobStatusEntity);
            
            jobStatusEntity.setProcessDate(DateTimeUtility.getDateByCountryCode(countryCode));
            jobStatusEntity.setProcessStartTime(DateTimeUtility.getTimeByCountryCode(countryCode));

            JobScheduleEntity jobScheduleEntity = jobScheduleRepository.lockJobById(countryCode, jobId, jobSequence);
          
            if(jobScheduleEntity!=null && !jobScheduleEntity.isLocked())
            {
                jobScheduleEntity.setLocked(true);
                jobScheduleRepository.save(jobScheduleEntity);

                try
                { 
                    jobScheduleEntity.setLastExecuted(DateTimeUtility.getTimeByCountryCode(countryCode));
                    jobScheduleEntity.setJobSequenceId(jobStatusEntity.getJobSequenceId());
                    if(StringUtility.containsData(jobScheduleEntity.getRetryServiceProgram()))
                    {
                        log.println("Invoking Program "+jobScheduleEntity.getRetryServiceProgram());
                        List<ErrorObject> obj  = retryDynamicAutowireService.execute(jobScheduleEntity);
                        log.println("Completed Program "+jobScheduleEntity.getRetryServiceProgram());
                        if(obj!=null && obj.size()>0) {
                            jobStatusEntity.setStatus("F");
                            log.println("[Failed Executing Job] [Country Code - "+countryCode+"] [Job ID - "+jobId+"] ["+DateTimeUtility.getTimeByCountryCode(countryCode)+"]"); // CORRRECT THE LOGIC TO STAMP DETAILS IN DATABASE ALSO
                        } else {
                            jobStatusEntity.setStatus("S");
                            log.println("[Successful - Job Completed ] [Country Code - "+countryCode+"] [Job ID - "+jobId+"] ["+DateTimeUtility.getTimeByCountryCode(countryCode)+"]");
                        }
                    }
                }
                catch(Exception e)
                {
                	log.printErrorMessage(e);

                    jobStatusEntity.setStatus("F");
                    log.println("[Failed Executing Job] [Country Code - "+countryCode+"] [Job ID - "+jobId+"] ["+DateTimeUtility.getTimeByCountryCode(countryCode)+"]"); // CORRRECT THE LOGIC TO STAMP DETAILS IN DATABASE ALSO
                }
                finally
                {
                    jobScheduleEntity.setLocked(false);
                    jobScheduleRepository.save(jobScheduleEntity);  
                }
            } else {
                log.println("[Completed - Job is Locked by Another Process - Job Not Executed] [Country Code - "+countryCode+"] [Job ID - "+jobId+"] ["+DateTimeUtility.getTimeByCountryCode(countryCode)+"]");
            }
            
        }
        catch(Exception e) {
            jobStatusEntity.setStatus("F");
            log.printErrorMessage(e);
        } finally {
            logStats(jobStatusEntity);
        }
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    private void logStats(JobStatusEntity jobStatusEntity)
    {
        try
        {
            jobStatusEntity.setProcessEndTime(DateTimeUtility.getTimeByCountryCode(jobStatusEntity.getCountryCode()));
            jobStatusEntity.setVmName(SystemUtility.getInstanceName());
            jobStatusRepository.save(jobStatusEntity);
        }
        catch(Exception e)
        {
        	LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "logStats", LogType.APPLICATION.name());
        	log.printErrorMessage(e);

        }
    }
    
    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    private JobStatusEntity generateJobStatusID(JobStatusEntity jobStatusEntity) throws Exception
    {
        StringBuffer sequenceId = new StringBuffer();

        try
        {
            Query qry = null;
            //String dataBaseType   = CountryConfig.getCountryParam(trObj.getCountryCode(),BaseConstants.DATABASE_GROUP_CNTRY_PARAM,BaseConstants.DATABASE_TYPE);
            String dataBaseType   = ApplicationConfiguration.getInstance().getHashicorpValutedProperties(BaseConstants.DATABASE_TYPE);
            
            if(dataBaseType != null && dataBaseType.equalsIgnoreCase(BaseConstants.ORACLE)) {
                qry = entityManager.createNativeQuery("SELECT JOB_SEQUENCE.NEXTVAL FROM DUAL");
            } else {
                qry = entityManager.createNativeQuery("SELECT NEXTVAL('job_sequence')");                
            }

            sequenceId.append((DateTimeUtility.getDateByCountryCode(jobStatusEntity.getCountryCode())).toString().replaceAll("-","")).append(StringUtility.padLeft(String.valueOf(qry.getResultList().get(0)), 8,"0"));
            jobStatusEntity.setJobSequenceId(sequenceId.toString());
        }
        catch(Exception e)
        {
        	LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "generateJobStatusID", LogType.APPLICATION.name());
        	log.printErrorMessage(e);

            sequenceId = new StringBuffer();
            sequenceId.append(DateTimeUtility.formatDate((DateTimeUtility.getDateByCountryCode("HK").toString()),"yyyy-MM-dd","YYMMDD")).append(generateSecretNumber());
        }
        return jobStatusEntity;
    }

	static String generateSecretNumber() {
	    SecureRandom secRandom = new SecureRandom();
	    return String.format("%09d", secRandom.nextInt(999999999));
	}
}
