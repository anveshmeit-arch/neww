package com.scb.clm.core.service;

import java.util.List;

import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.codesetup.NodesEntity;
import com.scb.clm.common.model.transactions.NodeStatus;
import com.scb.clm.common.model.transactions.TravellingObject;

public interface DecisionMakerInterface 
{
    public void isGoodToProceed(TravellingObject travelObj,NodesEntity nodesEntity,List<NodeServicesEntity> service,NodeStatus nodeStatus);
    public void buildResponse(TravellingObject travelObj,NodesEntity nodesEntity,List<NodeServicesEntity> service,boolean isSuccess) throws ProcessException;
}
