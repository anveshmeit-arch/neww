package com.scb.clm.core.service;

import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;

public interface ServiceInterface
{

    public String getServiceName();

    /* 
     * Method to Execute Request
     */
    public ServiceStatus execute(TravellingObject travellingObject,NodeServicesEntity srvEntity) throws ProcessException;

    /* 
     * Method to Read the Request
     */
    public Object readRequestObject(TravellingObject travellingObject,NodeServicesEntity srvEntity) throws ProcessException;

    /* 
     * Method to Validate Request Data
     */
    public void validateData(TravellingObject travellingObject,NodeServicesEntity srvEntity,Object requestPayload) throws ProcessException;

    /* 
     * Method to Construct Outbound Objects -  CLM Object to Interface Object
     */
    public Object constructOutboundObject(TravellingObject travellingObject,NodeServicesEntity srvEntity,Object requestPayload) throws ProcessException;

    /* 
     * Method to execute the service logic
     */
    public Object process(TravellingObject travellingObject,NodeServicesEntity srvEntity,ServiceStatus serviceStatus,Object processPayload) throws ProcessException;

    /* 
     * Method to Construct Inbound Objects - Interface Object to CLM Object
     */
    public Object constructServiceResponse(TravellingObject travellingObject,NodeServicesEntity srvEntity,Object obj,ServiceStatus serviceStatus) throws ProcessException;

}