package com.scb.clm.core.service;

import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.model.transactions.TravellingObject;

public interface FlowIdentifierInterface 
{
    public String extractFlowIdentifier(TravellingObject travelObj) throws ProcessException;
}
