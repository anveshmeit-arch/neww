package com.scb.clm.core.service;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;

import com.scb.clm.common.exception.ErrorObject;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.model.codesetup.JobScheduleEntity;

public interface ScheduleServiceInterface
{

    public String getServiceName();

    public List<ErrorObject> executeRetry(JobScheduleEntity jobScheduleEntity) throws ProcessException;

    public ResponseEntity<Object> executeService(JobScheduleEntity jobScheduleEntity,Map<String,String> header) throws ProcessException;

}