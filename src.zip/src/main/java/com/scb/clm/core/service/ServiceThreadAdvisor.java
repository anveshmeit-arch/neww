package com.scb.clm.core.service;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.codesetup.NodesEntity;
import com.scb.clm.common.model.transactions.ServiceMetadata;
import com.scb.clm.common.model.transactions.TravellingObject;

@Service
public class ServiceThreadAdvisor 
{
    private final Map<String, ServiceThreadAdvisorInterface> servicesByName;

    /**
     *  
     * 
     * <p>
     *
     * @param         N.A
     * @return        
     * @exception     
     * @see
     * @since         June 2025
     */
    @Autowired
    public ServiceThreadAdvisor(List<ServiceThreadAdvisorInterface> getServiceName) 
    {
        servicesByName = getServiceName.stream().collect(Collectors.toMap(ServiceThreadAdvisorInterface::getServiceName, Function.identity()));
    }

    /**
     *  
     * 
     * <p>
     *
     * @param         N.A
     * @return        
     * @exception     
     * @see
     * @since         June 2025
     */
    public ServiceMetadata[] seekAdvice(TravellingObject travellingObject,NodesEntity nodesEntity,NodeServicesEntity nodeServicesEntity) throws ProcessException
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "execute", LogType.APPLICATION.name());

        try
        {
            ServiceThreadAdvisorInterface service = servicesByName.get(nodeServicesEntity.getThreadAdvisor());

            if(service==null) {
                log.println("No Interface Implementations found for Thread Advisor ["+nodeServicesEntity.getThreadAdvisor()+"]");
                return null;
            }

            return service.execute(travellingObject,nodesEntity,nodeServicesEntity);
        }
        catch (Exception e ) 
        {
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, BaseConstants.INTERNAL_PROCESSING_ERROR,"Thread Advisor Error - Check the Thread Advisor Setup ["+nodeServicesEntity.getThreadAdvisor()+"]");
        }
    }
    
}
