package com.scb.clm.core.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.log.AsyncServiceProcessor;
import com.scb.clm.common.log.DatabaseLogger;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.codesetup.NodesEntity;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.util.StringUtility;

@Service
public class ServiceProcessor 
{
    @Autowired
    DynamicAutowireService dynamicAutowireService;

    @Autowired
    AsyncServiceProcessor asyncServiceProcessor;

    @Autowired
    DatabaseLogger databaseLogger;

    @Autowired
    RetryBasketService retryBasketService;

    /**
     *  
     * 
     * <p>
     *
     * @param         N.A
     * @return        
     * @exception     
     * @see
     * @since         
     */
    public ServiceStatus executeService(TravellingObject travelObj,NodesEntity nodesEntity,NodeServicesEntity nodeServicesEntity)
    {
        ServiceStatus serviceStatus = new ServiceStatus(
                nodeServicesEntity.getId().getFlowIdentifier(),
                nodeServicesEntity.getId().getNodeIdentifier(),
                nodeServicesEntity.getId().getServiceIdentifier());

        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "methodname", LogType.APPLICATION.name());

        try
        {
            if(nodeServicesEntity.getServicesEntity().getServiceProgram()==null || !StringUtility.containsData(nodeServicesEntity.getServicesEntity().getServiceProgram()))
            {
                throw new ProcessException(BaseConstants.ERROR_TYPE_VALIDATION,BaseConstants.SERVICE_PROGRAM_NOT_CONFIGURED,"SERVICE PROGRAM NOT CONFIGURED FOR COUNTRY CODE ["+nodeServicesEntity.getId().getCountryCode()+"] - SERVICE ID ["+nodeServicesEntity.getId().getServiceIdentifier()+"]");
            }

            log.println("Service Program Configured ["+nodeServicesEntity.getServicesEntity().getDescription()+"-"+nodeServicesEntity.getServicesEntity().getServiceProgram()+"]");

            if(nodesEntity.getAsyncProcess()!=null && nodesEntity.getAsyncProcess().equalsIgnoreCase("Y")) {
                asyncServiceProcessor.execute(travelObj, nodeServicesEntity);
                serviceStatus.setStatus(BaseConstants.SERVICE_SUCCESS);
            } else {
                serviceStatus = dynamicAutowireService.execute(travelObj, nodeServicesEntity);
            }
            serviceStatus.setNodeSequenceId(nodesEntity.getSequenceId());
        }   
        catch(Exception e)
        {
            serviceStatus.setStatus(BaseConstants.SERVICE_FAILURE);
            log.printErrorMessage(e);
        }
        finally
        {
            postServiceActions(travelObj,nodesEntity,nodeServicesEntity,serviceStatus);
        }
        return serviceStatus;
    }

    /**
     *  
     * 
     * <p>
     *
     * @param         N.A
     * @return        
     * @exception     
     * @see
     * @since         
     */
    public void postServiceActions(TravellingObject travelObj,NodesEntity nodesEntity,NodeServicesEntity nodeServicesEntity,ServiceStatus serviceStatus)
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "postServiceActions", LogType.APPLICATION.name());

        try 
        {
            if(nodeServicesEntity!=null && nodeServicesEntity.getLogTime()!=null && nodeServicesEntity.getLogTime().equalsIgnoreCase("Y")
                    && (nodesEntity.getAsyncProcess()==null || !nodesEntity.getAsyncProcess().equalsIgnoreCase("Y")) ) 
            {
                databaseLogger.construcOutboundLog(travelObj,serviceStatus,nodeServicesEntity);
            } 
            else 
            {
                if(nodeServicesEntity != null && nodeServicesEntity.getId() != null && nodeServicesEntity.getId().getCountryCode() != null) 
                {
                    log.println("Database Logging Not Enabled for Service "+nodeServicesEntity.getId().getCountryCode()+"-"+nodeServicesEntity.getId().getFlowIdentifier()+"-"+nodeServicesEntity.getId().getNodeIdentifier()+"-"+nodeServicesEntity.getId().getServiceIdentifier());
                }
            }

            if(
                    serviceStatus.getStatus().equalsIgnoreCase(BaseConstants.SERVICE_FAILURE) && 
                    "Y".equalsIgnoreCase(nodeServicesEntity.getRetryEnabled()) &&
                    StringUtility.containsData(nodeServicesEntity.getRetryJobId())
             )
            {
                retryBasketService.addToRetryBasket(travelObj,nodesEntity,nodeServicesEntity,serviceStatus);
            }
        }
        catch (Exception e) 
        {
            log.printErrorMessage(e);
        }
        //RETRY BASKET INSERTIONS
    }
}
