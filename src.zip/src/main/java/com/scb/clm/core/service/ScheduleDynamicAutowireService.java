package com.scb.clm.core.service;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ErrorObject;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.model.codesetup.JobScheduleEntity;

@Service
public class ScheduleDynamicAutowireService
{
    private final Map<String, ScheduleServiceInterface> servicesByName;

    @Autowired
    public ScheduleDynamicAutowireService(List<ScheduleServiceInterface> getServiceName) {
        servicesByName = getServiceName.stream()
                .collect(Collectors.toMap(ScheduleServiceInterface::getServiceName, Function.identity()));
    }

    public List<ErrorObject> execute(JobScheduleEntity jobScheduleEntity) throws ProcessException
    {
        try {
            ScheduleServiceInterface service = servicesByName.get(jobScheduleEntity.getRetryServiceProgram());
            return service.executeRetry(jobScheduleEntity);
        } catch (Exception e) {
            throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, BaseConstants.INTERNAL_PROCESSING_ERROR,"Configuration Error - Check the Process Setup ["+jobScheduleEntity.getRetryServiceProgram()+"]");
        }
    }
}
