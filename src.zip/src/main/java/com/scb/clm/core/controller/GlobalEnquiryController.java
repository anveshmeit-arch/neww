package com.scb.clm.core.controller;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.repository.InboundRequestsRepository;
import com.scb.clm.common.util.ModuleContextManager;
import com.scb.clm.common.util.QueryParameterParsingUtility;
import com.scb.clm.common.util.ResponseBuilder;
import com.scb.clm.common.util.ServiceContextCache;
import com.scb.clm.core.service.OrchestrationService;

import jakarta.servlet.http.HttpServletRequest;

@RestController
public class GlobalEnquiryController extends ResponseBuilder 
{

	@Autowired 
	OrchestrationService orchestrationService;

	@Autowired
	InboundRequestsRepository inboundRequestsRepository;

	@Autowired
	QueryParameterParsingUtility queryParameterParsingUtility;
	
	public int maxResponseResults  = 0;
	int maxRecords				   = 0;
    LoggerUtil log                 = null;
    LoggerUtil reqLog              = null;

	/**
	 * <Description>
	 * <p> 
	 * <p> 
	 *  
	 * @param 
	 * @return
	 * @exception
	 * @see
	 * @since
	 */


	@GetMapping(value ={"/profile/{apiVersion}/{pathIdentifier}/{id}","/profile/{apiVersion}/{pathIdentifier}"})  
	public ResponseEntity<?> getByID(HttpServletRequest request,
			@PathVariable(value = "id", required = false) String requestData,
			@RequestHeader Map<String,String> requestHeaders,@PathVariable("apiVersion") String apiVersion,
			@PathVariable("pathIdentifier") String pathIdentifier) {

		System.out.println("PathIdentifier"+pathIdentifier);
		System.out.println("RequestData Value"+requestData);
		System.out.println("Request Query : "+request.getQueryString());

		return processRequest(requestData,requestHeaders,apiVersion,pathIdentifier,request);

	}
	/**
	 * <Description>
	 * <p> 
	 * <p> 
	 *  
	 * @param 
	 * @return
	 * @exception
	 * @see
	 * @since
	 */
	public ResponseEntity<Object> processRequest(String requestData,Map<String,String> requestHeaders,String apiVersion,String pathIdentifier,HttpServletRequest request)
	{
		long startTime                    =  System.currentTimeMillis();
		
		TravellingObject travellingObject =  new TravellingObject();
		System.out.println("[Post] [ProcessRequest] Request Data # "+(cleanStringData(requestData)));
		System.out.println("[Post] [ProcessRequest] Request Header # "+(cleanMapData(requestHeaders)));
		String queryString = null;

		try
		{
			travellingObject.setApiVersion(apiVersion);
			travellingObject.setPathIdentifier(pathIdentifier);
			travellingObject.setRequestType(pathIdentifier);
			travellingObject.setRequestData(requestData);
			System.out.println("TravellingObject Request : "+travellingObject.getRequestData());

			travellingObject.setRequestHeaders(requestHeaders);
			setHeaderValues(travellingObject,requestHeaders);
			ServiceContextCache.getInstance().createProviderContext(travellingObject.getServiceContext());
			log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "processRequest", LogType.APPLICATION.name());
			reqLog = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "processRequest", "RequestResponse");
			reqLog.printReqResLog(startTime, 0);
			
			if(request.getQueryString() !=null) {
				queryString=java.net.URLDecoder.decode(request.getQueryString(), "UTF-8");
			}

			if (requestData!=null) {
				orchestrationService.executeProcessFlow(travellingObject);
			}
			else {
				offlineFindAll(queryString,travellingObject);
			}
            log.println("[BaseController] # Response_Time # Country Code "+travellingObject.getCountryCode()+" # Path "+travellingObject.getPathIdentifier()+" # "+ (System.currentTimeMillis()-startTime) +" ms / "+ (System.currentTimeMillis()-startTime)/1000 +" seconds");
			
			return returnSuccessData(travellingObject);
		}
		catch (ProcessException e)
		{
			System.out.println("Exception for # BaseController # processRequest  # "+e.getLocalizedMessage()+" / "+e.getMessage());
			return returnFailure(e,travellingObject);
		}
		catch (Exception e)
		{
			System.out.println("Exception for # BaseController # processRequest  # "+e.getLocalizedMessage()+" / "+e.getMessage());
			return returnFailure("Unable to Read the Request");
		}
		finally
		{
			printServiceTimings(travellingObject);
			reqLog.printReqResLog(startTime, System.currentTimeMillis());
			ModuleContextManager.getModuleContext().removeModuleCache();
		}
	}


	@SuppressWarnings("unchecked")
	public    void  offlineFindAll(String queryString ,TravellingObject travellingObject) throws Exception 
	{
		System.out.println("Offline Mode - Inside findAll method  - Max record value from request:: "+maxRecords);
		HashMap<String, List<String>> filterMap = null;		
		System.out.println("In Offline Find##"+queryString);		
		filterMap=queryParameterParsingUtility.getValueList(queryString);
		System.out.println("FILTERMAP##"+filterMap);	

		try 
		{
			if (filterMap.size() > 0) 
			{				     
				travellingObject.setFilterMap(filterMap);
				orchestrationService.executeProcessFlow(travellingObject);
			}
		}
		catch(Exception e) 
		{
			System.out.println("coming to this offlineFindAll exception in customers resources");
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "offlineFindAll", LogType.APPLICATION.name());
			log.printErrorMessage(e);
			throw e;
		} 
		finally 
		{
			System.out.println("FINALLY --- coming to this offlineFindAll in customers resources");
		}

	}


	private void printServiceTimings(TravellingObject travellingObject)
	{
		try
		{ 
			for (Map.Entry<String,ServiceStatus> entry : travellingObject.getServiceStatus().entrySet())
			{
				System.out.println("Service ID - " + entry.getKey() +
						", Timings - Request Time - " + new Timestamp(entry.getValue().getRequestTime().getTime())+" / Response Time - "+new Timestamp(entry.getValue().getResponseTime().getTime())+" "
						+ " Time Taken "+(entry.getValue().getResponseTime().getTime()-entry.getValue().getRequestTime().getTime())
						+ " ms /  "+((entry.getValue().getResponseTime().getTime()-entry.getValue().getRequestTime().getTime()))/1000+" Seconds" );
			}
		}
		catch(Exception e)
		{

		}
	}

	/**
	 * <Description>
	 * <p> 
	 * <p> 
	 *  
	 * @param 
	 * @return
	 * @exception
	 * @see
	 * @since
	 */
	private void setHeaderValues(TravellingObject travellingObject,Map<String,String> requestHeaders) throws ProcessException
	{
		try
		{
			if(requestHeaders==null)
			{
				System.out.println("BaseController # No HeaderValues # ");
				return;
			}

			travellingObject.setCountryCode(requestHeaders.get(BaseConstants.SERVICE_API_HEADER_COUNTRY_CODE));
			travellingObject.setInterfaceId(requestHeaders.get(BaseConstants.SERVICE_API_HEADER_INTERFACE_ID));
			travellingObject.setOriginalTransactionIDforRetryRequest(requestHeaders.get(BaseConstants.SERVICE_API_HEADER_ORIGINAL_TRANSACTION_ID));
			travellingObject.setTransactionID(requestHeaders.get(BaseConstants.SERVICE_API_HEADER_TRANSACTION_ID));
			travellingObject.setDuplicateFlag(requestHeaders.get(BaseConstants.SERVICE_API_HEADER_DUPLICATE_FLAG));

		}
		catch(Exception e)
		{
			System.out.println("Exception for # BaseController # setHeaderValues  # "+e.getLocalizedMessage()+" / "+e.getMessage());
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "setHeaderValues", LogType.APPLICATION.name());
			log.printErrorMessage(e);

			throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,BaseConstants.CLM_GENERIC_ERROR,"INVALID HEADER DATA");
		}
		finally
		{
			//N.A
		}
	}
}
