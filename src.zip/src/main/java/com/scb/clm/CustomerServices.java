package com.scb.clm;

import java.time.ZoneId;
import java.time.format.TextStyle;
import java.util.Locale;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.scb.clm.common.config.ApplicationConfiguration;
import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.framework.logger.LoggerUtil;

import jakarta.annotation.PostConstruct;


@EnableCaching
@EnableAsync
@SpringBootApplication
public class CustomerServices  extends SpringBootServletInitializer
{

    private static final LoggerUtil log = LoggerUtil.getInstance(CustomerServices.class, BaseConstants.APPLICATION_NAME+"-"+System.getProperty("serviceName"),"GBL");

    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    public static void main(String[] args) {
        log.println("\n*****************************************************************************");
        log.println("\n               CUSTOMER LIFECYCLE MANAGEMENT SERVICES ");
        log.println("\n*****************************************************************************\n");
        System.setProperty("LOGGING_MANAGER","java.util.logging.manager=org.apache.logging.log4j.jul.LogManager");
        SpringApplication.run(CustomerServices.class, args);
    }


    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application)
    {
        System.setProperty("LOGGING_MANAGER","java.util.logging.manager=org.apache.logging.log4j.jul.LogManager");
        return application.sources(CustomerServices.class);
    }

    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    @PostConstruct
    public static void clmBanner()
    {
        log.println("\n*****************************************************************");
        log.println("CLM Services Started in : "+ZoneId.systemDefault().getDisplayName(TextStyle.FULL, Locale.ROOT)+" Zone");

        log.println("");
        log.println("         ____   _       __  __     ____    _____ ____   __     __  ___    ____   _____   ____   ");
        log.println("        / ___| | |     |  \\/  |   / ___|  | ____|  _ \\  \\ \\   / / |_ _|  / ___| | ____| / ___|  ");
        log.println("       | |     | |     | |\\/| |   \\___ \\  |  _| | |_) |  \\ \\ / /   | |  | |     |  _|   \\___ \\  ");
        log.println("       | |___  | |___  | |  | |    ___) | | |___|  _ <    \\ V /    | |  | |___  | |___   ___) | ");
        log.println("        \\____| |_____| |_|  |_|   |____/  |_____|_| \\_\\    \\_/    |___|  \\____| |_____| |____/  ");

    }

    /**
     * Code Setup Spring Boot
     * <p> Initiates Thread Executor Queue for Asynchronous Request Processing.
     * <p> Based on the process Mode in the Smart Sync request message, Request Object will be passed into this message
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    @Bean(name="LoggerQueue")
    public TaskExecutor logExecutor()
    {
        String asyncCorePoolSize    = "3";
        String asyncMaxPoolSize     = "10";
        String asyncQueueCapacity   = "100";
        ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();

        try
        {
            asyncCorePoolSize   = ApplicationConfiguration.getPropertiesHash(BaseConstants.ASYNC_CORE_POOL_SIZE);
            asyncMaxPoolSize    = ApplicationConfiguration.getPropertiesHash(BaseConstants.ASYNC_MAX_POOL_SIZE);
            asyncQueueCapacity  = ApplicationConfiguration.getPropertiesHash(BaseConstants.ASYNC_QUEUE_CAPACITY);

            int corePoolSize  = Integer.parseInt ( (asyncCorePoolSize  !=null && asyncCorePoolSize.trim().length() >0) ? asyncCorePoolSize.trim():"3");
            int maxPoolSize   = Integer.parseInt ( (asyncMaxPoolSize   !=null && asyncMaxPoolSize.trim().length()  >0) ? asyncMaxPoolSize.trim():"10");
            int queueCapacity = Integer.parseInt ( (asyncQueueCapacity !=null && asyncQueueCapacity.trim().length()>0) ? asyncQueueCapacity.trim():"100");

            log.println("LogExecutor Initializing CorePoolSize #"+corePoolSize+"# MaxPoolSize #"+maxPoolSize+"# QueueCapacity #"+queueCapacity+"#");

            threadPoolTaskExecutor.setThreadNamePrefix("CLM-Async-");
            threadPoolTaskExecutor.setCorePoolSize(corePoolSize);
            threadPoolTaskExecutor.setMaxPoolSize(maxPoolSize);
            threadPoolTaskExecutor.setQueueCapacity(queueCapacity);
            threadPoolTaskExecutor.afterPropertiesSet();
            log.println("LogExecutor Initialized CorePoolSize #"+corePoolSize+"# MaxPoolSize #"+maxPoolSize+"# QueueCapacity #"+queueCapacity+"#");
        }
        catch (Exception e)
        {
            log.println("LogExecutor # Exception for # CLMApplication # "+e.getLocalizedMessage()+" / "+e.getMessage());
        }
        return threadPoolTaskExecutor;
    }

    /**
     * Code Setup Spring Boot
     * <p> Initiates Thread Executor Queue for Asynchronous Request Processing.
     * <p> Based on the process Mode in the Smart Sync request message, Request Object will be passed into this message
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    @Bean(name="ServiceQueue")
    public TaskExecutor serviceExecutor()
    {
        String asyncCorePoolSize    = "3";
        String asyncMaxPoolSize     = "10";
        String asyncQueueCapacity   = "100";
        ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();

        try
        {
            asyncCorePoolSize   = ApplicationConfiguration.getPropertiesHash(BaseConstants.ASYNC_CORE_POOL_SIZE);
            asyncMaxPoolSize    = ApplicationConfiguration.getPropertiesHash(BaseConstants.ASYNC_MAX_POOL_SIZE);
            asyncQueueCapacity  = ApplicationConfiguration.getPropertiesHash(BaseConstants.ASYNC_QUEUE_CAPACITY);

            int corePoolSize  = Integer.parseInt ( (asyncCorePoolSize  !=null && asyncCorePoolSize.trim().length() >0) ? asyncCorePoolSize.trim():"3");
            int maxPoolSize   = Integer.parseInt ( (asyncMaxPoolSize   !=null && asyncMaxPoolSize.trim().length()  >0) ? asyncMaxPoolSize.trim():"10");
            int queueCapacity = Integer.parseInt ( (asyncQueueCapacity !=null && asyncQueueCapacity.trim().length()>0) ? asyncQueueCapacity.trim():"100");

            log.println("\nServiceExecutor Initializing CorePoolSize #"+corePoolSize+"# MaxPoolSize #"+maxPoolSize+"# QueueCapacity #"+queueCapacity+"#");

            threadPoolTaskExecutor.setThreadNamePrefix("CLM-Async-");
            threadPoolTaskExecutor.setCorePoolSize(corePoolSize);
            threadPoolTaskExecutor.setMaxPoolSize(maxPoolSize);
            threadPoolTaskExecutor.setQueueCapacity(queueCapacity);
            threadPoolTaskExecutor.afterPropertiesSet();
            log.println("ServiceExecutor Initialized CorePoolSize #"+corePoolSize+"# MaxPoolSize #"+maxPoolSize+"# QueueCapacity #"+queueCapacity+"#");
        }
        catch (Exception e)
        {
            log.println("ServiceExecutor # Exception for # CLMApplication # "+e.getLocalizedMessage()+" / "+e.getMessage());
        }
        return threadPoolTaskExecutor;
    }


}
