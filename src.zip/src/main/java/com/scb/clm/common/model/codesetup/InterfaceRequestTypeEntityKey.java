package com.scb.clm.common.model.codesetup;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

/*
 * 
 * @author       1378958
 * @version      1.0
 * @since           
 * @use          
 */
@Embeddable
public class InterfaceRequestTypeEntityKey implements Serializable,Cloneable
{

    private static final long serialVersionUID = 5749586117488357622L;

    @Column(name = "COUNTRY_CODE", nullable = false ,insertable=false, updatable=false)
    private String countryCode;

    @Column(name = "INTERFACE_ID", nullable = false ,insertable=false, updatable=false)
    private String interfaceIdentifier;

    @Column(name = "REQUEST_TYPE", nullable = false ,insertable=false, updatable=false)
    private String requestType;

    public InterfaceRequestTypeEntityKey() {

    }

    public InterfaceRequestTypeEntityKey (String countryCode,String interfaceIdentifier,String requestType) {
        this.countryCode            =     countryCode;
        this.interfaceIdentifier    =     interfaceIdentifier;
        this.requestType            =     requestType;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getInterfaceIdentifier() {
        return interfaceIdentifier;
    }

    public void setInterfaceIdentifier(String interfaceIdentifier) {
        this.interfaceIdentifier = interfaceIdentifier;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    @Override
    public int hashCode() {
        StringBuilder finalHashCode = new StringBuilder();
        if (this.countryCode != null && this.interfaceIdentifier != null)
        {
            finalHashCode.append(countryCode);
            finalHashCode.append(interfaceIdentifier);
        }
        return finalHashCode.toString().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
        {
            return true;
        }
        if ((obj == null) || (obj.getClass() != this.getClass())) 
        {
            return false;
        }
        InterfaceRequestTypeEntityKey other = (InterfaceRequestTypeEntityKey) obj;
        return   Objects.equals(this.countryCode, other.countryCode) 
                && Objects.equals(this.interfaceIdentifier, other.interfaceIdentifier);
    }

    @Override
    public Object clone() {
        try {
            return (InterfaceRequestTypeEntityKey) super.clone();
        } catch (CloneNotSupportedException e) {
            return new InterfaceRequestTypeEntityKey(this.getCountryCode(),this.getInterfaceIdentifier(),this.getRequestType());
        }
    }
}
