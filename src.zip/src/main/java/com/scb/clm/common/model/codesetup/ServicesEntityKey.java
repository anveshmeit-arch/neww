package com.scb.clm.common.model.codesetup;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

/*
 * 
 * @author       1378958
 * @version      1.0
 * @since           
 * @use          
 */
@Embeddable
public class ServicesEntityKey implements Serializable,Cloneable
{
    private static final long serialVersionUID = 2796933623456269579L;

    @Column(name = "COUNTRY_CODE", nullable = false ,insertable=false, updatable=false)
    private String countryCode;

    @Column(name = "SERVICE_ID", nullable = false ,insertable=false, updatable=false)
    private String serviceID;

    public ServicesEntityKey() {

    }

    public ServicesEntityKey (String countryCode,String serviceID) {
        this.countryCode = countryCode;
        this.serviceID   = serviceID;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getServiceID() {
        return serviceID;
    }

    public void setServiceID(String serviceID) {
        this.serviceID = serviceID;
    }

    @Override
    public int hashCode() {
        StringBuilder finalHashCode = new StringBuilder();
        if (this.countryCode != null && 
                this.serviceID != null) 
        {
            finalHashCode.append(countryCode);
            finalHashCode.append(serviceID);
        }
        return finalHashCode.toString().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
        {
            return true;
        }
        if ((obj == null) || (obj.getClass() != this.getClass())) 
        {
            return false;
        }
        ServicesEntityKey other = (ServicesEntityKey) obj;
        return   Objects.equals(this.countryCode, other.countryCode) 
                && Objects.equals(this.serviceID, other.serviceID);
    }

    @Override
    public Object clone() {
        try {
            return (ServicesEntityKey) super.clone();
        } catch (CloneNotSupportedException e) {
            return new ServicesEntityKey(this.getCountryCode(),this.getServiceID());
        }
    }    
}
