package com.scb.clm.common.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.config.ErrorCodeConfig;
import com.scb.clm.common.exception.ErrorObject;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.transactions.ErrorResponse;
import com.scb.clm.common.model.transactions.TravellingObject;

public class ResponseBuilder {

    /**
     * @Use           
     * @return            
     * @exception      
     * @see                
     * @since          V1.0
     */
    protected static String generateErrorContent(List<ErrorObject> errorList,String errorCode,String errorString)
    {
        if (errorList != null) 
        {
            return (String)JSONUtility.domainWrapperToJSON(errorList);
        } 
        else 
        {
            errorList = new ArrayList<ErrorObject>();
            if(errorCode==null || errorCode.trim().length()==0) 
            {
                errorCode = BaseConstants.CLM_GENERIC_ERROR;
            }
            if(errorString==null || errorString.trim().length()==0) 
            {
                errorString = "[Please Contact Support]";
            }
            errorList.add(new ErrorObject(BaseConstants.ERROR_TYPE_TECHNICAL,errorCode,errorString));
            return (String)JSONUtility.domainWrapperToJSON(errorList);
        }
    }


    /**
     * @Use           
     * @return            
     * @exception      
     * @see                
     * @since          V1.0
     */
    protected static String generateErrorContent(ErrorResponse errorResponse)
    {
        return (String)JSONUtility.domainWrapperToJSON(errorResponse);
    }

    /**
     * @Use           
     * @return            
     * @exception      
     * @see                
     * @since          V1.0
     */
    protected static String generateBodyContent(TravellingObject travellingObject)
    {
        if (travellingObject == null) 
        {
            return null;
        } 
        else 
        {
            return (String) travellingObject.getResponseData();
        }
    }

    /**
     * @Use           
     * @return            
     * @exception      
     * @see                
     * @since          V1.0
     */
    protected ResponseEntity<Object> returnSuccessData(TravellingObject travellingObject)
    {
        if(travellingObject != null) 
        {
            System.out.println("Generating Response ");
            return ResponseEntity.status(getHttpStatus(travellingObject))
                    .header("Content-Type", "application/json; charset=UTF-8")
                    .header("Content-Disposition", "inline;")
                    .header("application-reference-id",(travellingObject.getApplicationReferenceNumber() == null ? "" : travellingObject.getApplicationReferenceNumber()))
                    .body(constructJSONResponse(travellingObject.getResponseData()));
        } 
        else 
        {
            System.out.println("Generating Response [Data Set] ");
            return ResponseEntity.status(BaseConstants.HTTP_500)
                    .header("Content-Type", "application/json; charset=UTF-8")
                    .header("Content-Disposition", "inline;")
                    .body("CLM Exception");
        }
    }


    /**
     * @Use           
     * @return            
     * @exception      
     * @see                
     * @since          V1.0
     */
    public ResponseEntity<Object> returnFailure(String errorString)
    {
        return ResponseEntity.status(BaseConstants.HTTP_500)
                .header("Content-Type", "application/json; charset=UTF-8")
                .header("Content-Disposition", "inline;")
                .body(generateErrorContent(null,null,errorString));
    }  

    /**
     * @Use           
     * @return            
     * @exception      
     * @see                
     * @since          V1.0
     */
    //    
    public ResponseEntity<Object> returnFailure(ProcessException e,TravellingObject travellingObject)
    {
        ArrayList<ErrorObject> errorDetails     = new ArrayList<ErrorObject>();
        ErrorResponse errorResponse = new ErrorResponse();

        try 
        {
            if(travellingObject.getErrorDetails()!=null && travellingObject.getErrorDetails().size()>0) {
                errorDetails.addAll(travellingObject.getErrorDetails());
            }
            if(e.getErrorList() !=null && e.getErrorList().size()>0) {
                errorDetails.addAll(e.getErrorList());
            }
            errorResponse.addErrors(errorDetails);
            return ResponseEntity
                    .badRequest()
                    .header("Content-Type", "application/json; charset=UTF-8").body(generateErrorContent(errorResponse));
        }
        catch (Exception eX) 
        {
        	LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "returnFailure", LogType.APPLICATION.name());
        	log.printErrorMessage(eX);

            return ResponseEntity
                    .badRequest()
                    .header("Content-Type", "application/json; charset=UTF-8").body(generateErrorContent(null,null,null));
        }
    }  

    /**
     * @Use           
     * @return            
     * @exception      
     * @see                
     * @since          V1.0
     */
    protected String cleanStringData(String data) {
        return (data==null)?null:data.replaceAll("[\r\n]","");
    }

    /**
     * @Use           
     * @return            
     * @exception      
     * @see                
     * @since          V1.0
     */
    protected String cleanMapData(Map<String,String> data) {
        return (data==null)?null:data.toString().replaceAll("[\r\n]","");
    }

    /**
     * @Use           
     * @return            
     * @exception      
     * @see                
     * @since          V1.0
     */
    protected String constructJSONResponse(Object data)
    {
        return (String) JSONUtility.domainWrapperToJSON(data);
    }

    /**
     * @Use           
     * @return            
     * @exception      
     * @see                
     * @since          V1.0
     */
    protected int getHttpStatus(TravellingObject travelObject)
    {
        int httpCode = BaseConstants.HTTP_200;

        if( travelObject!=null && travelObject.getErrorDetails()!=null && travelObject.getErrorDetails().size()>0)
        {
            for(ErrorObject err : travelObject.getErrorDetails())
            {
                int newCode  = ErrorCodeConfig.getHttpStatus(travelObject.getCountryCode(), err.getCode(), err.getType());
                if(newCode > httpCode) {
                    httpCode = newCode;
                    System.out.println("[Upgrading HTTP Response Code ] ["+httpCode+"]");        
                }
            }
        }
        System.out.println("[HTTP Response Code Generated] ["+httpCode+"]");        
        return httpCode; 
    }
}
