package com.scb.clm.common.model.transactions;

import java.util.HashMap;
import java.util.Map;

public class ServiceMetadata 
{

    private String serviceCountryCode;

    private String serviceIdentifier;

    private Map<String, Object> threadDataMap = new HashMap<>();

    public String getServiceCountryCode() {
        return serviceCountryCode;
    }

    public void setServiceCountryCode(String serviceCountryCode) {
        this.serviceCountryCode = serviceCountryCode;
    }

    public String getServiceIdentifier() {
        return serviceIdentifier;
    }

    public void setServiceIdentifier(String serviceIdentifier) {
        this.serviceIdentifier = serviceIdentifier;
    }

    public Map<String, Object> getThreadDataMap() {
        return threadDataMap;
    }

    public void setThreadDataMap(Map<String, Object> threadDataMap) {
        this.threadDataMap = threadDataMap;
    }

    public void addData(String key, Object value) {
        threadDataMap.put(key, value);
    }

    public Object getData(String key) {
        return threadDataMap.get(key);
    }

    public void removeData(String key) {
        threadDataMap.remove(key);
    }

    public void clearData() {
        threadDataMap.clear();
    }

}
