package com.scb.clm.common.config.jpa;
import java.util.HashMap;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

import com.scb.clm.common.config.ApplicationConfiguration;
import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;

@Configuration
@EnableJpaRepositories(basePackages = {"com.scb.clm.*"},
entityManagerFactoryRef = "clmDatabaseEntityManager", transactionManagerRef = "clmDatabaseTransactionManager")
//@Profile("default")
public class CLMDatabaseConfiguration {
    @Autowired
    private Environment env;

    private HashMap<String, String> dbProperties = null;
    public CLMDatabaseConfiguration() {
        super();
    }


    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Primary
    @Bean
    public LocalContainerEntityManagerFactoryBean clmDatabaseEntityManager() {
        final LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(clmDataSource());
        em.setPackagesToScan("com.scb.clm.*");
        final HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        em.setJpaVendorAdapter(vendorAdapter);
        final HashMap<String, Object> properties = new HashMap<String, Object>();
        properties.put("hibernate.hbm2ddl.auto", env.getProperty("spring.jpa.hibernate.ddl-auto"));
        //properties.put("hibernate.dialect", env.getProperty("spring.jpa.properties.hibernate.dialect"));
        if(dbProperties.get("DATABASE_TYPE").equals("O")) {
        	properties.put("hibernate.dialect", env.getProperty("spring.jpa.properties.hibernate.oracle.dialect"));
        }else if(dbProperties.get("DATABASE_TYPE").equals("P")) {
        	properties.put("hibernate.dialect", env.getProperty("spring.jpa.properties.hibernate.postgres.dialect"));
        }
        properties.put("hibernate.format_sql", env.getProperty("spring.jpa.properties.hibernate.format_sql"));
        properties.put("hibernate.show_sql", env.getProperty("spring.jpa.properties.hibernate.show_sql"));
        properties.put("hibernate.use_sql_comments", env.getProperty("spring.jpa.properties.hibernate.use_sql_comments"));
        properties.put("hibernate.type", env.getProperty("spring.jpa.properties.hibernate.type"));
        properties.put("hibernate.naming.physical-strategy", env.getProperty("spring.jpa.hibernate.naming.physical-strategy"));

        properties.put("hibernate.enable_lazy_load_no_trans", env.getProperty("spring.jpa.properties.hibernate.enable_lazy_load_no_trans"));

        em.setJpaPropertyMap(properties);
        return em;
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
	@Primary
	@Bean
	public DataSource clmDataSource() {
		final DriverManagerDataSource dataSource = new DriverManagerDataSource();
		ApplicationConfiguration applicationConfiguration = null;
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "clmDataSource", LogType.APPLICATION.name());

		try {
			applicationConfiguration = ApplicationConfiguration.getInstance();
			dbProperties = applicationConfiguration.getHashicorpValutedProperties();
			dataSource.setDriverClassName(dbProperties.get(BaseConstants.DB_DRIVER).toString());
			dataSource.setUrl(dbProperties.get(BaseConstants.JDBC_URL).toString());
			dataSource.setUsername(dbProperties.get(BaseConstants.DB_USER_ID).toString());
			dataSource.setPassword(dbProperties.get(BaseConstants.DB_PW).toString());
			log.println("Datasource Loaded ");
		} catch (Exception e) {
			log.printErrorMessage(e);
		}
		return dataSource;
	}

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @Primary
    @Bean
    public PlatformTransactionManager clmDatabaseTransactionManager() {
        final JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(clmDatabaseEntityManager().getObject());
        return transactionManager;
    }

}


