package com.scb.clm.common.filter;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FilterAllowed{
	@JsonProperty("resource_type") 
    public String resource_type;
	public String getResource_type() {
		return resource_type;
	}
	public void setResource_type(String resource_type) {
		this.resource_type = resource_type;
	}
	public ArrayList<FilterAttribute> getFilter_attribute() {
		return filter_attribute;
	}
	public void setFilter_attribute(ArrayList<FilterAttribute> filter_attribute) {
		this.filter_attribute = filter_attribute;
	}
	@JsonProperty("filter_attribute") 
    public ArrayList<FilterAttribute> filter_attribute;
}

