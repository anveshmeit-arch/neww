package com.scb.clm.common.security.auth;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.scb.clm.common.filter.FilterAllowed;
public class Acl
{
    public String interfacename;
    public Permissions permissions;

    public String getInterfacename() 
    {
        return interfacename;
    }
    
    public void setInterfacename(String interfacename) 
    {
        this.interfacename = interfacename;
    }
    
    public Permissions getPermissions() 
    {
        return permissions;
    }
    
    public void setPermissions(Permissions permissions) 
    {
        this.permissions = permissions;
    }

    public String getRequesttype() {
		return requesttype;
	}
	public void setRequesttype(String requesttype) {
		this.requesttype = requesttype;
	}
	public String getGet() {
		return get;
	}
	public void setGet(String get) {
		this.get = get;
	}
	public String getPost() {
		return post;
	}
	public void setPost(String post) {
		this.post = post;
	}
	public String getDelete() {
		return delete;
	}
	public void setDelete(String delete) {
		this.delete = delete;
	}
	public String getInclude() {
		return include;
	}
	public void setInclude(String include) {
		this.include = include;
	}
	
	public ArrayList<FilterAllowed> getFilter_allowed() {
		System.out.println("filter_allowed:"+filter_allowed);
		return filter_allowed;
	}
	public void setFilter_allowed(ArrayList<FilterAllowed> filter_allowed) {
		System.out.println(" set filter_allowed:"+filter_allowed);

		this.filter_allowed = filter_allowed;
	}
	


	@JsonProperty("interfaceid") 
	public String interfaceid;
	
	public String getInterfaceid() {
		return interfaceid;
	}
	public void setInterfaceid(String interfaceid) {
		this.interfaceid = interfaceid;
	}



	@JsonProperty("requesttype") 
	public String requesttype;
	
	@JsonProperty("get") 
	public String get;
	
	@JsonProperty("post") 
    public String post;
	
	@JsonProperty("delete") 
    public String delete;
	
	@JsonProperty("include") 
    public String include;
	
	
	@JsonProperty("filter_allowed") 
    public ArrayList<FilterAllowed> filter_allowed;
}
