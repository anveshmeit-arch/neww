package com.scb.clm.common.model.transactions;

import com.scb.clm.common.config.BaseConstants;

public class NodeStatus
{    
	private String flowIdentifier;
	private String nodeIdentifier;
	private String nodeSequenceId;
	private String skipToNode;

	private boolean processToNextNode	=	true;
	private String status 				=	BaseConstants.NODE_SUCCESS;

	public String getFlowIdentifier() {
		return flowIdentifier;
	}

	public void setFlowIdentifier(String flowIdentifier) {
		this.flowIdentifier = flowIdentifier;
	}

	public String getNodeIdentifier() {
		return nodeIdentifier;
	}

	public void setNodeIdentifier(String nodeIdentifier) {
		this.nodeIdentifier = nodeIdentifier;
	}

	public String getNodeSequenceId() {
		return nodeSequenceId;
	}

	public void setNodeSequenceId(String nodeSequenceId) {
		this.nodeSequenceId = nodeSequenceId;
	}

	public String getSkipToNode() {
		return skipToNode;
	}

	public void setSkipToNode(String skipToNode) {
		this.skipToNode = skipToNode;
	}

	public boolean isProcessToNextNode() {
		return processToNextNode;
	}

	public void setProcessToNextNode(boolean processToNextNode) {
		this.processToNextNode = processToNextNode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}


}
