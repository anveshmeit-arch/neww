package com.scb.clm.common.repository;

import java.util.List;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.scb.clm.common.model.codesetup.CountryCodeEntity;

@Repository
public interface CountryCodeRepository extends JpaRepository<CountryCodeEntity, String> { 

    @Override
    public <S extends CountryCodeEntity> S save(S entity);

    @Override
    @Cacheable("Country")
    public CountryCodeEntity getOne(String arg0);

    public List<CountryCodeEntity> findAll();

    @Cacheable("Nationality")
    @Query(value = "SELECT n.nationalityCode FROM CountryCodeEntity n where n.countryCode= :countryCode")
    public String getNationality(@Param("countryCode") String countryCode);

}