package com.scb.clm.common.security.auth;


import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.filter.FilterAllowed;
import com.scb.clm.common.filter.FilterAttribute;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.util.AuthUtility;
import com.scb.clm.common.util.ExceptionUtility;
import com.scb.clm.common.util.QueryParameterParsingUtility;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;

@Component
@Order(Ordered.LOWEST_PRECEDENCE)
public final class AuthorizationFilter implements Filter {

	HashMap<String,String> headerData = getHttpHeaderDetails();

	String url =null;

	@Autowired
	ObjectMapper objectMapper;

	private FilterConfig filterConfig = null;
	private ACLRoot aclObject                   =   null;
	private ArrayList<Acl> aclList              =   null;

	@Autowired
	QueryParameterParsingUtility queryParameterParsingUtility;

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		System.out.println("coming into AuthorizationFilter");
		HashMap<String,String> headerData = getHttpHeaderDetails();
		short statusCode;
		String exceptionReasonInJson = null;
		String decodedurl  = null;
		ACLMapper aclMapper               = null;

		String method =((HttpServletRequest)request).getMethod();
		System.out.println("Request Method : "+method); //Request Method : GET
		int filterFound=0;

		System.out.println("((HttpServletRequest)request).getRequestURL() : "+((HttpServletRequest)request).getRequestURL());
		System.out.println("((HttpServletRequest)request).getPathInfo() : "+((HttpServletRequest)request).getPathInfo());
		System.out.println("((HttpServletRequest)request).getQueryString() : "+((HttpServletRequest)request).getQueryString());
		if(((HttpServletRequest)request).getRequestURI() != null && AuthUtility.isHealthCheckJsp(((HttpServletRequest)request).getRequestURI(),((HttpServletRequest)request).getContextPath())) {
			chain.doFilter(request, response);
		}else {
				if (((HttpServletRequest)request).getQueryString() != null ) {
					url = ((HttpServletRequest)request).getRequestURL().toString()+ "?"+  ((HttpServletRequest)request).getQueryString();
				}
				else {
					url = ((HttpServletRequest)request).getRequestURL().toString(); //+ "?"+  ((HttpServletRequest)request).getQueryString();
				}		
				System.out.println("URL : "+ url);
				if(((HttpServletRequest)request).getQueryString() !=null) {
					decodedurl = java.net.URLDecoder.decode( ((HttpServletRequest)request).getQueryString(), "UTF-8");
					filterFound = decodedurl.indexOf("filter[");
		
					System.out.println("Decoded URL##"+decodedurl);
				}
				String resourceName = getResourceType(url, method);
				System.out.println("resourceName is : "+resourceName); //resourceName is : customers
		
		
		
				try 
				{
					System.out.println("ACL For Country Code ["+headerData.get(BaseConstants.API_HEADER_COUNTRY_CODE)+"]");
					aclObject = ACLMapper.getInstance(headerData.get(BaseConstants.API_HEADER_COUNTRY_CODE));
				} 
				catch (Exception e1) 
				{
					LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "doFilter", LogType.APPLICATION.name());
					log.printErrorMessage(e1);
		
				}
		
				Acl aclForinterfaceName = null;	
		
				String interfaceName = headerData.get(BaseConstants.API_HEADER_INTERFACE_ID);
		
				System.out.println("interfaceName : "+ interfaceName);
		
				
		
				if (aclObject !=null && isAuthorized(headerData,interfaceName, method, resourceName))
				{

				    for (int i=0; i<aclObject.getAcl().size(); i++) {
				        System.out.println("aclRoot.getAcl().get(i).getInterfacename() : " + aclObject.getAcl().get(i).getInterfacename());
				        if(aclObject.getAcl().get(i).getInterfacename().equalsIgnoreCase(interfaceName)) {
				            aclForinterfaceName = aclObject.getAcl().get(i);
				            System.out.println("aclforInterfaceId is : "+aclForinterfaceName);
				            break;
				        }
				    }

				    System.out.println("InterfaceId Inside Authorization Filter : "+ headerData.get(BaseConstants.API_HEADER_INTERFACE_ID));
				    System.out.println("InterfaceName Value ["+interfaceName+"]");
				    if (decodedurl==null) {

				        chain.doFilter(request, response);
				    }
				}else {
				    System.out.println("ACL is not loaded");
				    statusCode = 400;
				    exceptionReasonInJson = "{\"message\": \""+interfaceName + " is not authorized to perform " + method + " request\"}";
				    ExceptionUtility.printException(exceptionReasonInJson, response, statusCode);
				}
		
		
		
				if (aclForinterfaceName !=null) {
					System.out.println("methodType : "+method);		
		
					System.out.println("methodType : "+method);		
		
					if (method.equalsIgnoreCase("GET") && decodedurl!=null) {
						List<String> inputArrayList = new ArrayList<String>();
						HashMap<String, List<String>> filterMap = null;
						filterMap=queryParameterParsingUtility.getValueList(decodedurl);
						System.out.println("FilterMap in Authorization Filter##"+filterMap);	
						if (filterFound != -1) {
							inputArrayList.addAll(filterMap.keySet());							 
						}
						//System.out.println("filter value : "+filterFieldName.substring(0,filterFieldName.length()-1));
		
						ArrayList<FilterAllowed> filterAllowedList = aclForinterfaceName.getFilter_allowed();
						System.out.println("filterAllowedList : "+filterAllowedList.size());
						ArrayList<FilterAttribute> filterAttribute = null;
						String filterAttributeArray=null;
						List<String> filterAttributeList=new ArrayList<String>() ;
		
						boolean correctFilter = false;
		
						for(int i=0; i<filterAllowedList.size(); i++) { 
							System.out.println("filterAllowedList.get(i).getResource_type() : "+filterAllowedList.get(i).getResource_type()+"//"+filterAllowedList.get(i).getFilter_attribute());
							if( filterAllowedList.get(i).getResource_type() !=null 
									&& filterAllowedList.get(i).getResource_type().equalsIgnoreCase(resourceName) 
									&& filterAllowedList.get(i).getFilter_attribute() !=null) { 
								filterAttribute = filterAllowedList.get(i).getFilter_attribute(); 
								for(FilterAttribute setOfFilters : filterAttribute) {				    	  
									filterAttributeArray = setOfFilters.filter_input;
									filterAttributeList.add(filterAttributeArray);	    	  		
		
								}
								System.out.println("inputArrayList : "+inputArrayList);
								System.out.println("filterAttributeList : "+filterAttributeList);
		
								try {
									if (inputArrayList.size()>0 && filterAttributeList.size() >0 && filterAttributeList.containsAll(inputArrayList)){
										System.out.println("If condition");
										correctFilter = true;
										break;
									} else {
										System.out.println("Else condition");
									}
								}catch(Exception e) {
									System.out.println("Inside Exception ....");
									LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "doFilter", LogType.APPLICATION.name());
									log.printErrorMessage(e);
		
									throw e;
								}
							} 
							if (correctFilter) {
								break;
							}
						}
						if (!correctFilter) {
							System.out.println("Filter is not Allowed");
							statusCode = 400;
							exceptionReasonInJson = "{\"message\": \"Given Filter is not Allowed for this " + resourceName + " Resource API \"}";
							ExceptionUtility.printException(exceptionReasonInJson, response, statusCode);
						} else {
							System.out.println("success");
							chain.doFilter(request, response);
		
						}
					}
				}
		
		}
		
		System.out.println("End of AuthorizationFilter");


	}


	public String isACLLoaded() 
	{
		if (aclObject == null) 
		{
			System.out.println("ACL matrix is not loaded.");
			return null;
		}
		return "loaded";
	}

	public boolean isAuthorized(HashMap<String,String> headerData,String interfaceName, String method, String resourceName) 
	{
		aclList = aclObject.getAcl();
		String getValue="";
		String postValue="";
		String patchValue="";
		String deleteValue="";

		for(Acl acl : aclList) 
		{
			if (acl.getInterfacename().equalsIgnoreCase(interfaceName)) 
			{
				Permissions per = acl.getPermissions();
				if (method.equalsIgnoreCase("GET")) 
				{
					getValue = per.getGet();
					List<String> resourceList = Stream.of(getValue.split(",", -1)).collect(Collectors.toList());
					System.out.println("resourceList"+resourceList);
					System.out.println("resourceName"+resourceName);
					if (resourceList.contains("all") || resourceList.contains(resourceName)) 
					{
						System.out.println("Inside Get having resourceName : "+ resourceName);                		
						return true;
					} 
					else if (resourceList.contains("none")) 
					{
						return false;
					}
				} 
				else if (method.equalsIgnoreCase("POST")) 
				{
					postValue = per.getPost();
					List<String> resourceList = Stream.of(postValue.split(",", -1)).collect(Collectors.toList());
					if (resourceList.contains("all") || resourceList.contains(resourceName)) 
					{
						System.out.println("Inside Post having resourceName : "+ resourceName);                		
						return true;
					} 
					else if (resourceList.contains("none")) 
					{
						return false;
					}
				} 
				else if (method.equalsIgnoreCase("PATCH")) 
				{
					patchValue = per.getPatch();
					List<String> resourceList = Stream.of(patchValue.split(",", -1)).collect(Collectors.toList());

					if (resourceList.contains("all") || resourceList.contains(resourceName)) 
					{
						System.out.println("Inside Patch having resourceName : "+ resourceName);                		
						return true;
					} 
					else if (resourceList.contains("none")) 
					{
						return false;
					}
				} 
				else if (method.equalsIgnoreCase("DELETE")) 
				{
					deleteValue = per.getDelete();
					List<String> resourceList = Stream.of(deleteValue.split(",", -1)).collect(Collectors.toList());

					if (resourceList.contains("all") || resourceList.contains(resourceName)) 
					{
						System.out.println("Inside Get having resourceName : "+ resourceName);                		
						return true;
					} 
					else if (resourceList.contains("none")) 
					{
						return false;
					}
				}
			}
		}
		return false;
	}
	public HashMap<String,String> getHttpHeaderDetails()
	{
		HashMap<String,String> headerData = new HashMap<String,String>();

		try
		{
			ServletRequestAttributes attr = (ServletRequestAttributes)RequestContextHolder.getRequestAttributes();

			if(attr!=null) {
				if (attr.getRequest().getHeader("transactionId") != null)
				{
					headerData.put(BaseConstants.API_HEADER_TRANSACTION_ID,attr.getRequest().getHeader("transactionId"));
				}
				if (attr.getRequest().getHeader("countryCode") != null)
				{
					headerData.put(BaseConstants.API_HEADER_COUNTRY_CODE,attr.getRequest().getHeader("countryCode"));
				}
				if (attr.getRequest().getHeader("interfaceId") != null)
				{
					headerData.put(BaseConstants.API_HEADER_INTERFACE_ID,attr.getRequest().getHeader("interfaceId"));
				} 
			}
		}
		catch (Exception e) {
			LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "getHttpHeaderDetails", LogType.APPLICATION.name());
			log.printErrorMessage(e);

			throw e;
		}
		return headerData;
	}

	public String getResourceType(String url, String protocolMethod) {
		String uri="profile/v1/";
		int startIndexForResourceName = -1;
		int endIndexForResourceName = -1;
		startIndexForResourceName = url.lastIndexOf(uri);

		System.out.println("startIndexForResourceName value : "+ startIndexForResourceName);
		if (startIndexForResourceName != -1) { 
			endIndexForResourceName = url.lastIndexOf("/", startIndexForResourceName+uri.length());
			System.out.println("endIndexForResourceName value : "+ endIndexForResourceName);
		}
		System.out.println("endIndexForResourceName value : "+ endIndexForResourceName);
		System.out.println("[URL : "+ url+"]");

		String resourceName = "";
		if (startIndexForResourceName != -1 && endIndexForResourceName !=-1) {
			resourceName = url.substring(endIndexForResourceName+1);
			System.out.println("resourceName inside the If condition : "+ resourceName);
		}	
		startIndexForResourceName = resourceName.lastIndexOf("/");
		System.out.println("startIndexForResourceName value 2nd time : "+ startIndexForResourceName);
		if (startIndexForResourceName != -1) {
			resourceName = resourceName.substring(0,startIndexForResourceName);
			System.out.println("resourceName inside the If condition - 2nd value: "+ resourceName);
		}	
		startIndexForResourceName = resourceName.lastIndexOf("?");
		System.out.println("startIndexForResourceName value 3nd time : "+ startIndexForResourceName);
		if (startIndexForResourceName != -1) {
			resourceName = resourceName.substring(0,startIndexForResourceName);
			System.out.println("resourceName inside the If condition - 3nd value: "+ resourceName);
		}
		return resourceName;
	}


	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		this.setFilterConfig(filterConfig);
	}



	public void destroy() {
		this.setFilterConfig(null);
	}


	/**
	 * @return the filterConfig
	 */
	public FilterConfig getFilterConfig() {
		return filterConfig;
	}


	/**
	 * @param filterConfig the filterConfig to set
	 */
	public void setFilterConfig(FilterConfig filterConfig) {
		this.filterConfig = filterConfig;
	}

}