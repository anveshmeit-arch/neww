package com.scb.clm.common.security.auth;

public class Permissions
{
    public String get;
    public String post;
    public String patch;
    public String delete;

    public String getGet() {
        return get;
    }
    public void setGet(String get) {
        this.get = get;
    }
    public String getPost() {
        return post;
    }
    public void setPost(String post) {
        this.post = post;
    }
    public String getPatch() {
        return patch;
    }
    public void setPatch(String patch) {
        this.patch = patch;
    }
    public String getDelete() {
        return delete;
    }
    public void setDelete(String delete) {
        this.delete = delete;
    }
}
