package com.scb.clm.common.repository;

import java.util.List;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.relational.core.mapping.Table;
import org.springframework.stereotype.Repository;

import com.scb.clm.common.model.codesetup.CountryParametersEntity;
import com.scb.clm.common.model.codesetup.CountryParametersEntityKey;

@Table
@Repository
public interface CountryParametersRepository extends JpaRepository<CountryParametersEntity, CountryParametersEntityKey>
{

    @Override
    public <S extends CountryParametersEntity> S save(S entity);

    @Override
    public CountryParametersEntity getOne(CountryParametersEntityKey arg0);

    @Override
    public List<CountryParametersEntity> findAll();

    @Cacheable("ParameterGroupAndParamCode")
    List<CountryParametersEntity> findByIdCountryCodeAndIdParameterGroup(String countryCode, String parameterGroup);

    @Cacheable("CountryParametersByGroupAndParamCode")
    List<CountryParametersEntity> findByIdCountryCodeAndIdParameterGroupAndParameterCode(String countryCode, String parameterGroup, String parameterCode);
}