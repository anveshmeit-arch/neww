package com.scb.clm.common.framework.logger;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Map;

import org.apache.logging.log4j.ThreadContext;

public class  LogThreadMapContext

{
	private static LogThreadMapContext singleton = new LogThreadMapContext();
	
	private static Map<Long,LoggerUtil> threadHash= new Hashtable<Long,LoggerUtil>();
	private static Hashtable<String,LoggerUtil> stringHash= new Hashtable<String,LoggerUtil>();
	
	private LogThreadMapContext(){

	}
	
	public static LogThreadMapContext getInstance(){
		
		if (singleton!=null) {
			return singleton;
		}
		else  {
			return new LogThreadMapContext();
		}
	}
	
	// File name which are formed using 3 - set argument
	public void setLogger(LoggerUtil logger)
	{
		threadHash.put(Thread.currentThread().getId(),logger);
	}

	public LoggerUtil getLogger()
	{
	    return threadHash.get(Thread.currentThread().getId());
	}
	
	public void removeLogger()
	{
		String threadId = Long.toString(Thread.currentThread().getId());
		//ThreadContext.fileMap.remove(threadId+"common");
		threadHash.remove(Thread.currentThread().getId());
		//ThreadContext.remove("appLogPath");
		Enumeration<String> enumKey = stringHash.keys();
		   while(enumKey.hasMoreElements()) {
			   String key = enumKey.nextElement();

		       if(key.contains(threadId)){
		    	   //ThreadContext.fileMap.remove(key);
		    	   stringHash.remove(key);
		       }
		   }
	}

	
	// File name which are formed using 4 - set argument, Only used in frame work, for logs like request.log
	public void setLogger(String name , LoggerUtil logger)
	{
		stringHash.put(Thread.currentThread().getId()+name,logger);
	}

	public LoggerUtil getLogger(String fileName)
	{
		return stringHash.get(Thread.currentThread().getId()+fileName);
	}
	
	public void removeLogger(String fileName)
	{
		String threadkey = Thread.currentThread().getId()+fileName;
		//ThreadContext.fileMap.remove(threadkey);
		stringHash.remove(threadkey);
	}
	
	
}
