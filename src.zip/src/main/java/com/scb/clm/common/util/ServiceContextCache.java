package com.scb.clm.common.util;

public class ServiceContextCache extends ModuleCache {

	private static ServiceContextCache serviceContextCache = null; //Modified for Sonar Fix
	final static String ENQ = "ENQUIRY";

	private ServiceContextCache() {
	}

	public static ServiceContextCache getInstance() {
		if (serviceContextCache == null) {
			serviceContextCache = new ServiceContextCache();
		}		
		return serviceContextCache;
	}

	public void createProviderContext(ServiceContext serviceContext)  {
			setServiceContext(serviceContext);
		}

	private void setServiceContext(ServiceContext serviceContext) {
		setCacheObject(ENQ, serviceContext,SystemUtilityConstants.SERVICECONTEXT);
	}

	public ServiceContext getServiceContext(){
		return (ServiceContext) getCacheObject(ENQ, SystemUtilityConstants.SERVICECONTEXT);
	}
}
