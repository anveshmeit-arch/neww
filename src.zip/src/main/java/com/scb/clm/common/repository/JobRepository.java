package com.scb.clm.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.scb.clm.common.model.codesetup.JobsEntity;

@Repository
public interface JobRepository extends JpaRepository<JobsEntity, String>{

    @Override
    public <S extends JobsEntity> S save(S entity);

}
