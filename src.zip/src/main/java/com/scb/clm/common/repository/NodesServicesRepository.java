package com.scb.clm.common.repository;

import java.util.List;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.relational.core.mapping.Table;
import org.springframework.stereotype.Repository;

import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.codesetup.NodeServicesEntityKey;

@Table
@Repository
public interface NodesServicesRepository extends JpaRepository<NodeServicesEntity, NodeServicesEntityKey>
{

    @Override
    public <S extends NodeServicesEntity> S save(S entity);

    @Override
    @Cacheable("NodeServices")
    public NodeServicesEntity getOne(NodeServicesEntityKey arg0);

    @Cacheable("NodeServicesByFlowAndNode")
    List<NodeServicesEntity> findByIdCountryCodeAndIdFlowIdentifierAndIdNodeIdentifierAndStatusFlag(String countryCode,  String flowIdentifier, String nodeIdentifier,String statusFlag);

}