package com.scb.clm.common.db.support;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyStore;
import java.util.HashMap;

import javax.net.ssl.SSLContext;

import org.apache.hc.client5.http.classic.HttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClientBuilder;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.client5.http.socket.ConnectionSocketFactory;
import org.apache.hc.client5.http.socket.PlainConnectionSocketFactory;
import org.apache.hc.client5.http.ssl.SSLConnectionSocketFactory;
import org.apache.hc.core5.http.URIScheme;
import org.apache.hc.core5.http.config.Registry;
import org.apache.hc.core5.http.config.RegistryBuilder;
import org.apache.hc.core5.ssl.SSLContextBuilder;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.util.ResourceUtils;
import org.springframework.web.client.RestTemplate;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ProcessException;

public class RestTemplateConfig 
{

	private static final String KEYSTORE_INSTANCE_TYPE = "JKS";
	private static RestTemplateConfig restTemplateConfig;
	private static RestTemplate restTemplate;

	/**
	 * <Description>
	 * <p> 
	 * <p> 
	 *  
	 * @param 
	 * @return
	 * @exception
	 * @see
	 * @since
	 */
	protected RestTemplate getRestTemplate() throws ProcessException 
	{
		return restTemplate;
	}

	/**
	 * <Description>
	 * <p> 
	 * <p> 
	 *  
	 * @param 
	 * @return
	 * @exception
	 * @see
	 * @since
	 */
	protected static RestTemplateConfig getInstance(HashMap<String, String> argRequestInfo) throws ProcessException 
	{
		synchronized(RestTemplateConfig.class) 
		{      
			RestTemplateConfig inst = restTemplateConfig;         
			if (inst == null) 
			{
				synchronized(RestTemplateConfig.class) 
				{  
					restTemplateConfig = new RestTemplateConfig();
					restTemplate = new RestTemplate(clientHttpsRequestFactory(argRequestInfo));
					System.out.println("RestTemplateConfig_Instance_Created");               
				}
			}
		}
		return restTemplateConfig;
	}

	/**
	 * <Description>
	 * <p> 
	 * <p> 
	 *  
	 * @param 
	 * @return
	 * @exception
	 * @see
	 * @since
	 */
	protected static HttpComponentsClientHttpRequestFactory clientHttpsRequestFactory(HashMap<String, String> argRequestInfoDetails) throws ProcessException
	{
		KeyStore keyStore = null;
		File keyFiles = null;
		FileInputStream keyStream = null;

		try 
		{
			System.out.println("HttpComponentsClientHttpRequestFactory_Created");

			keyStore = KeyStore.getInstance(KEYSTORE_INSTANCE_TYPE);
			keyFiles = new File(argRequestInfoDetails.get("keyStorePath"));
			keyStream = new FileInputStream(keyFiles);

			keyStore.load(keyStream, argRequestInfoDetails.get("keyStoreCredentials").toCharArray());

			SSLContext sslContext = SSLContextBuilder.create()
					.loadTrustMaterial(ResourceUtils.getFile(argRequestInfoDetails.get("trustStorePath")),argRequestInfoDetails.get("truststoreCredential").toCharArray())
					.loadKeyMaterial(keyStore, argRequestInfoDetails.get("keyStoreCredentials").toCharArray()).build();

			Registry<ConnectionSocketFactory> socketRegistry = RegistryBuilder.<ConnectionSocketFactory>create()
					.register(URIScheme.HTTPS.getId(), new SSLConnectionSocketFactory(sslContext))
					.register(URIScheme.HTTP.getId(), new PlainConnectionSocketFactory())
					.build();

			HttpClient httpClient = HttpClientBuilder.create()
					.setConnectionManager(new PoolingHttpClientConnectionManager(socketRegistry))
					.setConnectionManagerShared(true)
					.build();

			HttpComponentsClientHttpRequestFactory clientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
			//            clientHttpRequestFactory.setHttpClient(httpClient);
			return clientHttpRequestFactory;
		} 
		catch (Exception e) 
		{
			throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL, BaseConstants.CLM_GENERIC_ERROR," Exception - "+e.getMessage());
		}
		finally 
		{
			if (keyStream != null) 
			{
				try 
				{
					keyStream.close();
				} 
				catch (IOException e) 
				{
					throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL, BaseConstants.CLM_GENERIC_ERROR," IOException - "+e.getMessage());
				}
			}
		}
	}
}
