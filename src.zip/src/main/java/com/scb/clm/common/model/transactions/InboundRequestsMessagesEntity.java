package com.scb.clm.common.model.transactions;

import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/*
 * 
 *  @author      1378958
 *  @version     1.0
 *  @since       
 *  @use         
 */
@Entity
@Table(name = "CLM_INBOUND_REQUEST_MESSAGES")
public class InboundRequestsMessagesEntity extends AbstractPersistableEntity<String> implements Cloneable,LoggerInterface
{
    @Id
    @Column(name="REQUEST_ID")
    private String requestId;

    @Column(name="COUNTRY_CODE")
    private String countryCode;

 //   @Lob
    //    @Type(type="org.hibernate.type.BinaryType")
    @Column(name = "REQUEST_MESSAGE")
    private String requestMessage;

   // @Lob
    //  @Type(type="org.hibernate.type.BinaryType")
    @Column(name = "RESPONSE_MESSAGE")
    private String responseMessage;

    @ManyToOne
    @JoinColumns({
        @JoinColumn(name="REQUEST_ID", referencedColumnName="REQUEST_ID", insertable= false, updatable= false)
    })
    private InboundRequestsEntity inboundRequestsMessagesEntityMapper;

    public InboundRequestsMessagesEntity() {
    }

    public InboundRequestsMessagesEntity(String requestId) {
        this.requestId = requestId;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getRequestMessage() {
        return requestMessage;
    }

    public void setRequestMessage(String requestMessage) {
        this.requestMessage = requestMessage;
    }

    public String getResponseMessage() {
        return responseMessage;
    }

    public void setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
    }

    @Override
    public String getId() 
    {
        return this.requestId;
    }

    @Override
    public int hashCode() {
        StringBuilder finalHashCode = new StringBuilder();
        if (this.requestId != null) 
        {
            finalHashCode.append(requestId);
        }
        return finalHashCode.toString().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
        {
            return true;
        }
        if ((obj == null) || (obj.getClass() != this.getClass())) 
        {
            return false;
        }
        InboundRequestsMessagesEntity other = (InboundRequestsMessagesEntity) obj;
        return Objects.equals(this.requestId, other.requestId);
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return (InboundRequestsMessagesEntity) super.clone();
    }   

}
