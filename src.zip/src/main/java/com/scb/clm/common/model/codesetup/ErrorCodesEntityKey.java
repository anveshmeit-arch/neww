package com.scb.clm.common.model.codesetup;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

/*
 * 
 * @author       1378958
 * @version      1.0
 * @since           
 * @use          
 */
@Embeddable
public class ErrorCodesEntityKey implements Serializable,Cloneable
{
    public ErrorCodesEntityKey() {

    }

    private static final long serialVersionUID = 1103847698360379355L;

    @Column(name = "COUNTRY_CODE", nullable = false ,insertable=false, updatable=false)
    private String countryCode;

    @Column(name = "ERROR_CODE", nullable = false ,insertable=false, updatable=false)
    private String errorCode;

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public ErrorCodesEntityKey (String countryCode,String reportID) {
        this.countryCode    =     countryCode;
        this.errorCode       =     reportID;
    }

    @Override
    public int hashCode() {
        StringBuilder finalHashCode = new StringBuilder();
        if (this.countryCode != null && 
                this.errorCode != null) 
        {
            finalHashCode.append(countryCode);
            finalHashCode.append(errorCode);
        }
        return finalHashCode.toString().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
        {
            return true;
        }
        if ((obj == null) || (obj.getClass() != this.getClass())) 
        {
            return false;
        }
        ErrorCodesEntityKey other = (ErrorCodesEntityKey) obj;
        return   Objects.equals(this.countryCode, other.countryCode) 
                && Objects.equals(this.errorCode, other.errorCode);
    }

    @Override
    public Object clone() {
        try {
            return (ErrorCodesEntityKey) super.clone();
        } catch (CloneNotSupportedException e) {
            return new ErrorCodesEntityKey(this.getCountryCode(),this.getErrorCode());
        }
    }    
}
