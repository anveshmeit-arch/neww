package com.scb.clm.common.util;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.springframework.stereotype.Component;
@Component
public class QueryParameterParsingUtility {

//Used to get filter values from the URL
public HashMap<String,List<String>> getValueList(String url){
	HashMap<String,List<String>> hm1=new HashMap<String,List<String>>();
	System.out.println("getValueList url:"+url);

	if(url!=null) {
		int startIndex=url.indexOf("filter[");
		
		int endIndex=url.indexOf("&fields[",startIndex);
		String urlSub=null;
		if(endIndex==-1) {
			endIndex=url.indexOf("&page[",startIndex);
		}
		if(endIndex==-1) {
			endIndex=url.indexOf("&include=",startIndex);
		}
		System.out.println("getValueList startIndex:"+startIndex+"//"+endIndex);

		if(startIndex!=-1 && endIndex!=-1) {
			urlSub=url.substring(startIndex, endIndex);
		}else if(startIndex!=-1){
			urlSub=url.substring(startIndex);
		}else {
			urlSub=url;
		}
		System.out.println("urlSub:"+urlSub);
		if(urlSub!=null) {
			String[] strArray1 = urlSub.split("&");
		for (int j = 0; j < strArray1.length; j += 1) {
			String[] strArray = strArray1[j].split("[\\[\\]]",-1);
			String fieldName="";
			List<String> filedValue=new ArrayList<>();
			String fieldOperator="";
			for (int i = 1; i < strArray.length; i += 1) {
				if(i==1) {
					fieldName=strArray[i];
				} else if(i==strArray.length-1) {
					filedValue.add((strArray[i].substring(1, strArray[i].length())));
				}else if(strArray[i]!=null) {
					fieldOperator=strArray[i];
				}
				if(fieldOperator==null || fieldOperator.isEmpty()) {
					fieldOperator="eq";
				}
			hm1.put(fieldName, filedValue);
			} 
		}
	}
		}
	System.out.println("Value List"+hm1);
	return hm1 ;
}



}
