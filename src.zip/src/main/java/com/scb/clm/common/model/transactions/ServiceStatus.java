package com.scb.clm.common.model.transactions;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ErrorObject;

public class ServiceStatus
{
    private String flowIdentifier;
    private String nodeIdentifier;
    private String nodeSequenceId;
    private String serviceIdentifier;
    private String status = BaseConstants.SERVICE_FAILURE;

    private Timestamp requestTime;
    private Timestamp responseTime;

    private Object requestPayload;
    private Object responsePayload;
    
    private Map<String,String> serviceParams = new HashMap<String,String>();

    //Interface Details
    private String interfaceId;
    private String httpStatus;

    private ArrayList<ErrorObject> errorObject = new ArrayList<>();

    public ServiceStatus(String flowIdentifier,String nodeIdentifier,String serviceIdentifier) {
        this.flowIdentifier     =   flowIdentifier;
        this.nodeIdentifier     =   nodeIdentifier;
        this.serviceIdentifier  =   serviceIdentifier;
    }

    public String getFlowIdentifier() {
        return flowIdentifier;
    }

    public void setFlowIdentifier(String flowIdentifier) {
        this.flowIdentifier = flowIdentifier;
    }

    public String getNodeIdentifier() {
        return nodeIdentifier;
    }

    public void setNodeIdentifier(String nodeIdentifier) {
        this.nodeIdentifier = nodeIdentifier;
    }

    public String getNodeSequenceId() {
        return nodeSequenceId;
    }

    public void setNodeSequenceId(String nodeSequenceId) {
        this.nodeSequenceId = nodeSequenceId;
    }

    public String getServiceIdentifier() {
        return serviceIdentifier;
    }

    public void setServiceIdentifier(String serviceIdentifier) {
        this.serviceIdentifier = serviceIdentifier;
    }

    public Timestamp getRequestTime() {
        return requestTime;
    }

    public void setRequestTime(Timestamp requestTime) {
        this.requestTime = requestTime;
    }

    public Timestamp getResponseTime() {
        return responseTime;
    }

    public void setResponseTime(Timestamp responseTime) {
        this.responseTime = responseTime;
    }

    public Object getRequestPayload() {
        return requestPayload;
    }

    public void setRequestPayload(Object requestPayload) {
        this.requestPayload = requestPayload;
    }

    public String getInterfaceId() {
        return interfaceId;
    }

    public void setInterfaceId(String interfaceId) {
        this.interfaceId = interfaceId;
    }

    public String getHttpStatus() {
        return httpStatus;
    }

    public void setHttpStatus(String httpStatus) {
        this.httpStatus = httpStatus;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public ArrayList<ErrorObject> getErrorObject() {
        return errorObject;
    }

    public Object getResponsePayload() {
        return responsePayload;
    }

    public void setResponsePayload(Object responsePayload) {
        this.responsePayload = responsePayload;
    }

    public void setErrorObject(ArrayList<ErrorObject> errorObject) {
        this.errorObject = errorObject;
    }

    public void addErrorObject(List<ErrorObject> errorObject) {
        if(this.errorObject == null) {
            this.errorObject = new ArrayList<ErrorObject>();     
        }
        this.errorObject.addAll(errorObject);
    }
    
    public void addErrorObject(ErrorObject errorObject) {
        if(this.errorObject == null) {
            this.errorObject = new ArrayList<ErrorObject>();     
        }
        this.errorObject.add(errorObject);
    }

    public String printKey() {
        return this.flowIdentifier+" - "+this.nodeIdentifier+" - "+this.serviceIdentifier;
    }

	public Map<String, String> getServiceParams() {
		return serviceParams;
	}

	public void setServiceParams(Map<String, String> serviceparams) {
		this.serviceParams = serviceparams;
	}
	
	public void addServiceParams(String key, String value) {
		serviceParams.put(key, value);
	}
}
