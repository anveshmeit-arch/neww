package com.scb.clm.common.model.transactions;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/*
 * 
 *  @author      1378958
 *  @version     1.0
 *  @since       
 *  @use         
 */
@Entity
@Table(name = "CLM_JOB_STATUS")
public class JobStatusEntity extends AbstractPersistableEntity<String> implements Cloneable,LoggerInterface
{
    @Id
    @Column(name="JOB_SEQUENCE_ID")
    private String jobSequenceId;

    @Column(name="COUNTRY_CODE")
    private String countryCode;

    @Column(name="JOB_ID")
    private String jobId;

    @Column(name="PROCESS_DATE")
    private Date processDate;

    @Column(name="PROCESS_START_TIME")
    private Timestamp processStartTime;

    @Column(name="PROCESS_END_TIME")
    private Timestamp processEndTime;

    @Column(name="STATUS")
    private String status = "X";

    @Column(name="VM_NAME")
    private String vmName;
    
    public JobStatusEntity() {

    }
    public JobStatusEntity(String jobSequenceId) {
        this.jobSequenceId = jobSequenceId;
    }

    public JobStatusEntity(String countryCode,String jobId) {
        this.countryCode = countryCode;
        this.jobId = jobId;
    }

    @Override
    public String getId() {
        return this.jobSequenceId;
    }

    public String getJobSequenceId() {
        return jobSequenceId;
    }
    public void setJobSequenceId(String jobSequenceId) {
        this.jobSequenceId = jobSequenceId;
    }
    public String getCountryCode() {
        return countryCode;
    }
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }
    public String getJobId() {
        return jobId;
    }
    public void setJobId(String jobId) {
        this.jobId = jobId;
    }
    public Date getProcessDate() {
        return processDate;
    }
    public void setProcessDate(Date processDate) {
        this.processDate = processDate;
    }
    public Timestamp getProcessStartTime() {
        return processStartTime;
    }
    public void setProcessStartTime(Timestamp processStartTime) {
        this.processStartTime = processStartTime;
    }
    public Timestamp getProcessEndTime() {
        return processEndTime;
    }
    public void setProcessEndTime(Timestamp processEndTime) {
        this.processEndTime = processEndTime;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public String getVmName() {
		return vmName;
	}
    
	public void setVmName(String vmName) {
		this.vmName = vmName;
	}
	
	@Override
    public int hashCode() {
        StringBuilder finalHashCode = new StringBuilder();
        if (this.jobSequenceId != null) 
        {
            finalHashCode.append(jobSequenceId);
        }
        return finalHashCode.toString().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
        {
            return true;
        }
        if ((obj == null) || (obj.getClass() != this.getClass())) 
        {
            return false;
        }
        JobStatusEntity other = (JobStatusEntity) obj;
        return Objects.equals(this.jobSequenceId, other.jobSequenceId);
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return (JobStatusEntity) super.clone();
    }
}
