package com.scb.clm.common.model.codesetup;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

/*
 * 
 *  @author      1663398
 *  @version     1.0
 *  @since       
 *  @use         
 */

@Embeddable
public class JobsEntityKey implements Serializable,Cloneable
{
    private static final long serialVersionUID = 1103847698360379356L;

    @Column(name = "COUNTRY_CODE", nullable = false ,insertable=false, updatable=false)
    private String countryCode;

    @Column(name = "JOB_ID", nullable = false ,insertable=false, updatable=false)
    private String jobId;

    public JobsEntityKey() {

    }

    public JobsEntityKey(String countryCode, String jobId) {
        this.countryCode = countryCode;
        this.jobId = jobId;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    @Override
    public int hashCode() {
        StringBuilder finalHashCode = new StringBuilder();
        if (this.countryCode != null && this.jobId != null) 
        {
            finalHashCode.append(countryCode);
            finalHashCode.append(jobId);
        }
        return finalHashCode.toString().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
        {
            return true;
        }
        if ((obj == null) || (obj.getClass() != this.getClass())) 
        {
            return false;
        }
        JobsEntityKey other = (JobsEntityKey) obj;
        return   Objects.equals(this.countryCode, other.countryCode) 
                && Objects.equals(this.jobId, other.jobId);
    }

    @Override
    public Object clone() {
        try {
            return (JobsEntityKey) super.clone();
        } catch (CloneNotSupportedException e) {
            return new JobsEntityKey(this.getCountryCode(),this.getJobId());
        }
    }    

}
