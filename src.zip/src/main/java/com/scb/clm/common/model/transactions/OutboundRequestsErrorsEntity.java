package com.scb.clm.common.model.transactions;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/*
 * 
 *  @author      1378958
 *  @version     1.0
 *  @since       
 *  @use         
 */
@Entity
@Table(name = "CLM_OUTBOUND_REQUEST_ERRORS")
public class OutboundRequestsErrorsEntity implements Cloneable
{
    @EmbeddedId
    private OutboundRequestsErrorsEntityKey id;

    @Column(name="COUNTRY_CODE")
    private String countryCode;

    @Column(name="ERROR_CODE")
    private String errorCode;

    @Column(name="ERROR_MESSAGE")
    private String errorMessage;

    @ManyToOne
    @JoinColumns({
        @JoinColumn(name="REQUEST_ID", referencedColumnName="REQUEST_ID", insertable= false, updatable= false)
    })
    private OutboundRequestsEntity outboundRequestsErrorMapper;

    public OutboundRequestsErrorsEntity() {

    }


    public OutboundRequestsErrorsEntity(OutboundRequestsErrorsEntityKey id) {
        this.id = id;
    }

    public OutboundRequestsErrorsEntityKey getId() {
        return id;
    }

    public void setId(OutboundRequestsErrorsEntityKey id) {
        this.id = id;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

}
