package com.scb.clm.common.model.transactions;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

/*
 * 
 * @author       1378958
 * @version      1.0
 * @since           
 * @use          
 */
@Embeddable
public class RetryBasketEntityKey implements Serializable,Cloneable
{

    private static final long serialVersionUID = -4045247808710332832L;

    @Column(name = "COUNTRY_CODE", nullable = false ,insertable=false, updatable=false)
    private String countryCode;

    @Column(name = "RETRY_ID", nullable = false ,insertable=false, updatable=false)
    private String retryID;

    public RetryBasketEntityKey() {

    }

    public RetryBasketEntityKey (String countryCode,String retryID) {
        this.countryCode    =     countryCode;
        this.retryID        =     retryID;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getRetryID() {
        return retryID;
    }

    public void setRetryID(String retryID) {
        this.retryID = retryID;
    }

    @Override
    public int hashCode() {
        StringBuilder finalHashCode = new StringBuilder();
        if (this.countryCode != null && this.retryID != null)
        {
            finalHashCode.append(countryCode);
            finalHashCode.append(retryID);
        }
        return finalHashCode.toString().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
        {
            return true;
        }
        if ((obj == null) || (obj.getClass() != this.getClass())) 
        {
            return false;
        }
        RetryBasketEntityKey other = (RetryBasketEntityKey) obj;
        return   Objects.equals(this.countryCode, other.countryCode) 
                && Objects.equals(this.retryID, other.retryID);
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return (RetryBasketEntityKey) super.clone();
    }
}
