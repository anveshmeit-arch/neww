package com.scb.clm.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.scb.clm.common.model.transactions.JobStatusEntity;

@Repository
public interface JobStatusRepository extends JpaRepository<JobStatusEntity, String>
{
    @Override
    public <S extends JobStatusEntity> S save(S entity);
}