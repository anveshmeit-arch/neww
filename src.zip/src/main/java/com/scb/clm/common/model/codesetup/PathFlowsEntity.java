package com.scb.clm.common.model.codesetup;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/*
 * 
 *  @author      1378958
 *  @version     1.0
 *  @since          
 *  @use         
 */
@Entity
@Table(name = "CLM_PATH_FLOWS")
public class PathFlowsEntity {

    @EmbeddedId
    private PathFlowsEntityKey id;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "STATUS_FLAG")
    private String statusFlag;
    
    @ManyToOne
    @JoinColumns({
        @JoinColumn(name="COUNTRY_CODE", referencedColumnName="COUNTRY_CODE", insertable= false, updatable= false),
        @JoinColumn(name="PATH_IDENTIFIER", referencedColumnName="PATH_IDENTIFIER",insertable= false, updatable=false)
    })
    private PathIdentifierEntity pathIdentifierMapper;

    public PathFlowsEntityKey getId() {
        return id;
    }

    public void setId(PathFlowsEntityKey id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatusFlag() {
        return statusFlag;
    }

    public void setStatusFlag(String statusFlag) {
        this.statusFlag = statusFlag;
    }

    
}
