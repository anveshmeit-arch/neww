package com.scb.clm.common.config;

import java.util.Timer;

public class SchedulerMain extends Thread 
{
    
    public void run() 
    {
        System.out.println("Starting Scheduler [Thread] ");

        Timer time = new Timer(); 
        ScheduledTask st = new ScheduledTask();
        time.schedule(st, 0, 5000); // Create Repetitively task for every 5 secs

        while (true)  
        {
            System.out.println("Scheduler [Looping] ");
            try 
            {
                Thread.sleep(1000);
            } 
            catch (Exception e) 
            {
            }
            System.out.println("Scheduler [After Sleep] : "+ ScheduledTask.flag);

            if (ScheduledTask.flag) 
            {
                break;
            }
        }
       
    }
}
