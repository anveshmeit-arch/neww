package com.scb.clm.common.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.CountryParametersEntity;
import com.scb.clm.common.repository.CountryParametersRepository;
import com.scb.clm.common.util.StringUtility;


@Service
public class CountryConfig
{

    @Autowired 
    private CountryParametersRepository countryParametersRepository;

    private static HashMap<String,String> countryParamMap = new HashMap<String,String>();
    private static HashMap<String,String> countryParamMapWithoutSequence = new HashMap<String,String>();
    private static HashMap<String, List<String>> countryParamGroup = new HashMap<>();

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    public void loadCountryConfig()
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "loadCountryConfig", LogType.APPLICATION.name());

        try
        {
            log.println("*****************************************************************");
            log.println("*              INITIALIZING COUNTRY PARAMETERS                  *");
            log.println("*****************************************************************\n");

            List<CountryParametersEntity> parameters = countryParametersRepository.findAll();

            for(CountryParametersEntity parametersEntity : parameters)
            {
                countryParamMap.put(
                        parametersEntity.getId().getCountryCode()+parametersEntity.getId().getParameterGroup()+parametersEntity.getId().getParameterSequence()+parametersEntity.getParameterCode(),
                        parametersEntity.getParameterValue()
                        );
                countryParamMapWithoutSequence.put(
                        parametersEntity.getId().getCountryCode()+parametersEntity.getId().getParameterGroup()+parametersEntity.getParameterCode(),
                        parametersEntity.getParameterValue()
                        );

                addElementToMap(countryParamGroup, parametersEntity.getId().getCountryCode()+parametersEntity.getId().getParameterGroup(), parametersEntity.getParameterValue());
            }

            log.println("[Total Country Param Loaded ] : ["+countryParamMap.size()+"]"); 
        }
        catch (Exception e) 
        {
        	log.printErrorMessage(e);
        }
    }   

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    public static String getGatewayCountryParam(String paramCode)
    {
        return getCountryParam("00","GATEWAY","1",paramCode,false);
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    public static String getGatewayCountryParam(String countryCode,String paramCode)
    {
        if(countryCode == null || countryCode.trim().length()==0) {
            return getCountryParam("00","GATEWAY","1",paramCode,false);
        } else {
            return getCountryParam(countryCode,"GATEWAY","1",paramCode,false);
        }
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    public static String getCountryParam(String paramGroup,String paramCode)
    {
        return getCountryParam("00",paramGroup,"1",paramCode,false);
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    public static String getCountryParam(String countryCode,String paramGroup,String paramCode)
    {
        return getCountryParam(countryCode,paramGroup,"1",paramCode,false);
    }
    
    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    public static String getCountryParam(String countryCode,String paramGroup,String paramSequence,String paramCode,boolean isWithSequence)
    {

        try
        {
            String searchString  =  "";
            if(isWithSequence)
            {searchString = 
            ( StringUtility.containsData(countryCode)?countryCode:"00" )   +
            ( StringUtility.containsData(paramGroup)?paramGroup:"00" ) +
            ( StringUtility.containsData(paramSequence)?paramSequence:"1" ) +
            ( StringUtility.containsData(paramCode)?paramCode:"1" );
            System.out.println("Country Parameter for "+searchString + " [ " +countryParamMap.get(searchString) +" ] ");
            return countryParamMap.get(searchString);
            } else {
                searchString = 
                        ( StringUtility.containsData(countryCode)?countryCode:"00" )   +
                        ( StringUtility.containsData(paramGroup)?paramGroup:"00" ) +
                        ( StringUtility.containsData(paramCode)?paramCode:"1" );
                System.out.println("Country Parameter[Without Sequence] for "+searchString + " [ " +countryParamMapWithoutSequence.get(searchString) +" ] ");
                return countryParamMapWithoutSequence.get(searchString);
            }
        }
        catch(Exception e)
        {
            System.out.println("[FATAL]");
            return null;
        }
    }

    void addElementToMap(HashMap<String, List<String>> map, String key, String value) 
    {
        if (!map.containsKey(key)) 
        {
            map.put(key, new ArrayList<>());
        }
        map.get(key).add(value);
    }

       /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    public static List<String> getSystemDefaultGroups(String paramGroup)
    {
        return countryParamGroup.get("00"+paramGroup);
    }
}
