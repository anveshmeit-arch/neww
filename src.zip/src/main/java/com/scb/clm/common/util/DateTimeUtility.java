package com.scb.clm.common.util;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ProcessException;

public class DateTimeUtility {

    private static HashMap<String, String> countryTimeZone = new HashMap<String, String>();

    static {
        countryTimeZone.put("HK", "Asia/Hong_Kong");
        countryTimeZone.put("US", "America/New_York");
        countryTimeZone.put("IN", "Asia/Kolkata");
        countryTimeZone.put("SG", "Asia/Singapore");
    }

    public static Timestamp getTimeByCountryCode(String countryCode) {
        ZonedDateTime zonedDateTime = ZonedDateTime.now(ZoneId.of((countryTimeZone.get(countryCode) == null) ? "Asia/Hong_Kong" : countryTimeZone.get(countryCode)));
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
        String formatterTimestamp = zonedDateTime.format(formatter);
        return Timestamp.valueOf(formatterTimestamp);
    }

    public static LocalDateTime getLocalDateTimeByCountryCode(String countryCode) {
        return LocalDateTime.now(ZoneId.of((
                DateTimeUtility.countryTimeZone.get(countryCode) == null) ? "Asia/Hong_Kong" : DateTimeUtility.countryTimeZone.get(countryCode)));
    }

    public static java.sql.Date getDateByCountryCode(String countryCode) throws ProcessException {
        ZonedDateTime zonedDateTime = ZonedDateTime.now(ZoneId.of((countryTimeZone.get(countryCode) == null) ? "Asia/Hong_Kong" : countryTimeZone.get(countryCode)));
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String formatterTimestamp = zonedDateTime.format(formatter);
        return java.sql.Date.valueOf(formatterTimestamp);
    }

    public static Timestamp getCurrentTime() {
        return Timestamp.from(Instant.now());
    }

    public static java.sql.Date getCurrentDateForLogging(String countryCode) {
        return new java.sql.Date((System.currentTimeMillis()));
    }

    public static java.sql.Date parseDate(String date, String sourceFormat) throws Exception {
        Date parsed = new SimpleDateFormat(sourceFormat).parse(date);
        java.sql.Date sqlDate = new java.sql.Date(parsed.getTime());
        return sqlDate;
    }

    public static String getCurrentDateForLogging() {
        /* This method doesn't need country based logic as it may provide duplicate primary key*/
        DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        Date date = new Date();
        return (dateFormat.format(date));
    }

    public static String formatDate(String date, String sourceFormat, String targetFormat) throws ProcessException {
        try {
            Date myDate = new SimpleDateFormat(sourceFormat).parse(date);
            return new SimpleDateFormat(targetFormat).format(myDate);
        } catch (Exception e) {
            throw new ProcessException(BaseConstants.ERROR_TYPE_VALIDATION, BaseConstants.VALIDATION_ERROR, "Date Format Error [" + date + "] [" + targetFormat + "] ");
        }
    }

    public static String formatDateToString(Date date, String targetFormat) throws ProcessException {
        try {
        	DateFormat dateFormat = new SimpleDateFormat(targetFormat);
            return dateFormat.format(date);
        } catch (Exception e) {
            throw new ProcessException(BaseConstants.ERROR_TYPE_VALIDATION, BaseConstants.VALIDATION_ERROR, "Date Format Error [" + date + "] [" + targetFormat + "] ");
        }
    }

    public static String formatDate(String date, String targetFormat) throws ProcessException {
        try {
            Date myDate = new SimpleDateFormat("dd-MM-yyyy").parse(date);
            return new SimpleDateFormat(targetFormat).format(myDate);
        } catch (Exception e) {
            throw new ProcessException(BaseConstants.ERROR_TYPE_VALIDATION, BaseConstants.VALIDATION_ERROR, "Date Format Error [" + date + "] [" + targetFormat + "] ");
        }
    }

    public static boolean isValidFormat(String format, String value) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(format);
            sdf.setLenient(false);
            sdf.parse(value);
        } catch (Exception ex) {
            System.out.println("# FATAL # isValidFormat # Error ");
            return false;
        }
        return true;
    }

    public static boolean isValidDateRegex(String date) {
        String regexPattern = "^\\d{4}-\\d{2}-\\d{2}$";
        Pattern standardPattern = Pattern.compile(regexPattern);
        Matcher match = standardPattern.matcher(date);
        return match.matches();
    }

    public static int checkDaysDifference(String fromDate, String toDate, String format) throws ProcessException {
        try {
            SimpleDateFormat myFormat = new SimpleDateFormat(format);
            Date date1 = myFormat.parse(fromDate);
            Date date2 = myFormat.parse(toDate);
            long diff = date2.getTime() - date1.getTime();
            return (int) TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
        } catch (Exception e) {
            throw new ProcessException(BaseConstants.ERROR_TYPE_VALIDATION, BaseConstants.VALIDATION_ERROR, "Date Difference Validation Error [" + format + "] [" + fromDate + "] [" + toDate + "]");
        }
    }
}
