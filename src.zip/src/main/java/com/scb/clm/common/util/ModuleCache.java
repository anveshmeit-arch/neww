package com.scb.clm.common.util;

import java.util.HashMap;

public abstract class ModuleCache {

	protected Object getCacheObject(String key,String cacheConstant){
		Object cacheValue=null;
		try{
		HashMap constantHash = (HashMap)ModuleContextManager.getModuleContext().getModuleCache();
		if (constantHash !=null){
			HashMap valueHash=(HashMap) constantHash.get(cacheConstant);				
			if(valueHash!=null){
				cacheValue = valueHash.get(key);					
			}		
		}
		}catch (Exception e) {
			System.out.println("ModuleCache:ERROR:getCacheObject():"+e.getMessage());
		}
		return cacheValue;
	}
	protected void setCacheObject(String key, Object obj, String cacheConstant) {
		try{
			HashMap valueHash=null;
			HashMap constantHash=(HashMap)ModuleContextManager.getModuleContext().getModuleCache();		
			if (constantHash != null){
				valueHash = (HashMap)constantHash.get(cacheConstant);
				if(valueHash!=null){
						if(valueHash.size()==0){
							valueHash =new HashMap();
						}
						valueHash.put(key, obj);
						constantHash.put(cacheConstant, valueHash);
					valueHash = new HashMap();
					if(constantHash.size()==0){
						constantHash = new HashMap();
					}
					valueHash.put(key, obj);
					constantHash.put(cacheConstant, valueHash);	
				}
			}else{//constant hash is null
				valueHash = new HashMap();
				valueHash.put(key, obj);
				constantHash = new HashMap();
				constantHash.put(cacheConstant, valueHash);				
			}
			ModuleContextManager.getModuleContext().setModuleCache(constantHash);
			
		}catch (Exception e) {
			System.out.println("Exception During setCacheObject --- "+ e.getMessage());
		}
	}

}
