package com.scb.clm.common.security.auth;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.net.URL;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.RSAPublicKeySpec;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;

import org.apache.commons.codec.binary.Base64;
import org.apache.hc.core5.ssl.SSLContextBuilder;
import org.springframework.core.io.ClassPathResource;

import com.auth0.jwk.InvalidPublicKeyException;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Maps;
import com.scb.clm.common.config.ApplicationConfiguration;
import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.config.CountryConfig;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;

public class AuthenticationInitializer extends Thread 
{

    private static final String TRUE = "true";
    private static RSAPublicKey tokenPublicKey;
    private static List<RSAPublicKey> publicKeys = new ArrayList<>();;
    private KeyFactory kf; 
    private static String requirePublicKeyRefresh = "TRUE";

    public void run()
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "run", LogType.APPLICATION.name());
        log.println("KEY [AuthenticationInitializer] Thread is Running...");
        if ((null != requirePublicKeyRefresh) && TRUE.equals(requirePublicKeyRefresh)) 
        {
        	log.println("Public Key Refreshed");
            retrievePublicKeys("00");
            try 
            {
                Thread.sleep(1000000);
            }
            catch (InterruptedException e) 
            {
            	log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "run", LogType.APPLICATION.name());
            	log.printErrorMessage(e);

            }
        }
    }

    public void retrievePublicKeys(String countryCodeWithRegion) 
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "retrievePublicKeys", LogType.APPLICATION.name());
        log.println("Checking Auth Init [retrievePublicKeys] [countryCodeWithRegion "+countryCodeWithRegion+"]");
        try 
        {
            log.println("Size of public Keys before clearing::"+ ((publicKeys==null)?null:publicKeys.size()));

            if(null != publicKeys) 
            { 
                publicKeys.clear();
            }
            log.println("Size of Public Keys : [ "+publicKeys==null?null:publicKeys.size()+" ]");

            String response = getKeyThruSocketFactory(countryCodeWithRegion);

            log.println("Response of Public Key URL : [ "+ response+" ]");
            this.intializejwks(response);
        }
        catch (Exception e) 
        {
            log.println("Error Occured During Key Refresh..");
            log.println(e.getMessage());

            if (null == tokenPublicKey) {
                throw new IllegalStateException(e);
            }
            else {
                log.println("");
            }
        }
    }

    public String getKeyThruSocketFactory(String countryCodeWithRegion) throws KeyStoreException, CertificateException, IOException, UnrecoverableKeyException, NoSuchAlgorithmException 
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "getKeyThruSocketFactory", LogType.APPLICATION.name());
        log.println("[GATEWAY_PUBLIC_KEY_URL] [ "+CountryConfig.getGatewayCountryParam(countryCodeWithRegion,BaseConstants.GATEWAY_PUBLIC_KEY_URL)+ "] ");
        String publicKeyUrl= CountryConfig.getGatewayCountryParam(countryCodeWithRegion,BaseConstants.GATEWAY_PUBLIC_KEY_URL);
        log.println(" URL ["+publicKeyUrl+"]");

        StringBuilder response = new StringBuilder();
        SSLContext sslcontext = SSLContext.getInstance("TLS");

        
        try
        {
        	sslcontext = ApplicationConfiguration.getInstance().getSSLContext();
        	SSLSocketFactory factory = sslcontext.getSocketFactory();
            URL url;
            HttpsURLConnection connection;
            String ip=publicKeyUrl;
            url = new URL(ip);
            log.println("URL "+ip);
            connection = (HttpsURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setUseCaches (false);
            connection.setDoInput(true);
            connection.setDoOutput(true);
            connection.setSSLSocketFactory(factory);
            int responseCode = connection.getResponseCode();
            log.println("responsecode is "+responseCode);
            InputStream inputStream;

            if (200 <= responseCode && responseCode <= 299) 
            {
                log.println("Coming - [Success]");
                inputStream = connection.getInputStream();
            } 
            else 
            {
            	log.println("Coming - [Error]");
                inputStream = connection.getErrorStream();
            }

            BufferedReader in = new BufferedReader(
                    new InputStreamReader(
                            inputStream));

            String currentLine;
            while ((currentLine = in.readLine()) != null) {
                response.append(currentLine);
            }

            log.println("Through Socket Connect Factory : "+ response.toString());
            in.close();
            connection.disconnect();

        }
        catch(Exception e) 
        {
        	log.printErrorMessage(e);

        }
        return response.toString();
    }



    public static RSAPublicKey getPublicKey() {
        return tokenPublicKey;
    }


    private void intializejwks(String jwksUrlContent) throws IOException, InvalidPublicKeyException {
    	LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "intializejwks", LogType.APPLICATION.name());
        JsonFactory factory = new JsonFactory();
        JsonParser parser = factory.createParser(jwksUrlContent);
        TypeReference<Map<String, Object>> typeReference = new TypeReference<Map<String, Object>>() {
        };
        Map<String, Object> jwks = new ObjectMapper().reader().readValue(parser, typeReference);

        @SuppressWarnings("unchecked")
        final List<Map<String, Object>> keys = (List<Map<String, Object>>) jwks.get("keys");

        for(Map<String, Object> key : keys) {
            log.println("Public key received:::"+this.getRSAPublicKey(key));
            publicKeys.add(this.getRSAPublicKey(key));
        }
        log.println("size of public key list::"+publicKeys.size());
        log.println("checking auth inti 6");
    }

    private RSAPublicKey getRSAPublicKey(Map<String, Object> key) throws InvalidPublicKeyException {
    	LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "getRSAPublicKey", LogType.APPLICATION.name());
        Map<String, Object> values = Maps.newHashMap(key);
        String kty = (String) values.remove("kty");
        log.println("checking auth inti 7");

        if(!"RSA".equalsIgnoreCase(kty)) {
            throw new InvalidPublicKeyException("The key is not of type RSA", null);

        }

        try {
            if(null == kf) {
                kf = KeyFactory.getInstance("RSA");
            }

            BigInteger modulus = new BigInteger(1, Base64.decodeBase64((String)values.get("n")));
            BigInteger exponent = new BigInteger(1, Base64.decodeBase64((String)values.get("e")));

            return (RSAPublicKey)kf.generatePublic(new RSAPublicKeySpec(modulus, exponent));
        } catch (InvalidKeySpecException e) {
            throw new InvalidPublicKeyException("Invalid public key", e);
        } catch (NoSuchAlgorithmException e) {
            throw new InvalidPublicKeyException("Invalid algorithm to generate key", e);
        }
    }

    public static List<RSAPublicKey> getAllKeys() {
        return publicKeys;
    }
}