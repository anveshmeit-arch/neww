package com.scb.clm.common.db.support;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.security.Provider;
import java.security.Security;
import java.util.Properties;

public class CryptoParameters {


	private String providerClassName = null;
	private String symentickeyAlgName  = null;
	private String aSymentickeyAlgName = null;
	private String applicationID = null;
	private String keyStroreAlgName = null;
	private String CertAlg = null;
	private String companyID = null;
	private String keyFilesLoca = null;
	private String fileName = null;
	private static CryptoParameters initializeParameters = null;


	public static CryptoParameters getInstance() throws Exception {

//				if (initializeParameters == null)
//				{
//					initializeParameters = new CryptoParameters();
//				}
		return initializeParameters;
	}

	public static void initCrypto(String filePath) throws Exception {
		initializeParameters = new CryptoParameters(filePath);
	}


	public CryptoParameters(String filePath) throws Exception
	{

		try{

			loadCryptoParameters(filePath);
			System.out.println("Loaded CypParams");

		}
		catch(Exception e)
		{
			throw new Exception(e);
		}
	}


	public void loadCryptoParameters(String iniPath) throws Exception
	{
		//String iniPath = "/apps/Crypto/CryptoConfig.ser";
		//String iniPath = "C:\\Users\\1294252\\Desktop\\Crypto\\CryptoConfig.ser";
		FileInputStream fileIn = new FileInputStream(iniPath);
		ObjectInputStream in = new ObjectInputStream(fileIn);
		FileInputStream fileInit = new FileInputStream(iniPath);
		try {
			Properties list = (Properties) in.readObject();
			//list.load(new java.io.FileInputStream(iniPath));
			list.load(fileInit);
			providerClassName = list.getProperty("providerClassName");
			symentickeyAlgName = list.getProperty("symentickeyAlgName");
			aSymentickeyAlgName = list.getProperty("aSymentickeyAlgName");
			applicationID = list.getProperty("applicationID");
			keyStroreAlgName = list.getProperty("keyStroreAlgName");
			CertAlg = list.getProperty("CertAlg");
			companyID = list.getProperty("countryCode");
			keyFilesLoca = list.getProperty("keyFileLocation");


		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new FileNotFoundException();

		} catch (IOException e) {
			e.printStackTrace();
			throw new IOException();
		}
		finally {
			try {
				if(in!=null){
					in.close();
				}
				if(fileIn!=null){
					fileIn.close();
				}
				if(fileInit!=null){
					fileInit.close();
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}

		}

		if (Security.getProvider(providerClassName) == null) {
			try {
				Security.addProvider((Provider) Class.forName("com.ibm.crypto.provider.IBMJCE").newInstance());
			} catch (Exception ex) {
				System.out.println("Cannot install provider: " + ex.getMessage());
				return;
			}
		}

	}

	public String getApplicationID() {
		return applicationID;
	}


	public void setApplicationID(String applicationID) {
		this.applicationID = applicationID;
	}


	public String getASymentickeyAlgName() {
		return aSymentickeyAlgName;
	}


	public void setASymentickeyAlgName(String symentickeyAlgName) {
		aSymentickeyAlgName = symentickeyAlgName;
	}


	public String getCertAlg() {
		return CertAlg;
	}


	public void setCertAlg(String certAlg) {
		CertAlg = certAlg;
	}


	public String getCompanyID() {
		return companyID;
	}


	public void setCompanyID(String comID) {
		this.companyID = comID;
	}


	public String getKeyFilesLoca() {
		//return "C:\\Users\\1294252\\Desktop\\Crypto\\";
		return keyFilesLoca;
	}


	public void setKeyFilesLoca(String keyFilesLoca) {
		this.keyFilesLoca = keyFilesLoca;
	}


	public String getKeyStroreAlgName() {
		return keyStroreAlgName;
	}


	public void setKeyStroreAlgName(String keyStroreAlgName) {
		this.keyStroreAlgName = keyStroreAlgName;
	}


	public String getProviderClassName() {
		return providerClassName;
	}


	public void setProviderClassName(String providerClassName) {
		this.providerClassName = providerClassName;
	}


	public String getSymentickeyAlgName() {
		return symentickeyAlgName;
	}


	public void setSymentickeyAlgName(String symentickeyAlgName) {
		this.symentickeyAlgName = symentickeyAlgName;
	}


	public String getFileName() {
		return fileName;
	}


	public void setFileName(String fileName) {
		this.fileName = fileName;
	}





}
