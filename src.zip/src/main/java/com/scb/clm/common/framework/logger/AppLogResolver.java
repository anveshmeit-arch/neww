package com.scb.clm.common.framework.logger;


import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.layout.template.json.resolver.EventResolver;
import org.apache.logging.log4j.layout.template.json.resolver.TemplateResolverConfig;
import org.apache.logging.log4j.layout.template.json.util.JsonWriter;


public final class AppLogResolver implements EventResolver {

    private final String field;

    //private final double hiExcLimit;

    AppLogResolver(final TemplateResolverConfig config) {
    	field = config.getString("field");
    	//System.out.println("AppLogResolver Initiate");
       // if (rangeArray == null) {} else if (rangeArray.size() != 2) {} else {}
    }

    static String getName() {
    	//System.out.println("App Log Initiate");
        return "appLog";
    }

    @Override
    public void resolve(
            final LogEvent value,
            final JsonWriter jsonWriter) {
    	//System.out.println("field ----->"+field+" <----- value ----->"+value.getContextData().getValue(field));
        jsonWriter.writeValue(value.getContextData().getValue(field));
    }


}
