package com.scb.clm.common.repository;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.scb.clm.common.model.codesetup.InterfaceRequestTypeEntity;
import com.scb.clm.common.model.codesetup.InterfaceRequestTypeEntityKey;

@Repository
public interface InterfaceRequestTypeRepository extends JpaRepository<InterfaceRequestTypeEntity, InterfaceRequestTypeEntityKey> { 

    @Override
    public <S extends InterfaceRequestTypeEntity> S save(S entity);

    @Override
    @Cacheable("InterfaceRequestType")
    public InterfaceRequestTypeEntity getOne(InterfaceRequestTypeEntityKey arg0);

    @Cacheable("InterfaceURL")
    @Query(value = "SELECT n.requestUrl FROM InterfaceRequestTypeEntity n where n.id.countryCode= :countryCode and n.id.interfaceIdentifier= :interfaceIdentifier and n.id.requestType= :requestType and n.inBoundOutBoundFlag =:inBoundOutBoundFlag and n.statusFlag =:statusFlag")
    public String getInterfaceURL(@Param("countryCode") String countryCode,@Param("interfaceIdentifier") String interfaceIdentifier,@Param("requestType") String requestType,@Param("inBoundOutBoundFlag") String inBoundOutBoundFlag,@Param("statusFlag") String statusFlag);

}