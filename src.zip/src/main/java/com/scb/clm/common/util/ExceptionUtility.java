package com.scb.clm.common.util;

import java.io.IOException;
import java.io.OutputStream;

import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletResponse;

public class ExceptionUtility 
{
    public static void printException(String str, ServletResponse response, short statusCode) throws IOException 
    {
        response.setContentType("application/json");
        response.setCharacterEncoding("utf-8");
        ((HttpServletResponse) response).setStatus(statusCode);
        response.setContentLength(str.getBytes().length);
        java.io.ByteArrayOutputStream bout = new java.io.ByteArrayOutputStream();
        OutputStream os = response.getOutputStream();
        os.flush();
        os.write(str.getBytes());
        os.close();
    }
}
