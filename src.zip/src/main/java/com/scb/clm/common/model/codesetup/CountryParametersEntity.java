package com.scb.clm.common.model.codesetup;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

/*
 * 
 *  @author      1378958 
 *  @version     1.0
 *  @since       
 *  @use         
 */
@Entity
@Table(name = "CLM_COUNTRY_PARAMETERS")
public class CountryParametersEntity implements Cloneable
{
    @EmbeddedId
    private CountryParametersEntityKey id;

    @Column(name="PARAM_CODE")
    private String parameterCode;

    @Column(name="PARAM_VALUE")
    private String parameterValue;

    public CountryParametersEntity() {

    }

    public CountryParametersEntityKey getId() {
        return (CountryParametersEntityKey) id.clone();
    }

    public void setId(CountryParametersEntityKey id) {
        this.id = (CountryParametersEntityKey) id.clone();
    }

    public String getParameterCode() {
        return parameterCode;
    }

    public void setParameterCode(String parameterCode) {
        this.parameterCode = parameterCode;
    }

    public String getParameterValue() {
        return parameterValue;
    }

    public void setParameterValue(String parameterValue) {
        this.parameterValue = parameterValue;
    }

    public CountryParametersEntity clone() throws CloneNotSupportedException {  
        return (CountryParametersEntity) super.clone();  
    }  
}
