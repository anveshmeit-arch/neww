package com.scb.clm.common.util;

import java.util.HashMap;

public interface ModuleContext {
	
	public HashMap<?, ?> getModuleCache();		
	public void setModuleCache(HashMap<?, ?> hashMap);
	public void removeModuleCache();

}
