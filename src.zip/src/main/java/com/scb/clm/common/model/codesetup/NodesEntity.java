package com.scb.clm.common.model.codesetup;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

/*
 * 
 * @author   1378958
 * @version  1.0
 * @since 
 * @use
 */
@Entity
@Table(name = "CLM_NODES")
public class NodesEntity implements Cloneable
{
    @EmbeddedId
    private NodesEntityKey id;

    @Column(name="SEQUENCE_ID")
    private String sequenceId;

    @Column(name="PROGRAM")
    private String nodeProgram;

    @Column(name="ASYNC_PROCESS")
    private String asyncProcess;

    @Column(name="REROUTE_NODE")
    private String rerouteNode;

    @Column(name="STATUS_FLAG")
    private String statusFlag;

    @ManyToOne
    @JoinColumns({
        @JoinColumn(name="COUNTRY_CODE", referencedColumnName="COUNTRY_CODE", insertable= false, updatable= false),
        @JoinColumn(name="FLOW_ID", referencedColumnName="FLOW_ID",insertable= false, updatable=false)
    })
    private FlowsEntity flowMapper;

    @OneToMany(fetch=FetchType.EAGER,mappedBy="nodeMapper")
    @Cascade({CascadeType.ALL})
    private Set<NodeServicesEntity> serviceDetail        =     new     HashSet<>();

    public NodesEntity() {

    }

    public NodesEntityKey getId() {
        return id;
    }

    public void setId(NodesEntityKey id) {
        this.id = id;
    }

    public String getSequenceId() {
        return sequenceId;
    }

    public void setSequenceId(String sequenceId) {
        this.sequenceId = sequenceId;
    }

    public String getNodeProgram() {
        return nodeProgram;
    }

    public void setNodeProgram(String nodeProgram) {
        this.nodeProgram = nodeProgram;
    }

    public String getAsyncProcess() {
        return asyncProcess;
    }

    public void setAsyncProcess(String asyncProcess) {
        this.asyncProcess = asyncProcess;
    }

    public String getRerouteNode() {
		return rerouteNode;
	}

	public void setRerouteNode(String rerouteNode) {
		this.rerouteNode = rerouteNode;
	}

	public String getStatusFlag() {
        return statusFlag;
    }

    public void setStatusFlag(String statusFlag) {
        this.statusFlag = statusFlag;
    }

    public NodesEntity clone() throws CloneNotSupportedException {  
        return (NodesEntity) super.clone();  
    }

}



