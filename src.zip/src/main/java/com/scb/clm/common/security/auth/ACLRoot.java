package com.scb.clm.common.security.auth;

import java.util.ArrayList;

public class ACLRoot
{
    public ArrayList<Acl> acl;

    public ArrayList<Acl> getAcl() 
    {
        return acl;
    }

    public void setAcl(ArrayList<Acl> acl) 
    {
        this.acl = acl;
    }

}