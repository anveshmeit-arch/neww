package com.scb.clm.common.db.support;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.spec.InvalidKeySpecException;
import java.sql.SQLException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.SecretKeySpec;



public class KeyReader{
	
		
	private static KeyReader keyReader = null;

	public static KeyReader getInstance() throws Exception {
	
				if (keyReader == null)
				{
					keyReader = new KeyReader();
			
				}
		return keyReader;
	}

	
	public byte[] decryptKeyStorePwd(String companyid) throws Exception
	
	{
		byte[] Passbytes = null;
		byte[] Desbytes =  null;
		byte keyStoreByts[] = null;
		
		CryptoParameters.getInstance().setCompanyID(companyid);
		
		
		  try {
			  
			  CryptoParameters.getInstance().setFileName(CryptoParameters.getInstance().getKeyFilesLoca()+ CryptoParameters.getInstance().getCompanyID() + "/KEYStoreEncPass.key");

			  Passbytes = CryptoUtility.getInstance().readKeysFromFile(CryptoParameters.getInstance().getFileName());
			  
			  CryptoParameters.getInstance().setFileName(CryptoParameters.getInstance().getKeyFilesLoca()+ CryptoParameters.getInstance().getCompanyID() + "/DESkey.key");
			
			  Desbytes = CryptoUtility.getInstance().readKeysFromFile(CryptoParameters.getInstance().getFileName());
		 
			  SecretKey dkey = new SecretKeySpec(Desbytes, CryptoParameters.getInstance().getSymentickeyAlgName());
    	  
    	      Cipher cipherdes = null;
		
			  cipherdes = Cipher.getInstance(CryptoParameters.getInstance().getSymentickeyAlgName(), CryptoParameters.getInstance().getProviderClassName());
		
			  cipherdes.init(Cipher.DECRYPT_MODE, dkey);
			
			  keyStoreByts = cipherdes.doFinal(Passbytes);
		
    			
		} catch (Exception e) 
		
		{
			
			e.printStackTrace();
			
				if(e instanceof InvalidKeyException)
					throw new InvalidKeyException(e.getMessage());
				
				if(e instanceof NoSuchAlgorithmException)
					throw new NoSuchAlgorithmException(e.getMessage());
				
				if(e instanceof NoSuchProviderException)
					throw new NoSuchProviderException(e.getMessage());
				
				if(e instanceof InvalidKeySpecException)
					throw new InvalidKeySpecException(e.getMessage());
				
				if(e instanceof NoSuchPaddingException)
					throw new NoSuchPaddingException();
				
				if(e instanceof IllegalBlockSizeException)
					throw new IllegalBlockSizeException(e.getMessage());
				
				if(e instanceof BadPaddingException)
					throw new BadPaddingException(e.getMessage());
				
				if(e instanceof FileNotFoundException)
					throw new FileNotFoundException(e.getMessage());
				
				if(e instanceof IOException)
					throw new IOException(e.getMessage());
				
						
		}
	
		return keyStoreByts;
	     
	     
	}
	
       public static String decryptDBUserName(String companyid,String applicationID) throws Exception	
	   {
		byte[] userIdBytes = null;
		byte[] Desbytes =  null;
		byte keyStoreByts[] = null;
		String dbUserName = null;
		
		CryptoParameters.getInstance().setCompanyID(companyid);		
		
		  try {
			  
			  CryptoParameters.getInstance().setFileName(CryptoParameters.getInstance().getKeyFilesLoca()+ CryptoParameters.getInstance().getCompanyID()+"/"+applicationID+"_EncyUserName.key");

			  userIdBytes = CryptoUtility.getInstance().readKeysFromFile(CryptoParameters.getInstance().getFileName());
			  
			  CryptoParameters.getInstance().setFileName(CryptoParameters.getInstance().getKeyFilesLoca()+ CryptoParameters.getInstance().getCompanyID() + "/DESkey.key");
			
			  Desbytes = CryptoUtility.getInstance().readKeysFromFile(CryptoParameters.getInstance().getFileName());
		 
			  SecretKey dkey = new SecretKeySpec(Desbytes, CryptoParameters.getInstance().getSymentickeyAlgName());
    	  
    	      Cipher cipherdes = null;
		
			  cipherdes = Cipher.getInstance(CryptoParameters.getInstance().getSymentickeyAlgName(), CryptoParameters.getInstance().getProviderClassName());
		
			  cipherdes.init(Cipher.DECRYPT_MODE, dkey);
			
			  keyStoreByts = cipherdes.doFinal(userIdBytes);
			  
			 dbUserName = new String(keyStoreByts);
		
    			
		} catch (Exception e) 
		
		{
			
			e.printStackTrace();
			
				if(e instanceof InvalidKeyException)
					throw new InvalidKeyException(e.getMessage());
				
				if(e instanceof NoSuchAlgorithmException)
					throw new NoSuchAlgorithmException(e.getMessage());
				
				if(e instanceof NoSuchProviderException)
					throw new NoSuchProviderException(e.getMessage());
				
				if(e instanceof InvalidKeySpecException)
					throw new InvalidKeySpecException(e.getMessage());
				
				if(e instanceof NoSuchPaddingException)
					throw new NoSuchPaddingException();
				
				if(e instanceof IllegalBlockSizeException)
					throw new IllegalBlockSizeException(e.getMessage());
				
				if(e instanceof BadPaddingException)
					throw new BadPaddingException(e.getMessage());
				
				if(e instanceof FileNotFoundException)
					throw new FileNotFoundException(e.getMessage());
				
				if(e instanceof IOException)
					throw new IOException(e.getMessage());
				
						
		}
	
		return dbUserName;
	     
	     
	}
       
       
	
	
		
	
}
