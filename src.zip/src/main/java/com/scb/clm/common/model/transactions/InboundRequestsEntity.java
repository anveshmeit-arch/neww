package com.scb.clm.common.model.transactions;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

/*
 * 
 *  @author      1378958
 *  @version     1.0
 *  @since       
 *  @use         
 */
@Entity
@Table(name = "CLM_INBOUND_REQUESTS")
public class InboundRequestsEntity extends AbstractPersistableEntity<String> implements Cloneable,LoggerInterface
{
    @Id
    @Column(name="REQUEST_ID")
    private String requestId;

    @Column(name="COUNTRY_CODE")
    private String countryCode;

    @Column(name="INTERFACE_ID")
    private String interfaceId;

    @Column(name="REQUEST_TYPE")
    private String requestType;

    @Column(name="APPLICATION_REFERENCE")
    private String applicationReference;

    @Column(name="TRACKING_ID")
    private String trackingID;

    @Column(name="DUPLICATE_FLAG")
    private String duplicateFlag;

    @Column(name="REQUEST_DATE")
    private Date requestDate;

    @Column(name="REQUEST_TIME")
    private Timestamp requestTime;

    @Column(name="RESPONSE_TIME")
    private Timestamp responseTime;

    @Column(name="STATUS")
    private String status;

    @Column(name="VM_NAME")
    private String vmName;

    @Column(name="API_METHOD")
    private String apiMethod;

    @OneToMany(fetch=FetchType.LAZY,mappedBy="inboundRequestsErrorsEntityMapper")
    @Cascade({CascadeType.ALL})
    private Set<InboundRequestsErrorsEntity> inboundRequestsErrorsEntity  =     new     HashSet<>();

    @OneToOne(fetch=FetchType.LAZY,mappedBy="inboundRequestsMessagesEntityMapper")
    @Cascade({CascadeType.ALL})
    private InboundRequestsMessagesEntity inboundRequestsMessagesEntity;

    @OneToMany(fetch=FetchType.LAZY,mappedBy="inboundRequestsStatisticsEntityMapper")
    @Cascade({CascadeType.ALL})
    private Set<InboundRequestsStatisticsEntity> inboundRequestsStatisticsEntity;
    
    public InboundRequestsEntity() {

    }

    public InboundRequestsEntity(String requestId) {
        this.requestId = requestId;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getInterfaceId() {
        return interfaceId;
    }

    public void setInterfaceId(String interfaceId) {
        this.interfaceId = interfaceId;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public String getApplicationReference() {
        return applicationReference;
    }

    public void setApplicationReference(String applicationReference) {
        this.applicationReference = applicationReference;
    }

    public String getTrackingID() {
        return trackingID;
    }

    public void setTrackingID(String trackingID) {
        this.trackingID = trackingID;
    }

    public String getDuplicateFlag() {
        return duplicateFlag;
    }

    public void setDuplicateFlag(String duplicateFlag) {
        this.duplicateFlag = duplicateFlag;
    }

    public Date getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    public Timestamp getRequestTime() {
        return requestTime;
    }

    public void setRequestTime(Timestamp requestTime) {
        this.requestTime = requestTime;
    }

    public Timestamp getResponseTime() {
        return responseTime;
    }

    public void setResponseTime(Timestamp responseTime) {
        this.responseTime = responseTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getVmName() {
		return vmName;
	}

	public void setVmName(String vmName) {
		this.vmName = vmName;
	}

    public String getApiMethod() {
        return apiMethod;
    }

    public void setApiMethod(String apiMethod) {
        this.apiMethod = apiMethod;
    }
	public Set<InboundRequestsErrorsEntity> getInboundRequestsErrorsEntity() {
        return inboundRequestsErrorsEntity;
    }

    public void setInboundRequestsErrorsEntity(Set<InboundRequestsErrorsEntity> inboundRequestsErrorsEntity) {
        this.inboundRequestsErrorsEntity = inboundRequestsErrorsEntity;
    }

    public InboundRequestsMessagesEntity getInboundRequestsMessagesEntity() {
        return inboundRequestsMessagesEntity;
    }

    public void setInboundRequestsMessagesEntity(InboundRequestsMessagesEntity inboundRequestsMessagesEntity) {
        this.inboundRequestsMessagesEntity = inboundRequestsMessagesEntity;
    }

    public Set<InboundRequestsStatisticsEntity> getInboundRequestsStatisticsEntity() {
        return inboundRequestsStatisticsEntity;
    }

    public void setInboundRequestsStatisticsEntity(Set<InboundRequestsStatisticsEntity> inboundRequestsStatisticsEntity) {
        this.inboundRequestsStatisticsEntity = inboundRequestsStatisticsEntity;
    }

    public void addErrors(InboundRequestsErrorsEntity errorDetail) {
        if(this.inboundRequestsErrorsEntity == null) {
            this.inboundRequestsErrorsEntity= new HashSet<InboundRequestsErrorsEntity>();     
        }
        this.inboundRequestsErrorsEntity.add(errorDetail);
    }

    public void addStatistics(InboundRequestsStatisticsEntity statsDetail) {
        if(this.inboundRequestsStatisticsEntity == null) {
            this.inboundRequestsStatisticsEntity= new HashSet<InboundRequestsStatisticsEntity>();     
        }
        this.inboundRequestsStatisticsEntity.add(statsDetail);
    }
    
    @Override
    public String getId() 
    {
        return this.requestId;
    }

    @Override
    public int hashCode() {
        StringBuilder finalHashCode = new StringBuilder();
        if (this.requestId != null) 
        {
            finalHashCode.append(requestId);
        }
        return finalHashCode.toString().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
        {
            return true;
        }
        if ((obj == null) || (obj.getClass() != this.getClass())) 
        {
            return false;
        }
        InboundRequestsEntity other = (InboundRequestsEntity) obj;
        return Objects.equals(this.requestId, other.requestId);
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return (InboundRequestsEntity) super.clone();
    }   

}
