package com.scb.clm.common.repository;

import java.util.List;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.relational.core.mapping.Table;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.scb.clm.common.model.codesetup.NodesEntity;
import com.scb.clm.common.model.codesetup.NodesEntityKey;

@Table
@Repository
public interface NodesRepository extends JpaRepository<NodesEntity, NodesEntityKey>
{

    @Override
    public <S extends NodesEntity> S save(S entity);

    @Override
    @Cacheable("Nodes")
    public NodesEntity getOne(NodesEntityKey arg0);

    @Cacheable("NodesByFlowAndSequence")
    List<NodesEntity> findByIdCountryCodeAndIdFlowIdentifierAndSequenceIdAndStatusFlag(String countryCode,String flowIdentifier,String sequenceId,String statusFlag); 

    @Cacheable("MaxNodeLevel")
    @Query(value = "SELECT max(cast (n.sequenceId as int)) FROM NodesEntity n where n.id.countryCode= :countryCode and n.id.flowIdentifier= :flowIdentifier and n.statusFlag =:statusFlag")
    public Long getMaxNodeLevel(@Param("countryCode") String countryCode,@Param("flowIdentifier") String flowIdentifier,@Param("statusFlag") String statusFlag);

}