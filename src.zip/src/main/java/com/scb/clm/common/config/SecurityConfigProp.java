package com.scb.clm.common.config;

import java.util.List;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

@ConfigurationProperties(prefix = "security")
@Configuration
@Getter
@Setter

public class SecurityConfigProp {
	private Map<String, List<String>> url;
}
