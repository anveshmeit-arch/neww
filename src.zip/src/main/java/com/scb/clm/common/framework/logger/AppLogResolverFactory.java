package com.scb.clm.common.framework.logger;

import org.apache.logging.log4j.core.config.plugins.Plugin;
import org.apache.logging.log4j.core.config.plugins.PluginFactory;
import org.apache.logging.log4j.layout.template.json.resolver.EventResolverContext;
import org.apache.logging.log4j.layout.template.json.resolver.EventResolverFactory;
import org.apache.logging.log4j.layout.template.json.resolver.TemplateResolverConfig;
import org.apache.logging.log4j.layout.template.json.resolver.TemplateResolverFactory;

/**
 * {@link AppLogResolverResolver} factory.
 */
@Plugin(name = "AppLogResolverFactory", category = TemplateResolverFactory.CATEGORY)
public final class AppLogResolverFactory implements EventResolverFactory {

    private static final AppLogResolverFactory INSTANCE =
            new AppLogResolverFactory();

    private AppLogResolverFactory() {}

    @PluginFactory
    public static AppLogResolverFactory getInstance() {
        return INSTANCE;
    }

    @Override
    public String getName() {
    	//System.out.println("AppLogResolverFactory return AppLogResolver name" + AppLogResolver.getName());
        return AppLogResolver.getName();
    }

    @Override
    public AppLogResolver create(
            final EventResolverContext context,
            final TemplateResolverConfig config) {
    	//System.out.println("AppLogResolverFactory Initiate AppLogResolver");
        return new AppLogResolver(config);
    }

}