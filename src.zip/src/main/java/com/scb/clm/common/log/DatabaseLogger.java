package com.scb.clm.common.log;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.scb.clm.common.config.ApplicationConfiguration;
import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ErrorObject;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.CountryParametersEntity;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.transactions.InboundRequestsEntity;
import com.scb.clm.common.model.transactions.InboundRequestsErrorsEntity;
import com.scb.clm.common.model.transactions.InboundRequestsErrorsEntityKey;
import com.scb.clm.common.model.transactions.InboundRequestsMessagesEntity;
import com.scb.clm.common.model.transactions.InboundRequestsStatisticsEntity;
import com.scb.clm.common.model.transactions.InboundRequestsStatisticsEntityKey;
import com.scb.clm.common.model.transactions.LoggerInterface;
import com.scb.clm.common.model.transactions.OutboundRequestsEntity;
import com.scb.clm.common.model.transactions.OutboundRequestsErrorsEntity;
import com.scb.clm.common.model.transactions.OutboundRequestsErrorsEntityKey;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.repository.CountryParametersRepository;
import com.scb.clm.common.repository.InboundRequestsRepository;
import com.scb.clm.common.repository.OutboundRequestsRepository;
import com.scb.clm.common.util.DateTimeUtility;
import com.scb.clm.common.util.JSONUtility;
import com.scb.clm.common.util.StringUtility;
import com.scb.clm.common.util.SystemUtility;

@Component
public class DatabaseLogger
{

    @Autowired
    CountryParametersRepository countryParametersRepository;

    @Autowired
    InboundRequestsRepository inboundRequestsRepository;

    @Autowired
    OutboundRequestsRepository outboundRequestsRepository;

    /**
     *
     *
     * @param
     * @return 
     * @exception
     * @see
     * @since 
     */
    @Async("LoggerQueue")
    public void logData(TravellingObject travellingObject,LoggerInterface loggerInterface)
    {
        try
        {
            System.out.println("In Logger Framework");
            if(loggerInterface instanceof InboundRequestsEntity) {
                inboundRequestsRepository.saveAndFlush((InboundRequestsEntity) loggerInterface);
            } else if (loggerInterface instanceof OutboundRequestsEntity) {
                OutboundRequestsEntity obJOutboundRequestsEntity = (OutboundRequestsEntity) loggerInterface;
            	 if(obJOutboundRequestsEntity.getStatus() != null && !obJOutboundRequestsEntity.getStatus().equals(BaseConstants.NOT_ATTEMPTED)) {
            		 outboundRequestsRepository.saveAndFlush((OutboundRequestsEntity) loggerInterface);
            	 }
            } else {
                throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,BaseConstants.CLM_GENERIC_ERROR,"UNKNOWN LOG PATTERN");
            }
        }
        catch (Exception e)
        {
        	LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "logData", LogType.APPLICATION.name());
        	log.printErrorMessage(e);

        } 
        finally
        {
            //N.A
        }
    }

    /**
     *  
     * 
     * <p>
     *
     * @param         N.A
     * @return        
     * @exception     
     * @see
     * @since         March 2024
     */
    public void construcOutboundLog(TravellingObject trObj,ServiceStatus serviceStatus,NodeServicesEntity nodeServicesEntity) throws ProcessException
    {
        try
        {
            LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "construcOutboundLog", LogType.APPLICATION.name());
            
            if(nodeServicesEntity!=null && StringUtility.containsData(nodeServicesEntity.getLogTime()) && !nodeServicesEntity.getLogTime().equalsIgnoreCase("Y")) {
                log.println("DataBase Log (OutBound) Disabled for the Service");
                return;
            }
            
            OutboundRequestsEntity outboundRequestsEntity = null;
            String sequenceNumber = null;
            //String dataBaseType   = CountryConfig.getCountryParam(trObj.getCountryCode(),BaseConstants.DATABASE_GROUP_CNTRY_PARAM,BaseConstants.DATABASE_TYPE);
            String dataBaseType   = ApplicationConfiguration.getInstance().getHashicorpValutedProperties(BaseConstants.DATABASE_TYPE);
            
            if(dataBaseType != null && dataBaseType.equalsIgnoreCase(BaseConstants.ORACLE)) 
            {
                sequenceNumber = outboundRequestsRepository.getOracleOutboundSequenceNumber().toString();
            } else {
                sequenceNumber = outboundRequestsRepository.getPostgresOutboundSequenceNumber().toString();
            }
            
            sequenceNumber        = DateTimeUtility.formatDate(DateTimeUtility.getCurrentDateForLogging(),"yyMMddHHmmss")+""+String.format("%08d", Integer.parseInt(sequenceNumber));

            outboundRequestsEntity =  new OutboundRequestsEntity(sequenceNumber);
            outboundRequestsEntity.setApplicationReference(trObj.getApplicationReferenceNumber());
            outboundRequestsEntity.setCountryCode(trObj.getCountryCode());
            outboundRequestsEntity.setTrackingID(trObj.getTransactionID());
            outboundRequestsEntity.setDuplicateFlag(trObj.getDuplicateFlag());
            outboundRequestsEntity.setInterfaceId(serviceStatus.getInterfaceId());
            outboundRequestsEntity.setRequestType(nodeServicesEntity.getId().getServiceIdentifier());
            outboundRequestsEntity.setInboundRequestID(trObj.getInBoundLogSequenceNumber());
            outboundRequestsEntity.setHttpResponseCode(validateHttpCode(serviceStatus.getHttpStatus()));

            outboundRequestsEntity.setRequestDate(DateTimeUtility.getDateByCountryCode(trObj.getCountryCode()));

            outboundRequestsEntity.setRequestTime(serviceStatus.getRequestTime());                
            outboundRequestsEntity.setResponseTime(serviceStatus.getResponseTime());
            outboundRequestsEntity.setStatus(serviceStatus.getStatus());
            outboundRequestsEntity.setVmName(SystemUtility.getInstanceName());

            if(serviceStatus.getErrorObject()!=null && serviceStatus.getErrorObject().size() >0) {
                int i=0;
                for (ErrorObject errorObject : serviceStatus.getErrorObject()) {
                    OutboundRequestsErrorsEntity errorsEntity = new OutboundRequestsErrorsEntity(new OutboundRequestsErrorsEntityKey(sequenceNumber,String.valueOf(++i)));
                    errorsEntity.setCountryCode(trObj.getCountryCode());
                    errorsEntity.setErrorCode(getErrorData(errorObject.getCode(),10));
                    errorsEntity.setErrorMessage(getErrorData((String) errorObject.getDescription(),500));
                    outboundRequestsEntity.addErrors(errorsEntity);
                }
            }

            logData(trObj,outboundRequestsEntity);
        }
        catch (Exception e)
        {
        	LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "construcOutboundLog", LogType.APPLICATION.name());
        	log.printErrorMessage(e);

            throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,BaseConstants.CLM_DB_LOGGING_ERROR,"OUTBOUND LOG ERROR");
        }
        finally
        {
            //N.A
        }
        
    }

    /**
     *  
     * 
     * <p>
     *
     * @param         N.A
     * @return        
     * @exception     
     * @see
     * @since         March 2024
     */
    public void constructInBoundLog(TravellingObject trObj,InboundRequestsEntity inboundRequestsEntity) throws ProcessException
    {
        try
        {
            if(trObj == null) {
                throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,BaseConstants.CLM_DB_LOGGING_ERROR,"INVALID REQUEST PARAMETERS");
            }

            inboundRequestsEntity.setApplicationReference(trObj.getApplicationReferenceNumber());
            inboundRequestsEntity.setCountryCode(trObj.getCountryCode());
            inboundRequestsEntity.setTrackingID(trObj.getTransactionID());
            inboundRequestsEntity.setDuplicateFlag(trObj.getDuplicateFlag());
            inboundRequestsEntity.setInterfaceId(trObj.getInterfaceId());
            inboundRequestsEntity.setRequestType(trObj.getPathIdentifier());
            inboundRequestsEntity.setRequestDate(DateTimeUtility.getDateByCountryCode(trObj.getCountryCode()));
            inboundRequestsEntity.setResponseTime(DateTimeUtility.getTimeByCountryCode(trObj.getCountryCode()));
            inboundRequestsEntity.setVmName(SystemUtility.getInstanceName());
            inboundRequestsEntity.setApiMethod(trObj.getServiceContext().getHttpMethod());

            if(trObj.getErrorDetails()!=null && trObj.getErrorDetails().size() >0) {
                inboundRequestsEntity.setStatus("F");
                int i=0;
                for (ErrorObject errorObject : trObj.getErrorDetails()) {
                    InboundRequestsErrorsEntity errorsEntity = new InboundRequestsErrorsEntity(new InboundRequestsErrorsEntityKey(inboundRequestsEntity.getId(),String.valueOf(++i)));
                    errorsEntity.setCountryCode(trObj.getCountryCode());
                    errorsEntity.setErrorCode(getErrorData(errorObject.getCode(),10));
                    errorsEntity.setErrorMessage(getErrorData((String) errorObject.getDescription(),500));
                    inboundRequestsEntity.addErrors(errorsEntity);
                }
            } else {
                inboundRequestsEntity.setStatus("S");
            }

            List<CountryParametersEntity> logParam = countryParametersRepository.findByIdCountryCodeAndIdParameterGroupAndParameterCode(trObj.getCountryCode(),"LOG", "INBOUND_MESSG_LOG");
            if(logParam!=null && logParam.size()>0 && logParam.get(0)!=null && logParam.get(0).getParameterValue()!=null && logParam.get(0).getParameterValue().equalsIgnoreCase("Y")) {
                InboundRequestsMessagesEntity inboundRequestsMessagesEntity = new InboundRequestsMessagesEntity(inboundRequestsEntity.getId());
                inboundRequestsMessagesEntity.setCountryCode(trObj.getCountryCode());
                if(trObj.getRequestData() != null && !trObj.getRequestData().toString().trim().equalsIgnoreCase("")) {
                    inboundRequestsMessagesEntity.setRequestMessage(trObj.getRequestData().toString());
                }

                try {
                    String resp = (String)JSONUtility.domainWrapperToJSON(trObj.getResponseData());
                    if(resp != null && !resp.trim().equalsIgnoreCase("")) {
                        inboundRequestsMessagesEntity.setResponseMessage(resp);
                    }
                } catch (Exception e) {
                    //N.A
                }
                
                
                inboundRequestsEntity.setInboundRequestsMessagesEntity(inboundRequestsMessagesEntity);
            } else {
                System.out.println("Request Message is Not Stamped In Database");
            }

            if(trObj.getServiceStatus()!=null && trObj.getServiceStatus().size()>0) 
            {
                for (Map.Entry<String, ServiceStatus> entry : trObj.getServiceStatus().entrySet())
                {
                    ServiceStatus srvStatus = entry.getValue();
                    InboundRequestsStatisticsEntity statsEntity = new InboundRequestsStatisticsEntity
                            (
                                    new InboundRequestsStatisticsEntityKey
                                    (
                                            inboundRequestsEntity.getId(),
                                            srvStatus.getFlowIdentifier(),
                                            srvStatus.getNodeIdentifier(),
                                            srvStatus.getNodeSequenceId(),
                                            srvStatus.getServiceIdentifier()
                                    )
                            );
                    statsEntity.setCountryCode(trObj.getCountryCode());
                    statsEntity.setServiceStartTime(srvStatus.getRequestTime());
                    statsEntity.setServiceEndTime(srvStatus.getResponseTime());
                    statsEntity.setStatusFlag(srvStatus.getStatus());
                    inboundRequestsEntity.addStatistics(statsEntity);
                }
            }
            logData(trObj,inboundRequestsEntity);
        }
        catch (ProcessException e)
        {
            throw e;
        }
        catch (Exception e)
        {
        	LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "constructInBoundLog", LogType.APPLICATION.name());
        	log.printErrorMessage(e);

            throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL,BaseConstants.CLM_DB_LOGGING_ERROR,"INBOUND LOG ERROR");
        }
        finally
        {
            //N.A
        }
    }



    /**
     *  
     * 
     * <p>
     *
     * @param         N.A
     * @return         
     * @exception       
     * @see
     * @since         August 2024
     */
    public String validateHttpCode(String httpCode) 
    {
    	if(httpCode==null) 
    	{
    		return null;
    	}
    	else if (httpCode.length()>3) 
    	{
    		System.out.println("Invalid HTTP Code - Please Validate "+httpCode);
    		return "ERR";
    	} 
    	else
    	{
    		return httpCode;
    	}
    }
    
    public String getErrorData(String data, int maxLength) 
    {    
        if(data==null) {
            return null;
        }
        if(data.length() < maxLength) {
            return data;
        } else {
            return data.substring(0,maxLength);
        }   
    }
}