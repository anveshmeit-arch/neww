package com.scb.clm.common.model.codesetup;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

/*
 * 
 *  @author      1378958
 *  @version     1.0
 *  @since          
 *  @use         
 */
@Embeddable
public class PathFlowsEntityKey implements Serializable {

    @Column(name = "COUNTRY_CODE")
    private String countryCode;

    @Column(name = "PATH_IDENTIFIER")
    private String pathIdentifier;

    @Column(name = "FLOW_ID")
    private String flowId;

    // Default constructor
    public PathFlowsEntityKey() {}

    // Parameterized constructor
    public PathFlowsEntityKey(String countryCode, String pathIdentifier, String flowId) {
        this.countryCode = countryCode;
        this.pathIdentifier = pathIdentifier;
        this.flowId = flowId;
    }

    // Getters and Setters
    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getPathIdentifier() {
        return pathIdentifier;
    }

    public void setPathIdentifier(String pathIdentifier) {
        this.pathIdentifier = pathIdentifier;
    }

    public String getFlowId() {
        return flowId;
    }

    public void setFlowId(String flowId) {
        this.flowId = flowId;
    }

    // Override equals and hashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PathFlowsEntityKey that = (PathFlowsEntityKey) o;
        return Objects.equals(countryCode, that.countryCode) &&
               Objects.equals(pathIdentifier, that.pathIdentifier) &&
               Objects.equals(flowId, that.flowId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(countryCode, pathIdentifier, flowId);
    }

}
