package com.scb.clm.common.model.codesetup;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

/*
 * 
 *  @author      1663398
 *  @version     1.0
 *  @since       
 *  @use         
 */

@Embeddable
public class JobScheduleEntityKey implements Serializable,Cloneable
{

    private static final long serialVersionUID = 1103847698360379375L;

    @Column(name = "COUNTRY_CODE", nullable = false ,insertable=false, updatable=false)
    private String countryCode;

    @Column(name = "JOB_ID", nullable = false ,insertable=false, updatable=false)
    private String jobId;

    @Column(name = "JOB_SEQUENCE", nullable = false ,insertable=false, updatable=false)
    private String jobSequence;

    public JobScheduleEntityKey() {

    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public String getJobSequence() {
        return jobSequence;
    }

    public void setJobSequence(String jobSequence) {
        this.jobSequence = jobSequence;
    }


    public JobScheduleEntityKey(String countryCode, String jobId, String jobSequence) {
        this.countryCode = countryCode;
        this.jobId = jobId;
        this.jobSequence = jobSequence;
    }

    @Override
    public int hashCode() {
        StringBuilder finalHashCode = new StringBuilder();
        if (this.countryCode != null && this.jobId != null && this.jobSequence != null) 
        {
            finalHashCode.append(countryCode);
            finalHashCode.append(jobId);
            finalHashCode.append(jobSequence);
        }
        return finalHashCode.toString().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
        {
            return true;
        }
        if ((obj == null) || (obj.getClass() != this.getClass())) 
        {
            return false;
        }
        JobScheduleEntityKey other = (JobScheduleEntityKey) obj;
        return   Objects.equals(this.countryCode, other.countryCode) 
                && Objects.equals(this.jobId, other.jobId)
                && Objects.equals(this.jobSequence, other.jobSequence);
    }

    @Override
    public Object clone() {
        try {
            return (JobScheduleEntityKey) super.clone();
        } catch (CloneNotSupportedException e) {
            return new JobScheduleEntityKey(this.getCountryCode(),this.getJobId(),this.getJobSequence());
        }
    }    

}
