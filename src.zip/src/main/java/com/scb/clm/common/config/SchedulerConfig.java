package com.scb.clm.common.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;

@Configuration
public class SchedulerConfig
{
    
    /**
     * Action - Dependency For JobSchedulerService
     * 
     * <p>
     *
     * @param         N.A
     * @return         
     * @exception      
     * @see
     * @since         May 2024
     */
    @Bean
    public ThreadPoolTaskScheduler taskScheduler()
    {
        ThreadPoolTaskScheduler scheduler = new ThreadPoolTaskScheduler();
        scheduler.setPoolSize(10);
        scheduler.setThreadNamePrefix("CLMTask-");
        scheduler.initialize();
        return scheduler;
    }
}
