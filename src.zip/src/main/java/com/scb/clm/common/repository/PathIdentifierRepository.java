package com.scb.clm.common.repository;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.scb.clm.common.model.codesetup.PathIdentifierEntity;
import com.scb.clm.common.model.codesetup.PathIdentifierEntityKey;

@Repository
public interface PathIdentifierRepository extends JpaRepository<PathIdentifierEntity, PathIdentifierEntityKey>
{
    @Override
    public <S extends PathIdentifierEntity> S save(S entity);

    @Cacheable("FlowsByPathIdentifierStatus")
    PathIdentifierEntity findByIdCountryCodeAndIdPathIdentifierAndStatusFlag(String countryCode,  String pathIdentifier,String statusFlag);
}