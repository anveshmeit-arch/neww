package com.scb.clm.common.util;


/**
 * Defines all utility methods related to common security package.
 */
public final class AuthUtility {
	public static final String HEALTH_CHECK_JSP = "/HealthCheck.jsp";

	private AuthUtility() {

	}

	/**
	 * Pass HttpServletRequest's requestUri  and contextPath as parameter to check if
	 * incoming URL is HealthCheck.jsp or not
	 * 
	 * @param requestUri
	 * @param contextPath
	 * @return true if HttpServletRqeuest.getRequestURI is HealthCheck.jsp otherwise
	 *         false.
	 */
	public static boolean isHealthCheckJsp(String requestUri, String contextPath) {
		System.out.println("Incoming URI - requestUri ["+requestUri+"] ,"+"Context Path ["+contextPath+"]");
		String healthCheckJspPath = contextPath + HEALTH_CHECK_JSP;
		return requestUri.equalsIgnoreCase(healthCheckJspPath);
	}

}
