package com.scb.clm.common.framework.logger;

import java.io.File;

import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.config.plugins.Plugin;
import org.apache.logging.log4j.core.lookup.StrLookup;

import com.scb.clm.common.config.BaseConstants;

@Plugin(name = "file", category = StrLookup.CATEGORY)
public class FileLookup implements StrLookup {

	@Override
	public String lookup(String key) {
		return Thread.currentThread().getName();
	}
	//String marker = null;
	@Override
	public String lookup(LogEvent event, String key) {
		
		String fileName = null;
		if(event.getContextData()!=null && !event.getContextData().isEmpty()) {
		
			if(event.getContextData().getValue(event.getContextData().getValue("threadName")+event.getLoggerName())!= null) {
				fileName = event.getContextData().getValue(event.getContextData().getValue("threadName")+event.getLoggerName());
			}
			else if(event.getMarker() != null){
				fileName =LoggerDataProvider.getSpecificLogPath()+File.separatorChar+BaseConstants.APPLICATION_NAME+"-"+System.getProperty("serviceName")+"_"+event.getMarker().getName();
			}
		}
		if(fileName == null && event.getMarker() != null){
			fileName =LoggerDataProvider.getSpecificLogPath()+File.separatorChar+BaseConstants.APPLICATION_NAME+"-"+System.getProperty("serviceName")+"_"+event.getMarker().getName();
		}
		if(fileName == null){
			fileName = LoggerDataProvider.getCommonAppLogFile();
		}
		return fileName;
	}

}    
