package com.scb.clm.common.repository;

import java.util.List;

import jakarta.persistence.LockModeType;
import jakarta.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.scb.clm.common.model.codesetup.JobScheduleEntity;
import com.scb.clm.common.model.codesetup.JobScheduleEntityKey;

@Repository
public interface JobScheduleRepository extends JpaRepository<JobScheduleEntity, JobScheduleEntityKey>
{

    @Override
    public <S extends JobScheduleEntity> S save(S entity);

    @Override
    public JobScheduleEntity getOne(JobScheduleEntityKey arg0);

    @Query(value = "SELECT js.cronExpression FROM JobScheduleEntity js WHERE js.id.jobId = :jobId AND js.retryServiceProgram = :retryServiceProgram and js.statusFlag='1'")
    String findCronExpressionByRetryServiceProgramAndId_JobId(@Param("jobId")String jobId, @Param("retryServiceProgram")String retryServiceProgram);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Transactional
    @Query("SELECT j FROM JobScheduleEntity j WHERE j.locked = false and j.statusFlag='1'")
    List<JobScheduleEntity> findUnlockedJobs();

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Transactional
    @Query("SELECT j FROM JobScheduleEntity j WHERE j.id.countryCode = :countryCode and j.id.jobId = :jobId and j.id.jobSequence = :jobSequence and j.statusFlag='1'")
    JobScheduleEntity lockJobById(@Param("countryCode")String countryCode, @Param("jobId")String jobId, @Param("jobSequence")String jobSequence);

}
