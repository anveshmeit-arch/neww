package com.scb.clm.common.model.codesetup;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

/*
 * 
 * @author       1378958
 * @version      1.0
 * @since        
 * @use          
 */
@Embeddable
public class CountryParametersEntityKey implements Serializable,Cloneable
{

    private static final long serialVersionUID = -6175995217663775813L;

    @Column(name = "COUNTRY_CODE", nullable = false ,insertable=false, updatable=false)
    private String countryCode;

    @Column(name = "PARAM_GROUP", nullable = false ,insertable=false, updatable=false)
    private String parameterGroup;

    @Column(name = "PARAM_SEQUENCE", nullable = false ,insertable=false, updatable=false)
    private String parameterSequence;

    public CountryParametersEntityKey () {

    }

    public CountryParametersEntityKey (String countryCode,String parameterGroup,String parameterSequence) {
        this.countryCode       = countryCode;
        this.parameterGroup    = parameterGroup;
        this.parameterSequence = parameterSequence;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getParameterGroup() {
        return parameterGroup;
    }

    public void setParameterGroup(String parameterGroup) {
        this.parameterGroup = parameterGroup;
    }

    public String getParameterSequence() {
        return parameterSequence;
    }

    public void setParameterSequence(String parameterSequence) {
        this.parameterSequence = parameterSequence;
    }

    @Override
    public int hashCode() {
        StringBuilder finalHashCode = new StringBuilder();
        if (this.countryCode != null && 
                this.parameterGroup != null &&
                this.parameterSequence != null 
                ) 
        {
            finalHashCode.append(countryCode);
            finalHashCode.append(parameterGroup);
            finalHashCode.append(parameterSequence);
        }
        return finalHashCode.toString().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
        {
            return true;
        }
        if ((obj == null) || (obj.getClass() != this.getClass())) 
        {
            return false;
        }
        CountryParametersEntityKey other = (CountryParametersEntityKey) obj;
        return   Objects.equals(this.countryCode, other.countryCode) 
                && Objects.equals(this.parameterGroup, other.parameterGroup)
                && Objects.equals(this.parameterSequence, other.parameterSequence);
    }

    @Override
    public Object clone() {
        try {
            return (CountryParametersEntityKey) super.clone();
        } catch (CloneNotSupportedException e) {
            return new CountryParametersEntityKey(this.getCountryCode(),this.getParameterGroup(),this.getParameterSequence());
        }
    }    
}
