package com.scb.clm.common.config;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLEncoder;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TimeZone;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.xml.XMLConstants;
import javax.xml.bind.DatatypeConverter;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.hc.client5.http.classic.HttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClientBuilder;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.client5.http.socket.ConnectionSocketFactory;
import org.apache.hc.client5.http.socket.PlainConnectionSocketFactory;
import org.apache.hc.client5.http.ssl.SSLConnectionSocketFactory;
import org.apache.hc.core5.http.HttpStatus;
import org.apache.hc.core5.http.URIScheme;
import org.apache.hc.core5.http.config.Registry;
import org.apache.hc.core5.http.config.RegistryBuilder;
import org.apache.hc.core5.ssl.SSLContextBuilder;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.ResourceUtils;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.clm.common.db.support.CryptoDecrypter;
import com.scb.clm.common.db.support.CryptoParameters;
import com.scb.clm.common.db.support.HashiCorpImplementation;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.util.ServiceContext;
import com.scb.clm.common.util.ServiceParameterUtility;

@Component
public class ApplicationConfiguration
{

    private static HashMap<String,ApplicationConfiguration> appConfigInstanceHash    =   new HashMap<String, ApplicationConfiguration>();
    private static HashMap<String,String> propertiesHash                             =   new HashMap<String, String>();
    private static HashMap < String, HashMap < String, String >> allCountriesProperties        =   null;
    private HashMap<String, HashMap<String, String>> hashicorpValutedProperties =   new HashMap<>();
    private String appLogPath = null;
    private String defCompanyID = null;
    private String defEnvID = null;

    private String env = System.getProperty("spring.profiles.active");
    private static String serviceName = System.getProperty("serviceName");

    static boolean isSecretsLoadedSuccessfull     = false;

    private ApplicationConfiguration() {

    }
    /**
     * Returns the ApplicationConfiguration Instance with which the data can be
     * placed and accessed from the memory. Method takes no arguments as it is common for the application
     * <p>
     *
     * @param         N.A
     * @return        ApplicationConfiguration Instance
     * @exception     ProcessException
     * @see
     * @since         March 2024
     */
    public static synchronized  ApplicationConfiguration getInstance()
    {
        ApplicationConfiguration appConfigInstanceObject = (ApplicationConfiguration) appConfigInstanceHash.get(serviceName);
        try
        {
            if (appConfigInstanceObject == null)
            {

                appConfigInstanceObject = new ApplicationConfiguration();
                appConfigInstanceHash.put(serviceName, appConfigInstanceObject);
                appConfigInstanceObject.getAllCountriesMappedProperty();
                appConfigInstanceObject.loadApplicationProperties();
            }
            /*
             * else { System.out.println("appConfigInstanceObject is not null" ); }
             */
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            ProcessException pe = new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL, BaseConstants.APP_INSTANCE_ERROR,"Application Configuration / Object Instance Error");
            pe.printStackTrace();
        }
        finally
        {
            // N.A
        }
        return appConfigInstanceObject;
    }

    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    private HashMap<String, HashMap<String, String>> readAppConfig()
    {
        System.out.println("Reading - App CLM_AppConfig.xml");

        HashMap<String, HashMap<String, String>> appConfigurations = null;
        try
        {

            if(serviceName == null || env == null) {

                throw new ProcessException("ERROR","SYS00","Service Name or Spring Profiles is Mandatory For This Instance");
            }
            appConfigurations = new HashMap<>();
            DocumentBuilderFactory dbFactory        =   DocumentBuilderFactory.newInstance();
            HashMap<String, String> properties      =   null;
            DocumentBuilder dBuilder;

            dbFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            dBuilder                                =   dbFactory.newDocumentBuilder();
            // String envAppPath                       =   BaseConstants.APP_CONFIG_PATH;
            String appConfigFile = "CLM_";

            appConfigFile = appConfigFile+serviceName+"_"+env+"_"+BaseConstants.APP_CONFIG_PATH;
            System.out.println("Reading - App "+appConfigFile);
            Document doc  =   dBuilder.parse((new FileInputStream(ResourceUtils.getFile(ResourceUtils.CLASSPATH_URL_PREFIX+appConfigFile).getPath())));
            doc.getDocumentElement().normalize();

            NodeList configNodeList     = doc.getElementsByTagName("Config");
            Node configNode             = configNodeList.item(0);
            Element configElement       = (Element) configNode;

            if (configElement.getAttribute("type") != null && !configElement.getAttribute("type").equals(""))
            {
                NodeList componentNodeList = doc.getElementsByTagName("component");
                for(int i = 0 ; i<componentNodeList.getLength();i++)
                {
                    Node componentNode            = componentNodeList.item(i);
                    Element componentElement    = (Element) componentNode;
                    if (componentElement.getAttribute("key").equals("defCompanyID")){
                        setDefCompanyID(componentElement.getAttribute("value"));
                    }
                    if (componentElement.getAttribute("key").equals("defEnvID")){
                        setDefEnvID(componentElement.getAttribute("value"));
                    }
                }
            }

            for (int temp = 1; temp < configNodeList.getLength(); temp++)
            {
                Node configNode2            = configNodeList.item(temp);
                Element configElement2      = (Element) configNode2;
                NodeList componentNodeList2 = configElement2.getElementsByTagName("component");
                properties                  = new HashMap<String, String>();

                for (int temp2 = 0; temp2 < componentNodeList2.getLength(); temp2++)
                {
                    Node componentNode2 = componentNodeList2.item(temp2);

                    if (componentNode2.getNodeType() == Node.ELEMENT_NODE)
                    {
                        Element componentElement2 = (Element) componentNode2;
                        properties.put(componentElement2.getAttribute("key"), componentElement2.getAttribute("value"));
                    }
                }
                appConfigurations.put(configElement2.getAttribute("companyID"), properties);
            }
        }

        catch (Exception e)
        {
            e.printStackTrace();
            System.out.println("Error - ReadAppConfig - Exception : " + e);

        }
        finally {
            System.out.println("ReadAppConfig - Details : " + appConfigurations.toString());
        }
        return appConfigurations;
    }


    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    public void getAllCountriesMappedProperty() throws Exception
    {
        //HashMap < String, HashMap < String, String >> allCountriesProperties        =   null;
        HashMap < String, String > properties                                       =   new HashMap < > ();
        LoggerUtil log = null;
        String companyID = null;
        String pwdFromCrypto = null;
        allCountriesProperties = readAppConfig();

        if(!allCountriesProperties.isEmpty() && allCountriesProperties.size() >0 )
        {
            Iterator<Entry<String, HashMap<String, String>>> it = allCountriesProperties.entrySet().iterator();

            while (it.hasNext())
            {
                Map.Entry< String, HashMap < String, String >> prop = (Map.Entry< String, HashMap < String, String >>) it.next();
                companyID = prop.getKey() != null ? prop.getKey().toString() : "";
                properties = (HashMap < String, String > ) prop.getValue();
                HashMap <String, String> dbProperties = null;
                //this.appLogPath = dbProperties.get("appLogPath");
                this.setAppLogPath(properties.get("appLogPath"));
                //String appId = properties.get(BaseConstants.APPLICATION_NAME);
                ServiceContext context = new ServiceContext();
                context.setCountryCode(companyID);
                properties.put("companyID", companyID);
                properties.put("appid", serviceName);
                //log = LoggerUtil.getInstance(ApplicationConfiguration.class, BaseConstants.APPLICATION_NAME,companyID,LogType.APPLICATION.name());
                log = LoggerUtil.getInstance(this.getClass(), BaseConstants.APPLICATION_NAME+"-"+System.getProperty("serviceName"),companyID);

                try {
                    CryptoParameters.initCrypto(properties.get("CertificatePath")+ File.separatorChar + properties.get("CRYPTO_CONFIG"));
                } catch (Exception e){

                    e.printStackTrace();
                    log.printErrorMessage(e);
                }
                dbProperties = getHashiCorpVaultDetails(properties);

                if(properties.get("isHCEnabled")!=null && properties.get("isHCEnabled").equals("Y"))
                {

                    System.out.println("Properties Get Key [" + (prop.getKey() + "] Value [" + prop.getValue())+"]");

                    System.out.println("Country Code - AppConfig : " + companyID);

                    if(properties.get("HC_INVOKE_START_TIME")==null)
                    {
                        System.out.println("During Server startup :"+companyID);
                        System.out.println("All_Details_Before_Server_Start_UP :");

                        HashMap<String, String> HCDetails = HashiCorpImplementation.getDBPassword(dbProperties);

                        //System.out.println("HCDetails ================================> "+HCDetails);
                        if(HCDetails!=null && !HCDetails.isEmpty())
                        {
                            pwdFromCrypto = HCDetails.get("PWD");
                            dbProperties.put(BaseConstants.DB_PW, HCDetails.get("PWD"));
                            dbProperties.put(BaseConstants.DB_USER_ID, HCDetails.get(BaseConstants.DB_USER_ID));
                            dbProperties.put("HC_INVOKE_START_TIME", HCDetails.get("HC_INVOKE_START_TIME"));
                            //hashicorpValutedProperties.put(companyID, dbProperties);
                        }
                    }

                }

                if(dbProperties.get(BaseConstants.DB_PW) == null && pwdFromCrypto == null){
                    // String pwdFromCrypto = null;
                    log.println("HC_Down_During_Start_up:"+companyID +":Reading From Crypto");
                    try {
                        pwdFromCrypto = CryptoDecrypter.getInstance().decryptDBPwd(properties.get("appid"), companyID);
                        if(pwdFromCrypto !=null){
                            dbProperties.put(BaseConstants.DB_PW, pwdFromCrypto);
                            dbProperties.put(BaseConstants.DB_USER_ID, properties.get(BaseConstants.DB_SCHEMA_ID));
                        }
                    }
                    catch(Exception e)
                    {
                        /* e.printStackTrace(); */
                        log.printErrorMessage(e);
                    }

                }
                if(properties.get("DATABASE_TYPE").equals("O")) {
                    dbProperties.put("DB_DRIVER", BaseConstants.ORACLE_DRIVER);
                }else if(properties.get("DATABASE_TYPE").equals("P")) {
                    dbProperties.put("DB_DRIVER", BaseConstants.POSTGRES_DRIVER);
                }
                dbProperties.put("DATABASE_TYPE", properties.get("DATABASE_TYPE"));
                dbProperties.put(BaseConstants.JDBC_URL, properties.get("DB_URL"));
                dbProperties.put("DATABASE_TYPE", properties.get("DATABASE_TYPE"));
                this.hashicorpValutedProperties.put(companyID, dbProperties);
            }
            log.println("MultiCtyHashicorpValutedProperties Loaded ==========> ");
            allCountriesProperties.put(companyID, properties);
        }
        else {
            throw new ProcessException("ERROR", "SYS01", "No App Config Found");
        }
        // return hashicorpValutedProperties;
    }


    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    public static HashMap<String, String> getHashiCorpVaultDetails(HashMap<String, String> properties)
    {
        HashMap<String, String> input = new HashMap<String, String>();
        input.put("isHCEnabled", properties.get("isHCEnabled"));
        input.put("tokenURL", properties.get("HC_TokenURL"));
        input.put("icm_cert", properties.get("HC_ClientAuth"));
        input.put("passwordURL",properties.get("HC_PasswordURL"));
        input.put("keyStorePath", properties.get("HC_KeyStorePath"));
        input.put("keyStoreCredentials", properties.get("HC_KeyStoreCredentials"));
        input.put("trustStorePath",properties.get("HC_TrustStorePath"));
        input.put("truststoreCredential", properties.get("HC_TruststoreCredential"));
        input.put("keyStoreCredentials", properties.get("HC_KeyStoreCredentials"));
        input.put("WhenToInvokeHC", properties.get("WhenToInvokeHC"));
        if(properties.get("NextRotationHours")!=null) {
            input.put("NextRotationHours",properties.get("NextRotationHours"));
        }
        if(properties.get("NextRotationDays")!=null) {
            input.put("NextRotationDays",properties.get("NextRotationDays"));
        }
        input.put("currentPassword", properties.get("currentPassword"));
        input.put("appID", properties.get("appid"));
        input.put("companyID",  properties.get("companyID"));
        if(properties.get("CertificatePath")!=null) {
            System.out.println("Certificate_PATH");
            input.put("certificatePath", properties.get("CertificatePath")+ "/" + properties.get("CRYPTO_CONFIG"));
        }
        return input;
    }


    /**
     * Returns Void
     *
     * This method is to load all the application related properties which is present in the System_Properties.xml file
     * and root tag "Config"
     *
     *
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since        March 2024
     */
    public void loadApplicationProperties()
    {
        try
        {
            System.out.println("# Loading Application Properties #");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();

            dbFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);

            DocumentBuilder dBuilder;

            dBuilder        =    dbFactory.newDocumentBuilder();
            Document doc    =    dBuilder.parse((getClass().getResourceAsStream(BaseConstants.APP_PROPERTY_FILE_PATH)));
            doc.getDocumentElement().normalize();

            NodeList configNodeList = doc.getElementsByTagName("Config");
            Node configNode         = configNodeList.item(0);
            Element configElement   = (Element) configNode;

            if (configElement.getAttribute("type") != null
                    && !configElement.getAttribute("type").equals("")
                    && configElement.getAttribute("type").equals("Config"))
            {
                NodeList componentNodeList = doc.getElementsByTagName("component");
                for(int i = 0 ; i<componentNodeList.getLength();i++)
                {
                    Node componentNode          = componentNodeList.item(i);
                    Element componentElement    = (Element) componentNode;

                    if(componentElement.getAttribute("key") !=null
                            && componentElement.getAttribute("key").trim().length()>0
                            && componentElement.getAttribute("value") !=null
                            && componentElement.getAttribute("value").trim().length()>0)
                    {
                        System.out.println(" Key "+componentElement.getAttribute("key") +" # Value "+ componentElement.getAttribute("value"));
                        propertiesHash.put(componentElement.getAttribute("key"),componentElement.getAttribute("value"));
                    }
                    else
                    {
                        System.out.println(" # Empty Key or Value # Key "+componentElement.getAttribute("key") + componentElement.getAttribute("value"));
                    }
                }
            }
        }
        catch (Exception e)
        {
            System.out.println("# Application Properties NOT LOADED 3-#  Please check System_Properties.xml # ");
        }
    }


    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    public void loadClientIdClientSecret(String countryCode) throws ProcessException, NoSuchAlgorithmException, KeyManagementException, UnsupportedEncodingException
    {

        URL url;
        HttpsURLConnection connection;
        InputStream inputStream;
        String query;
        String urlOfNsdl;
        String encodedBasicAuth = null;

        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "loadClientIdClientSecret", LogType.APPLICATION.name());
        log.println("Gateway Register URL ["+ CountryConfig.getGatewayCountryParam((countryCode == null ? "00": countryCode),"GATEWAY_REGISTER_URL")+"]");
        String catalystEnabled = CountryConfig.getCountryParam((countryCode == null ? "00": countryCode),"GATEWAY", "CATALYST_ENABLED");

        if((catalystEnabled != null && catalystEnabled.trim().equalsIgnoreCase("Y"))) {
            query = String.format("client_name=%s", CountryConfig.getCountryParam((countryCode == null ? "00": countryCode),"GATEWAY","CATALYST_GATEWAY_URL_USER"), "UTF-8");
//        	urlOfNsdl=CountryConfig.getGatewayCountryParam(countryCode,"CATALYST_GATEWAY_REGISTER_URL")+query;   //"https://identity-hk-sit.api.dev.net:8263/api/identity/oauth2/dcr/v1.0/register?client_name=50403_icm_user_ICM";
            Map<String, String> ldapAuthMap = getLDAPauthDetails();
            if (ldapAuthMap != null && !ldapAuthMap.isEmpty()) {
                encodedBasicAuth = DatatypeConverter.printBase64Binary((ldapAuthMap.get("USERNAME")+":"+ ldapAuthMap.get("PASSWORD")).getBytes("UTF-8"));
            }
        }else {
            query = String.format("client_name=%s", URLEncoder.encode(BaseConstants.CLIENT_NAME, "UTF-8"));
            //"https://identity-hk-sit.api.dev.net:8263/api/identity/oauth2/dcr/v1.0/register?client_name=50403_icm_user_ICM";
        }
        urlOfNsdl=CountryConfig.getGatewayCountryParam((countryCode == null ? "00": countryCode),"GATEWAY_REGISTER_URL")+query;
        SSLContext sslcontext = getSSLContext();
        SSLSocketFactory factory = sslcontext.getSocketFactory();


        try
        {
            url = new URL(urlOfNsdl);
            connection = (HttpsURLConnection) url.openConnection();
            connection.setRequestMethod(BaseConstants.GET_REQUEST);
            if(catalystEnabled != null && catalystEnabled.trim().equalsIgnoreCase("Y")) {
                connection.setRequestProperty(BaseConstants.AUTHORIZATION_HEADER, BaseConstants.AUTHORIZATION_HEADER_BASIC +encodedBasicAuth);
            }else {
                connection.setRequestProperty(BaseConstants.WS02_IDENTITY_USER, BaseConstants.API_IDENTITY_USER);
            }
            connection.setUseCaches (false);
            connection.setDoInput(true);
            connection.setDoOutput(true);
            connection.setSSLSocketFactory(factory);
            int responseCode = connection.getResponseCode();

            if (200 <= responseCode && responseCode <= 299)
            {
                log.println("ClientId & ClientSecret Refresh Success During Startup");
                inputStream = connection.getInputStream();
            }
            else
            {
                inputStream = connection.getErrorStream();
            }
            BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
            Object obj = new JSONParser().parse(in);
            JSONObject json = (JSONObject) obj;
            StartUpConfigurations.clientIdClientSecretMap.put((countryCode==null?"":countryCode)+BaseConstants.CLIENT_ID, json.get(BaseConstants.CLIENT_ID).toString());
            StartUpConfigurations.clientIdClientSecretMap.put((countryCode==null?"":countryCode)+BaseConstants.CLIENT_SECRET, json.get(BaseConstants.CLIENT_SECRET).toString());
            log.println("StartUpConfigurations.clientIdClientSecretMap : "+StartUpConfigurations.clientIdClientSecretMap);
            in.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
            log.printErrorMessage(e);
            // throw new ProcessException(BaseConstants.ERROR_TYPE_PROCESSING,BaseConstants.CLM_GENERIC_ERROR,"Error During ClientId and Client Secret Formation");
        }
    }

    private Map<String, String> getLDAPauthDetails() throws ProcessException {
        System.out.println("Inside getLDAPauthDetails method");
        Map<String, String> ldapAuthMap = null;
        try {
            ldapAuthMap = CryptoDecrypter.getInstance().decryptUserNameAndPwd("GBL", "ICM_GBL_KONG_LDAP");
            System.out.println("Inside getLDAPauthDetails method -- " + ldapAuthMap.size()+", "+ldapAuthMap);
        } catch (Exception e) {

            throw new ProcessException(BaseConstants.ERROR_TYPE_PROCESSING,BaseConstants.CLM_GENERIC_ERROR,"Error During Access Token Generation");
        }
        return ldapAuthMap;
    }

    public String getAccessToken(TravellingObject trObj,String scope) throws ProcessException
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "getAccessToken", LogType.APPLICATION.name());
        log.println("Configurations Map "+StartUpConfigurations.clientIdClientSecretMap.toString());

        if(trObj!=null && trObj.getServiceContext().isRegionAvailable())
        {
            log.println("Searching for Client ID [With Region] "+trObj.getServiceContext().getCountryCodeWithRegion()+BaseConstants.CLIENT_ID + " / Secret Id " +trObj.getServiceContext().getCountryCodeWithRegion()+BaseConstants.CLIENT_SECRET + " / Scope "+scope);

            return getAccessToken(StartUpConfigurations.clientIdClientSecretMap.get(trObj.getServiceContext().getCountryCodeWithRegion()+BaseConstants.CLIENT_ID), StartUpConfigurations.clientIdClientSecretMap.get(trObj.getServiceContext().getCountryCodeWithRegion()+BaseConstants.CLIENT_SECRET),scope,trObj);
        }
        else if(trObj!=null)
        {
            log.println("Searching for Client ID [Default - Without Region] "+trObj.getServiceContext().getCountryCodeWithRegion()+BaseConstants.CLIENT_ID + " / Secret Id " +trObj.getServiceContext().getCountryCodeWithRegion()+BaseConstants.CLIENT_SECRET + " / Scope "+scope);

            return getAccessToken(StartUpConfigurations.clientIdClientSecretMap.get(trObj.getCountryCode()+BaseConstants.CLIENT_ID), StartUpConfigurations.clientIdClientSecretMap.get(trObj.getCountryCode()+BaseConstants.CLIENT_SECRET),scope,trObj);
        }
        else
        {
            throw new ProcessException(BaseConstants.ERROR_TYPE_PROCESSING,BaseConstants.CLM_GENERIC_ERROR,"Internal Error - No Travelling Object");
        }
    }


    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    private String getAccessToken(String clientId, String clientSecret, String scope, TravellingObject trObj) throws ProcessException
    {
        String gatewayTokenUrl;
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "loadClientIdClientSecret", LogType.APPLICATION.name());

        try
        {
            log.println("Searching Token for Client ID ["+clientId+"] Secret ID ["+clientSecret+"] Scope ["+scope+"] ");

            HttpHeaders httpHeaders = new HttpHeaders();
            gatewayTokenUrl = CountryConfig.getGatewayCountryParam(trObj.getServiceContext().getCountryCodeWithRegion(),"GATEWAY_TOKEN_URL");
            log.println("Gateway Token URL  ["+gatewayTokenUrl+"] Country Param  ["+(trObj.getServiceContext().getCountryCodeWithRegion())+"] [GATEWAY_TOKEN_URL]");


            String encodedBasicAuth = DatatypeConverter.printBase64Binary((clientId+":"+ clientSecret).getBytes("UTF-8"));
            httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            httpHeaders.add(BaseConstants.AUTHORIZATION_HEADER, BaseConstants.AUTHORIZATION_HEADER_BASIC +encodedBasicAuth);
            httpHeaders.add(BaseConstants.CONTENT_TYPE,MediaType.APPLICATION_FORM_URLENCODED_VALUE);
            httpHeaders.add(BaseConstants.ACCEPT, MediaType.APPLICATION_JSON_VALUE);//  "application/json"
            MultiValueMap<String, String> map= new LinkedMultiValueMap<String, String>();
            map.add(BaseConstants.API_GRANT_TYPE,BaseConstants.CLIENT_CREDENTIALS);
            map.add(BaseConstants.SCOPE, scope);
            javax.net.ssl.SSLContext  sslContext = getSSLContext();
            Registry<ConnectionSocketFactory> socketRegistry = RegistryBuilder.<ConnectionSocketFactory>create()
                    .register(URIScheme.HTTPS.getId(), new SSLConnectionSocketFactory(sslContext))
                    .register(URIScheme.HTTP.getId(), new PlainConnectionSocketFactory())
                    .build();
            HttpClient httpClient = HttpClientBuilder.create()
                    .setConnectionManager(new PoolingHttpClientConnectionManager(socketRegistry))
                    .setConnectionManagerShared(true)
                    .build();

            HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);

//            HttpClient client = HttpClients.custom().setSSLContext(sslContext).build();
////            HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
//            requestFactory.setHttpClient(client);
            RestTemplate restTemplate = new RestTemplate(requestFactory);
            ResponseEntity<String> response = restTemplate.exchange(gatewayTokenUrl, HttpMethod.POST, new HttpEntity<MultiValueMap<String, String>>(map, httpHeaders),   String.class);
            if(response.getStatusCode().is2xxSuccessful())
            {
                Object obj = new JSONParser().parse(response.getBody());
                JSONObject jo = (JSONObject) obj;
                String access_token = (String) jo.get("access_token");
                ObjectMapper objectMapper = new ObjectMapper();
                return access_token;
            }
            else
            {
                throw new ProcessException(BaseConstants.ERROR_TYPE_PROCESSING,BaseConstants.CLM_GENERIC_ERROR,"Error During Access Token Generation");
            }
        }
        catch(Exception ex)
        {
            System.out.println("exception block "+ex.getMessage());
            ex.printStackTrace();
            throw new ProcessException(BaseConstants.ERROR_TYPE_PROCESSING,BaseConstants.CLM_GENERIC_ERROR,"Error During Access Token Generation");
        }
    }

    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    public SSLContext getSSLContext() throws ProcessException, NoSuchAlgorithmException, KeyManagementException {
        KeyStore keyStore           = null;
        File keyFiles               = null;
        FileInputStream keyStream   = null;
        SSLContext sslcontext       = null;

        try
        {
            keyStore = KeyStore.getInstance("JKS");
            System.out.println("childHashMap.get(\"CONSUMER_API_JKS\") ::: "+ CountryConfig.getGatewayCountryParam("CONSUMER_API_JKS"));
            //keyFiles = new File(CountryConfig.getGatewayCountryParam("CONSUMER_API_JKS"));
            keyFiles = new File("C:\\Users\\8223073\\goldenversions\\setupforprojectcode\\globus.jks");
            keyStream = new FileInputStream(keyFiles);
            keyStore.load(keyStream,CountryConfig.getGatewayCountryParam("KEY_STREAM").trim().toCharArray());
            sslcontext = SSLContextBuilder
                    .create()
                    .loadTrustMaterial(keyFiles,CountryConfig.getGatewayCountryParam("KEY_SIGN").trim().toCharArray())
                    .loadKeyMaterial(keyStore,CountryConfig.getGatewayCountryParam("KEY_STORE_SIGN").trim().toCharArray())
                    .build();
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new ProcessException(BaseConstants.ERROR_TYPE_PROCESSING,BaseConstants.CLM_GENERIC_ERROR,"Error During SSLContext Preparation");
        }
        return sslcontext;
    }

    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    public ContactServerInfo contactServer(ContactServerInfo contactServerInfo,TravellingObject trObj) throws Exception {
        HttpsURLConnection connection = null;
        StringBuilder responseBuf = null;
        String freshToken = null;
        String token = null;
        int response = 0;
        OutputStream os = null;
        try {
            LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "contactServer", LogType.APPLICATION.name());

            log.println("Client Secret "+StartUpConfigurations.clientIdClientSecretMap.get(BaseConstants.CLIENT_ID) +"  --  "+ StartUpConfigurations.clientIdClientSecretMap.get(BaseConstants.CLIENT_SECRET));
            token = getAccessToken(trObj, contactServerInfo.getScope());
            log.println("Service URL : "+ contactServerInfo.getServiceUrl());
            log.println("Token found inside contactServer : "+ token+"] Scope ["+contactServerInfo.getScope()+"]");
            connection = getConnection(contactServerInfo.getServiceUrl(), token, contactServerInfo.getTrackingId(), contactServerInfo.getCountryCode(), contactServerInfo.getInterfaceId(), contactServerInfo.getProtocolMethod(), contactServerInfo.getScope(), contactServerInfo.getSrvEntity());
            if (contactServerInfo.getProtocolMethod().equalsIgnoreCase("POST")) {
                os = connection.getOutputStream();
                os.write(contactServerInfo.getRequestMessage().getBytes());
                os.flush();
            }

            response = connection.getResponseCode();
            log.println("Response Code : "+response);
            contactServerInfo.setHttpResponseCode(""+response);

            InputStream inputStream = null;
            boolean checkFlag= false;
            do
            {
                if (response == HttpStatus.SC_UNAUTHORIZED)
                {
                    freshToken = getAccessToken(trObj, contactServerInfo.getScope());
                    connection = getConnection(contactServerInfo.getServiceUrl(), freshToken,  contactServerInfo.getTrackingId(), contactServerInfo.getCountryCode(), contactServerInfo.getInterfaceId(), contactServerInfo.getProtocolMethod(), contactServerInfo.getScope(), contactServerInfo.getSrvEntity());
                    os = connection.getOutputStream();
                    os.write(contactServerInfo.getRequestMessage().getBytes());
                    os.flush();
                    response = connection.getResponseCode();
                    contactServerInfo.setHttpResponseCode(""+response);
                    checkFlag=true;
                }
                else if (response == HttpStatus.SC_BAD_REQUEST || response == HttpStatus.SC_INTERNAL_SERVER_ERROR || response >= 400)
                {
                    inputStream = connection.getErrorStream();
                    checkFlag=false;
                }
                else if (response >= 200 && response <=299)
                {
                    inputStream = connection.getInputStream();
                    checkFlag=false;
                }
            } while(checkFlag);

            BufferedReader in   =   new BufferedReader(new InputStreamReader(inputStream));
            responseBuf         =   new StringBuilder();

            String currentLine;
            while ((currentLine = in.readLine()) != null)
            {
                responseBuf.append(currentLine);
            }

            in.close();
            log.println("Actual API Response ::: "+responseBuf.toString());

            contactServerInfo.setResponseMessage(responseBuf.toString());

        } catch (Exception e) {
            /* e.printStackTrace(); */
            throw e;
        }

        return contactServerInfo;
    }


    /**
     * <Description>
     * <p>
     * <p>
     *
     * @param
     * @return
     * @exception
     * @see
     * @since
     */
    public HttpsURLConnection getConnection(String ip, String token, String trackingId, String countryCode, String interfaceId, String protocolMethod, String scope, NodeServicesEntity srvEntity) throws UnrecoverableKeyException
    {
        HttpsURLConnection connection = null;

        try
        {
            URL url = new URL(ip);
            connection = (HttpsURLConnection) url.openConnection();
            connection.setRequestMethod(protocolMethod);
            connection.setRequestProperty(BaseConstants.CONTENT_TYPE,"application/vnd.api+json; charset=utf-8");
            connection.setRequestProperty(BaseConstants.AUTHORIZATION_HEADER, "Bearer "+ token);

            if (scope.equalsIgnoreCase("ICMService"))
            {
                if(srvEntity != null && srvEntity.getNodeServicesMapper() != null) {
                    connection.setRequestProperty("cdd-suppress-indicator", ServiceParameterUtility.getParameter(srvEntity.getNodeServicesMapper(),"CDD","CDD_SUPPRESS_INDICATOR"));
                }
                connection.setRequestProperty(BaseConstants.API_HEADER_COUNTRYCODE, countryCode);
            }

            connection.setRequestProperty(BaseConstants.API_HEADER_TRANSACTION_ID, trackingId);
            connection.setRequestProperty(BaseConstants.API_HEADER_INTERFACE_ID, interfaceId);
            connection.setUseCaches (false);
            connection.setDoInput(true);
            connection.setDoOutput(true);
            javax.net.ssl.SSLContext  sslContext = getSSLContext();
            SSLSocketFactory factory = sslContext.getSocketFactory();
            connection.setSSLSocketFactory(factory);
        }
        catch(Exception e)
        {
            /* e.printStackTrace(); */
        }
        return connection;
    }

    /**
     * @return the hashicorpValutedProperties
     */
    public  HashMap<String, String> getHashicorpValutedProperties() {
        return hashicorpValutedProperties.get("GBL");
    }

    /**
     * @param hashicorpValutedProperties the hashicorpValutedProperties to set
     */
    public void setHashicorpValutedProperties(String companyId, HashMap<String, String> dbProperties) {
        this.hashicorpValutedProperties.put(companyId, dbProperties);
    }
    /**
     * @return the hashicorpValutedProperties
     */
    public String getHashicorpValutedProperties(String key) {
        return hashicorpValutedProperties.get("GBL").get(key) != null ? hashicorpValutedProperties.get("GBL").get(key).toString() : null;
    }

    public HashMap<String, HashMap<String, String>> getAllCountriesProperties() {
        return allCountriesProperties;
    }

    public HashMap<String, String> getAllCountriesProperties(String countryCode) {
        return getAllCountriesProperties().get(countryCode);
    }

    /**
     * @return the propertiesHash
     */
    public static HashMap<String, String> getPropertiesHash() {
        return propertiesHash;
    }

    public static String getPropertiesHash(String key) {
        return propertiesHash.get(key);
    }
    /**
     * @param propertiesHash the propertiesHash to set
     */
    public static void setPropertiesHash(HashMap<String, String> propertiesHash) {
        ApplicationConfiguration.propertiesHash = propertiesHash;
    }

    /**
     * @return the appLogPath
     */
    public String getAppLogPath() {
        return this.appLogPath;
    }

    /**
     * @param appLogPath the appLogPath to set
     */
    public void setAppLogPath(String appLogPath) {
        this.appLogPath = appLogPath;
    }
    /**
     * @return the defCompanyID
     */
    public String getDefCompanyID() {
        return defCompanyID;
    }
    /**
     * @param defCompanyID the defCompanyID to set
     */
    public void setDefCompanyID(String defCompanyID) {
        this.defCompanyID = defCompanyID;
    }
    /**
     * @return the defEnvID
     */
    public String getDefEnvID() {
        return defEnvID;
    }
    /**
     * @param defEnvID the defEnvID to set
     */
    public void setDefEnvID(String defEnvID) {
        this.defEnvID = defEnvID;
    }
    /**
     * @return the appConfigInstanceHash
     */
    public static HashMap<String, ApplicationConfiguration> getAppConfigInstanceHash() {
        return appConfigInstanceHash;
    }

    public HashMap<String, String> isPasswordRoated(String companyId) {

        HashMap<String, String> DBdetails  = getHashicorpValutedProperties();
        HashMap<String, String> HCDetails = null;
        //HashMap<String, String> countryProperties = allCountriesProperties.get(companyId);
        // System.out.println("For_Request :"+countryProperties+"Country Code:"+companyId);
        //System.out.println("DB:Properties:"+DBdetails);
        //System.out.println("CURRENT_PASSWORD_in_isPasswordRoated:"+DBdetails.get(UploadsConstants.PERSISTENCE_JDBC_PW));
        java.util.Date gmtDateOfNextRotation = null;
        LoggerUtil logger = LoggerUtil.getInstance(this.getClass(), BaseConstants.APPLICATION_NAME+"-"+System.getProperty("serviceName"),companyId);
        if(DBdetails.get("isHCEnabled")!=null && DBdetails.get("isHCEnabled").equals("Y")) {

            try {
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
                java.util.Date currentdate = new Date(System.currentTimeMillis());
                formatter.setTimeZone(TimeZone.getTimeZone("GMT+00:00"));
                java.util.Date gmtDateOfToday = formatter.parse(formatter.format(currentdate));

                if(DBdetails.get("HC_INVOKE_START_TIME")!=null){
                    gmtDateOfNextRotation = formatter.parse(DBdetails.get("HC_INVOKE_START_TIME"));
                    long difference_In_Time = gmtDateOfNextRotation.getTime() - gmtDateOfToday.getTime();
                    long differenceInMilliSeconds
                            = Math.abs(gmtDateOfToday.getTime() - gmtDateOfNextRotation.getTime());
                    long difference_In_Days
                            = (difference_In_Time
                            / (1000 * 60 * 60 * 24))
                            % 365;
                    long differenceInHours
                            = (differenceInMilliSeconds / (60 * 60 * 1000))
                            % 24;
                    System.out.println(differenceInHours);
                    long difference_In_Seconds = (difference_In_Time / 1000) % 60;
                    long difference_In_Minutes = (difference_In_Time / (1000 * 60)) % 60;
                    System.out.print('\r');
                    System.out.println("HashiCorp will initiate in : " +difference_In_Days +" Days: "+ differenceInHours + "Hours: "+ difference_In_Minutes + " min "
                            + difference_In_Seconds + " seconds");
                }

                if (DBdetails.get("HC_INVOKE_START_TIME")== null || (gmtDateOfToday != null && gmtDateOfToday.after(gmtDateOfNextRotation))) {
                    System.out.println("All_Details_Before_Rotate_Password :");
                    HCDetails = rotatePassword(companyId,DBdetails.get(BaseConstants.DB_PW));
                    if(HCDetails!=null && HCDetails.get("isPWDRotated")!=null && HCDetails.get("isPWDRotated").equals("Y")) {

                        DBdetails.put(BaseConstants.DB_PW, HCDetails.get("PWD"));
                        DBdetails.put("HC_INVOKE_START_TIME", HCDetails.get("HC_INVOKE_START_TIME"));
                        System.out.println("All_Details_After_Rotate_Password :");
                        //countriesDataSourceProperties.remove(companyId);
                        setHashicorpValutedProperties("GBL", DBdetails);
                        //countriesDataSourceProperties.put(companyId, DBdetails);
                        System.out.println("Killing Existing Session for :"+companyId);



                    }
                }

            }catch(Exception e)
            {
                logger.printErrorMessage(e);
                System.out.println("Exception in Dababase Manager :"+companyId);
            }
        }
        return DBdetails;
    }

    public synchronized HashMap<String, String> rotatePassword(String companyID,String password){

        HashMap<String, String> countryProperties = getHashicorpValutedProperties();
        LoggerUtil logger = LoggerUtil.getInstance(this.getClass(), BaseConstants.APPLICATION_NAME+"-"+System.getProperty("serviceName"),companyID);

        countryProperties.put("currentPassword", password);
        HashMap<String, String> HCDetails = null;
        countryProperties.put("companyID", companyID);

        try {
            // ADO Sonar fix 2873918
            HCDetails = HashiCorpImplementation.getDBPassword(countryProperties);

        }catch(Exception e)
        {
            logger.printErrorMessage(e);;
        }

        return HCDetails;
    }
}
