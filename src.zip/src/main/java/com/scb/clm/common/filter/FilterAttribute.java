package com.scb.clm.common.filter;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FilterAttribute{
	@JsonProperty("filter_input") 
    public String filter_input;

	public String getFilter_input() {
		return filter_input;
	}

	public void setFilter_input(String filter_input) {
		this.filter_input = filter_input;
	}
}

