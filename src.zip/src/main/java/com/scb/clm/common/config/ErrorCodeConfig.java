package com.scb.clm.common.config;

import java.util.HashMap;
import java.util.List;

import jakarta.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.clm.common.model.codesetup.ErrorCodesEntity;
import com.scb.clm.common.repository.ErrorCodesRepository;


@Service
public class ErrorCodeConfig 
{
    @Autowired 
    private ErrorCodesRepository errorCodesRepository;

    private static HashMap<String,ErrorCodesEntity> errorCodeMap = new HashMap<String,ErrorCodesEntity>();

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    @PostConstruct
    public void loadErrorConfig()
    {
        
        System.out.println("*****************************************************************");
        System.out.println("*              INITIALIZING ERROR CONFIGURATIONS                *");
        System.out.println("*****************************************************************\n");
        List<ErrorCodesEntity> errorCodes = errorCodesRepository.findAll();

        for(ErrorCodesEntity errorCodesEntity : errorCodes)
        {
            errorCodeMap.put(errorCodesEntity.getId().getCountryCode()+errorCodesEntity.getId().getErrorCode(), errorCodesEntity);
        }
        System.out.println("[Total Error Codes Loaded ] : ["+errorCodeMap.size()+"]");
    }   

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    public static int getHttpStatus(String countryCode,String errorCode,String errorType)
    {
        int httpStatus      = BaseConstants.HTTP_500;
        int configuredCode  = 0;
        try
        {
            configuredCode = Integer.parseInt(errorCodeMap.get(countryCode+errorCode).getHttpStatus());

            System.out.println("Searching Code Configured in Database For Country Code ["+countryCode+"] Error Code ["+errorCode+"] Http Code ["+configuredCode+"]");

            if(configuredCode >0) 
            {
                httpStatus = configuredCode;
            }
        }
        catch(Exception e)
        {
            //N.A
        }

        if(errorType!=null && configuredCode == 0)
        {
            if(errorType.equals(BaseConstants.ERROR_TYPE_TECHNICAL))
            {
                httpStatus = BaseConstants.HTTP_500;
            } else {
                httpStatus = BaseConstants.HTTP_400;
            }
        }

        return httpStatus;
    }
}
