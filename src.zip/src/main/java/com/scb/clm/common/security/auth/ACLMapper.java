package com.scb.clm.common.security.auth;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;

import org.springframework.core.io.ClassPathResource;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.util.JSONUtility;

public class ACLMapper 
{
    static HashMap<String ,ACLMapper>  aclInstanceMap = new HashMap<String ,ACLMapper>();

    static HashMap<String ,ACLRoot> aclObject = new HashMap<>() ;     
    
    public static synchronized ACLRoot getInstance(String countryCode) throws Exception 
    {
        try
        { 
            if(aclInstanceMap.get(countryCode) == null)
            {
                ACLMapper obj = new ACLMapper();  
                aclInstanceMap.put(countryCode, obj);
                initForACL(countryCode);
            }
        }
        catch(Exception exce)
        {
        	System.out.print("Error in #ACLMapper# #getInstance#");
            throw exce;
        }
        return aclObject.get(countryCode);
    }

    public static void initForACL(String countryCode) throws Exception
    {
        try
        {
			if(countryCode != null) {
            System.out.println("GlobusApplication.companyId : "+ countryCode);
            File file = new ClassPathResource("/"+countryCode+"_acl.json").getFile();
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            String line = "";
            StringBuffer strbuf = new StringBuffer();
            while((line = br.readLine()) != null) {
                System.out.println(line);
                strbuf.append(line);
            }
            ACLRoot root = (ACLRoot) JSONUtility.jsonTODomainWrapper(strbuf.toString(), ACLRoot.class);
            aclObject.put(countryCode,root);

            System.out.println("AclObject  : "+aclObject);
			}
        }
        catch(FileNotFoundException fnF)
        {
        	System.out.print("Error in #ACLMapper# #aclInstanceMap#");

            throw fnF;
        }
        catch(Exception e)
        {
        	System.out.print("Error in #ACLMapper# #aclInstanceMap#");

            throw e;
        }
    }
}
