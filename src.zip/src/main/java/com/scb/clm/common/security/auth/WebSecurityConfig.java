package com.scb.clm.common.security.auth;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.filter.CharacterEncodingFilter;

import com.scb.clm.common.config.SecurityConfigProp;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
@Import(SecurityConfigProp.class)

public class WebSecurityConfig {
	@Autowired
	SecurityConfigProp securityConfig;

	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		System.out.println("securityFilterChain:");
		Map<String, List<String>> urlPatterns = securityConfig.getUrl();

		http.csrf(AbstractHttpConfigurer::disable).authorizeHttpRequests(authorizationManagerRequestMatcherRegistry -> {
			urlPatterns.forEach((method, urls) -> {
				HttpMethod httpMethodType = getHttpMethodType(method);
				for (String url : urls) {
					if(!"".equals(url.strip())){
						authorizationManagerRequestMatcherRegistry.requestMatchers(httpMethodType, url.strip())
						.permitAll();
					}
				}
			});
			authorizationManagerRequestMatcherRegistry.anyRequest().authenticated();
		});
		return http.build();
	}

	@Bean
	public WebSecurityCustomizer webSecurityCustomizer() {
		System.out.println("Inside webSecurityCustomizer HealthCheck");
		return (web) -> web.ignoring().requestMatchers("/HealthCheck.jsp");
	}

	@Bean
	public CharacterEncodingFilter characterEncodingFilter() {
		CharacterEncodingFilter filter = new CharacterEncodingFilter();
		filter.setEncoding("UTF-8");
		filter.setForceEncoding(true);
		return filter;
	}

	private HttpMethod getHttpMethodType(String method) {
		HttpMethod type = null;
		if (HttpMethod.GET.name().equalsIgnoreCase(method)) {
			type = HttpMethod.GET;
		} else if (HttpMethod.POST.name().equalsIgnoreCase(method)) {
			type = HttpMethod.POST;
		} else if (HttpMethod.PATCH.name().equalsIgnoreCase(method)) {
			type = HttpMethod.PATCH;
		} else if (HttpMethod.DELETE.name().equalsIgnoreCase(method)) {
			type = HttpMethod.DELETE;
		} else if (HttpMethod.PUT.name().equalsIgnoreCase(method)) {
			type = HttpMethod.PUT;
		}
		return type;
	}
}
