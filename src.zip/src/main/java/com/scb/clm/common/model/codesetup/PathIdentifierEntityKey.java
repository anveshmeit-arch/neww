package com.scb.clm.common.model.codesetup;

import java.io.Serializable;
import java.util.Objects;
import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

/*
 * 
 *  @author      1378958
 *  @version     1.0
 *  @since          
 *  @use         
 */
@Embeddable
public class PathIdentifierEntityKey implements Serializable 
{

    @Column(name = "COUNTRY_CODE")
    private String countryCode;

    @Column(name = "PATH_IDENTIFIER")
    private String pathIdentifier;

    public PathIdentifierEntityKey() {}

    public PathIdentifierEntityKey(String countryCode, String pathIdentifier) {
        this.countryCode = countryCode;
        this.pathIdentifier = pathIdentifier;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getPathIdentifier() {
        return pathIdentifier;
    }

    public void setPathIdentifier(String pathIdentifier) {
        this.pathIdentifier = pathIdentifier;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PathIdentifierEntityKey that = (PathIdentifierEntityKey) o;
        return Objects.equals(countryCode, that.countryCode) &&
               Objects.equals(pathIdentifier, that.pathIdentifier);
    }

    @Override
    public int hashCode() {
        return Objects.hash(countryCode, pathIdentifier);
    }
}
