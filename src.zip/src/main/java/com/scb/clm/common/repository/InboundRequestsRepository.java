package com.scb.clm.common.repository;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.scb.clm.common.model.transactions.InboundRequestsEntity;

@Repository
public interface InboundRequestsRepository extends JpaRepository<InboundRequestsEntity, String> { 

    @Override
    public <S extends InboundRequestsEntity> S save(S entity);

    @Override
    public <S extends InboundRequestsEntity> S saveAndFlush(S entity);

    @Override
    public InboundRequestsEntity getOne(String arg0);

    public List<InboundRequestsEntity> findAll();

    @Query(value = "SELECT INBOUND_REQ_SEQUENCE.nextval FROM DUAL", nativeQuery = true)
    public BigDecimal getOracleInboundSequenceNumber();

    @Query(value = "SELECT NEXTVAL('inbound_req_sequence')", nativeQuery = true)
    public BigDecimal getPostgresInboundSequenceNumber();

}