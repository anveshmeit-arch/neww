package com.scb.clm.common.model.transactions;

public interface LoggerInterface {

}
