package com.scb.clm.common.security.auth;


import java.util.ArrayList;
import java.util.List;

import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;

import com.sc.rpbwm.auth.BearerToken;

@Component
public class JwtAuthenticationProvider implements AuthenticationProvider 
{

    @Override
    public boolean supports(Class<?> authentication) 
    {
        return (JwtAuthenticationToken.class.isAssignableFrom(authentication));
    }

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException 
    {
        return authentication instanceof JwtAuthenticationToken ?
                getJwtAuthentication(((JwtAuthenticationToken) authentication).getBearerToken()) : null;
    }

    @SuppressWarnings("unused")
    private Authentication getJwtAuthentication(BearerToken token) 
    {
        List<GrantedAuthority> authorities =  new ArrayList<>();
        authorities.add(new SimpleGrantedAuthority("NON_IMP_USER"));
        return new JwtAuthenticationToken(authorities,token);
    }
}
