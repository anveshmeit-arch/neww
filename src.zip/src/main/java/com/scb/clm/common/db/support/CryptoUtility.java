package com.scb.clm.common.db.support;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class CryptoUtility {
	
	static CryptoUtility cryptoValidator = null;
	
	
	
	public static CryptoUtility getInstance() throws Exception 
	
	{
		
		if (cryptoValidator == null)
		{
			cryptoValidator = new CryptoUtility();
		}
		return cryptoValidator;
	}
	
	
	public  boolean chkFileAndFolderStatus(String FileName,String companyID) throws Exception
	{
		
		boolean isFolderAvail = false;
		
		try{
		
		File folder = new File(CryptoParameters.getInstance().getKeyFilesLoca() + CryptoParameters.getInstance().getCompanyID() +"/");
	
		File[] listOfFiles = folder.listFiles();
		
		if(checkDirStatus(folder) && listOfFiles != null && listOfFiles.length > 0)
		{
			
	    for (int i = 0; i < listOfFiles.length; i++) {
	    	
	      if (listOfFiles[i].isFile()) {
	     
	        if(listOfFiles[i].getName().trim().equals(FileName))
	    	  {
	    			        	
	    		  if(getReplaceConfirmation(FileName).equalsIgnoreCase("Y"))
	    		  {
	    			
	    			  isFolderAvail = true;
	    		  }
	    		  else
	    		  {
	    			System.out.println("");
					System.out.println("");
					System.out.println("");
					System.out.println("Operation Cancelled. Please Try Again Later");
	    		//	System.exit(0); //Commented for Sonoa Fix
	    		  }
	    		  
	    	  }
	        else
	        {
	        	isFolderAvail = true;
	        }
	      } 
	     
	     
	      }
		}else
		{
		
			isFolderAvail =  true;
		}
	    
		}catch(Exception e)
		{
			e.printStackTrace();
			throw new Exception(e);
			
			
		}
		     
	  return isFolderAvail;
	}
	
	public String getReplaceConfirmation(String flName) throws IOException
	
	{
		 String confirmStatus = null;		
		
	    System.out.println("");
	    	
			//confirmStatus = br.readLine();
	    confirmStatus = "Y";
			
			
			
		
		return confirmStatus;
	}
	
	
	public boolean checkDirStatus(File folder) throws Exception
	
	{
		
		return true;
	}
	
public void writeIntoFile(String FileName,byte[] dataByts) throws Exception
	
	{
		try
		{
		
		FileOutputStream foStream = null;
		foStream = new FileOutputStream(FileName);
	    ByteArrayOutputStream oStream = new ByteArrayOutputStream();
		oStream.write(dataByts);
		oStream.writeTo(foStream);
		oStream.close();
		foStream.close();
		
		}catch(Exception exe)
		{
			exe.printStackTrace();
			throw exe;
		   
	    }
	
	}


public byte [] readKeysFromFile(String FileName) throws Exception

{
	InputStream in = null;
	ByteArrayOutputStream baos = null;

	
	try {

		  File file = new File(FileName);
		  in = new FileInputStream(file);
		  baos = new ByteArrayOutputStream();
		  byte[] buf = new byte[(int) file.length()];
		  boolean done=false;
		  while (!done) {
		  int amtRead = in.read(buf);
		  if (amtRead == -1) {
		  done = true; 
		  } else {
		  baos.write(buf, 0, amtRead);
		  }
		  }
		  return baos.toByteArray();
		 
	}catch (Exception exe) {
		exe.printStackTrace();
		throw exe;
	}
	finally {
		if(baos!=null) {
			baos.close();
		}
		if(in!=null)
		{
			in.close();
		}
	}

}

}
