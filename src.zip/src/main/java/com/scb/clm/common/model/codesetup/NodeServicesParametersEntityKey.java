package com.scb.clm.common.model.codesetup;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

/*
 * 
 * @author       1378958
 * @version      1.0
 * @since           
 * @use          
 */
@Embeddable
public class NodeServicesParametersEntityKey implements Serializable,Cloneable
{

    private static final long serialVersionUID = 7718500301252020026L;

    @Column(name = "COUNTRY_CODE", nullable = false ,insertable=false, updatable=false)
    private String countryCode;

    @Column(name = "FLOW_ID", nullable = false ,insertable=false, updatable=false)
    private String flowIdentifier;

    @Column(name = "NODE_ID", nullable = false ,insertable=false, updatable=false)
    private String nodeIdentifier;

    @Column(name = "SERVICE_ID", nullable = false ,insertable=false, updatable=false)
    private String serviceIdentifier;

    @Column(name = "PARAM_GROUP", nullable = false ,insertable=false, updatable=false)
    private String parameterGroup;

    @Column(name = "PARAM_SEQUENCE", nullable = false ,insertable=false, updatable=false)
    private String parameterSequence;

    public NodeServicesParametersEntityKey() {

    }

    public NodeServicesParametersEntityKey (String countryCode,String flowIdentifier,String nodeIdentifier,String serviceIdentifier,String parameterGroup,String parameterSequence){
        this.countryCode  = countryCode;
        this.flowIdentifier       = flowIdentifier;
        this.nodeIdentifier       = nodeIdentifier;
        this.serviceIdentifier    = serviceIdentifier;
        this.parameterGroup       = parameterGroup;
        this.parameterSequence    = parameterSequence;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getFlowIdentifier() {
        return flowIdentifier;
    }

    public void setFlowIdentifier(String flowIdentifier) {
        this.flowIdentifier = flowIdentifier;
    }

    public String getNodeIdentifier() {
        return nodeIdentifier;
    }

    public void setNodeIdentifier(String nodeIdentifier) {
        this.nodeIdentifier = nodeIdentifier;
    }

    public String getServiceIdentifier() {
        return serviceIdentifier;
    }

    public void setServiceIdentifier(String serviceIdentifier) {
        this.serviceIdentifier = serviceIdentifier;
    }

    public String getParameterGroup() {
        return parameterGroup;
    }

    public void setParameterGroup(String parameterGroup) {
        this.parameterGroup = parameterGroup;
    }

    public String getParameterSequence() {
        return parameterSequence;
    }

    public void setParameterSequence(String parameterSequence) {
        this.parameterSequence = parameterSequence;
    }

    @Override
    public int hashCode() {
        StringBuilder finalHashCode = new StringBuilder();
        if (this.countryCode != null && this.flowIdentifier != null
                && this.nodeIdentifier != null && this.serviceIdentifier != null 
                && this.parameterGroup!=null
                && this.parameterSequence!=null)
        {
            finalHashCode.append(countryCode);
            finalHashCode.append(flowIdentifier);
            finalHashCode.append(nodeIdentifier);
            finalHashCode.append(serviceIdentifier);
            finalHashCode.append(parameterGroup);
            finalHashCode.append(parameterSequence);
        }
        return finalHashCode.toString().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) 
        {
            return true;
        }
        if ((obj == null) || (obj.getClass() != this.getClass())) 
        {
            return false;
        }
        NodeServicesParametersEntityKey other = (NodeServicesParametersEntityKey) obj;
        return   Objects.equals(this.countryCode, other.countryCode) 
                && Objects.equals(this.flowIdentifier, other.flowIdentifier)
                && Objects.equals(this.nodeIdentifier, other.nodeIdentifier) 
                && Objects.equals(this.serviceIdentifier, other.serviceIdentifier) 
                && Objects.equals(this.parameterGroup, other.parameterGroup)
                && Objects.equals(this.parameterSequence,other.parameterSequence);
    }

    @Override
    public Object clone() {
        try {
            return (NodeServicesParametersEntityKey) super.clone();
        } catch (CloneNotSupportedException e) {
            return new NodeServicesParametersEntityKey(this.getCountryCode(),this.getFlowIdentifier(),this.getNodeIdentifier(),this.getServiceIdentifier(),this.getParameterGroup(),this.getParameterSequence());
        }
    }
}



