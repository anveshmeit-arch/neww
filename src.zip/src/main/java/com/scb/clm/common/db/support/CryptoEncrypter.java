package com.scb.clm.common.db.support;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;


public class CryptoEncrypter
{
  private static CryptoEncrypter encrytPWD = null;

  public static CryptoEncrypter getInstance() throws Exception
  {
    if (encrytPWD == null)
    {
      encrytPWD = new CryptoEncrypter();
    }

    return encrytPWD;
  }

  
  public void encyptDBPwd(String appID, String companyID, String pwd,String cryptoPath)
    throws Exception
  {
    CryptoParameters.getInstance().setCompanyID(companyID);
    CryptoParameters.getInstance().setApplicationID(appID);
    FileInputStream localFileInputStream =null;
    try
    {
      KeyReader localKeyReader = new KeyReader();
      byte[] arrayOfByte1 = localKeyReader.decryptKeyStorePwd(CryptoParameters.getInstance().getCompanyID());
      String str = new String(arrayOfByte1);

      CryptoParameters.getInstance().setFileName(CryptoParameters.getInstance().getKeyFilesLoca() + CryptoParameters.getInstance().getCompanyID() + "/StoreKeys.jck");

      localFileInputStream = new FileInputStream(CryptoParameters.getInstance().getFileName());
      KeyStore localKeyStore = KeyStore.getInstance(CryptoParameters.getInstance().getKeyStroreAlgName(), CryptoParameters.getInstance().getProviderClassName());
      localKeyStore.load(localFileInputStream, str.toCharArray());

      Certificate localCertificate = localKeyStore.getCertificate("PrivateKeys");
      PublicKey localPublicKey = localCertificate.getPublicKey();

      Cipher localCipher = Cipher.getInstance(CryptoParameters.getInstance().getASymentickeyAlgName(), CryptoParameters.getInstance().getProviderClassName());

      localCipher.init(1, localPublicKey);

      byte[] arrayOfByte2 = pwd.getBytes();
      byte[] arrayOfByte3 = localCipher.doFinal(arrayOfByte2);

      CryptoParameters.getInstance().setFileName(CryptoParameters.getInstance().getKeyFilesLoca() + CryptoParameters.getInstance().getCompanyID() + "/" + CryptoParameters.getInstance().getApplicationID() + "_EncyPwd.key");

      if (!CryptoUtility.getInstance().chkFileAndFolderStatus(CryptoParameters.getInstance().getApplicationID() + "_EncyPwd.key", CryptoParameters.getInstance().getCompanyID()))
      {
        //System.exit(0);
    	  System.out.println("Existed");
      }

      CryptoUtility.getInstance().writeIntoFile(CryptoParameters.getInstance().getFileName(), arrayOfByte3);

      System.out.println(CryptoParameters.getInstance().getApplicationID() + " DB Password Encrypted Successfully And File Are Stored In " + CryptoParameters.getInstance().getKeyFilesLoca() + CryptoParameters.getInstance().getCompanyID());
      System.out.println();
      System.out.println();
     
    }
    catch (Exception localException)
    {
      localException.printStackTrace();

      if ((localException instanceof InvalidKeyException))
        throw new InvalidKeyException(localException);
      if ((localException instanceof NoSuchAlgorithmException))
        throw new NoSuchAlgorithmException(localException);
      if ((localException instanceof NoSuchProviderException))
        throw new NoSuchProviderException(localException.getMessage());
      if ((localException instanceof KeyStoreException))
        throw new KeyStoreException(localException);
      if ((localException instanceof IllegalBlockSizeException))
        throw new IllegalBlockSizeException(localException.getMessage());
      if ((localException instanceof BadPaddingException))
        throw new BadPaddingException(localException.getMessage());
      if ((localException instanceof FileNotFoundException))
        throw new FileNotFoundException(localException.getMessage());
      if ((localException instanceof IOException))
        throw new IOException(localException.getMessage());
      if ((localException instanceof KeyStoreException))
        throw new KeyStoreException(localException);
      if ((localException instanceof CertificateException))
        throw new CertificateException(localException);
      if ((localException instanceof NoSuchPaddingException)) {
        throw new NoSuchPaddingException(localException.getMessage());
      }
      throw new Exception(localException);
    }
    finally {
		if(localFileInputStream!=null)
		{
			localFileInputStream.close();
		}
	}
  }
  
  public static void encyptHCDBPwd(String appID, String companyID, String pwd,String cryptoPath)
		    throws Exception
		  {
			CryptoParameters.initCrypto(cryptoPath);
		    CryptoParameters.getInstance().setCompanyID(companyID);
		    CryptoParameters.getInstance().setApplicationID(appID);
		    FileInputStream localFileInputStream = null;
		    try
		    {
		      KeyReader localKeyReader = new KeyReader();
		      byte[] arrayOfByte1 = localKeyReader.decryptKeyStorePwd(CryptoParameters.getInstance().getCompanyID());
		      String str = new String(arrayOfByte1);

		      CryptoParameters.getInstance().setFileName(CryptoParameters.getInstance().getKeyFilesLoca() + CryptoParameters.getInstance().getCompanyID() + "/StoreKeys.jck");

		      localFileInputStream = new FileInputStream(CryptoParameters.getInstance().getFileName());
		      KeyStore localKeyStore = KeyStore.getInstance(CryptoParameters.getInstance().getKeyStroreAlgName(), CryptoParameters.getInstance().getProviderClassName());
		      localKeyStore.load(localFileInputStream, str.toCharArray());

		      Certificate localCertificate = localKeyStore.getCertificate("PrivateKeys");
		      PublicKey localPublicKey = localCertificate.getPublicKey();

		      Cipher localCipher = Cipher.getInstance(CryptoParameters.getInstance().getASymentickeyAlgName(), CryptoParameters.getInstance().getProviderClassName());

		      localCipher.init(1, localPublicKey);

		      byte[] arrayOfByte2 = pwd.getBytes();
		      byte[] arrayOfByte3 = localCipher.doFinal(arrayOfByte2);

		      CryptoParameters.getInstance().setFileName(CryptoParameters.getInstance().getKeyFilesLoca() + CryptoParameters.getInstance().getCompanyID() + "/" + CryptoParameters.getInstance().getApplicationID() + "_EncyPwd.key");

		      if (!CryptoUtility.getInstance().chkFileAndFolderStatus(CryptoParameters.getInstance().getApplicationID() + "_EncyPwd.key", CryptoParameters.getInstance().getCompanyID()))
		      {
		    	  System.out.println("Existed");
		      }

		      CryptoUtility.getInstance().writeIntoFile(CryptoParameters.getInstance().getFileName(), arrayOfByte3);

		      System.out.println(CryptoParameters.getInstance().getApplicationID() + " DB Password Encrypted Successfully And File Are Stored In " + CryptoParameters.getInstance().getKeyFilesLoca() + CryptoParameters.getInstance().getCompanyID());
		      System.out.println();
		      System.out.println();
		    }
		    catch (Exception localException)
		    {
		      localException.printStackTrace();

		      if ((localException instanceof InvalidKeyException))
		        throw new InvalidKeyException(localException);
		      if ((localException instanceof NoSuchAlgorithmException))
		        throw new NoSuchAlgorithmException(localException);
		      if ((localException instanceof NoSuchProviderException))
		        throw new NoSuchProviderException(localException.getMessage());
		      if ((localException instanceof KeyStoreException))
		        throw new KeyStoreException(localException);
		      if ((localException instanceof IllegalBlockSizeException))
		        throw new IllegalBlockSizeException(localException.getMessage());
		      if ((localException instanceof BadPaddingException))
		        throw new BadPaddingException(localException.getMessage());
		      if ((localException instanceof FileNotFoundException))
		        throw new FileNotFoundException(localException.getMessage());
		      if ((localException instanceof IOException))
		        throw new IOException(localException.getMessage());
		      if ((localException instanceof KeyStoreException))
		        throw new KeyStoreException(localException);
		      if ((localException instanceof CertificateException))
		        throw new CertificateException(localException);
		      if ((localException instanceof NoSuchPaddingException)) {
		        throw new NoSuchPaddingException(localException.getMessage());
		      }
		      throw new Exception(localException);
		    }
		    finally {
				if(localFileInputStream!=null)
				{
					localFileInputStream.close();
				}
		  }
  
}
}