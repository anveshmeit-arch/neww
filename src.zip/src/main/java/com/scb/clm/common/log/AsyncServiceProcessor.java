package com.scb.clm.common.log;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.model.codesetup.NodeServicesEntity;
import com.scb.clm.common.model.transactions.ServiceStatus;
import com.scb.clm.common.model.transactions.TravellingObject;
import com.scb.clm.common.util.DateTimeUtility;
import com.scb.clm.common.util.ModuleContextManager;
import com.scb.clm.common.util.ServiceContextCache;
import com.scb.clm.core.service.DynamicAutowireService;

@Service
public class AsyncServiceProcessor
{

    @Autowired
    DynamicAutowireService dynamicAutowireService;

    @Autowired
    DatabaseLogger databaseLogger;
    
    
    LoggerUtil log = null;
    /**
     *
     *
     * @param
     * @return 
     * @exception
     * @see
     * @since 
     */
    @Async("ServiceQueue")
    public void execute(TravellingObject travelObj,NodeServicesEntity nodeServicesEntity)
    {
        ServiceStatus serviceStatus = new ServiceStatus(
                nodeServicesEntity.getId().getFlowIdentifier(),
                nodeServicesEntity.getId().getNodeIdentifier(),
                nodeServicesEntity.getId().getServiceIdentifier());
        try
        {
            System.out.println("[ProcessAsyncService] ");
            travelObj.setFlowIdentifier(nodeServicesEntity.getId().getFlowIdentifier());
            travelObj.getServiceContext().setServiceType(nodeServicesEntity.getId().getFlowIdentifier());
            ServiceContextCache.getInstance().createProviderContext(travelObj.getServiceContext());
            log = LoggerUtil.getInstance(System.getProperty("serviceName"), AsyncServiceProcessor.class.getName(), "execute", LogType.APPLICATION.name());
            log.println("ProcessAsyncService Started");
            serviceStatus.setRequestTime(DateTimeUtility.getTimeByCountryCode(travelObj.getCountryCode())); 
            serviceStatus = dynamicAutowireService.execute(travelObj, nodeServicesEntity);
            serviceStatus.setResponseTime(DateTimeUtility.getTimeByCountryCode(travelObj.getCountryCode())); 
        }
        catch(Exception e)
        {
            serviceStatus.setStatus(BaseConstants.SERVICE_FAILURE);
            log.printErrorMessage(e);
        }
        finally
        {
        	log.println("ProcessAsyncService Ended");
            try {
                if(nodeServicesEntity.getLogTime()!=null && nodeServicesEntity.getLogTime().equalsIgnoreCase("Y")) 
                {
                    databaseLogger.construcOutboundLog(travelObj,serviceStatus,nodeServicesEntity);
                } 
                else 
                {
                    log.println("Database Logging Not Enabled for Service "+nodeServicesEntity.getId().getCountryCode()+"-"+nodeServicesEntity.getId().getFlowIdentifier()+"-"+nodeServicesEntity.getId().getNodeIdentifier()+"-"+nodeServicesEntity.getId().getServiceIdentifier());
                }
            }
            catch (Exception e) {
            	log.printErrorMessage(e);
            }
            ModuleContextManager.getModuleContext().removeModuleCache();
        }
    }
}