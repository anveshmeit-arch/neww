package com.scb.clm.common.model.transactions;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

/*
 * 
 * @author       1378958
 * @version      1.0
 * @since           
 * @use          
 */
@Embeddable
public class OutboundRequestsErrorsEntityKey implements Serializable,Cloneable
{

    private static final long serialVersionUID = 5749586117488357622L;

    @Column(name = "REQUEST_ID", nullable = false ,insertable=false, updatable=false)
    private String requestId;

    @Column(name = "SEQUENCE_NUMBER", nullable = false ,insertable=false, updatable=false)
    private String sequenceNumber;

    public OutboundRequestsErrorsEntityKey() {

    }

    public OutboundRequestsErrorsEntityKey (String requestId,String sequenceNumber) {
        this.requestId         =     requestId;
        this.sequenceNumber    =     sequenceNumber;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getSequenceNumber() {
        return sequenceNumber;
    }

    public void setSequenceNumber(String sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    @Override
    public int hashCode() {
        StringBuilder finalHashCode = new StringBuilder();
        if (this.requestId != null && this.sequenceNumber != null)
        {
            finalHashCode.append(requestId);
            finalHashCode.append(sequenceNumber);
        }
        return finalHashCode.toString().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
        {
            return true;
        }
        if ((obj == null) || (obj.getClass() != this.getClass())) 
        {
            return false;
        }
        OutboundRequestsErrorsEntityKey other = (OutboundRequestsErrorsEntityKey) obj;
        return   Objects.equals(this.requestId, other.requestId) 
                && Objects.equals(this.sequenceNumber, other.sequenceNumber);
    }

    @Override
    public Object clone() throws CloneNotSupportedException 
    {
        return (OutboundRequestsErrorsEntityKey) super.clone();
    }
}
