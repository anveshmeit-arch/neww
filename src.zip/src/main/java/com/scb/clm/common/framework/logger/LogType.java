package com.scb.clm.common.framework.logger;

public enum LogType {
    APPLICATION, ERROR, SYSTEM, TRANSACTION, SECURITY, AUDIT,CONSOLE
}
