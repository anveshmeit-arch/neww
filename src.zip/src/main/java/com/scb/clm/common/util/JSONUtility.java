package com.scb.clm.common.util;

import java.util.List;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.clm.common.exception.ErrorObject;

/*
 * 
 *  @author     1378958 
 *  @version    1.0
 *  @since         
 *  @use        
 */
public class JSONUtility {

    /**
     * Returns    
     * @param          
     * @return          
     * @exception     
     * @see
     * @since         
     */    
    public static <T> Object jsonTODomainWrapper(Object nativeLogonReqMsg,Class<T> domainWrapperName)
    {
        ObjectMapper mapper        =    new ObjectMapper();
        Object domainWrapper    =    null;
        try 
        {
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            domainWrapper = mapper.readValue(nativeLogonReqMsg.toString(),domainWrapperName);
            return domainWrapper;
        } catch (Exception e) {
            System.out.println("Error Inside jsonTODomainWrapper::domainWrapperClassName="+domainWrapperName+"::Exception"+e);
        }
        return domainWrapper;
    }

    /**
     * Returns    
     * @param          
     * @return          
     * @exception     
     * @see
     * @since         
     */    
    public static <T> Object domainWrapperToJSON(Object nativeLogonResMsg,Class<T> domainWrapperClassName) {
        ObjectMapper mapper = new ObjectMapper();
        Object jsonResponse = null;
        try 
        {
            jsonResponse = mapper.writeValueAsString(nativeLogonResMsg);            
        } catch (Exception e) {
            System.out.println("Error Inside domainWrapperToJSON::domainWrapperClassName="+domainWrapperClassName+"::Exception"+e);
        }
        return jsonResponse;
    }

    /**
     * Returns    
     * @param          
     * @return          
     * @exception     
     * @see
     * @since        April 2020
     */    
    public static <T> Object jsonToListOfDomainWrapper(Object jsonDomainMsg,Class<T> domainWrapperClassName)
    {
        ObjectMapper mapper     = new ObjectMapper();
        Object domainWrapper     = null;
        try 
        {
            domainWrapper =  mapper.readValue(jsonDomainMsg.toString(), mapper.getTypeFactory().constructCollectionType(List.class, domainWrapperClassName));                        
        } catch (Exception e) {
            System.out.println("Exception for # JSONUtility # jsonToListOfDomainWrapper # Exception # "+e.getLocalizedMessage()+" / "+e.getMessage());
            System.out.println("Error Inside jsonToListOfDomainWrapper::domainWrapperClassName="+domainWrapperClassName+"::Exception"+e);
        }
        return domainWrapper;
    }

    /**
     * Returns    
     *  
     * @param          
     * @return          
     * @exception     
     * @see
     * @since       
     */    
    public static String constructNativeExceptionMessage(List<ErrorObject> errorList) 
    {
        return (String) JSONUtility.domainWrapperToJSON(errorList,ErrorObject.class);
    }    

    /**
     * Returns    
     *  
     * @param          
     * @return          
     * @exception     
     * @see
     * @since         
     */    
    public static String constructNativeExceptionMessage(ErrorObject errorList) 
    {
        return (String) JSONUtility.domainWrapperToJSON(errorList,ErrorObject.class);
    }    

    /**
     * Returns    
     *  
     * @param          
     * @return          
     * @exception     
     * @see
     * @since        
     */    
    public static <T> Object domainWrapperToJSON(Object nativeLogonResMsg) 
    {
        ObjectMapper mapper = new ObjectMapper();
        Object jsonResponse = null;
        try 
        {
            jsonResponse = mapper.writeValueAsString(nativeLogonResMsg);            
        } 
        catch (Exception e) 
        {
            System.out.println("Exception for # JSONUtility # jsonTODomainWrapper #  # "+e.getLocalizedMessage()+" / "+e.getMessage());          
        }
        return jsonResponse;
    }
}
