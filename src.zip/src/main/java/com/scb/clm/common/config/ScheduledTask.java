package com.scb.clm.common.config;

import java.util.List;
import java.util.TimerTask;

import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;

public class ScheduledTask extends TimerTask 
{
    
    int maxTries            = 3;
    static boolean flag     = false;

    public void run()
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "run", LogType.APPLICATION.name());         
        List<String> regions = CountryConfig.getSystemDefaultGroups("COUNTRY_REGIONS");
        log.println("Regions " + (regions==null?null:regions.toString()));
        loadDefaultRegionData();

        if(regions!=null && regions.size() >0)
        {
            log.println("Loading Regions Data" + regions);
            for(String region : regions) 
            {
                log.println("Loading Keys for Regions " + region);                
                loadRegionData(region);
            }
        }

    }

    void loadDefaultRegionData() 
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "loadDefaultRegionData", LogType.APPLICATION.name());         
        int count=0;

        while(!flag && (++count < maxTries))
        {
            if (StartUpConfigurations.clientIdClientSecretMap.get("client_id") != null && StartUpConfigurations.clientIdClientSecretMap.get("client_secret") !=null)
            {
                log.println("ScheduledTask - Secret ID For Default Region Obtained "+StartUpConfigurations.clientIdClientSecretMap);
                flag = true;    
            } 
            else
            {
                try
                {
                    log.println("ScheduledTask - Loading Client Id Secret Id [Default]");
                    ApplicationConfiguration.getInstance().loadClientIdClientSecret(null);
                    log.println("ScheduledTask - Generated Client Id Secret Id [Default]");
                } 
                catch (Exception e) 
                {
                	log.printErrorMessage(e);
                }
            }
        }
    }

    void loadRegionData (String region)
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "loadRegionData", LogType.APPLICATION.name());         
        boolean flag = false;
        int count=0;
        log.println("ScheduledTask - Starting Secret ID Generation for Region ["+region+"]");
        while(!flag && (++count < maxTries))
        {
            if (StartUpConfigurations.clientIdClientSecretMap.get(region+"client_id") != null && StartUpConfigurations.clientIdClientSecretMap.get(region+"client_secret") !=null)
            {
                log.println("ScheduledTask - Secret ID Obtained for Region ["+region+"] "+StartUpConfigurations.clientIdClientSecretMap);
                flag = true;    
            } 
            else 
            {
                try
                {
                    log.println("ScheduledTask - Loading Client Id Secret Id [Database Configurations] for Region ["+region+"]");
                    ApplicationConfiguration.getInstance().loadClientIdClientSecret(region);
                    log.println("ScheduledTask - Generated Client Id Secret Id [Database Configurations] for Region ["+region+"]");   
                }
                catch (Exception e) 
                {
                	log.printErrorMessage(e);
                }
            }
        }
    }
}