package com.scb.clm.common.model.codesetup;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

/*
 * 
 * @author       1378958
 * @version      1.0
 * @since        
 * @use          
 */
@Embeddable
public class FlowsEntityKey implements Serializable,Cloneable
{
    private static final long serialVersionUID = 1103847698360379355L;

    @Column(name = "COUNTRY_CODE", nullable = false ,insertable=false, updatable=false)
    private String countryCode;

    @Column(name = "FLOW_ID", nullable = false ,insertable=false, updatable=false)
    private String flowIdentifier;

    public FlowsEntityKey () {
    }

    public FlowsEntityKey (String countryCode) {
        this.countryCode     =     countryCode;
    }

    public FlowsEntityKey (String countryCode,String flowIdentifier) {
        this.countryCode     =     countryCode;
        this.flowIdentifier  =     flowIdentifier;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getFlowIdentifier() {
        return flowIdentifier;
    }

    public void setFlowIdentifier(String flowIdentifier) {
        this.flowIdentifier = flowIdentifier;
    }

    @Override
    public int hashCode() {
        StringBuilder finalHashCode = new StringBuilder();
        if (this.countryCode != null && this.flowIdentifier != null) 
        {
            finalHashCode.append(countryCode);
            finalHashCode.append(flowIdentifier);
        }
        return finalHashCode.toString().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
        {
            return true;
        }
        if ((obj == null) || (obj.getClass() != this.getClass())) 
        {
            return false;
        }
        FlowsEntityKey other = (FlowsEntityKey) obj;
        return   Objects.equals(this.countryCode, other.countryCode) 
                && Objects.equals(this.flowIdentifier, other.flowIdentifier);
    }

    @Override
    public Object clone() {
        try {
            return (FlowsEntityKey) super.clone();
        } catch (CloneNotSupportedException e) {
            return new FlowsEntityKey(this.getCountryCode(),this.getFlowIdentifier());
        }
    }    
}
