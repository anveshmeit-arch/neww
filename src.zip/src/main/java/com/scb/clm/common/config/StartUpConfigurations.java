package com.scb.clm.common.config;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;

import jakarta.annotation.PostConstruct;

@Service
public class StartUpConfigurations 
{
    
    @Autowired
    CountryConfig countryConfig;
    
    @Autowired
    ApplicationConfiguration applicationConfiguration;

    public static HashMap<String, String> clientIdClientSecretMap = new HashMap<String, String>();
    
    @PostConstruct
    public void loadStartUpConfigurations()
    {
        countryConfig.loadCountryConfig();

        try
        {
            SchedulerMain schedulerMain = new SchedulerMain();
            schedulerMain.start();
        }
        catch(Exception e)
        {
        	LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "loadStartUpConfigurations", LogType.APPLICATION.name());
        	log.printErrorMessage(e);

        }
    }
    
}
