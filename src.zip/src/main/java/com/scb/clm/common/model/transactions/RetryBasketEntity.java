package com.scb.clm.common.model.transactions;

import java.sql.Date;
import java.sql.Timestamp;

import com.scb.clm.common.util.WrapperUtility;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;

/*
 * 
 *  @author      1378958
 *  @version     1.0
 *  @since       
 *  @use         
 */
@Entity
@Table(name = "CLM_RETRY_BASKET")
public class RetryBasketEntity implements Cloneable
{
    @EmbeddedId
    private RetryBasketEntityKey id;

    @Column(name="PROCESS_DATE")
    private Date processDate;

    @Column(name="JOB_ID")
    private String jobID;
 
    @Lob
//    @Type(type="org.hibernate.type.BinaryType")
    @Column(name = "MESSAGE")
    private byte[] message;

    @Column(name="RETRY_COUNT")
    private String retryCount;

    @Column(name="LATEST_PROCESS_TIME")
    private Timestamp latestProcessTime;
    
    @Column(name="STATUS")
    private String status;
    
    public RetryBasketEntity() {

    }

    public RetryBasketEntity(RetryBasketEntityKey id) {
        this.id= id;
    }

    public RetryBasketEntityKey getId() {
        return id;
    }

    public void setId(RetryBasketEntityKey id) {
        this.id = id;
    }

    public Date getProcessDate() {
        return WrapperUtility.cloneData(processDate);
    }

    public void setProcessDate(Date processDate) {
        this.processDate = processDate;
    }

    public String getJobID() {
        return jobID;
    }

    public void setJobID(String jobID) {
        this.jobID = jobID;
    }

    public String getRetryCount() {
        return retryCount;
    }

    public void setRetryCount(String retryCount) {
        this.retryCount = retryCount;
    }

    public Timestamp getLatestProcessTime() {
        return latestProcessTime;
    }

    public void setLatestProcessTime(Timestamp latestProcessTime) {
        this.latestProcessTime = latestProcessTime;
    }

    public byte[] getMessage() {
        return message;
    }

    public void setMessage(byte[] message) {
        this.message = message;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    } 
}
