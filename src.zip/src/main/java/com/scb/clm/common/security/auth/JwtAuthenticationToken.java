package com.scb.clm.common.security.auth;

import java.util.Collection;

import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

import com.sc.rpbwm.auth.BearerToken;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class JwtAuthenticationToken extends AbstractAuthenticationToken {

    private static final long serialVersionUID = 1L;
    private Collection<? extends GrantedAuthority> authorities;
    private String token;
    private BearerToken bearerToken;

    public JwtAuthenticationToken(Collection<? extends GrantedAuthority> authorities) {
        super(authorities);
        this.eraseCredentials();
        this.authorities = authorities;
        System.out.println(">>>>>>>>>getBearerToken()::"+getBearerToken());
        super.setAuthenticated(true);
    }

    public JwtAuthenticationToken(Collection<? extends GrantedAuthority> authorities, BearerToken bearerToken ) {
        super(authorities);
        this.eraseCredentials();
        this.authorities = authorities;
        this.bearerToken=bearerToken;
        super.setAuthenticated(true);
    }

    public JwtAuthenticationToken(BearerToken bearerToken) {
        super(null);
        this.bearerToken=bearerToken;
        setBearerToken(bearerToken);
    }


    public BearerToken getBearerToken() {
        return bearerToken;
    }

    public void setBearerToken(BearerToken bearerToken) {
        this.bearerToken = bearerToken;
    }

    @Override
    public Object getCredentials() {
        // TODO Auto-generated method stub
        //return token;
        return "N/A";
    }


    @Override
    public Object getPrincipal() {

        return this.token;

    }

}
