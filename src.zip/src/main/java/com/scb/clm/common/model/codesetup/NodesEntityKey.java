package com.scb.clm.common.model.codesetup;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

/*
 * 
 * @author       1378958
 * @version      1.0
 * @since           
 * @use          
 */
@Embeddable
public class NodesEntityKey implements Serializable,Cloneable
{
    private static final long serialVersionUID = -3717433805942173594L;

    @Column(name = "COUNTRY_CODE", nullable = false ,insertable=false, updatable=false)
    private String countryCode;

    @Column(name = "FLOW_ID", nullable = false ,insertable=false, updatable=false)
    private String flowIdentifier;

    @Column(name = "NODE_ID", nullable = false ,insertable=false, updatable=false)
    private String nodeIdentifier;

    public NodesEntityKey() {

    }

    public NodesEntityKey (String countryCode,String flowIdentifier,String nodeIdentifier){
        this.countryCode      = countryCode;
        this.flowIdentifier   = flowIdentifier;
        this.nodeIdentifier   = nodeIdentifier;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }


    public String getFlowIdentifier() {
        return flowIdentifier;
    }

    public void setFlowIdentifier(String flowIdentifier) {
        this.flowIdentifier = flowIdentifier;
    }

    public String getNodeIdentifier() {
        return nodeIdentifier;
    }

    public void setNodeIdentifier(String nodeIdentifier) {
        this.nodeIdentifier = nodeIdentifier;
    }

    @Override
    public int hashCode() {
        StringBuilder finalHashCode = new StringBuilder();
        if (this.countryCode != null && this.flowIdentifier != null
                && this.nodeIdentifier != null)
        {
            finalHashCode.append(countryCode);
            finalHashCode.append(flowIdentifier);
            finalHashCode.append(nodeIdentifier);
        }
        return finalHashCode.toString().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) 
        {
            return true;
        }
        if ((obj == null) || (obj.getClass() != this.getClass())) 
        {
            return false;
        }
        NodesEntityKey other = (NodesEntityKey) obj;
        return   Objects.equals(this.countryCode, other.countryCode) 
                && Objects.equals(this.flowIdentifier, other.flowIdentifier)
                && Objects.equals(this.nodeIdentifier, other.nodeIdentifier);
    }

    @Override
    public Object clone() {
        try {
            return (NodesEntityKey) super.clone();
        } catch (CloneNotSupportedException e) {
            return new NodesEntityKey(this.getCountryCode(),this.getFlowIdentifier(),this.getNodeIdentifier());
        }
    }
}



