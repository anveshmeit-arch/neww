package com.scb.clm.common.util;

public class ModuleContextManager {

	private static ModuleContext moduleContext = null;
	private static final String MODULE_THREAD_MAP = "ThreadMap";
	private static final String MODULE_EHCACHE = "EHCACHE";


	private static void initialize(){
		try{
			String thrdCtxImplementation = null;
			if (thrdCtxImplementation == null) {
				thrdCtxImplementation = MODULE_THREAD_MAP;
			}

			if (thrdCtxImplementation.equalsIgnoreCase(MODULE_THREAD_MAP)) {
				moduleContext = ModuleThreadMapContext.getInstance();	
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception During initialize --- "+ e.getMessage() );
		}
	}

	public static ModuleContext getModuleContext(){
		if (moduleContext == null){
			initialize();
		}
		return moduleContext;
	}

}
