package com.scb.clm.common.model.transactions;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

/*
 * 
 *  @author      1378958
 *  @version     1.0
 *  @since       
 *  @use         
 */
@Entity
@Table(name = "CLM_OUTBOUND_REQUESTS")
public class OutboundRequestsEntity extends AbstractPersistableEntity<String> implements Cloneable,LoggerInterface
{
    @Id
    @Column(name="REQUEST_ID")
    private String requestId;

    @Column(name="COUNTRY_CODE")
    private String countryCode;

    @Column(name="INTERFACE_ID")
    private String interfaceId;

    @Column(name="REQUEST_TYPE")
    private String requestType;

    @Column(name="INBOUND_REQUEST_ID")
    private String inboundRequestID;

    @Column(name="APPLICATION_REFERENCE")
    private String applicationReference;

    @Column(name="TRACKING_ID")
    private String trackingID;

    @Column(name="DUPLICATE_FLAG")
    private String duplicateFlag;

    @Column(name="REQUEST_DATE")
    private Date requestDate;

    @Column(name="REQUEST_TIME")
    private Timestamp requestTime;

    @Column(name="RESPONSE_TIME")
    private Timestamp responseTime;

    @Column(name="HTTP_RESPONSE_CODE")
    private String httpResponseCode;

    @Column(name="STATUS")
    private String status;

    @Column(name="VM_NAME")
    private String vmName;
    
    @OneToMany(fetch=FetchType.LAZY,mappedBy="outboundRequestsErrorMapper")
    @Cascade({CascadeType.ALL})
    private Set<OutboundRequestsErrorsEntity> outboundRequestsErrorsEntity  =     new     HashSet<>();

    public OutboundRequestsEntity() {

    }
    public OutboundRequestsEntity(String requestId) {
        this.requestId = requestId;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getInterfaceId() {
        return interfaceId;
    }

    public void setInterfaceId(String interfaceId) {
        this.interfaceId = interfaceId;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public String getInboundRequestID() {
        return inboundRequestID;
    }
    public void setInboundRequestID(String inboundRequestID) {
        this.inboundRequestID = inboundRequestID;
    }
    public String getApplicationReference() {
        return applicationReference;
    }

    public void setApplicationReference(String applicationReference) {
        this.applicationReference = applicationReference;
    }

    public String getTrackingID() {
        return trackingID;
    }

    public void setTrackingID(String trackingID) {
        this.trackingID = trackingID;
    }

    public String getDuplicateFlag() {
        return duplicateFlag;
    }

    public void setDuplicateFlag(String duplicateFlag) {
        this.duplicateFlag = duplicateFlag;
    }

    public Date getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    public Timestamp getRequestTime() {
        return requestTime;
    }

    public void setRequestTime(Timestamp requestTime) {
        this.requestTime = requestTime;
    }

    public Timestamp getResponseTime() {
        return responseTime;
    }

    public void setResponseTime(Timestamp responseTime) {
        this.responseTime = responseTime;
    }

    public String getHttpResponseCode() {
        return httpResponseCode;
    }

    public void setHttpResponseCode(String httpResponseCode) {
        this.httpResponseCode = httpResponseCode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getVmName() {
		return vmName;
	}
	public void setVmName(String vmName) {
		this.vmName = vmName;
	}
	public Set<OutboundRequestsErrorsEntity> getOutboundRequestsErrorsEntity() {
        return outboundRequestsErrorsEntity;
    }
    public void setOutboundRequestsErrorsEntity(Set<OutboundRequestsErrorsEntity> outboundRequestsErrorsEntity) {
        this.outboundRequestsErrorsEntity = outboundRequestsErrorsEntity;
    }

    @Override
    public String getId() {
        // TODO Auto-generated method stub
        return this.requestId;
    }

    public void addErrors(OutboundRequestsErrorsEntity errorDetail) {
        if(this.outboundRequestsErrorsEntity == null) {
            this.outboundRequestsErrorsEntity= new HashSet<OutboundRequestsErrorsEntity>();     
        }
        this.outboundRequestsErrorsEntity.add(errorDetail);
    }

    @Override
    public int hashCode() {
        StringBuilder finalHashCode = new StringBuilder();
        if (this.requestId != null) 
        {
            finalHashCode.append(requestId);
        }
        return finalHashCode.toString().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
        {
            return true;
        }
        if ((obj == null) || (obj.getClass() != this.getClass())) 
        {
            return false;
        }
        OutboundRequestsEntity other = (OutboundRequestsEntity) obj;
        return Objects.equals(this.requestId, other.requestId);
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return (OutboundRequestsEntity) super.clone();
    }   

}
