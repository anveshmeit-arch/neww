package com.scb.clm.common.model.codesetup;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

/*
 * 
 *  @author      1378958
 *  @version     1.0
 *  @since          
 *  @use         
 */
@Entity
@Table(name = "CLM_FLOWS")
public class FlowsEntity implements Cloneable
{
    @EmbeddedId
    private FlowsEntityKey id;

    @Column(name="DESCRIPTION")
    private String flowDescription;

    @Column(name="PATH_IDENTIFIER")
    private String pathIdentifier;

    @Column(name="MODEL_CLASS")
    private String modelClass;

    @Column(name="STATUS_FLAG")
    private String statusFlag;

    @Column(name="LOG_TIME")
    private String logTime;
    
    @OneToMany(fetch=FetchType.EAGER,mappedBy="flowMapper")
    @Cascade({CascadeType.ALL})
    private Set<NodesEntity> nodesDetail  =     new     HashSet<>();

    public FlowsEntity() {

    }

    public FlowsEntity (FlowsEntityKey id) {
        this.id = (FlowsEntityKey) id.clone();
    }

    public FlowsEntity (String countryCode,String pathIdentifier) {
        this.id = new FlowsEntityKey(countryCode);
        this.pathIdentifier = pathIdentifier;
    }

    public FlowsEntityKey getId() {
        return (FlowsEntityKey) id.clone();
    }

    public void setId(FlowsEntityKey id) {
        this.id = (FlowsEntityKey) id.clone();
    }

    public String getFlowDescription() {
        return flowDescription;
    }

    public void setFlowDescription(String flowDescription) {
        this.flowDescription = flowDescription;
    }

    public String getPathIdentifier() {
        return pathIdentifier;
    }

    public void setPathIdentifier(String pathIdentifier) {
        this.pathIdentifier = pathIdentifier;
    }

    public String getModelClass() {
        return modelClass;
    }

    public void setModelClass(String modelClass) {
        this.modelClass = modelClass;
    }

    public String getStatusFlag() {
        return statusFlag;
    }

    public void setStatusFlag(String statusFlag) {
        this.statusFlag = statusFlag;
    }

    public String getLogTime() {
        return logTime;
    }

    public void setLogTime(String logTime) {
        this.logTime = logTime;
    }

    public Set<NodesEntity> getNodesDetail() {
        return nodesDetail.stream().collect(Collectors.toSet());
    }

    public void setNodesDetail(Set<NodesEntity> nodesDetail) {
        this.nodesDetail = nodesDetail.stream().collect(Collectors.toSet());
    }

    public FlowsEntity clone() throws CloneNotSupportedException {  
        return (FlowsEntity) super.clone();  
    }  


}
