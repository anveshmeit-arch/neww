package com.scb.clm.common.util;

import java.util.HashMap;
import java.util.Set;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.model.codesetup.NodeServicesParametersEntity;

public class ServiceParameterUtility
{

    public static String getParameter(Set<NodeServicesParametersEntity> parameter,String groupID,String paramCode)
    {
        
        String paramValue   = null;
        try
        {
            for (NodeServicesParametersEntity paramList : parameter) 
            {
                if(paramList.getId().getParameterGroup().equals(groupID) && paramList.getParamCode().equals(paramCode)) 
                {
                    if(paramList.getStatusFlag().equalsIgnoreCase(BaseConstants.CODE_SETUP_ACTIVE)) 
                    {
                        paramValue = paramList.getParamValue();
                    }
                }
            }
        }
        catch(Exception e)
        {
        	System.out.print("Error in #ServiceParameterUtilityr# #getParameter#");

        }
        return paramValue;
    }

    public static HashMap<String,String> getParameterList(Set<NodeServicesParametersEntity> parameter,String groupID)
    {
        HashMap<String,String> paramMap = new HashMap<String,String>();
        try
        {
            for (NodeServicesParametersEntity paramList : parameter) 
            {
                if(paramList.getId().getParameterGroup().equals(groupID)) 
                {
                    if(paramList.getStatusFlag().equalsIgnoreCase(BaseConstants.CODE_SETUP_ACTIVE)) 
                    {
                        paramMap.put(paramList.getParamCode(),paramList.getParamValue());     
                    }
                }
            }
        }
        catch(Exception e)
        {
        	System.out.print("Error in #ServiceParameterUtilityr# #getParameterList#");

        }
        return paramMap;
    }
}
