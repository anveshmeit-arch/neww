package com.scb.clm.common.model.transactions;

import java.sql.Timestamp;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/*
 * 
 *  @author      1378958
 *  @version     1.0
 *  @since       
 *  @use         
 */
@Entity
@Table(name = "CLM_INBOUND_REQUEST_STATISTICS")
public class InboundRequestsStatisticsEntity implements Cloneable
{
    @EmbeddedId
    private InboundRequestsStatisticsEntityKey id;

    @Column(name="COUNTRY_CODE")
    private String countryCode;

    @Column(name="SERVICE_START_TIME")
    private Timestamp serviceStartTime;

    @Column(name="SERVICE_END_TIME")
    private Timestamp serviceEndTime;

    @Column(name="STATUS_FLAG")
    private String statusFlag;

    @ManyToOne
    @JoinColumns({
        @JoinColumn(name="REQUEST_ID", referencedColumnName="REQUEST_ID", insertable= false, updatable= false)
    })
    private InboundRequestsEntity inboundRequestsStatisticsEntityMapper;

    public InboundRequestsStatisticsEntity() {

    }

    public InboundRequestsStatisticsEntity(InboundRequestsStatisticsEntityKey id) {
        this.id = id;
    }

    public InboundRequestsStatisticsEntityKey getId() {
        return id;
    }

    public void setId(InboundRequestsStatisticsEntityKey id) {
        this.id = id;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public Timestamp getServiceStartTime() {
        return serviceStartTime;
    }

    public void setServiceStartTime(Timestamp serviceStartTime) {
        this.serviceStartTime = serviceStartTime;
    }

    public Timestamp getServiceEndTime() {
        return serviceEndTime;
    }

    public void setServiceEndTime(Timestamp serviceEndTime) {
        this.serviceEndTime = serviceEndTime;
    }

    public String getStatusFlag() {
        return statusFlag;
    }

    public void setStatusFlag(String statusFlag) {
        this.statusFlag = statusFlag;
    }

}
