package com.scb.clm.common.util;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;

public class SystemUtility {

    /**
     *  
     * 
     * <p>
     *
     * @param         N.A
     * @return        
     * @exception     
     * @see
     * @since         August 2024
     */
    public static String getInstanceName() 
    {
    	String instanceName = null;
    	try 
    	{
    		instanceName = System.getProperty("catalina.base");    		
    		instanceName = instanceName.substring(instanceName.lastIndexOf("/")+1);
    		if(instanceName!=null && instanceName.length() > 25) {
    			instanceName = instanceName.substring(0,25);
    		}
    		System.out.println(instanceName);
    	} 
    	catch (Exception e) 
    	{
    		System.out.print("Error in #SystemUtility# #getInstanceName#");

    	}
    	return instanceName;
    }  
    
    public static String getServiceName() {
        return System.getProperty("serviceName");
    }
    
}
