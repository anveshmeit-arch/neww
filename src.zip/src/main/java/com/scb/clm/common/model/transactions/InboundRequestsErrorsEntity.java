package com.scb.clm.common.model.transactions;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/*
 * 
 *  @author      1378958
 *  @version     1.0
 *  @since       
 *  @use         
 */
@Entity
@Table(name = "CLM_INBOUND_REQUEST_ERRORS")
public class InboundRequestsErrorsEntity implements Cloneable
{
    @EmbeddedId
    private InboundRequestsErrorsEntityKey id;

    @Column(name="COUNTRY_CODE")
    private String countryCode;

    @Column(name="ERROR_CODE")
    private String errorCode;

    @Column(name="ERROR_MESSAGE")
    private String errorMessage;

    @ManyToOne
    @JoinColumns({
        @JoinColumn(name="REQUEST_ID", referencedColumnName="REQUEST_ID", insertable= false, updatable= false)
    })
    private InboundRequestsEntity inboundRequestsErrorsEntityMapper;

    public InboundRequestsErrorsEntity() {

    }

    public InboundRequestsErrorsEntity(InboundRequestsErrorsEntityKey id) {
        this.id = id;
    }

    public InboundRequestsErrorsEntityKey getId() {
        return id;
    }

    public void setId(InboundRequestsErrorsEntityKey id) {
        this.id = id;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

}
