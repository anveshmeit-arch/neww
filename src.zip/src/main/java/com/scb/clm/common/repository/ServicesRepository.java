package com.scb.clm.common.repository;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.scb.clm.common.model.codesetup.ServicesEntity;
import com.scb.clm.common.model.codesetup.ServicesEntityKey;

@Repository
public interface ServicesRepository extends JpaRepository<ServicesEntity, ServicesEntityKey> { 

    @Override
    public <S extends ServicesEntity> S save(S entity);

    @Override
    @Cacheable("Services")
    public ServicesEntity getOne(ServicesEntityKey arg0);
    
    @Cacheable("ServicesCntryCodeId")
    public ServicesEntity findByIdCountryCodeAndIdServiceID(String countryCode,String serviceID);

}