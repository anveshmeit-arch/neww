package com.scb.clm.common.config;

import java.io.Serializable;

import com.scb.clm.common.model.codesetup.NodeServicesEntity;

public class ContactServerInfo implements Serializable {

	private static final long serialVersionUID = 8180536972051248686L;

	private String countryCode;

	private String serviceUrl;

	private String scope;

	private String trackingId;

	private String interfaceId;

	private String requestMessage;

	private String responseMessage;
	
	private String protocolMethod;

	private String httpResponseCode;

	private NodeServicesEntity srvEntity;

	public ContactServerInfo () {
		
	}
	
	public ContactServerInfo (String countryCode,String serviceUrl,String scope, String trackingId,String interfaceId,String requestMessage,String protocolMethod,NodeServicesEntity srvEntity)
	{
		this.countryCode	= countryCode;
		this.serviceUrl 	= serviceUrl; 
		this.scope 			= scope;
		this.trackingId 	= trackingId;
		this.interfaceId 	= interfaceId; 
		this.requestMessage = requestMessage;
		this.protocolMethod = protocolMethod; 
		this.srvEntity 		= srvEntity;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getServiceUrl() {
		return serviceUrl;
	}

	public void setServiceUrl(String serviceUrl) {
		this.serviceUrl = serviceUrl;
	}

	public String getScope() {
		return scope;
	}

	public void setScope(String scope) {
		this.scope = scope;
	}

	public String getTrackingId() {
		return trackingId;
	}

	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}

	public String getInterfaceId() {
		return interfaceId;
	}

	public void setInterfaceId(String interfaceId) {
		this.interfaceId = interfaceId;
	}

	public String getRequestMessage() {
		return requestMessage;
	}

	public void setRequestMessage(String requestMessage) {
		this.requestMessage = requestMessage;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public String getProtocolMethod() {
		return protocolMethod;
	}

	public void setProtocolMethod(String protocolMethod) {
		this.protocolMethod = protocolMethod;
	}

	public String getHttpResponseCode() {
		return httpResponseCode;
	}

	public void setHttpResponseCode(String httpResponseCode) {
		this.httpResponseCode = httpResponseCode;
	}

	public NodeServicesEntity getSrvEntity() {
		return srvEntity;
	}

	public void setSrvEntity(NodeServicesEntity srvEntity) {
		this.srvEntity = srvEntity;
	}

}
