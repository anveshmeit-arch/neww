package com.scb.clm.common.model.codesetup;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

/*
 * 
 *  @author      1378958 
 *  @version     1.0
 *  @since       
 *  @use         
 */
@Entity
@Table(name = "CLM_SERVICES")
public class ServicesEntity implements Cloneable,Serializable
{
    private static final long serialVersionUID = -8073790468882908446L;

    @EmbeddedId
    private ServicesEntityKey id;

    @Column(name="DESCRIPTION")
    private String description;

    @Column(name="SERVICE_PROGRAM")
    private String serviceProgram;

    @Column(name="STATUS_FLAG")
    private String statusFlag;

    public ServicesEntity() {

    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getServiceProgram() {
        return serviceProgram;
    }

    public void setServiceProgram(String serviceProgram) {
        this.serviceProgram = serviceProgram;
    }

    public String getStatusFlag() {
        return statusFlag;
    }

    public void setStatusFlag(String statusFlag) {
        this.statusFlag = statusFlag;
    }

    public ServicesEntity clone() throws CloneNotSupportedException {  
        return (ServicesEntity) super.clone();  
    }  

    public ServicesEntityKey getId() {
        return (ServicesEntityKey) id.clone();
    }

    public void setId(ServicesEntityKey id) {
        this.id = (ServicesEntityKey) id.clone();
    }

}
