package com.scb.clm.common.model.codesetup;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "CLM_COUNTRIES")
public class CountryCodeEntity implements Serializable,Cloneable
{

    private static final long serialVersionUID = -9076361791974164510L;

    @Id
    @Column(name="COUNTRY_CODE")
    private String countryCode;

    @Column(name="COUNTRY_NAME")
    private String countryName;

    @Column(name="ISO_COUNTRY_CODE")
    private String isoCountryCode;
    
    @Column(name="NATIONALITY_CODE")
    private String nationalityCode;

    public CountryCodeEntity() {

    }

    public CountryCodeEntity(String companyId) {
        super();
        this.countryCode = companyId;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getIsoCountryCode() {
        return isoCountryCode;
    }

    public void setIsoCountryCode(String isoCountryCode) {
        this.isoCountryCode = isoCountryCode;
    }

    public String getNationalityCode() {
        return nationalityCode;
    }

    public void setNationalityCode(String nationalityCode) {
        this.nationalityCode = nationalityCode;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((countryCode == null) ? 0 : countryCode.hashCode());
        result = prime * result + ((countryName == null) ? 0 : countryName.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) 
        {
            return true;
        }
        if (obj == null) 
        {
            return false;
        }
        if (getClass() != obj.getClass()) 
        {
            return false;
        }

        CountryCodeEntity other = (CountryCodeEntity) obj;
        if (countryCode == null) 
        {
            if (other.countryCode != null) 
            {
                return false;
            }
        } 
        else if (!countryCode.equals(other.countryCode)) 
        {
            return false;
        }
        if (countryName == null) 
        {
            if (other.countryName != null)
            {
                return false;
            }
        } 
        else if (!countryName.equals(other.countryName)) 
        {
            return false;
        }
        return true;
    }
}
