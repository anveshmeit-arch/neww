package com.scb.clm.common.repository;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.scb.clm.common.model.codesetup.InterfaceEntity;
import com.scb.clm.common.model.codesetup.InterfaceEntityKey;

@Repository
public interface InterfaceRepository extends JpaRepository<InterfaceEntity, InterfaceEntityKey> { 

    @Override
    public <S extends InterfaceEntity> S save(S entity);

    @Override
    @Cacheable
    public InterfaceEntity getOne(InterfaceEntityKey arg0);

}