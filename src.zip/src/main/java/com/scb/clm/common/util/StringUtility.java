package com.scb.clm.common.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StringUtility 
{

    public static final Pattern VALID_EMAIL_ADDRESS_REGEX =  Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);

    public static boolean validateeMail(String emailStr) 
    {
        Matcher matcher = VALID_EMAIL_ADDRESS_REGEX.matcher(emailStr);
        return matcher.find();
    }

    public static String toUpperCase(String data) 
    {
        if(data==null || data.trim().length()==0) {
            return data;
        } else {
            return data.toUpperCase();
        }
    }
    
    public static boolean isValidNumber(String number) 
    {
        if(number==null) {
            return false;
        }
        return number.chars().allMatch( Character::isDigit );
    }

    /**
     * @usage        Checks if the input length within the range
     *  
     * @param        Parameter Value, Min Length Allowed , Max Length Allowed 
     * @return       boolean (True - Success / False - Failed) 
     * @exception    N.A
     * @see
     * @since        
     */
    public static boolean minMaxlength(String data,String minLength,String maxLength) 
    {
        if( data==null )
        {
            return true;
        }
        else if( data.length()>= Integer.parseInt(minLength) && data.length()<= Integer.parseInt(maxLength) )
        {
            return true;
        }
        return false;
    }

    /**
     * @usage        Checks if the input length exceeds the value
     *  
     * @param        Parameter Value, Max Length Allowed 
     * @return       boolean (True - Success / False - Failed) 
     * @exception    N.A
     * @see
     * @since        
     */
    static boolean checkMaxlength(String data,String length) 
    {
        try
        {
            if(length==null) {
                return true;
            }
            if(data!= null && data.length() > Integer.parseInt(length)) {
                return false;
            }
            else {
                return true;
            }
        }
        catch(Exception e)
        {
            System.out.println("# checkMaxlength # Exception ");
            return false;
        }
    }


    /**
     * @usage        Checks if the input contains Numeric Data (For fields defined in HashMap - keyNumericInfo) 
     *  
     * @param          
     * @return       boolean (True - Success / False - Failed) 
     * @exception    N.A 
     * @see
     * @since        June 2021
     */
    static boolean checkNumeric(String data,String keyAvailable)
    {
        if(keyAvailable == null || data==null || data.trim().length() == 0)
        {
            return true;
        }

        String regex = "[0-9]+";
        return Pattern.matches(regex, data); 

    }

    public static boolean containsData(String str) {
        return (str != null && str.trim().length() > 0);
    }

    public static String padRight(String inputString, int length,String paddingChar) {
        if (inputString==null || inputString.length() >= length) {
            return inputString;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(inputString);
        while (sb.length() < length) {
            sb.append(paddingChar);
        }
        return sb.toString();
    }

    public static String padLeft(String inputString, int length,String paddingChar) {
        if (inputString==null || inputString.length() >= length) {
            return inputString;
        }
        StringBuilder sb = new StringBuilder();
        while (sb.length() < length - inputString.length()) {
            sb.append(paddingChar);
        }
        sb.append(inputString);

        return sb.toString();
    }
    
	public static boolean isAlphaNumeric(String s){
	    String pattern= "^[a-zA-Z0-9]*$";
	    return s.matches(pattern);
	}
	public static boolean isAlpha(String s){
	    String pattern= "^[a-zA-Z]*$";
	    return s.matches(pattern);
	}

	/**
	 * Allows only aplha,numbers and special characters only space,@,.,_,-,/
	 * @param s
	 * @return
	 */
	public static boolean isAlphaNumericSpecialChar(String s){
	    String pattern= "^[a-zA-Z0-9@._/-]*$";
	    return s.matches(pattern);
	}
	
	public static boolean isAlphaUpperCase(String s){
		if(s == null)
		{
			return false;
		}
	    String pattern= "^[A-Z]*$";
	    return s.matches(pattern);
	}

    public static boolean isEmpty(String str) {
        return str == null || str.trim().isEmpty();
    }
}
