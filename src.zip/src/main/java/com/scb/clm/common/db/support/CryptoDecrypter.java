package com.scb.clm.common.db.support;



import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;
import java.util.HashMap;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;


public class CryptoDecrypter
{

	private static CryptoDecrypter decryptPWD = null;

	public static CryptoDecrypter getInstance() throws Exception 
	{
		if (decryptPWD == null) 
		{
			decryptPWD = new CryptoDecrypter();
		}

		return decryptPWD;
	}

	public String decryptDBPwd(String AppID,String companyID) throws Exception
	{
		String decDBPwd 		= null;
		byte keyStoreByts[] 	= null;
		KeyStore keystore 		= null;
		PrivateKey privateKey 	= null;
		FileInputStream fin 	= null;
		byte[] encyKeyStoreByts = null;
		InputStream in 			= null;
		ByteArrayOutputStream baos = null;

		try{

			CryptoParameters.getInstance().setCompanyID(companyID);

			CryptoParameters.getInstance().setApplicationID(AppID);

			KeyReader keyReader = new KeyReader();

			keyStoreByts = keyReader.decryptKeyStorePwd(CryptoParameters.getInstance().getCompanyID());

			String kegStorePassword = new String(keyStoreByts);

			CryptoParameters.getInstance().setFileName(CryptoParameters.getInstance().getKeyFilesLoca()+ CryptoParameters.getInstance().getCompanyID() + "/StoreKeys.jck");

			fin = new FileInputStream(CryptoParameters.getInstance().getFileName());

			keystore = KeyStore.getInstance(CryptoParameters.getInstance().getKeyStroreAlgName(), CryptoParameters.getInstance().getProviderClassName());

			keystore.load(fin, kegStorePassword.toCharArray());

			privateKey = (PrivateKey) keystore.getKey("PrivateKeys",kegStorePassword.toCharArray());

			CryptoParameters.getInstance().setFileName(CryptoParameters.getInstance().getKeyFilesLoca()+ CryptoParameters.getInstance().getCompanyID() + "/"+ CryptoParameters.getInstance().getApplicationID() + "_EncyPwd.key");

			encyKeyStoreByts = CryptoUtility.getInstance().readKeysFromFile(CryptoParameters.getInstance().getFileName());

			Cipher cipher1 = Cipher.getInstance(CryptoParameters.getInstance().getASymentickeyAlgName(), CryptoParameters.getInstance().getProviderClassName());
			cipher1.init(Cipher.DECRYPT_MODE, privateKey);
			byte decDBPwdByts[] = cipher1.doFinal(encyKeyStoreByts);
			decDBPwd = new String(decDBPwdByts);

			System.out.println("DB Password Decrypted Successfully For The Application   ::  "+ CryptoParameters.getInstance().getApplicationID());



		}catch(Exception e)
		{

			e.printStackTrace();

			if(e instanceof InvalidKeyException)
				throw new InvalidKeyException(e.getMessage());

			else if(e instanceof NoSuchAlgorithmException)
				throw new NoSuchAlgorithmException(e.getMessage());

			else if(e instanceof NoSuchProviderException)
				throw new NoSuchProviderException(e.getMessage());

			else if(e instanceof InvalidKeySpecException)
				throw new InvalidKeySpecException(e.getMessage());

			else if(e instanceof KeyStoreException)
				throw new KeyStoreException(e.getMessage());

			else if(e instanceof IllegalBlockSizeException)
				throw new IllegalBlockSizeException(e.getMessage());

			else if(e instanceof BadPaddingException)
				throw new BadPaddingException(e.getMessage());

			else if(e instanceof FileNotFoundException)
				throw new FileNotFoundException(e.getMessage());

			else if(e instanceof IOException)
				throw new IOException(e.getMessage());
			/* Commented for Sonar Fix - Duplicate code
				else if (e instanceof KeyStoreException)
					throw new KeyStoreException(e.getMessage());
			 */
			else if(e instanceof CertificateException)
				throw new CertificateException(e.getMessage());

			else if( e instanceof UnrecoverableKeyException)
				throw new UnrecoverableKeyException(e.getMessage());

			else if(e instanceof NoSuchPaddingException)
				throw new NoSuchPaddingException(e.getMessage());
			else
				throw new Exception(e);

		}
		finally {
			try {
				if(fin!=null){
					fin.close();
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}

		}

		return decDBPwd;

	}


	public static HashMap<String,String> decryptUserNameAndPwd(String companyid,String applicationID) throws Exception
	{
		byte[] userIdBytes = null;
		byte[] pwdBytes = null;
		byte[] Desbytes =  null;
		byte keyStoreByts[] = null;
		String userName = null;
		String pwd = null;

		HashMap<String,String> details = new HashMap<String,String>();

		CryptoParameters.getInstance().setCompanyID(companyid);		

		try {

			CryptoParameters.getInstance().setFileName(CryptoParameters.getInstance().getKeyFilesLoca()+ CryptoParameters.getInstance().getCompanyID()+"/"+applicationID+"_EncyUserName.key");

			userIdBytes = CryptoUtility.getInstance().readKeysFromFile(CryptoParameters.getInstance().getFileName());

			CryptoParameters.getInstance().setFileName(CryptoParameters.getInstance().getKeyFilesLoca()+ CryptoParameters.getInstance().getCompanyID() + "/"+applicationID+"_key.key");

			Desbytes = CryptoUtility.getInstance().readKeysFromFile(CryptoParameters.getInstance().getFileName());

			SecretKey dkey = new SecretKeySpec(Desbytes, CryptoParameters.getInstance().getSymentickeyAlgName());

			Cipher cipherdes = null;

			cipherdes = Cipher.getInstance(CryptoParameters.getInstance().getSymentickeyAlgName(), CryptoParameters.getInstance().getProviderClassName());

			cipherdes.init(Cipher.DECRYPT_MODE, dkey);

			keyStoreByts = cipherdes.doFinal(userIdBytes);

			userName = new String(keyStoreByts);


			CryptoParameters.getInstance().setFileName(CryptoParameters.getInstance().getKeyFilesLoca()+ CryptoParameters.getInstance().getCompanyID()+"/"+applicationID+"_EncyPwd.key");

			pwdBytes = CryptoUtility.getInstance().readKeysFromFile(CryptoParameters.getInstance().getFileName());


			cipherdes.init(Cipher.DECRYPT_MODE, dkey);

			keyStoreByts = cipherdes.doFinal(pwdBytes);

			pwd = new String(keyStoreByts);
			details.put("USERNAME",userName);
			details.put("PASSWORD",pwd);                    
			return details;





		} catch (Exception e) 

		{

			e.printStackTrace();

			if(e instanceof InvalidKeyException)
				throw new InvalidKeyException(e.getMessage());

			if(e instanceof NoSuchAlgorithmException)
				throw new NoSuchAlgorithmException(e.getMessage());

			if(e instanceof NoSuchProviderException)
				throw new NoSuchProviderException(e.getMessage());

			if(e instanceof InvalidKeySpecException)
				throw new InvalidKeySpecException(e.getMessage());

			if(e instanceof NoSuchPaddingException)
				throw new NoSuchPaddingException();

			if(e instanceof IllegalBlockSizeException)
				throw new IllegalBlockSizeException(e.getMessage());

			if(e instanceof BadPaddingException)
				throw new BadPaddingException(e.getMessage());

			if(e instanceof FileNotFoundException)
				throw new FileNotFoundException(e.getMessage());

			if(e instanceof IOException)
				throw new IOException(e.getMessage());


		}

		return details;


	}
}
