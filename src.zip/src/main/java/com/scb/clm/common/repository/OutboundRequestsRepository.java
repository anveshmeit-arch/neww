package com.scb.clm.common.repository;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.scb.clm.common.model.transactions.OutboundRequestsEntity;

@Repository
public interface OutboundRequestsRepository extends JpaRepository<OutboundRequestsEntity, String> { 

    @Override
    public <S extends OutboundRequestsEntity> S save(S entity);

    @Override
    public OutboundRequestsEntity getOne(String arg0);

    @Query(value = "SELECT OUTBOUND_REQ_SEQUENCE.nextval FROM dual", nativeQuery = true)
    public BigDecimal getOracleOutboundSequenceNumber();

    @Query(value = "SELECT NEXTVAL('outbound_req_sequence')", nativeQuery = true)
    public BigDecimal getPostgresOutboundSequenceNumber();

    public List<OutboundRequestsEntity> findAll();

}