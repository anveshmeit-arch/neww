package com.scb.clm.common.model.codesetup;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;



/*
 * 
 *  @author      1378958 
 *  @version     1.0
 *  @since       
 *  @use         
 */
@Entity
@Table(name = "CLM_ERROR_CODES")
public class ErrorCodesEntity implements Cloneable
{
    @EmbeddedId
    private ErrorCodesEntityKey id;

    @Column(name="ERROR_TYPE")
    private String errorType;

    @Column(name="DESCRIPTION")
    private String errorDescription;

    @Column(name="HTTP_STATUS")
    private String httpStatus;
    
    public ErrorCodesEntity() {        
    }

    public ErrorCodesEntityKey getId() {
        return (ErrorCodesEntityKey) id.clone();
    }

    public void setId(ErrorCodesEntityKey id) {
        this.id = (ErrorCodesEntityKey) id.clone();
    }

    public String getErrorType() {
        return errorType;
    }

    public void setErrorType(String errorType) {
        this.errorType = errorType;
    }

    public String getErrorDescription() {
        return errorDescription;
    }

    public void setErrorDescription(String errorDescription) {
        this.errorDescription = errorDescription;
    }

    public String getHttpStatus() {
        return httpStatus;
    }

    public void setHttpStatus(String httpStatus) {
        this.httpStatus = httpStatus;
    }

    public ErrorCodesEntity clone() throws CloneNotSupportedException {  
        return (ErrorCodesEntity) super.clone();  
    }  
}
