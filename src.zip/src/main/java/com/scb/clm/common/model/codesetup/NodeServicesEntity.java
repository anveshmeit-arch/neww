package com.scb.clm.common.model.codesetup;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

import com.scb.clm.common.model.transactions.ServiceMetadata;

/*
 * 
 * @author       1378958
 * @version      1.0
 * @since           
 * @use          
 */
@Entity
@Table(name = "CLM_NODE_SERVICES")
public class NodeServicesEntity implements Cloneable
{
    @EmbeddedId
    private NodeServicesEntityKey id;

    @Column(name="LOG_TIME")
    private String logTime;

    @Column(name="RETRY_ENABLED")
    private String retryEnabled;
    
    @Column(name="RETRY_JOB_ID")
    private String retryJobId;
    
    @Column(name="THREAD_ADVISOR")
    private String threadAdvisor;

    @Column(name="STATUS_FLAG")
    private String statusFlag;

    @Transient
    private ServicesEntity servicesEntity;

    @Transient
    private ServiceMetadata serviceMetadata;

    @ManyToOne
    @JoinColumns({
        @JoinColumn(name="COUNTRY_CODE", referencedColumnName="COUNTRY_CODE", insertable= false, updatable= false),
        @JoinColumn(name="FLOW_ID", referencedColumnName="FLOW_ID",insertable= false, updatable=false), 
        @JoinColumn(name="NODE_ID", referencedColumnName="NODE_ID",insertable= false, updatable=false)
        //,@JoinColumn(name="SEQUENCE_ID", referencedColumnName="SEQUENCE_ID",insertable= false, updatable=false)
    })
    private NodesEntity nodeMapper;

    @OneToMany(fetch=FetchType.EAGER,mappedBy="nodeServicesMapper")
    @Cascade({CascadeType.ALL})
    private Set<NodeServicesParametersEntity> nodeServicesMapper        =     new     HashSet<>();

    public NodeServicesEntity() {

    }

    public NodeServicesEntity(NodeServicesEntityKey id) {
        this.id = id;
    }

    public NodeServicesEntity clone() throws CloneNotSupportedException {  
        return (NodeServicesEntity) super.clone();  
    }

    public NodeServicesEntityKey getId() {
        return id;
    }

    public void setId(NodeServicesEntityKey id) {
        this.id = id;
    }

    public String getLogTime() {
        return logTime;
    }

    public void setLogTime(String logTime) {
        this.logTime = logTime;
    }

    public String getRetryEnabled() {
        return retryEnabled;
    }

    public void setRetryEnabled(String retryEnabled) {
        this.retryEnabled = retryEnabled;
    }

    public String getRetryJobId() {
        return retryJobId;
    }

    public void setRetryJobId(String retryJobId) {
        this.retryJobId = retryJobId;
    }

    public String getThreadAdvisor() {
        return threadAdvisor;
    }

    public void setThreadAdvisor(String threadAdvisor) {
        this.threadAdvisor = threadAdvisor;
    }

    public String getStatusFlag() {
        return statusFlag;
    }

    public void setStatusFlag(String statusFlag) {
        this.statusFlag = statusFlag;
    }

    public ServicesEntity getServicesEntity() {
        return servicesEntity;
    }

    public void setServicesEntity(ServicesEntity servicesEntity) {
        this.servicesEntity = servicesEntity;
    }

    public ServiceMetadata getServiceMetadata() {
        return serviceMetadata;
    }

    public void setServiceMetadata(ServiceMetadata serviceMetadata) {
        this.serviceMetadata = serviceMetadata;
    }

    public Set<NodeServicesParametersEntity> getNodeServicesMapper() {
        return nodeServicesMapper;
    }

    public void setNodeServicesMapper(Set<NodeServicesParametersEntity> nodeServicesMapper) {
        this.nodeServicesMapper = nodeServicesMapper;
    }

}



