package com.scb.clm.common.security.auth;
import java.io.IOException;
import java.security.interfaces.RSAPublicKey;
import java.sql.Date;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.List;

import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.web.filter.OncePerRequestFilter;

import com.sc.rpbwm.auth.BearerToken;
import com.sc.rpbwm.auth.BearerTokenValidator;
import com.sc.rpbwm.auth.BearerTokenValidator.InvalidBearerTokenException;
import com.scb.clm.common.framework.logger.LogType;
import com.scb.clm.common.framework.logger.LoggerUtil;
import com.scb.clm.common.util.AuthUtility;
import com.scb.clm.common.util.ExceptionUtility;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Configuration
@Order(Ordered.HIGHEST_PRECEDENCE)
public class AuthenticationFilter extends OncePerRequestFilter 
{ 
    
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException 
    {
        LoggerUtil log = LoggerUtil.getInstance(System.getProperty("serviceName"), getClass().getName(), "doFilterInternal", LogType.APPLICATION.name()); 
//        log.println("[AuthenticationFilter]");
        
        short statusCode;
        String exceptionReasonInJson    =   null;
        String initTokenPayload         =   null;
        Date date                       =   null;
        boolean exceptionFlag           =   false;
        BearerToken token               =   null;
        String key                      =   null;
        
//        log.println("[Request Headers]"+request.getHeaderNames());
//        log.println("[AuthenticationFilter] [Protocol :" + request.getProtocol()+"] [PathInfo :" + request.getPathInfo()+"]");

        Enumeration<String> enums = request.getHeaderNames();

        String countryCodeFromRequest = null;
        String countrycode = null;
        String regionCode = "";
//        String country_code = null;
        String interfaceId = null;
        String transactionId = null;

        while (enums.hasMoreElements()) 
        {
            key = (String) enums.nextElement();

//            log.println("Gateway Header  [Name :" + key+"] [Value :" + request.getHeader(key)+"]");

            if (key.equalsIgnoreCase("X-JWT-Assertion")) 
            {
                initTokenPayload = request.getHeader(key);
                log.println("JWT Key ["+key+"] Value [" + initTokenPayload+" ]");
            }
            if (key.equalsIgnoreCase("countryCode")) 
            {
//                country_code = request.getHeader(key);
                countrycode = request.getHeader(key);
                log.println("Country Code Key ["+key+"] Value is [" + countrycode+" ]");
            }
            if (key.equalsIgnoreCase("region")) 
            {    
                regionCode = request.getHeader(key); 
                log.println("Region Code Key ["+regionCode+"] ");
            }
            if (key.equalsIgnoreCase("interface-id")) 
            {
                interfaceId = request.getHeader(key);
                log.println("Interface-id Key ["+key +"] Value [" + interfaceId+" ]");
            }          
            if (key.equalsIgnoreCase("x-xsrf-token")) 
            {
                log.println("X-XSRF-TOKEN Key [" + key+" ]");
            }
            if (initTokenPayload != null && !initTokenPayload.equalsIgnoreCase("NO_JWT_VALIDATE")) 
            {
                new AuthenticationInitializer().retrievePublicKeys(countrycode+(regionCode==null?"":regionCode));
                log.println("Pulic Keys Retrieved");
            }
            if (key.equalsIgnoreCase("transaction-id")) {
                log.println(key + " **** transaction-id header name is ::::: " + key);
                transactionId = request.getHeader(key);
                log.println(key + " **** transaction-id value is ::::: " + transactionId);
            }
        }

//        log.println("Request Token : " + initTokenPayload);
		String contextPath = request.getContextPath();

        // VALIDATE THE TOKEN
        if (initTokenPayload == null && !AuthUtility.isHealthCheckJsp(request.getRequestURI(),contextPath))
        {
            exceptionReasonInJson = "{\"message\": \"JWT header value is not found in the request\"}";
            statusCode = 401;
            ExceptionUtility.printException(exceptionReasonInJson, response, statusCode);
        } 
        else if (AuthUtility.isHealthCheckJsp(request.getRequestURI(),contextPath) || (initTokenPayload != null && initTokenPayload.equalsIgnoreCase("NO_JWT_VALIDATE")))
        {
//            log.println("[Coming to NO_JWT_VALIDATE]");

            try 
            {
                date = new Date(System.currentTimeMillis());
                System.out.println("Request In Time : " + date);
                filterChain.doFilter(request, response);
            } catch (Exception e) {           	
            	log.printErrorMessage(e);

            } finally {
                date = new Date(System.currentTimeMillis());
                System.out.println("Request Out time : " + date);
            }
        } 
        else 
        {
            if (initTokenPayload != null && initTokenPayload.trim().length()>0) 
            { 
                String tokenPayload = initTokenPayload.replace("Bearer ", "");
                log.println("JWT Generated Token:" + tokenPayload);
                token = null;
                log.println("Kong Gateway Request :" + countryCodeFromRequest);
                List<RSAPublicKey> publicKeys = AuthenticationInitializer.getAllKeys();
                log.println("Public keys size :" + (publicKeys !=null? publicKeys.size():0));
                log.println("Public keys size :" + (publicKeys !=null? Arrays.toString(publicKeys.toArray()):"Empty public key list"));
                for (RSAPublicKey publicKey : publicKeys)
                {
                    try 
                    {
                        exceptionFlag = false;
                        log.println("KONG Public Key : " + publicKey);
                        BearerTokenValidator validator = new BearerTokenValidator(() -> publicKey);
                        token = validator.parse(tokenPayload);
                        log.println("KONG Validated Token::::" + token);
                        break;
                    }
                    catch (InvalidBearerTokenException ex) 
                    {
                        exceptionFlag = true;
                        log.println("Error in validating the JWT using one particlar public key from KONG gateway");
                    }
                }
            } 
            else 
            {
                exceptionFlag = true;
            }
            try 
            {
                if (!exceptionFlag) 
                {
                    date = new Date(System.currentTimeMillis());
                    System.out.println("Request In Time  ::: "+ date);
                    filterChain.doFilter(request, response);
                } 
                else 
                {
                    exceptionReasonInJson = "{\"message\": \"JWT is invalid or incorrect or empty\"}";
                    statusCode = 401;
                    ExceptionUtility.printException(exceptionReasonInJson, response, statusCode);
                }
            }
            catch (Exception e) 
            {
            	log.printErrorMessage(e);

            } 
            finally 
            {
                date = new Date(System.currentTimeMillis());
                System.out.println("Response Out Time : " + date);
                token = null;
            }
        }
        System.out.println("Exiting CLM Filter");
    }
}