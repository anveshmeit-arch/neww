package com.scb.clm.common.db.support;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;

import org.apache.hc.core5.ssl.SSLContextBuilder;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ProcessException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.security.KeyStore;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;



public class HashiCorpImplementation 
{

    private static final String KEYSTORE_INSTANCE_TYPE = "JKS";

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    public static HashMap<String, String> getDBPassword(HashMap<String, String> argRequestInfo) throws ProcessException 
    {
        String dbPassword = "";
        HashMap<String, String> dbDetails = new HashMap<String, String>();

        System.out.println("Request_For_Token_" + argRequestInfo.get("tokenURL"));
        String gettokenurl = argRequestInfo.get("tokenURL");
        String str = new String("{\"name\":" + "\"" + argRequestInfo.get("icm_cert") + "\"}");

        KeyStore keyStore = null;
        File keyFiles = null;
        FileInputStream keyStream  = null;

        BufferedReader br = null;
        try
        {
            keyStore = KeyStore.getInstance(KEYSTORE_INSTANCE_TYPE);
            keyFiles = new File(argRequestInfo.get("keyStorePath"));
            keyStream = new FileInputStream(keyFiles);
            keyStore.load(keyStream,argRequestInfo.get("keyStoreCredentials").toCharArray());

            SSLContext sslContext = SSLContextBuilder
                    .create()
                    .loadTrustMaterial(new File(argRequestInfo.get("trustStorePath")), argRequestInfo.get("truststoreCredential").toCharArray())
                    .loadKeyMaterial(keyStore,argRequestInfo.get("keyStoreCredentials").toCharArray())
                    .build();

            HttpsURLConnection connection = (HttpsURLConnection) new URL(gettokenurl).openConnection();
            connection.setSSLSocketFactory(sslContext.getSocketFactory());
            connection.setRequestMethod("POST");
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            connection.setRequestProperty("Accept", "application/json");

            OutputStream os = connection.getOutputStream();
            os.write(str.getBytes());
            os.flush(); 

            if (connection.getResponseCode() >= 300) {

                throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL, BaseConstants.CLM_GENERIC_ERROR," # HTTP Response Code # "+connection.getResponseCode());
            }

            br = new BufferedReader(new InputStreamReader((connection.getInputStream())));

            String output;
            StringBuffer response =  new StringBuffer();

            while ((output = br.readLine()) != null) 
            {
                response.append(output);
            }

            JSONParser postparser = new JSONParser();
            JSONObject postjsonobj = (JSONObject) postparser.parse(response.toString());
            JSONObject postrootObj = (JSONObject) postjsonobj.get("auth");
            String clientToken = new String(postrootObj.get("client_token").toString());
            System.out.println("Client Access Token generated in Hashicorp "+ clientToken);
            StringBuffer passwordResponse = null;
            try 
            {
                passwordResponse = getDBPassword(argRequestInfo,clientToken);
                System.out.println("Success_For_Password_"+argRequestInfo.get("passwordURL"));
            }
            catch (Exception exception) 
            {
                System.out.println("All_Retry_Failed For Token :"+clientToken);
                throw exception;
            }
            JSONParser getparser = new JSONParser();
            JSONObject getjsonobj = (JSONObject) getparser.parse(passwordResponse.toString());
            JSONObject getrootObj = (JSONObject) getjsonobj.get("data");
            String dbUserName = getrootObj.get("username").toString();
            dbPassword = getrootObj.get("password").toString();
            System.out.println("DB UserName is :" + dbUserName);
            dbDetails.put("PWD", dbPassword);
            dbDetails.put(BaseConstants.DB_USER_ID, dbUserName);

            String lastVaultRotation = getrootObj.get("last_vault_rotation").toString();
            String ttl = getrootObj.get("ttl").toString();
            System.out.println("TTL Value: " + ttl);

            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

            Date lastVaultRotationDate = formatter.parse(lastVaultRotation);
            String actualLastVaultRotationDateAsString = formatter.format(lastVaultRotationDate);

            Calendar before = Calendar.getInstance();
            before.setTime(formatter.parse(actualLastVaultRotationDateAsString));

            if (argRequestInfo.get("NextRotationDays") != null && argRequestInfo.get("NextRotationDays").trim().length() > 0) {
                before.add(Calendar.DATE, Integer.parseInt(argRequestInfo.get("NextRotationDays")));
            }

            if (argRequestInfo.get("NextRotationHours") != null && argRequestInfo.get("NextRotationHours").trim().length() > 0) {
                before.add(Calendar.HOUR, Integer.parseInt(argRequestInfo.get("NextRotationHours")));
            }

            String nextRotationDateWithIncremental = formatter.format(before.getTime());
            before.setTime(formatter.parse(nextRotationDateWithIncremental));
            before.add(Calendar.MINUTE, Integer.parseInt(argRequestInfo.get("WhenToInvokeHC")));

            String startTime = formatter.format(before.getTime());
            dbDetails.put("HC_INVOKE_START_TIME", startTime);
            String currentPwd = argRequestInfo.get("currentPassword");

            if (currentPwd != null && currentPwd.equals(dbPassword)) {
                dbDetails.put("isPWDRotated", "N");
            } 
            else 
            {
                System.out.println("Password Changed:");
                try 
                {
                    CryptoEncrypter.getInstance().encyptHCDBPwd(argRequestInfo.get("appID"), argRequestInfo.get("companyID"),dbPassword,argRequestInfo.get("certificatePath"));
                }
                catch(Exception e) 
                {
                    System.out.println("# FATAL Exception # "+e.getMessage());
                }
                dbDetails.put("isPWDRotated","Y");
            }

            System.out.println("# Last_vault_rotation_From_Vault: # " + lastVaultRotation);
            System.out.println("# Last_vault_rotation_date_As_String: #" + actualLastVaultRotationDateAsString);
            System.out.println("# Next_vault_rotation_date_As_String: #" + startTime);
            System.out.println("# Success_For_Token_"+argRequestInfo.get("tokenURL"));
            return dbDetails;
        } 
        catch (Exception e) 
        {
            System.out.println("# Exception # Retrying_Both_API:"+e.getMessage());
            if (argRequestInfo.get("Token_Retry") == null) 
            {
                argRequestInfo.put("Token_Retry", "2");
                System.out.println(":Failed_For_Token_" + argRequestInfo.get("tokenURL") + " And Retry Of " + argRequestInfo.get("Token_Retry") + " Out Of 3");
                getDBPassword(argRequestInfo);
            }
            else if (argRequestInfo.get("Token_Retry") != null && Integer.parseInt(argRequestInfo.get("Token_Retry")) <= 2) 
            {
                int value = Integer.parseInt(argRequestInfo.get("Token_Retry")) + 1;
                argRequestInfo.put("Token_Retry", Integer.toString(value));
                System.out.println(":Failed_For_Token_" + argRequestInfo.get("tokenURL") + " And Retry Of " + argRequestInfo.get("Token_Retry") + "Out Of 3");
                getDBPassword(argRequestInfo);
            } 
            else 
            {
                System.out.println("All Access Token Retry Failed");
                throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL, BaseConstants.CLM_GENERIC_ERROR," Password Exception - "+e.getMessage());
            }
        }
        finally
        {
            try {
                br.close();
            }
            catch(Exception e) {
                throw new ProcessException(BaseConstants.ERROR_TYPE_TECHNICAL, BaseConstants.CLM_GENERIC_ERROR," Unable to Close Stream - "+e.getMessage());
            }
        }
        return null;
    }

    /**
     * <Description>
     * <p> 
     * <p> 
     *  
     * @param 
     * @return
     * @exception
     * @see
     * @since
     */
    protected static StringBuffer getDBPassword(HashMap<String, String> argRequestInfo, String clientToken) throws Exception 
    {
        KeyStore keyStore = null;
        File keyFiles = null;
        FileInputStream keyStream  = null;
        StringBuffer response = null;
        BufferedReader in = null;

        try 
        {
            System.out.println("Request_For_Password_" + argRequestInfo.get("passwordURL"));

            keyStore = KeyStore.getInstance(KEYSTORE_INSTANCE_TYPE);
            keyFiles = new File(argRequestInfo.get("keyStorePath"));
            keyStream = new FileInputStream(keyFiles);

            keyStore.load(keyStream,argRequestInfo.get("keyStoreCredentials").toCharArray());

            SSLContext sslContext = SSLContextBuilder
                    .create()
                    .loadTrustMaterial( new File(argRequestInfo.get("trustStorePath")), argRequestInfo.get("truststoreCredential").toCharArray())
                    .loadKeyMaterial(keyStore,argRequestInfo.get("keyStoreCredentials").toCharArray())
                    .build();

            HttpsURLConnection connection = (HttpsURLConnection) new URL(argRequestInfo.get("passwordURL")).openConnection();
            connection.setRequestMethod("GET");
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("X-Vault-Token", clientToken);
            connection.setRequestProperty("X-Vault-Forward", "active-node");

            connection.setSSLSocketFactory(sslContext.getSocketFactory());
            int responseCode = connection.getResponseCode();
            System.out.println("GET Response Code :: " + responseCode);
            if (responseCode == HttpsURLConnection.HTTP_OK) 
            { // success
                in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String inputLine;
                response = new StringBuffer();
                while ((inputLine = in.readLine()) != null) 
                {
                    response.append(inputLine);
                }
            }
            else 
            {
                System.out.println("GET request not worked");
            }
            return response;
        } 
        catch (Exception e)
        {
            System.out.println("Exception "+e.getMessage());
            if (argRequestInfo.get("Pwd_Retry") == null) 
            {
                argRequestInfo.put("Pwd_Retry", "2");
                System.out.println(":Failed_For_Password:" + clientToken + " And Retry Of " + argRequestInfo.get("Pwd_Retry") + " Out Of 3");
                return getDBPassword(argRequestInfo,clientToken);
            }
            else if (argRequestInfo.get("Pwd_Retry") != null && Integer.parseInt(argRequestInfo.get("Pwd_Retry")) <= 2) 
            {
                int value = Integer.parseInt(argRequestInfo.get("Pwd_Retry")) + 1;
                argRequestInfo.put("Pwd_Retry", Integer.toString(value));
                System.out.println(":Failed_For_Password:" + clientToken + " And Retry Of " + argRequestInfo.get("Pwd_Retry") + " Out Of 3");
                return getDBPassword(argRequestInfo,clientToken);
            } 
            else 
            {
                System.out.println("ALL_RETRY_FOR_PASSWORD FAILED "+clientToken);
                throw e;
            }
        }
        finally
        {
            if(in!=null) {
                in.close(); 
            }
        }
    }

}
