package com.scb.clm.common.config;

/*
 * 
 * @author     1378958 
 * @version    1.0
 * @since      
 * @use        Base Constants  
 */
public class BaseConstants
{  
    /* ERROR TYPE CONSTANTS */
    public static final String APPLICATION_NAME                       = "ICM"; 

    public static final String GLOBUS                                 = "GLOBUS";
    public static final String UJ                                     = "UJ";
    public static final String MULES                                  = "MULES";

    public static final String ERROR_TYPE_TECHNICAL                   = "TEC";
    public static final String ERROR_TYPE_BUSINESS                    = "BUS";
    public static final String ERROR_TYPE_VALIDATION                  = "VAL";
    public static final String ERROR_TYPE_PROCESSING                  = "PRO";    

    public static final String APP_CONFIG_PATH                        = "AppConfig.xml";
    public static final String APP_PROPERTY_FILE_PATH                 = "/System_Properties.xml";

    public static final String CODE_SETUP_ACTIVE                      = "1";
    public static final String DATABASE_GROUP_CNTRY_PARAM             = "DATABASE";
    public static final String DATABASE_TYPE                          = "DATABASE_TYPE";
    public static final String ORACLE                                 = "O";
    public static final String POSTGRES                               = "P";

    /* ERROR INFORMATION CONSTANTS */
    public static final String CLM_GENERIC_ERROR                      = "GB000000";
    public static final String CLM_REQUEST_ERROR                      = "GB000001";
    public static final String VALIDATION_ERROR                       = "GB000002";   
    public static final String APP_INSTANCE_ERROR                     = "GB000003";

    public static final String INVALID_HEADER_COUNTRY_CODE            = "GB000004";
    public static final String INVALID_HEADER_INTERFACE_ID            = "GB000005";
    public static final String INVALID_HEADER_TRANSACTION_ID          = "GB000006";
    public static final String INVALID_HEADER_APPLICATION_REFERENCE   = "GB000007";
    public static final String INVALID_API_VERSION                    = "GB000008";

    public static final String INVALID_INTERFACE_ID                   = "GB000009";
    public static final String INVALID_INTERFACE_REQUEST_TYPE         = "GB000010";
    public static final String INVALID_INTERFACE_REQUEST_JSON         = "GB000011";

    public static final String INVALID_REQUEST_FORMAT                 = "GB000012";

    public static final String CLM_DB_LOGGING_ERROR                   = "GB000013";

    //ORCHESTRATION LAYER ERROR CONSTANTS
    public static final String SERVICE_PROGRAM_NOT_CONFIGURED         = "GB000013";
    public static final String SERVICE_THREAD_ADVISOR_ERROR           = "GB000014";
    public static final String CLM_NO_FLOW_CONFIGURED                 = "GB000015";
    public static final String INVALID_FLOW_IDENTIFIER                = "GB000016";

    public static final String ERROR_IN_PATH_IDENTIFIER_SPECIAL_PROGRAM  = "GB000017";
    public static final String GENERAL_EXCEPTION_PATH_IDENTIFIER         = "GB000017";

    //CLM API HEADER CONSTANTS
    public static final String SERVICE_API_HEADER_COUNTRY_CODE              = "countrycode";    //DBT
    public static final String SERVICE_API_HEADER_INTERFACE_ID              = "interfaceid";    //DBT    
    public static final String SERVICE_API_HEADER_ORIGINAL_TRANSACTION_ID   = "originaltransactionid";
    public static final String SERVICE_API_HEADER_TRANSACTION_ID            = "transactionid";
    public static final String SERVICE_API_HEADER_DUPLICATE_FLAG            = "duplicateflag";

    
    // API HEADER CONSTANTS
    public static final String API_HEADER_COUNTRY_CODE                = "country-code";
    public static final String API_HEADER_COUNTRYCODE                 = "countrycode";
    public static final String API_HEADER_INTERFACE_ID                = "interface-id";
    public static final String API_HEADER_MESSSAGE_SENDER             = "message-sender";
    public static final String API_HEADER_TRANSACTION_ID              = "transaction-id";
    public static final String API_HEADER_ORIGINAL_TRANSACTION_ID     = "original-transaction-id";
    public static final String API_HEADER_APPLICATION_REFERENCE_ID    = "application-reference-id";
    public static final String API_HEADER_DUPLICATE_FLAG              = "duplicate-flag";
    public static final String API_HEADER_REQUEST_TYPE                = "";
    public static final String CONTENT_TYPE                           = "Content-Type";
    public static final String AUTHORIZATION_HEADER                   = "Authorization";
    public static final String GATEWAY                                = "GATEWAY";
    public static final String ACCEPT                                 = "accept";
    public static final String SCOPE                                  = "scope";
    public static final String CLIENT_NAME                            = "50403_globus_user_GLOBUS";

    public static final String API_IDENTITY_USER                      = "50403_globus_user";
    public static final String API_GRANT_TYPE                         = "grant_type";
    public static final String CLIENT_CREDENTIALS                     = "client_credentials";
    public static final String WS02_IDENTITY_USER                     = "WSO2-Identity-User";
    public static final String CLIENT_ID                              = "client_id";
    public static final String CLIENT_SECRET                          = "client_secret";
    public static final String GET_REQUEST                            = "GET";
    public static final String POST_REQUEST                           = "POST";
    public static final String AUTHORIZATION_HEADER_BASIC             = "Basic ";
    public static final String ICM_DEDUP_URL                          = "ICM_DEDUP_URL";
    public static final String ICM_CUSTOMERCREATE_URL                 = "ICM_CUSTOMERCREATE_URL";
    public static final String ICM_SCOPE                              = "ICMService";
    public static final String ICM_CONTENT_TYPE                       = "application/vnd.api+json";
    public static final String ICDD_SCOPE                             = "ICDDService_Initiate";
    public static final String ICDDSERVICE                            = "ICDDService";
	public static final String MULE_SCOPE                            = "MuleService";
    public static final String POST_PROTOCOL                          = "POST";
    public static final String PATCH_PROTOCOL                         = "PATCH";
    public static final String GATEWAY_PUBLIC_KEY_URL                 = "GATEWAY_PUBLIC_KEY_URL";
    
    // DATABASE CONSTANTS
    public static final String DB_PW                                  = "DB_PASSWORD";
    public static final String DB_USER_ID                             = "DB_USER_ID";
    public static final String ORACLE_DRIVER                          = "oracle.jdbc.OracleDriver";
    public static final String POSTGRES_DRIVER                        = "org.postgresql.Driver";
    public static final String JDBC_URL                               = "JDBC_URL";
    public static final String DB_SCHEMA_ID                           = "DB_SCHEMA_ID";
    public static final String DB_DRIVER                              = "DB_DRIVER";

    public static final String REQUEST_REGION                         = "region";
    public static final String REQUEST_METHOD_GET                     = "GET";

    public static final int    HTTP_200                               = 200;
    public static final int    HTTP_400                               = 400;
    public static final int    HTTP_500                               = 500;
	public static final String    NOT_ATTEMPTED                               = "X";

    public static final char   HTTP_4XX_SERIES                        = '4';
    public static final char   HTTP_5XX_SERIES                        = '5';
    
    //NODE CONSTANTS
    public static final String NODE_SUCCESS                           = "S";  
    public static final String NODE_FAILURE                           = "F";  

    //SERVICE CONSTANTS
    public static final String SERVICE_SUCCESS                        = "S";  
    public static final String SERVICE_FAILURE                        = "F";  
    public static final String INERFACE_ICM                           = "ICM";
    public static final String SERVICE_DEDUP                          = "SDEDUP";

    //***************** ASYNC CONFIGURATIONS ****************
    public static final String ASYNC_CORE_POOL_SIZE                   = "ASYNC_CORE_POOL_SIZE";
    public static final String ASYNC_MAX_POOL_SIZE                    = "ASYNC_MAX_POOL_SIZE";
    public static final String ASYNC_QUEUE_CAPACITY                   = "ASYNC_QUEUE_CAPACITY";
    //***************** ASYNC CONFIGURATIONS ****************

  

    public static final String INTERNAL_PROCESSING_ERROR              = "GB000006";

    public static final String ONBOARD_FLOW                           = "FONBRD";

    public static final String ONBOARD_CREATEICM_SRV                  = "FONBRD-NCRICM-SCRICM";
    public static final String ONBOARD_CREATECDD_SRV                  = "FONBRD-NCRCDD-SCRCDD";
    public static final String ONBOARD_MULE_SRV                       = "FONBRD-NMULES-SMULES";
    public static final String INVALID_APPLICATION_REFERENCE_NUMBER         = "PR000008";


    public static final String HTTP_GET                               = "GET";
    public static final String HTTP_POST                              = "POST";
    public static final String HTTP_PUT                               = "PUT";
    public static final String HTTP_PATCH                             = "PATCH";
    public static final String HTTP_DELETE                            = "DELETE";

}