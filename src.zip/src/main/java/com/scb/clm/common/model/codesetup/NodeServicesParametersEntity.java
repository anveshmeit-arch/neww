package com.scb.clm.common.model.codesetup;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/*
 * 
 * @author       1378958
 * @version      1.0
 * @since           
 * @use          
 */
@Entity
@Table(name = "CLM_NODE_SERVICE_PARAMETERS")
public class NodeServicesParametersEntity implements Cloneable
{
    @EmbeddedId
    private NodeServicesParametersEntityKey id;

    @Column(name="PARAM_CODE")
    private String paramCode;

    @Column(name="PARAM_VALUE")
    private String paramValue;
    
    @Column(name="STATUS_FLAG")
    private String statusFlag;

    @ManyToOne
    @JoinColumns({
        @JoinColumn(name="COUNTRY_CODE", referencedColumnName="COUNTRY_CODE", insertable= false, updatable= false),
        @JoinColumn(name="FLOW_ID", referencedColumnName="FLOW_ID",insertable= false, updatable=false), 
        @JoinColumn(name="NODE_ID", referencedColumnName="NODE_ID",insertable= false, updatable=false),
        @JoinColumn(name="SERVICE_ID", referencedColumnName="SERVICE_ID",insertable= false, updatable=false)
    })
    private NodeServicesEntity nodeServicesMapper;

    public NodeServicesParametersEntity() {

    }

    public NodeServicesParametersEntityKey getId() {
        return id;
    }

    public void setId(NodeServicesParametersEntityKey id) {
        this.id = id;
    }

    public String getParamCode() {
        return paramCode;
    }

    public void setParamCode(String paramCode) {
        this.paramCode = paramCode;
    }

    public String getParamValue() {
        return paramValue;
    }

    public void setParamValue(String paramValue) {
        this.paramValue = paramValue;
    }

    public String getStatusFlag() {
        return statusFlag;
    }

    public void setStatusFlag(String statusFlag) {
        this.statusFlag = statusFlag;
    }

}



