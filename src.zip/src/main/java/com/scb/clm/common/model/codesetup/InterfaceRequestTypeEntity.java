package com.scb.clm.common.model.codesetup;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/*
 * 
 *  @author      1378958
 *  @version     1.0
 *  @since       
 *  @use         
 */
@Entity
@Table(name = "CLM_INTERFACE_REQUEST_TYPES")
public class InterfaceRequestTypeEntity implements Cloneable
{
    @EmbeddedId
    private InterfaceRequestTypeEntityKey id;

    @Column(name="INBOUND_OUTBOUND_FLAG")
    private String inBoundOutBoundFlag;

    @Column(name="FLOW_ID")
    private String flowIdentifier;

    @Column(name="REQUEST_URL")
    private String requestUrl;

    @Column(name="STATUS_FLAG")
    private String statusFlag;

    @ManyToOne
    @JoinColumns({
        @JoinColumn(name="COUNTRY_CODE", referencedColumnName="COUNTRY_CODE", insertable= false, updatable= false),
        @JoinColumn(name="INTERFACE_ID", referencedColumnName="INTERFACE_ID",insertable= false, updatable=false)
    })
    private InterfaceEntity interfaceMapper;

    public InterfaceRequestTypeEntity() {

    }

    public InterfaceRequestTypeEntityKey getId() {
        return id;
    }

    public void setId(InterfaceRequestTypeEntityKey id) {
        this.id = id;
    }

    public String getInBoundOutBoundFlag() {
        return inBoundOutBoundFlag;
    }

    public void setInBoundOutBoundFlag(String inBoundOutBoundFlag) {
        this.inBoundOutBoundFlag = inBoundOutBoundFlag;
    }

    public String getFlowIdentifier() {
        return flowIdentifier;
    }

    public void setFlowIdentifier(String flowIdentifier) {
        this.flowIdentifier = flowIdentifier;
    }

    public String getRequestUrl() {
        return requestUrl;
    }

    public void setRequestUrl(String requestUrl) {
        this.requestUrl = requestUrl;
    }

    public String getStatusFlag() {
        return statusFlag;
    }

    public void setStatusFlag(String statusFlag) {
        this.statusFlag = statusFlag;
    }

}
