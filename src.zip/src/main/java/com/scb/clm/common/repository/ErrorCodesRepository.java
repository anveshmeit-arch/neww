package com.scb.clm.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.scb.clm.common.model.codesetup.ErrorCodesEntity;
import com.scb.clm.common.model.codesetup.ErrorCodesEntityKey;

@Repository
public interface ErrorCodesRepository extends JpaRepository<ErrorCodesEntity, ErrorCodesEntityKey> 
{ 
    public <S extends ErrorCodesEntity> S save(S entity);

    @Override
    public ErrorCodesEntity getOne(ErrorCodesEntityKey arg0);

}