package com.scb.clm.common.util;

import java.util.HashMap;
import java.util.Map;

import com.scb.clm.common.framework.logger.LogThreadMapContext;

public class ModuleThreadMapContext implements ModuleContext {

    private  HashMap<Thread, Map<?, ?>> moduleHashMap = new HashMap<Thread, Map<?, ?>>();
    private static volatile ModuleThreadMapContext singleton = null;

    private ModuleThreadMapContext(){
        moduleHashMap = new HashMap<Thread, Map<?, ?>>(); 
    }
    public static synchronized ModuleThreadMapContext getInstance(){
        return (singleton != null ? singleton : (singleton = new ModuleThreadMapContext()) );
    }

    public void setModuleCache(HashMap<?, ?> hashMap) {
        synchronized (moduleHashMap) {
            moduleHashMap.put(Thread.currentThread(), hashMap);
        }
    }
    public HashMap<?, ?> getModuleCache() {
        synchronized (moduleHashMap) {
            return  (HashMap<?, ?>)moduleHashMap.get(Thread.currentThread());
        }
    }
    public void removeModuleCache() {
    	LogThreadMapContext.getInstance().removeLogger();
        if (moduleHashMap.containsKey(Thread.currentThread())){
            synchronized (moduleHashMap) {
                moduleHashMap.remove(Thread.currentThread());
            }
        }
    }


}