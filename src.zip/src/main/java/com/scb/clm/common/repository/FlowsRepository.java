package com.scb.clm.common.repository;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.scb.clm.common.model.codesetup.FlowsEntity;
import com.scb.clm.common.model.codesetup.FlowsEntityKey;

@Repository
public interface FlowsRepository extends JpaRepository<FlowsEntity, FlowsEntityKey>
{

    @Override
    public <S extends FlowsEntity> S save(S entity);

    @Override
    @Cacheable("Flows")
    public FlowsEntity getOne(FlowsEntityKey arg0);

    @Cacheable("FlowsByPathIdentifier")
    FlowsEntity findByIdCountryCodeAndPathIdentifierAndStatusFlag(String countryCode,  String pathIdentifier,String statusFlag); 

    @Cacheable("FlowsByStatusFlag")
    FlowsEntity findByIdCountryCodeAndIdFlowIdentifierAndStatusFlag(String countryCode,  String flowIdentifier,String statusFlag); 
}