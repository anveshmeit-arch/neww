package com.scb.clm.common.util;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

/*
 *   @author     1378958
 *   @version    1.0
 *   @since      
 *   @use        
 */
public class WrapperUtility 
{

    /**
     *
     *
     * @param
     * @return
     * @exception
     * @see
     * @since 
     */
    public static String[] cloneData(String[] value)
    {
        return (value==null)?null:Arrays.copyOf(value,value.length,String[].class);
    }

    /**
     *
     *
     * @param
     * @return
     * @exception
     * @see
     * @since 
     */
    public static Timestamp cloneData(Timestamp value)
    {
        return (value == null)?null:(Timestamp)value.clone();
    }

    /**
     *
     *
     * @param
     * @return
     * @exception
     * @see
     * @since 
     */
    public static java.util.Date cloneData(java.util.Date value)
    {
        return (value == null)?null:(java.util.Date)value.clone();
    }

    /**
    *
    *
    * @param
    * @return
    * @exception
    * @see
    * @since 
    */
   public static java.sql.Date cloneData(java.sql.Date value)
   {
       return (value == null)?null:(java.sql.Date)value.clone();
   }
   
    /**
     *
     *
     * @param
     * @return
     * @exception
     * @see
     * @since 
     */
    public static byte[] cloneData(byte[] obj)
    {
        return (obj == null)?null:(byte[])obj.clone();
    }


    /**
     *
     *
     * @param
     * @return
     * @exception
     * @see
     * @since 
     */  
    public static<K, V> Map<K, V> cloneData(Map<K, V> originalmap)  
    {  
        return (originalmap==null)?null:originalmap.entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));  
    }
}
