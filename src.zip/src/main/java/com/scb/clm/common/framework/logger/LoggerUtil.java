package com.scb.clm.common.framework.logger;

import java.io.File;
import java.util.Arrays;

import org.apache.logging.log4j.Level;
//import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.MarkerManager;
import org.apache.logging.log4j.ThreadContext;
import org.apache.logging.log4j.spi.AbstractLogger;
import org.apache.logging.log4j.spi.ExtendedLogger;
import org.apache.logging.log4j.spi.ExtendedLoggerWrapper;

import com.scb.clm.common.config.BaseConstants;

//import scb.technical.integration.service.util.SystemServiceProvider;

public class LoggerUtil  extends ExtendedLoggerWrapper{

	/**
	 * 
	 */
	 private static final long serialVersionUID = 428256471773800L;
	    private final ExtendedLoggerWrapper logger;
	   
	private static final String FQCN = LoggerUtil.class.getName();
	
	public static final Marker CONSOLE = MarkerManager.getMarker(LogType.CONSOLE.toString());
	public static final Marker APPLICATION = MarkerManager.getMarker(LogType.APPLICATION.toString());
	public static final Marker SECURITY = MarkerManager.getMarker(LogType.SECURITY.toString());
	public static final Marker ERROR = MarkerManager.getMarker(LogType.ERROR.toString());
	public static final Marker TRANSACTION = MarkerManager.getMarker(LogType.TRANSACTION.toString());
	public static final Marker AUDIT = MarkerManager.getMarker(LogType.AUDIT.toString());
	public static final Marker SYSTEM = MarkerManager.getMarker(LogType.SYSTEM.toString());
	
	private String componentName;
	private String className;
	private String methodName;

	private String fileName;
	private String spclFileName;

	private String companyID;
	private String appID;
	private String messageID;
	private String serviceID;
	private String nativeSystem;
	private String userID;
	private String userBranch;
	private String userIPAddress;
	private String trackingId;
	//public Logger logger;
	public Marker marker;
	
	
    private LoggerUtil(Logger logger,String appName,String countryCode) {
        super((ExtendedLogger) logger, logger.getName(), logger.getMessageFactory());
        System.setProperty("LOGGING_MANAGER","java.util.logging.manager=org.apache.logging.log4j.jul.LogManager");
        System.setProperty("log4j.configurationFile", "log4j2.xml");
        System.setProperty("log4j2.contextSelector", "org.apache.logging.log4j.core.async.AsyncLoggerContextSelector");
        this.logger = this;
   	 	this.companyID = countryCode;
   	 	this.appID = appName;
   	 	this.componentName = System.getProperty("serviceName");
   	 	this.className = logger.getName();
   	 	//this.methodName = methodName;
   	 	this.fileName  = BaseConstants.APPLICATION_NAME+"-"+System.getProperty("serviceName")+"_"+APPLICATION.getName();
   	 	this.setMarker(APPLICATION);
        createLog();
    }
	
	private LoggerUtil(Logger logger,String componentName, String className, String methodName, String companyID, String interfaceID, String requestType, String appID) {
		 super((ExtendedLogger) logger, logger.getName(), logger.getMessageFactory());
		 	this.logger = this;
		 	System.setProperty("log4j.configurationFile", "log4j2.xml");
		 	System.setProperty("log4j2.contextSelector", "org.apache.logging.log4j.core.async.AsyncLoggerContextSelector");
			this.companyID = companyID;
			this.appID = appID;
			this.nativeSystem = interfaceID;
			this.messageID = requestType;
			this.fileName  = BaseConstants.APPLICATION_NAME+"-"+System.getProperty("serviceName")+"_"+APPLICATION.getName();
			this.componentName = componentName;
			this.className = className;
			this.methodName = methodName;
			//this.setSpclFileName("common");
			this.setMarker(APPLICATION);
			createLog();
	}

	private LoggerUtil(ExtendedLogger logger, String componentName, String className, String methodName, String spclFileName) {
		 super(logger, logger.getName(), logger.getMessageFactory());
		 this.logger = this;
		 System.setProperty("log4j.configurationFile", "log4j2.xml");
		 System.setProperty("log4j2.contextSelector", "org.apache.logging.log4j.core.async.AsyncLoggerContextSelector");
		 this.companyID = LoggerDataProvider.getCompanyID();
		 this.appID = LoggerDataProvider.getApplicationID();
		 
		 this.componentName = componentName;
		 this.className = className;
		 this.methodName = methodName;
		 
		 this.setSpclFileName(spclFileName);
		 //this.fileName = spclFileName;
			if (!MarkerManager.exists(spclFileName)) {
				this.fileName = spclFileName;
				this.setMarker(TRANSACTION);
			}else {
				//log.fileName = spclFileName;
				this.fileName  = BaseConstants.APPLICATION_NAME+"-"+System.getProperty("serviceName")+"_"+spclFileName;
				this.setMarker(MarkerManager.getMarker(spclFileName));
			}
		 
			if(LoggerDataProvider.getServiceContext()!=null){
				this.nativeSystem = LoggerDataProvider.getInterfaceID();
				this.messageID = LoggerDataProvider.getRequestType();
				this.serviceID = LoggerDataProvider.getServiceID();
				this.trackingId = LoggerDataProvider.getUUID();
			}
			
		 createLog();
	}
   
	private LoggerUtil(ExtendedLogger logger, String componentName, String className,  String spclFileName) {
		 super(logger, logger.getName(), logger.getMessageFactory());
		 this.logger = this;
		 System.setProperty("log4j.configurationFile", "log4j2.xml");
		 System.setProperty("log4j2.contextSelector", "org.apache.logging.log4j.core.async.AsyncLoggerContextSelector");
		 this.companyID = LoggerDataProvider.getCompanyID();
		 this.appID = LoggerDataProvider.getApplicationID();
		 
		 this.componentName = componentName;
		 this.className = className;
		// this.methodName = methodName;
		 
		 this.setSpclFileName(spclFileName);
		 //this.fileName = spclFileName;
			if (!MarkerManager.exists(spclFileName)) {
				this.fileName = spclFileName;
				this.setMarker(TRANSACTION);
			}else {
				//log.fileName = spclFileName;
				this.fileName  = BaseConstants.APPLICATION_NAME+"-"+System.getProperty("serviceName")+"_"+spclFileName;
				this.setMarker(MarkerManager.getMarker(spclFileName));
			}
		 
			if(LoggerDataProvider.getServiceContext()!=null){
				this.nativeSystem = LoggerDataProvider.getInterfaceID();
				this.messageID = LoggerDataProvider.getRequestType();
				this.serviceID = LoggerDataProvider.getServiceID();
				this.trackingId = LoggerDataProvider.getUUID();
			}
			
		 createLog();
	}
	
    public static LoggerUtil getInstance(final Class<?> loggerName,String appName,String countryCode) {
       
    	LoggerUtil log =null;
		synchronized (LoggerUtil.class) {
			log = LogThreadMapContext.getInstance().getLogger();
			
			if (log == null) {
				Logger wrapped = (Logger) LogManager.getLogger(loggerName);
				log = new LoggerUtil(wrapped, appName, countryCode);
				LogThreadMapContext.getInstance().setLogger(log);
			}
		}
    	
        return log;
    }
    
	public static LoggerUtil getInstance (String componentName, final Class<?> className, String logType) {
		LoggerUtil log =null;
		synchronized (LoggerUtil.class) {
			log = LogThreadMapContext.getInstance().getLogger();
			
			if (log == null) {
				//Logger wrapped = LogManager.getLogger("common");
				ExtendedLogger wrapped = (ExtendedLogger) LogManager.getContext(false).getLogger(className.getName());
				log = new LoggerUtil(wrapped,componentName,className.getName(),logType);
				LogThreadMapContext.getInstance().setLogger(log);
			}
		}

		log.componentName = componentName;
		log.className = className.getName();
		//log.methodName = methodName;
		return log;
	}



	public static LoggerUtil getInstance (String componentName, String className, String methodName) {
		LoggerUtil log =null;
		synchronized (LoggerUtil.class) {
			log = LogThreadMapContext.getInstance().getLogger();
			
			if (log == null) {
				//Logger wrapped = LogManager.getLogger("common");
				ExtendedLogger wrapped = (ExtendedLogger) LogManager.getContext(false).getLogger(APPLICATION.getName());
				log = new LoggerUtil(wrapped,componentName,className,methodName,APPLICATION.getName());
				LogThreadMapContext.getInstance().setLogger(log);
			}
		}

		log.componentName = componentName;
		log.className = className;
		log.methodName = methodName;
		return log;
	}
	
	
	public static LoggerUtil getInstance (String componentName, String className, String methodName,String companyID, String interfaceID, String requestType,String appID) {
		LoggerUtil log =null;
		synchronized (LoggerUtil.class) {
			log = LogThreadMapContext.getInstance().getLogger();
			if (log == null) {
				//Logger wrapped = LogManager.getLogger("common");
				ExtendedLogger wrapped = (ExtendedLogger) LogManager.getContext(true).getLogger(APPLICATION.getName());
				log = new LoggerUtil(wrapped,componentName,className,methodName,companyID,interfaceID,requestType,appID);
				LogThreadMapContext.getInstance().setLogger(log);
			}
		}
		log.componentName = componentName;
		log.className = className;
		log.methodName = methodName;
		return log;
	}

	public static LoggerUtil getInstance (String componentName, String className, String methodName, String spclFileName) {
		LoggerUtil log =null;

		synchronized (LoggerUtil.class) {

			log = LogThreadMapContext.getInstance().getLogger(spclFileName);

			if (log == null) {
				ExtendedLogger wrapped = (ExtendedLogger) LogManager.getContext(true).getLogger(spclFileName);
				log = new LoggerUtil(wrapped,componentName,className,methodName,spclFileName);
				LogThreadMapContext.getInstance().setLogger(spclFileName,log);
				
			}

		}

		log.componentName = componentName;
		log.className = className;
		log.methodName = methodName;
		log.spclFileName = spclFileName;
		//System.out.println("LogType exists---> "+MarkerManager.exists(spclFileName));
		
		return log;
	}

	
	public String getSpclFileName() {
		return spclFileName;
	}
	/**
	 * @param spclFileName the spclFileName to set
	 */
	public void setSpclFileName(String spclFileName) {
		this.spclFileName = spclFileName;
	}
	/**
	 * @return the marker
	 */
	public Marker getMarker() {
		return marker;
	}

	/**
	 * @param marker the marker to set
	 */
	public void setMarker(Marker marker) {
		this.marker = marker;
	}

	private void createLog() {

		try{
			//SIMD Changes for Date/Time and Timezone
			String filePath = null;
			if (this.appID == null) {
				throw new IllegalArgumentException("ApplicationId is Null");
			}
			//java.util.Date today = new java.sql.Date(System.currentTimeMillis());
			//filePath = "C:\\Users\\1524846\\Muthu\\apps\\"+today+"\\";
			filePath = LoggerDataProvider.getSpecificLogPath();
			try {
				//LoggerContext ctx = (LoggerContext) LogManager.getContext();
				if (this.fileName == null){
					this.fileName  = BaseConstants.APPLICATION_NAME+"-"+System.getProperty("serviceName")+"_"+this.getMarker().getName();
				}
				/*if (this.fileName == null){
					if(this.messageID != null && this.nativeSystem != null) {
						this.fileName  = this.messageID+"_"+((this.serviceID == null || this.serviceID == "") ? "" :this.serviceID+"_")+this.nativeSystem+"_"+this.getMarker().getName();
					}
					else if(this.messageID== null && this.nativeSystem != null) {
						this.fileName  = ((this.serviceID == null || this.serviceID == "") ? "" :this.serviceID+"_")+this.nativeSystem+"_"+this.getMarker().getName();
					}
					else if(this.messageID!= null && this.nativeSystem == null) {
						this.fileName  = this.messageID+"_"+((this.serviceID == null || this.serviceID == "") ? "" :this.serviceID+"_")+"Common"+"_"+this.getMarker().getName();
					}
					else {
						this.fileName  = BaseConstants.APPLICATION_NAME+"-"+System.getProperty("serviceName")+"_"+this.getMarker().getName();
					}
				}*/
				
				//Json Log Testing
				ThreadContext.put("companyID", this.companyID);
				ThreadContext.put("appID", this.appID);
				ThreadContext.put("nativeSystem", this.nativeSystem);
				ThreadContext.put("journeyPath", this.messageID);
				ThreadContext.put("serviceID", this.serviceID);
				ThreadContext.put("trackingId", this.trackingId);
				ThreadContext.put("componentName", this.componentName);
				ThreadContext.put("className", this.className);
				ThreadContext.put("methodName", this.methodName);
				ThreadContext.put("userID", this.userID);
				ThreadContext.put("userIPAddress", this.userIPAddress);
				ThreadContext.put("userBranch" , this.userBranch);
				ThreadContext.put("threadName", getThreadID());
				ThreadContext.put("appLogPath", filePath);
				ThreadContext.put("loggerName", this.logger.getName());
				String threadKey = getThreadID()+this.logger.getName();
				ThreadContext.put(threadKey,filePath+File.separatorChar+this.fileName);
				//ThreadContext.put(getThreadID()+"common",filePath+File.separatorChar+this.fileName);
				
				//ctx.updateLoggers();
			} catch (Exception ex) {
				ex.printStackTrace();
					this.logger.error("LOG-ERR: EXCEPTION WHILE CREATING LOGGER :" + ex.getMessage()); // Modified for Sonar Fix
				System.out.println("LOG-ERR: EXCEPTION WHILE CREATING LOGGER ");
				//ex.printStackTrace();
			}

		}catch(Exception e){
			e.printStackTrace();
				this.logger.error("LOG-ERR: EXCEPTION WHILE CREATING LOGGER :" + e.getMessage()); // Modified for Sonar Fix
			System.out.println("LOG-ERR: EXCEPTION WHILE CREATING LOGGER ");
			//e.printStackTrace();
			
		}
	}



	public static void removeLogInstance()
	{
		synchronized (LoggerUtil.class){
			LogThreadMapContext.getInstance().removeLogger();
			//ThreadContext.fileMap.remove(Thread.currentThread().getId());
		}
	}

	public static void removeLogInstance(String fileName)
	{
		synchronized (LoggerUtil.class){
			LogThreadMapContext.getInstance().removeLogger(fileName);
			//ThreadContext.fileMap.remove(Thread.currentThread().getId());
		}
	}

	// message print at ALL Level - 0
	public void println(String var) {
		//logger.info(formatLogging(var));
		//logger.logMessage(FQCN, Level.INFO, null,logger.getMessageFactory().newMessage(var) , null);
		printMessage(Level.INFO,this.getMarker(),formatLogging(var),null);
	}
	
	public void println(String var, boolean unicode) {
		if (unicode == true) {
			var = getHexData(var);
		}
		this.logger.info(formatLogging(var));
	}

	// message print at TRACE Level - 1 printTrace

	public void printTrace(String var) {
		//logger.trace(formatLogging(var));
		printMessage(Level.INFO,this.getMarker(),formatLogging(var),null);
	}
	
	public void printTrace(String var, boolean unicode) {
		if (unicode == true) {
			var = getHexData(var);
		}
		//this.logger.trace(formatLogging(var));
		printMessage(Level.INFO,this.getMarker(),formatLogging(var),null);
	}

	// message print at DEBUG Level - 2 printDebug

	public void printDebug(String var) {
		//logger.debug(formatLogging(var));
		printMessage(Level.INFO,this.getMarker(),formatLogging(var),null);
	}
	public void printDebug(String var, boolean unicode) {
		if (unicode == true) {
			var = getHexData(var);
		}
		//this.logger.debug(formatLogging(var));
		printMessage(Level.INFO,this.getMarker(),formatLogging(var),null);
	}
	// message print at INFO Level - 3 printInfo

	public void printFatal(String var) {
		//logger.fatal(formatLogging(var));
		printMessage(Level.INFO,this.getMarker(),formatLogging(var),null);
	}

	public void printFatal(String var, boolean unicode) {
		if (unicode == true) {
			var = getHexData(var);
		}
		//this.logger.fatal(formatLogging(var));
		printMessage(Level.INFO,this.getMarker(),formatLogging(var),null);
	}

	// message print at WARN Level - 4 printWarn

	public void printWarn(String var) {
		//logger.warn(formatLogging(var));
		printMessage(Level.INFO,this.getMarker(),formatLogging(var),null);
	}
	
	public void printWarn(String var, boolean unicode) {
		if (unicode == true) {
			var = getHexData(var);
		}
		//this.logger.warn(formatLogging(var));
		printMessage(Level.INFO,this.getMarker(),formatLogging(var),null);
	}


	// message print at ERROR Level - 5 printError

	public void printError(String var) {
		//logger.error(formatLogging(var));
		printMessage(Level.INFO,this.getMarker(),formatLogging(var),null);
	}
	
	public void printError(String var, boolean unicode) {
		if (unicode == true) {
			var = getHexData(var);
		}
		//this.logger.error(formatLogging(var));
		printMessage(Level.INFO,this.getMarker(),formatLogging(var),null);
	}


	// Printing the ErrorMessage from Exception
	public void printErrorMessage(Throwable err) {
	//	println("#:::ERROR TRACE:::" + err);
		//logger.error("#:::ERROR TRACE:::" + err,err); // Modified for Sonar Fix
		printMessage(Level.ERROR,this.getMarker(),formatLogging("#:::ERROR TRACE::: "+err.getMessage()),err);
	//	err.printStackTrace();
	}

    public void printMessage(final Level level, final Marker maker, final String message,Throwable err) {
        logger.logIfEnabled(FQCN, level, maker, message, err);
        
    }
    
    
	private static String getHexData(String str) {
		
		return LoggerDataProvider.getHexData(str);
	}

	private String formatLogging(String msg ) {

		StringBuilder buffer = new StringBuilder();
		buffer.append("#");
		//buffer.append(trackingId).append("#");
		buffer.append((trackingId == null || trackingId == "") ? "-" : trackingId).append("#");
		buffer.append((componentName == null || componentName == "") ? "-" : componentName).append("#");
		//buffer.append((className == null || className == "") ? "-" : className).append("#");
		//buffer.append((methodName == null || methodName == "") ? "-" : methodName).append("#");
		//buffer.append(getAdditionalDetails()).append("#");
		buffer.append(getThreadID()).append("#");
		buffer.append(getCloneID()).append("#");
		//buffer.append(getCloneID()).append("#");
		buffer.append(msg);
		
		return buffer.toString();
	}

	/*
	 * private String getAdditionalDetails() { StringBuilder buffer = new
	 * StringBuilder(); buffer.append( (userID == null || userID == "") ? "-" :
	 * userID ).append("#"); buffer.append( (userBranch == null || userBranch == "")
	 * ? "-" : userBranch ).append("#"); buffer.append( (userIPAddress == null ||
	 * userIPAddress == "") ? "-" : userIPAddress ).append("#");
	 * //buffer.append(companyID).append("#");
	 * buffer.append(getThreadID()).append("#");
	 * buffer.append(getCloneID()).append("#"); return buffer.toString(); }
	 */

	public void printReqResLog(long startTime, long endTime, String uniqueID ) {
	
		StringBuilder buffer = new StringBuilder();
		buffer.append(appID + ((endTime==0)?"REQUEST#":"RESPONSE#") + "#" + nativeSystem + "#" + 
				messageID + "#" + serviceID + "#" + ((endTime==0)?"I#":"O#"+(endTime - startTime)));
		printMessage(Level.INFO,TRANSACTION,formatLogging(buffer.toString()),null);
		//logger.info(formatLogging(buffer.toString()));
	}
	
	public void printReqResLog(long startTime, long endTime ) {
		printReqResLog(startTime, endTime, trackingId );
	}
	private String getThreadID(){
		//java.util.logging.LogRecord record = new java.util.logging.LogRecord(java.util.logging.Level.FINE, "SCB");
		return LoggerDataProvider.getThreadID();
	}
	

	private String getCloneID(){
		String cloneID = "CLONE_01";

		try{
			cloneID = System.getProperty("ServerName");

		}catch(Exception e){
			logger.info("SCBLogger :: Exception While reading the Clone ID"); // Modified for Sonar Fix
		}
		return cloneID;
	}
	
}
