package com.scb.clm.common.model.codesetup;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

/*
 * 
 *  @author      1663398
 *  @version     1.0
 *  @since       
 *  @use         
 */

@Entity
@Table(name = "CLM_JOBS")
public class JobsEntity implements Cloneable
{
    @EmbeddedId
    private JobsEntityKey id;

    @Column(name = "JOB_TYPE")
    private String jobType;

    @Column(name = "DESCRIPTION")
    private String description;

    @OneToMany(fetch=FetchType.EAGER,mappedBy="jobsMapper")
    @Cascade({CascadeType.ALL})
    private Set<JobScheduleEntity> jobScheduleEntity  =     new     HashSet<>();


    public JobsEntity() {
    }

    public JobsEntityKey getId() {
        return id;
    }

    public void setId(JobsEntityKey id) {
        this.id = id;
    }

    public String getJobType() {
        return jobType;
    }

    public void setJobType(String jobType) {
        this.jobType = jobType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Set<JobScheduleEntity> getJobScheduleEntity() {
        return jobScheduleEntity;
    }

    public void setJobScheduleEntity(Set<JobScheduleEntity> jobScheduleEntity) {
        this.jobScheduleEntity = jobScheduleEntity;
    }


}
