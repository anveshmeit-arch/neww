package com.scb.clm.common.model.transactions;

import java.util.ArrayList;
import java.util.HashMap;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.scb.clm.common.exception.ErrorObject;

public class ErrorResponse {

    @JsonProperty("error")
    private ArrayList<ErrorResponseDetails> errorResponseDetails;

    public ArrayList<ErrorResponseDetails> getErrorResponseDetails() {
        return errorResponseDetails;
    }

    public void setErrorResponseDetails(ArrayList<ErrorResponseDetails> errorResponseDetails) {
        this.errorResponseDetails = errorResponseDetails;
    }

    public void addErrors(ArrayList<ErrorObject> errorObject) {
        HashMap<String,String> duplicateCheck = new HashMap<String,String> ();

        if(this.errorResponseDetails == null) {
            this.errorResponseDetails = new ArrayList<ErrorResponseDetails>();     
        }
        for(ErrorObject obj : errorObject) {
            if(duplicateCheck.get(obj.getCode()+obj.getDescription()) == null) {
                this.errorResponseDetails.add(new ErrorResponseDetails(obj.getCode(),obj.getDescription()+""));
                duplicateCheck.put(obj.getCode()+obj.getDescription(), "-");
            } else {
                System.out.println("Duplicate Error Codes Found");
            }
        }
    }
}
