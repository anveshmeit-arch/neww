package com.scb.clm.common.util;

import java.util.Map;

import com.scb.clm.common.config.BaseConstants;

public class ServiceContext 
{

	/* CONTROLLER FIELDS */
	private String apiVersion;
	private String pathIdentifier;

	private String flowIdentifier;

	/* HEADER FIELDS */
	private String countryCode;
	private String interfaceId;
	private String transactionID;
	private String originalTransactionIDforRetryRequest;
	private String applicationReferenceNumber;
	private String duplicateFlag;
	private String requestType;

	private Map<String,String> requestHeaders = null;
	private String serviceType = null;
	private String processID = null;
	private String processName = null;

	private String httpMethod;

	public ServiceContext() {
		
	}
	 
	public String getApiVersion() {
		return apiVersion;
	}
	 
	public void setApiVersion(String apiVersion) {
		this.apiVersion = apiVersion;
	}
	 
	public String getPathIdentifier() {
		return pathIdentifier;
	}
	 
	public void setPathIdentifier(String pathIdentifier) {
		this.pathIdentifier = pathIdentifier;
	}
	 
	public String getFlowIdentifier() {
		return flowIdentifier;
	}
	 
	public void setFlowIdentifier(String flowIdentifier) {
		this.flowIdentifier = flowIdentifier;
	}
	 
	public String getCountryCode() {
		return countryCode;
	}
	 
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	 
	public String getInterfaceId() {
		return interfaceId;
	}
	 
	public void setInterfaceId(String interfaceId) {
		this.interfaceId = interfaceId;
	}
	 
	public String getTransactionID() {
		return transactionID;
	}
	 
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	 
	public String getOriginalTransactionIDforRetryRequest() {
		return originalTransactionIDforRetryRequest;
	}
	 
	public void setOriginalTransactionIDforRetryRequest(String originalTransactionIDforRetryRequest) {
		this.originalTransactionIDforRetryRequest = originalTransactionIDforRetryRequest;
	}
	 
	public String getApplicationReferenceNumber() {
		return applicationReferenceNumber;
	}
	 
	public void setApplicationReferenceNumber(String applicationReferenceNumber) {
		this.applicationReferenceNumber = applicationReferenceNumber;
	}
 
	public String getDuplicateFlag() {
		return duplicateFlag;
	}
	 
	public void setDuplicateFlag(String duplicateFlag) {
		this.duplicateFlag = duplicateFlag;
	}
	 
	public String getRequestType() {
		return requestType;
	}
	 
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	 
	public Map<String, String> getRequestHeaders() {
		return requestHeaders;
	}
	 
	public void setRequestHeaders(Map<String, String> requestHeaders) {
		this.requestHeaders = requestHeaders;
	}
	 
	public String getServiceType() {
		return serviceType;
	}
	 
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	 
	public String getProcessID() {
		return processID;
	}
	 
	public void setProcessID(String processID) {
		this.processID = processID;
	}
	 
	public String getProcessName() {
		return processName;
	}
	 
	public void setProcessName(String processName) {
		this.processName = processName;
	}
	
	 
	public String getHttpMethod() {
		return httpMethod;
	}

	 
	public void setHttpMethod(String httpMethod) {
		this.httpMethod = httpMethod;
	}

	public String getRequestHeaderValue(String headerKey) {
		return (getRequestHeaders().get(headerKey)==null?"":getRequestHeaders().get(headerKey).trim());
	}

	public String getCountryCodeWithRegion() {
        return this.getCountryCode()+getRequestHeaderValue(BaseConstants.REQUEST_REGION);
	}

	public boolean isRegionAvailable() {
		return (getRequestHeaderValue(BaseConstants.REQUEST_REGION).trim().length()==0)?false:true;
	}

	public String getRegion() {
		return (getRequestHeaderValue(BaseConstants.REQUEST_REGION));
	}	
}
