package com.scb.clm.common.util;

public interface SystemUtilityConstants {
	public static final String ENTRY_TYPE = "ENTRY_TYPE";
	public static final String REQUEST_TYPE = "REQUEST_TYPE";
	public static final String INTERFACEID = "INTERFACEID";
	public static final String SERVICECONTEXT = "SERVICECONTEXT";
	public static final String TRCKINGID ="TRCKINGID";	
	public static final String POSSIBLE_DUPLICATE = "POSSIBLE_DUPLICATE";
	public static final String ORIGINAL_TRACKING_ID = "ORIGINAL_TRACKING_ID";
	public static final String ERR_TYPE = "ERR";
	public static final String ERR_CODE = "1000";
	public static final String PROVIDER_SERVICE_TYPE="P";
	public static final String ERR_MSG = "SERVICE_TEMPORARILY_NOT_AVAILABLE";
	public static final String COMPANYID = "COMPANYID";
	public static final String ALL_SUCESS = "0000";
	public static final String DATABASE_TYPE = "DATABASE_TYPE";
	public static final String SERVER_STOP_START_LOG = "SERVER_STOP_START_LOG";
	public static final String PROCESSS_ID= "PROCESSS_ID";
	public static final String PROCESS_NAME= "PROCESS_NAME";
	public static final String DD_MM_YYYY_DATE_FORMAT= "dd-MM-yyyy";
	public static final String SYSTEM_PROCESS_ID = "SYSTEM_PROCESS";
	public static final String CRYPTO_CONFIG = "CryptoConfig.ser"; //Crypto config file. Added as part of SonarFix
	

	
	//Added for Jboss migration
	public static final String DATA_SOURCE_NAME = "DATA_SOURCE_NAME";
	public static final String DB_USER_ID = "DB_USER_ID";
	public static final String DB_DS_URL ="DB_DS_URL";
	public static final String SUCCESS = "successful";
	public static final String FAILED = "Failed";

    public static final String SYSTEM_SETUP_CACHE = "SYSTEM_SETUP";
    
    //Postgres
    public static final String DATABASE_TYPE_POSTGRESQL = "P";
    
    
    
}
