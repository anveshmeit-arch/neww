package com.scb.clm.common.model.codesetup;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

/*
 * 
 *  @author      1378958
 *  @version     1.0
 *  @since          
 *  @use         
 */
@Entity
@Table(name = "CLM_PATH_IDENTIFIERS")
public class PathIdentifierEntity {

    @EmbeddedId
    private PathIdentifierEntityKey id;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "FLOW_DECIDER_PROGRAM")
    private String flowDeciderProgram;

    @Column(name = "STATUS_FLAG")
    private String statusFlag;

    @OneToMany(fetch=FetchType.EAGER,mappedBy="pathIdentifierMapper")
    @Cascade({CascadeType.ALL})
    private Set<PathFlowsEntity> pathFlowDetail  =     new     HashSet<>();

    public PathIdentifierEntityKey getId() {
        return id;
    }

    public void setId(PathIdentifierEntityKey id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFlowDeciderProgram() {
        return flowDeciderProgram;
    }

    public void setFlowDeciderProgram(String flowDeciderProgram) {
        this.flowDeciderProgram = flowDeciderProgram;
    }

    public String getStatusFlag() {
        return statusFlag;
    }

    public void setStatusFlag(String statusFlag) {
        this.statusFlag = statusFlag;
    }

    public Set<PathFlowsEntity> getPathFlows() {
        return pathFlowDetail.stream().collect(Collectors.toSet());
    }
}
