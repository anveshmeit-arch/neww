package com.scb.clm.common.model.transactions;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

/*
 * 
 * @author       1378958
 * @version      1.0
 * @since           
 * @use          
 */
@Embeddable
public class InboundRequestsStatisticsEntityKey implements Serializable,Cloneable
{

    private static final long serialVersionUID = -420708246880333064L;

    @Column(name = "REQUEST_ID", nullable = false ,insertable=false, updatable=false)
    private String requestId;

    @Column(name = "FLOW_ID", nullable = false ,insertable=false, updatable=false)
    private String flowIdentifier;

    @Column(name = "NODE_ID", nullable = false ,insertable=false, updatable=false)
    private String nodeIdentifier;

    @Column(name = "NODE_SEQUENCE", nullable = false ,insertable=false, updatable=false)
    private String nodeSequenceId;

    @Column(name = "SERVICE_ID", nullable = false ,insertable=false, updatable=false)
    private String serviceIdentifier;

    
    public InboundRequestsStatisticsEntityKey() {

    }

    public InboundRequestsStatisticsEntityKey (String requestId,String flowIdentifier,String nodeIdentifier,String nodeSequenceId,String serviceIdentifier) {
        this.requestId         =     requestId;
        this.flowIdentifier    =     flowIdentifier;
        this.nodeIdentifier    =     nodeIdentifier;
        this.nodeSequenceId    =     nodeSequenceId;
        this.serviceIdentifier =     serviceIdentifier;
    }

  

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getFlowIdentifier() {
        return flowIdentifier;
    }

    public void setFlowIdentifier(String flowIdentifier) {
        this.flowIdentifier = flowIdentifier;
    }

    public String getNodeIdentifier() {
        return nodeIdentifier;
    }

    public void setNodeIdentifier(String nodeIdentifier) {
        this.nodeIdentifier = nodeIdentifier;
    }

    public String getNodeSequenceId() {
        return nodeSequenceId;
    }

    public void setNodeSequenceId(String nodeSequenceId) {
        this.nodeSequenceId = nodeSequenceId;
    }

    public String getServiceIdentifier() {
        return serviceIdentifier;
    }

    public void setServiceIdentifier(String serviceIdentifier) {
        this.serviceIdentifier = serviceIdentifier;
    }

    @Override
    public int hashCode() {
        StringBuilder finalHashCode = new StringBuilder();
        if (this.requestId != null && this.flowIdentifier != null && this.nodeIdentifier != null && this.nodeSequenceId != null && this.serviceIdentifier != null)
        {
            finalHashCode.append(requestId);
            finalHashCode.append(flowIdentifier);
            finalHashCode.append(nodeIdentifier);
            finalHashCode.append(nodeSequenceId);
            finalHashCode.append(serviceIdentifier);
        }
        return finalHashCode.toString().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
        {
            return true;
        }
        if ((obj == null) || (obj.getClass() != this.getClass())) 
        {
            return false;
        }
        InboundRequestsStatisticsEntityKey other = (InboundRequestsStatisticsEntityKey) obj;
        return   Objects.equals(this.requestId, other.requestId) 
                 && Objects.equals(this.flowIdentifier, other.flowIdentifier)
                 && Objects.equals(this.nodeIdentifier, other.nodeIdentifier)
                 && Objects.equals(this.nodeSequenceId, other.nodeSequenceId)
                 && Objects.equals(this.serviceIdentifier, other.serviceIdentifier);
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return (InboundRequestsStatisticsEntityKey) super.clone();
    }
}
