package com.scb.clm.common.model.transactions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ErrorObject;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.model.codesetup.NodeServicesEntityKey;
import com.scb.clm.common.util.ServiceContext;

public class TravellingObject
{


    HashMap<String, List<String>> filterMap = new HashMap<String, List<String>>();
    private Map<String,String> parameterOperatorList = new HashMap<String,String>();
    String[] strIncludes;
	boolean isLikeFound;

    //Request Data / Request Objects
    private Object requestData;
    private Object responseData;

    //Logger Fields
    private String inBoundLogSequenceNumber;

    //Service Data
    private Map<String,ServiceStatus> serviceStatus    =   new HashMap<String,ServiceStatus>();

    //Error Details
    private List<ErrorObject> errorDetails;

    private ServiceContext serviceContext;
    
    public TravellingObject(){
    	this.setServiceContext(new ServiceContext());
    }
    public ServiceStatus getServiceStatus(NodeServicesEntityKey nodesServiceEntityKey)
    {
        System.out.println("Searching Key "+nodesServiceEntityKey.getFlowIdentifier()+"-"+nodesServiceEntityKey.getNodeIdentifier()+"-"+nodesServiceEntityKey.getServiceIdentifier()+" in Travelling Object");

        if(this.serviceStatus == null) {
            return new ServiceStatus(nodesServiceEntityKey.getFlowIdentifier(),nodesServiceEntityKey.getNodeIdentifier(), nodesServiceEntityKey.getServiceIdentifier());
        } else  {
            return this.serviceStatus.get(nodesServiceEntityKey.getFlowIdentifier()+"-"+nodesServiceEntityKey.getNodeIdentifier()+"-"+nodesServiceEntityKey.getServiceIdentifier());
        }
    }

    public void addServiceStatus(ServiceStatus serviceStatus) throws ProcessException
    {
        if(this.serviceStatus == null) {
            this.serviceStatus = new HashMap<String,ServiceStatus>();
        }  
        if(serviceStatus.getFlowIdentifier() == null || serviceStatus.getNodeIdentifier() == null || serviceStatus.getServiceIdentifier() == null ) {
        	throw new ProcessException(BaseConstants.ERROR_TYPE_BUSINESS, BaseConstants.INVALID_APPLICATION_REFERENCE_NUMBER,"KEY FIELDS ARE EMPTY");
        }

        this.serviceStatus.put(serviceStatus.getFlowIdentifier()+"-"+serviceStatus.getNodeIdentifier()+"-"+serviceStatus.getServiceIdentifier() , serviceStatus);

        System.out.println("[Adding Service Errors to Travelling Object]");
        addErrors(serviceStatus.getErrorObject());

    }

    public String getApiVersion() {
        return getServiceContext().getApiVersion();
    }

    public void setApiVersion(String apiVersion) {
        this.getServiceContext().setApiVersion(apiVersion); 
    }

    public String getPathIdentifier() {
        return getServiceContext().getPathIdentifier();
    }

    public void setPathIdentifier(String pathIdentifier) {
        this.getServiceContext().setPathIdentifier(pathIdentifier);
    }

    public String getFlowIdentifier() {
        return getServiceContext().getFlowIdentifier();
    }

    public void setFlowIdentifier(String flowIdentifier) {
        this.getServiceContext().setFlowIdentifier(flowIdentifier);
    }

    public String getCountryCode() {
        return getServiceContext().getCountryCode();
    }

    public void setCountryCode(String countryCode) {
        this.getServiceContext().setCountryCode(countryCode);
    }

    public String getInterfaceId() {
        return getServiceContext().getInterfaceId();
    }

    public void setInterfaceId(String interfaceId) {
        this.getServiceContext().setInterfaceId(interfaceId);
    }

    public String getTransactionID() {
        return getServiceContext().getTransactionID();
    }

    public void setTransactionID(String transactionID) {
        this.getServiceContext().setTransactionID(transactionID);
    }

    public String getOriginalTransactionIDforRetryRequest() {
        return getServiceContext().getOriginalTransactionIDforRetryRequest();
    }

    public void setOriginalTransactionIDforRetryRequest(String originalTransactionIDforRetryRequest) {
        this.getServiceContext().setOriginalTransactionIDforRetryRequest(originalTransactionIDforRetryRequest);
    }

    public String getApplicationReferenceNumber() {
        return getServiceContext().getApplicationReferenceNumber();
    }

    public void setApplicationReferenceNumber(String applicationReferenceNumber) {
        this.getServiceContext().setApplicationReferenceNumber(applicationReferenceNumber);
    }

    public String getDuplicateFlag() {
        return getServiceContext().getDuplicateFlag();
    }

    public void setDuplicateFlag(String duplicateFlag) {
        this.getServiceContext().setDuplicateFlag(duplicateFlag);
    }

    public String getRequestType() {
        return getServiceContext().getRequestType();
    }

    public void setRequestType(String requestType) {
        this.getServiceContext().setRequestType(requestType);
    }

    public Map<String, String> getRequestHeaders() {
        return getServiceContext().getRequestHeaders();
    }

    public void setRequestHeaders(Map<String, String> requestHeaders) {
        this.getServiceContext().setRequestHeaders(requestHeaders);
    }
    public HashMap<String, List<String>> getFilterMap() {
		return filterMap;
	}

	public void setFilterMap(HashMap<String, List<String>> filterMap) {
		this.filterMap = filterMap;
	}

	public Map<String, String> getParameterOperatorList() {
		return parameterOperatorList;
	}

	public void setParameterOperatorList(Map<String, String> parameterOperatorList) {
		this.parameterOperatorList = parameterOperatorList;
	}

	public String[] getStrIncludes() {
		return strIncludes;
	}

	public void setStrIncludes(String[] strIncludes) {
		this.strIncludes = strIncludes;
	}

	public boolean getIsLikeFound() {
		return isLikeFound;
	}

	public void setIsLikeFound(boolean isLikeFound) {
		this.isLikeFound = isLikeFound;
	}

    public Object getRequestData() {
        return requestData;
    }

    public void setRequestData(Object requestData) {
        this.requestData = requestData;
    }

    public Object getResponseData() {
        return responseData;
    }

    public void setResponseData(Object responseData) {
        this.responseData = responseData;
    }

    public String getInBoundLogSequenceNumber() {
        return inBoundLogSequenceNumber;
    }

    public void setInBoundLogSequenceNumber(String inBoundLogSequenceNumber) {
        this.inBoundLogSequenceNumber = inBoundLogSequenceNumber;
    }

    public Map<String, ServiceStatus> getServiceStatus() {
        return serviceStatus;
    }

    public void setServiceStatus(Map<String, ServiceStatus> serviceStatus) {
        this.serviceStatus = serviceStatus;
    }

    public List<ErrorObject> getErrorDetails() {
        return errorDetails;
    }

    public void setErrorDetails(List<ErrorObject> errorDetails) {
        this.errorDetails = errorDetails;
    }

    public void addErrors(List<ErrorObject> errList) {
        if(this.errorDetails == null) {
            this.errorDetails= new ArrayList<ErrorObject>();     
        }
        this.errorDetails.addAll(errList);
    }

    public void addErrors(ErrorObject errObject) {
        if(this.errorDetails == null) {
            this.errorDetails= new ArrayList<ErrorObject>();     
        }
        this.errorDetails.add(errObject);
    }

    public String getServiceProcessParameter(String serviceId, String paramKey) {
    	String paramValue = "";  
    	if(getServiceStatus().get(serviceId)!=null &&
    			getServiceStatus().get(serviceId).getServiceParams()!=null &&
    			getServiceStatus().get(serviceId).getServiceParams().get(paramKey) != null
    	  )
    	{
    		paramValue = getServiceStatus().get(serviceId).getServiceParams().get(paramKey);
    	}
    	
    	return paramValue;
    }
	/**
	 * @return the serviceContext
	 */
	public ServiceContext getServiceContext() {
		return serviceContext;
	}
	/**
	 * @param serviceContext the serviceContext to set
	 */
	public void setServiceContext(ServiceContext serviceContext) {
		this.serviceContext = serviceContext;
	}

	public String getRegion() {
		return getServiceContext().getRegion();
	}

}
