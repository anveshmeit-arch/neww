package com.scb.clm.common.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.scb.clm.common.model.transactions.RetryBasketEntity;

@Repository
public interface RetryBasketRepository extends JpaRepository<RetryBasketEntity, String> { 

    @Modifying
    @Query(value = "INSERT INTO CLM_RETRY_BASKET(COUNTRY_CODE,RETRY_ID,PROCESS_DATE,JOB_ID,MESSAGE,RETRY_COUNT,LATEST_PROCESS_TIME,STATUS) "
                 + "                    VALUES  (:#{#retry.id.countryCode}, :#{#retry.id.retryID}, :#{#retry.processDate}, :#{#retry.jobID}, :#{#retry.message}, :#{#retry.retryCount}, :#{#retry.latestProcessTime}, :#{#retry.status} )", 
      nativeQuery = true)
    void insertToBasket(@Param("retry") RetryBasketEntity retry);

    @Override
    public <S extends RetryBasketEntity> S save(S entity);

    @Override
    public RetryBasketEntity getOne(String arg0);

    public List<RetryBasketEntity> findAll();

}