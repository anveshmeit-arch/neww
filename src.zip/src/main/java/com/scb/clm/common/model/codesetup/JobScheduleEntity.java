package com.scb.clm.common.model.codesetup;

import java.sql.Timestamp;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

/*
 * 
 *  @author      1663398
 *  @version     1.0
 *  @since       
 *  @use         
 */

@Entity
@Table(name = "CLM_JOB_SCHEDULES")
public class JobScheduleEntity implements Cloneable {

    @EmbeddedId
    private JobScheduleEntityKey id;

    @Column(name = "SPECIAL_PROGRAM")
    private String retryServiceProgram;

    @Column(name = "CRON_EXPRESSION")
    private String cronExpression;

    @ManyToOne
    @JoinColumns({
        @JoinColumn(name = "COUNTRY_CODE", referencedColumnName = "COUNTRY_CODE", insertable = false, updatable = false),
        @JoinColumn(name = "JOB_ID", referencedColumnName = "JOB_ID", insertable = false, updatable = false) })
    private JobsEntity jobsMapper;

    @Column(name = "LOCKED")
    private boolean locked = false;

    @Column(name="LAST_EXECUTED_TIME")
    private Timestamp lastExecuted;

    @Column(name="PATH_IDENTIFIER")
    private String pathIdentifier;
    
    @Column(name="API_VERSION")
    private String apiVersion;
    
    @Column(name="STATUS_FLAG")
    private String statusFlag;

    @Transient
    private String jobSequenceId;
    
    public JobScheduleEntity() {

    }

    public JobScheduleEntityKey getId() {
        return id;
    }

    public void setId(JobScheduleEntityKey id) {
        this.id = id;
    }

    public String getCronExpression() {
        return cronExpression;
    }

    public void setCronExpression(String cronExpression) {
        this.cronExpression = cronExpression;
    }

    public boolean isLocked() {
        return locked;
    }

    public void setLocked(boolean locked) {
        this.locked = locked;
    }

    public String getRetryServiceProgram() {
        return retryServiceProgram;
    }

    public void setRetryServiceProgram(String retryServiceProgram) {
        this.retryServiceProgram = retryServiceProgram;
    }

    public Timestamp getLastExecuted() {
        return lastExecuted;
    }

    public void setLastExecuted(Timestamp lastExecuted) {
        this.lastExecuted = lastExecuted;
    }

    public String getPathIdentifier() {
        return pathIdentifier;
    }

    public void setPathIdentifier(String pathIdentifier) {
        this.pathIdentifier = pathIdentifier;
    }

    public String getApiVersion() {
        return apiVersion;
    }

    public void setApiVersion(String apiVersion) {
        this.apiVersion = apiVersion;
    }

    public String getStatusFlag() {
        return statusFlag;
    }

    public void setStatusFlag(String statusFlag) {
        this.statusFlag = statusFlag;
    }

    public String getJobSequenceId() {
        return jobSequenceId;
    }

    public void setJobSequenceId(String jobSequenceId) {
        this.jobSequenceId = jobSequenceId;
    }

 

}
