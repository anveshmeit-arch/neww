package com.scb.clm.common.framework.logger;

import java.io.File;

import com.scb.clm.common.config.ApplicationConfiguration;
import com.scb.clm.common.config.BaseConstants;
import com.scb.clm.common.exception.ProcessException;
import com.scb.clm.common.util.ServiceContext;
import com.scb.clm.common.util.ServiceContextCache;

public class LoggerDataProvider {

	public static String getCompanyID() {
		if(getServiceContext()!=null) {
		return getServiceContext().getCountryCode();
		}else {
			return getApplicationConfiguration().getDefCompanyID();
		}
	}

	public static String getApplicationID() {
		return getApplicationConfiguration().getAllCountriesProperties("GBL").get("appid");
	}

	public static String getInterfaceID() {
		return getServiceContext().getInterfaceId();
	}

	public static String getRequestType() {
		return getServiceContext().getRequestType();
	}

	public static String getServiceID() {
		return getServiceContext().getServiceType();
	}

	public static String getSpecificLogPath() {
		java.util.Date today = new java.sql.Date(System.currentTimeMillis());
		return getApplicationConfiguration().getAppLogPath()+File.separatorChar+today;
	}

	public static String getCommonAppLogFile() {
		
		return getSpecificLogPath()+File.separatorChar+BaseConstants.APPLICATION_NAME+"-"+System.getProperty("serviceName")+"_"+LogType.APPLICATION.name();
	}
	
	public static String getTimeZone(String companyID) {
		return getApplicationConfiguration().getAllCountriesProperties("GBL").get("TIME_ZONE");
	}

	public static String getUUID() {
		return getServiceContext().getTransactionID();
	}

	public static String getProcess() {
		return getServiceContext().getProcessName();
	}

	public static ServiceContext getServiceContext() {
		return ServiceContextCache.getInstance().getServiceContext();
	}
	
	private static ApplicationConfiguration getApplicationConfiguration() {
		try {
			return ApplicationConfiguration.getInstance();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public static String getThreadID(){
		java.util.logging.LogRecord record = new java.util.logging.LogRecord(java.util.logging.Level.FINE, "SCB");
		return leftPad(Integer.toHexString(record.getThreadID()), 8, '0');
	}
	
	private static String leftPad(String string, int length, char prefixCharacter)
	{
		StringBuffer sb = new StringBuffer();
		if ((string != null) && (string.length() > length)) {
			return string.substring(0, length);
		}
		for (int i = (string == null) ? 0 : string.length(); i < length; ++i) {
			sb.append(prefixCharacter);
		}
		string = sb + string;
		return string;
	}
	
	public static String getHexData(String str) {
		StringBuilder stringbuffer = new StringBuilder();
		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);
			stringbuffer.append("\\u");
			stringbuffer.append(leftPad(Integer.toHexString(c), 4, '0'));
		}
		return stringbuffer.toString();
	}
}
