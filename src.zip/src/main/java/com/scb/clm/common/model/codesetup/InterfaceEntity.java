package com.scb.clm.common.model.codesetup;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

/*
 * 
 *  @author      1378958
 *  @version     1.0
 *  @since       
 *  @use         
 */
@Entity
@Table(name = "CLM_INTERFACES")
public class InterfaceEntity implements Cloneable
{
    @EmbeddedId
    private InterfaceEntityKey id;

    @Column(name="INTERFACE_NAME")
    private String interfaceName;

    @Column(name="INTERFACE_TYPE")
    private String interfaceType;

    @Column(name="STATUS_FLAG")
    private String statusFlag;

    @OneToMany(fetch=FetchType.EAGER,mappedBy="interfaceMapper")
    @Cascade({CascadeType.ALL})
    private Set<InterfaceRequestTypeEntity> interfaceRequestTypeEntity  =     new     HashSet<>();

    public InterfaceEntity() {

    }

    public InterfaceEntityKey getId() {
        return id;
    }

    public String getInterfaceName() {
        return interfaceName;
    }

    public String getInterfaceType() {
        return interfaceType;
    }

    public String getStatusFlag() {
        return statusFlag;
    }

    public void setId(InterfaceEntityKey id) {
        this.id = id;
    }

    public void setInterfaceName(String interfaceName) {
        this.interfaceName = interfaceName;
    }

    public void setInterfaceType(String interfaceType) {
        this.interfaceType = interfaceType;
    }

    public void setStatusFlag(String statusFlag) {
        this.statusFlag = statusFlag;
    }

    public Set<InterfaceRequestTypeEntity> getInterfaceRequestTypeEntity() {
        return interfaceRequestTypeEntity;
    }

    public void setInterfaceRequestTypeEntity(Set<InterfaceRequestTypeEntity> interfaceRequestTypeEntity) {
        this.interfaceRequestTypeEntity = interfaceRequestTypeEntity;
    }

}
