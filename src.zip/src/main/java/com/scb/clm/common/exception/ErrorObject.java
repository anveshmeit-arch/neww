package com.scb.clm.common.exception;

import java.io.Serializable;

/*
 * 
 * @author       
 * @version     1.0
 * @since        
 * @use         Intended to carry the Error Object
 */
public class ErrorObject implements Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = -8276168160578116159L;
    private String type;
    private String code;
    private Object description;
    private String fieldName;

    public void setType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setCode(String code) 
    {
        this.code = code;
    }
    public String getCode() 
    {
        return code;
    }

    public void setDescription(Object description) 
    {
        this.description = description;
    }
    public Object getDescription() 
    {
        return description;
    }

    public void setFieldName(String fieldName) 
    {
        this.fieldName = fieldName;
    }
    public String getFieldName() 
    {
        return fieldName;
    }

    public ErrorObject(String argType, String argCode, String argDescription) 
    {
        this.type = argType;
        this.code = argCode;
        this.description = argDescription;
    }

    public ErrorObject(String argType, String argCode, String argDescription,String fieldName) 
    {
        this.type = argType;
        this.code = argCode;
        this.description = argDescription;
        this.fieldName = fieldName;
    }

    @Override
    public int hashCode() 
    {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((code == null) ? 0 : code.hashCode());
        result = prime * result
                + ((fieldName == null) ? 0 : fieldName.hashCode());
        result = prime * result + ((type == null) ? 0 : type.hashCode());

        return result;
    }

    @Override
    public boolean equals(Object obj) 
    {
        if (this == obj) {
            return true;
        }

        if (obj == null){
            return false;
        }

        if (getClass() != obj.getClass()){
            return false;
        }

        ErrorObject other = (ErrorObject) obj;

        if (code == null) {
            if (other.code != null) {
                return false;
            }
        } else if (!code.equals(other.code)) {
            return false;
        }

        if (fieldName == null) {
            if (other.fieldName != null){
                return false;
            }
        } else if (!fieldName.equals(other.fieldName)){
            return false;
        }

        if (type == null) {
            if (other.type != null){
                return false;
            }
        } else if (!type.equals(other.type)){
            return false;
        }

        return true;
    }
}